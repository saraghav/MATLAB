/* Include files */

#include "blascompat32.h"
#include "DCDCconverter_sfun.h"
#include "c5_DCDCconverter.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "DCDCconverter_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)
#define c5_IN_NO_ACTIVE_CHILD          ((uint8_T)0U)
#define c5_IN_AutomaticControlMode     ((uint8_T)1U)
#define c5_IN_ChargingRail             ((uint8_T)2U)
#define c5_IN_DischargingRail          ((uint8_T)3U)
#define c5_IN_FinishedCharging         ((uint8_T)4U)
#define c5_IN_ManualBoostMode          ((uint8_T)5U)
#define c5_IN_ManualBuckMode           ((uint8_T)6U)
#define c5_IN_Off                      ((uint8_T)7U)

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
static void initialize_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct
  *chartInstance);
static void initialize_params_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct *
  chartInstance);
static void enable_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct
  *chartInstance);
static void disable_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct
  *chartInstance);
static void c5_update_debugger_state_c5_DCDCconverter
  (SFc5_DCDCconverterInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c5_DCDCconverter
  (SFc5_DCDCconverterInstanceStruct *chartInstance);
static void set_sim_state_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_st);
static void c5_set_sim_state_side_effects_c5_DCDCconverter
  (SFc5_DCDCconverterInstanceStruct *chartInstance);
static void finalize_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct
  *chartInstance);
static void sf_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct *chartInstance);
static void c5_chartstep_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct
  *chartInstance);
static void initSimStructsc5_DCDCconverter(SFc5_DCDCconverterInstanceStruct
  *chartInstance);
static void c5_enter_atomic_Off(SFc5_DCDCconverterInstanceStruct *chartInstance);
static void c5_DischargingRail(SFc5_DCDCconverterInstanceStruct *chartInstance);
static void c5_ChargingRail(SFc5_DCDCconverterInstanceStruct *chartInstance);
static void c5_FinishedCharging(SFc5_DCDCconverterInstanceStruct *chartInstance);
static void c5_AutomaticControlMode(SFc5_DCDCconverterInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c5_machineNumber, uint32_T
  c5_chartNumber);
static const mxArray *c5_sf_marshallOut(void *chartInstanceVoid, void *c5_inData);
static int32_T c5_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_u, const emlrtMsgIdentifier *c5_parentId);
static void c5_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c5_mxArrayInData, const char_T *c5_varName, void *c5_outData);
static const mxArray *c5_b_sf_marshallOut(void *chartInstanceVoid, void
  *c5_inData);
static uint8_T c5_b_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_b_tp_Off, const char_T *c5_identifier);
static uint8_T c5_c_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_u, const emlrtMsgIdentifier *c5_parentId);
static void c5_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c5_mxArrayInData, const char_T *c5_varName, void *c5_outData);
static const mxArray *c5_c_sf_marshallOut(void *chartInstanceVoid, void
  *c5_inData);
static const mxArray *c5_d_sf_marshallOut(void *chartInstanceVoid, void
  *c5_inData);
static real_T c5_d_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_IGBT_Top_State, const char_T *c5_identifier);
static real_T c5_e_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_u, const emlrtMsgIdentifier *c5_parentId);
static void c5_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c5_mxArrayInData, const char_T *c5_varName, void *c5_outData);
static boolean_T c5_f_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_AutomaticController, const char_T
  *c5_identifier);
static boolean_T c5_g_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_u, const emlrtMsgIdentifier *c5_parentId);
static void c5_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c5_mxArrayInData, const char_T *c5_varName, void *c5_outData);
static const mxArray *c5_h_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_b_setSimStateSideEffectsInfo, const char_T
  *c5_identifier);
static const mxArray *c5_i_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_u, const emlrtMsgIdentifier *c5_parentId);
static void init_dsm_address_info(SFc5_DCDCconverterInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct
  *chartInstance)
{
  real_T *c5_IGBT_Top_State;
  real_T *c5_IGBT_Bot_State;
  boolean_T *c5_AutomaticController;
  real_T *c5_UltracapacitorRelay;
  real_T *c5_ChargingRelay;
  real_T *c5_DischargingRelay;
  real_T *c5_BatteryRelay;
  c5_BatteryRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
  c5_DischargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c5_ChargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c5_UltracapacitorRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c5_AutomaticController = (boolean_T *)ssGetOutputPortSignal(chartInstance->S,
    3);
  c5_IGBT_Bot_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c5_IGBT_Top_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c5_sfEvent = CALL_EVENT;
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c5_doSetSimStateSideEffects = 0U;
  chartInstance->c5_setSimStateSideEffectsInfo = NULL;
  chartInstance->c5_tp_AutomaticControlMode = 0U;
  chartInstance->c5_tp_ChargingRail = 0U;
  chartInstance->c5_tp_DischargingRail = 0U;
  chartInstance->c5_tp_FinishedCharging = 0U;
  chartInstance->c5_tp_ManualBoostMode = 0U;
  chartInstance->c5_tp_ManualBuckMode = 0U;
  chartInstance->c5_tp_Off = 0U;
  chartInstance->c5_is_active_c5_DCDCconverter = 0U;
  chartInstance->c5_is_c5_DCDCconverter = c5_IN_NO_ACTIVE_CHILD;
  chartInstance->c5_dVrail_dT_threshold = 0.0;
  if (!(cdrGetOutputPortReusable(chartInstance->S, 1) != 0)) {
    *c5_IGBT_Top_State = 0.0;
  }

  if (!(cdrGetOutputPortReusable(chartInstance->S, 2) != 0)) {
    *c5_IGBT_Bot_State = 0.0;
  }

  if (!(cdrGetOutputPortReusable(chartInstance->S, 3) != 0)) {
    *c5_AutomaticController = FALSE;
  }

  if (!(cdrGetOutputPortReusable(chartInstance->S, 4) != 0)) {
    *c5_UltracapacitorRelay = 0.0;
  }

  if (!(cdrGetOutputPortReusable(chartInstance->S, 5) != 0)) {
    *c5_ChargingRelay = 0.0;
  }

  if (!(cdrGetOutputPortReusable(chartInstance->S, 6) != 0)) {
    *c5_DischargingRelay = 0.0;
  }

  if (!(cdrGetOutputPortReusable(chartInstance->S, 7) != 0)) {
    *c5_BatteryRelay = 0.0;
  }
}

static void initialize_params_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct *
  chartInstance)
{
}

static void enable_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct
  *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct
  *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c5_update_debugger_state_c5_DCDCconverter
  (SFc5_DCDCconverterInstanceStruct *chartInstance)
{
  uint32_T c5_prevAniVal;
  c5_prevAniVal = sf_debug_get_animation();
  sf_debug_set_animation(0U);
  if (chartInstance->c5_is_active_c5_DCDCconverter == 1U) {
    _SFD_CC_CALL(CHART_ACTIVE_TAG, 4U, chartInstance->c5_sfEvent);
  }

  if (chartInstance->c5_is_c5_DCDCconverter == c5_IN_Off) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 6U, chartInstance->c5_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 6U, chartInstance->c5_sfEvent);
  }

  if (chartInstance->c5_is_c5_DCDCconverter == c5_IN_DischargingRail) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 2U, chartInstance->c5_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 2U, chartInstance->c5_sfEvent);
  }

  if (chartInstance->c5_is_c5_DCDCconverter == c5_IN_ChargingRail) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 1U, chartInstance->c5_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 1U, chartInstance->c5_sfEvent);
  }

  if (chartInstance->c5_is_c5_DCDCconverter == c5_IN_FinishedCharging) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 3U, chartInstance->c5_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 3U, chartInstance->c5_sfEvent);
  }

  if (chartInstance->c5_is_c5_DCDCconverter == c5_IN_AutomaticControlMode) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 0U, chartInstance->c5_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 0U, chartInstance->c5_sfEvent);
  }

  if (chartInstance->c5_is_c5_DCDCconverter == c5_IN_ManualBuckMode) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 5U, chartInstance->c5_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 5U, chartInstance->c5_sfEvent);
  }

  if (chartInstance->c5_is_c5_DCDCconverter == c5_IN_ManualBoostMode) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 4U, chartInstance->c5_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 4U, chartInstance->c5_sfEvent);
  }

  sf_debug_set_animation(c5_prevAniVal);
  _SFD_ANIMATE();
}

static const mxArray *get_sim_state_c5_DCDCconverter
  (SFc5_DCDCconverterInstanceStruct *chartInstance)
{
  const mxArray *c5_st;
  const mxArray *c5_y = NULL;
  boolean_T c5_hoistedGlobal;
  boolean_T c5_u;
  const mxArray *c5_b_y = NULL;
  real_T c5_b_hoistedGlobal;
  real_T c5_b_u;
  const mxArray *c5_c_y = NULL;
  real_T c5_c_hoistedGlobal;
  real_T c5_c_u;
  const mxArray *c5_d_y = NULL;
  real_T c5_d_hoistedGlobal;
  real_T c5_d_u;
  const mxArray *c5_e_y = NULL;
  real_T c5_e_hoistedGlobal;
  real_T c5_e_u;
  const mxArray *c5_f_y = NULL;
  real_T c5_f_hoistedGlobal;
  real_T c5_f_u;
  const mxArray *c5_g_y = NULL;
  real_T c5_g_hoistedGlobal;
  real_T c5_g_u;
  const mxArray *c5_h_y = NULL;
  real_T c5_h_hoistedGlobal;
  real_T c5_h_u;
  const mxArray *c5_i_y = NULL;
  uint8_T c5_i_hoistedGlobal;
  uint8_T c5_i_u;
  const mxArray *c5_j_y = NULL;
  uint8_T c5_j_hoistedGlobal;
  uint8_T c5_j_u;
  const mxArray *c5_k_y = NULL;
  boolean_T *c5_AutomaticController;
  real_T *c5_BatteryRelay;
  real_T *c5_ChargingRelay;
  real_T *c5_DischargingRelay;
  real_T *c5_IGBT_Bot_State;
  real_T *c5_IGBT_Top_State;
  real_T *c5_UltracapacitorRelay;
  c5_BatteryRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
  c5_DischargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c5_ChargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c5_UltracapacitorRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c5_AutomaticController = (boolean_T *)ssGetOutputPortSignal(chartInstance->S,
    3);
  c5_IGBT_Bot_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c5_IGBT_Top_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c5_st = NULL;
  c5_st = NULL;
  c5_y = NULL;
  sf_mex_assign(&c5_y, sf_mex_createcellarray(10), FALSE);
  c5_hoistedGlobal = *c5_AutomaticController;
  c5_u = c5_hoistedGlobal;
  c5_b_y = NULL;
  sf_mex_assign(&c5_b_y, sf_mex_create("y", &c5_u, 11, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c5_y, 0, c5_b_y);
  c5_b_hoistedGlobal = *c5_BatteryRelay;
  c5_b_u = c5_b_hoistedGlobal;
  c5_c_y = NULL;
  sf_mex_assign(&c5_c_y, sf_mex_create("y", &c5_b_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c5_y, 1, c5_c_y);
  c5_c_hoistedGlobal = *c5_ChargingRelay;
  c5_c_u = c5_c_hoistedGlobal;
  c5_d_y = NULL;
  sf_mex_assign(&c5_d_y, sf_mex_create("y", &c5_c_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c5_y, 2, c5_d_y);
  c5_d_hoistedGlobal = *c5_DischargingRelay;
  c5_d_u = c5_d_hoistedGlobal;
  c5_e_y = NULL;
  sf_mex_assign(&c5_e_y, sf_mex_create("y", &c5_d_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c5_y, 3, c5_e_y);
  c5_e_hoistedGlobal = *c5_IGBT_Bot_State;
  c5_e_u = c5_e_hoistedGlobal;
  c5_f_y = NULL;
  sf_mex_assign(&c5_f_y, sf_mex_create("y", &c5_e_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c5_y, 4, c5_f_y);
  c5_f_hoistedGlobal = *c5_IGBT_Top_State;
  c5_f_u = c5_f_hoistedGlobal;
  c5_g_y = NULL;
  sf_mex_assign(&c5_g_y, sf_mex_create("y", &c5_f_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c5_y, 5, c5_g_y);
  c5_g_hoistedGlobal = *c5_UltracapacitorRelay;
  c5_g_u = c5_g_hoistedGlobal;
  c5_h_y = NULL;
  sf_mex_assign(&c5_h_y, sf_mex_create("y", &c5_g_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c5_y, 6, c5_h_y);
  c5_h_hoistedGlobal = chartInstance->c5_dVrail_dT_threshold;
  c5_h_u = c5_h_hoistedGlobal;
  c5_i_y = NULL;
  sf_mex_assign(&c5_i_y, sf_mex_create("y", &c5_h_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c5_y, 7, c5_i_y);
  c5_i_hoistedGlobal = chartInstance->c5_is_active_c5_DCDCconverter;
  c5_i_u = c5_i_hoistedGlobal;
  c5_j_y = NULL;
  sf_mex_assign(&c5_j_y, sf_mex_create("y", &c5_i_u, 3, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c5_y, 8, c5_j_y);
  c5_j_hoistedGlobal = chartInstance->c5_is_c5_DCDCconverter;
  c5_j_u = c5_j_hoistedGlobal;
  c5_k_y = NULL;
  sf_mex_assign(&c5_k_y, sf_mex_create("y", &c5_j_u, 3, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c5_y, 9, c5_k_y);
  sf_mex_assign(&c5_st, c5_y, FALSE);
  return c5_st;
}

static void set_sim_state_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_st)
{
  const mxArray *c5_u;
  boolean_T *c5_AutomaticController;
  real_T *c5_BatteryRelay;
  real_T *c5_ChargingRelay;
  real_T *c5_DischargingRelay;
  real_T *c5_IGBT_Bot_State;
  real_T *c5_IGBT_Top_State;
  real_T *c5_UltracapacitorRelay;
  c5_BatteryRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
  c5_DischargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c5_ChargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c5_UltracapacitorRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c5_AutomaticController = (boolean_T *)ssGetOutputPortSignal(chartInstance->S,
    3);
  c5_IGBT_Bot_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c5_IGBT_Top_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c5_u = sf_mex_dup(c5_st);
  *c5_AutomaticController = c5_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c5_u, 0)), "AutomaticController");
  *c5_BatteryRelay = c5_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c5_u, 1)), "BatteryRelay");
  *c5_ChargingRelay = c5_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c5_u, 2)), "ChargingRelay");
  *c5_DischargingRelay = c5_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c5_u, 3)), "DischargingRelay");
  *c5_IGBT_Bot_State = c5_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c5_u, 4)), "IGBT_Bot_State");
  *c5_IGBT_Top_State = c5_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c5_u, 5)), "IGBT_Top_State");
  *c5_UltracapacitorRelay = c5_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c5_u, 6)), "UltracapacitorRelay");
  chartInstance->c5_dVrail_dT_threshold = c5_d_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c5_u, 7)), "dVrail_dT_threshold");
  chartInstance->c5_is_active_c5_DCDCconverter = c5_b_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c5_u, 8)),
     "is_active_c5_DCDCconverter");
  chartInstance->c5_is_c5_DCDCconverter = c5_b_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c5_u, 9)), "is_c5_DCDCconverter");
  sf_mex_assign(&chartInstance->c5_setSimStateSideEffectsInfo,
                c5_h_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c5_u, 10)), "setSimStateSideEffectsInfo"), TRUE);
  sf_mex_destroy(&c5_u);
  chartInstance->c5_doSetSimStateSideEffects = 1U;
  c5_update_debugger_state_c5_DCDCconverter(chartInstance);
  sf_mex_destroy(&c5_st);
}

static void c5_set_sim_state_side_effects_c5_DCDCconverter
  (SFc5_DCDCconverterInstanceStruct *chartInstance)
{
  if (chartInstance->c5_doSetSimStateSideEffects != 0) {
    if (chartInstance->c5_is_c5_DCDCconverter == c5_IN_AutomaticControlMode) {
      chartInstance->c5_tp_AutomaticControlMode = 1U;
    } else {
      chartInstance->c5_tp_AutomaticControlMode = 0U;
    }

    if (chartInstance->c5_is_c5_DCDCconverter == c5_IN_ChargingRail) {
      chartInstance->c5_tp_ChargingRail = 1U;
    } else {
      chartInstance->c5_tp_ChargingRail = 0U;
    }

    if (chartInstance->c5_is_c5_DCDCconverter == c5_IN_DischargingRail) {
      chartInstance->c5_tp_DischargingRail = 1U;
    } else {
      chartInstance->c5_tp_DischargingRail = 0U;
    }

    if (chartInstance->c5_is_c5_DCDCconverter == c5_IN_FinishedCharging) {
      chartInstance->c5_tp_FinishedCharging = 1U;
    } else {
      chartInstance->c5_tp_FinishedCharging = 0U;
    }

    if (chartInstance->c5_is_c5_DCDCconverter == c5_IN_ManualBoostMode) {
      chartInstance->c5_tp_ManualBoostMode = 1U;
    } else {
      chartInstance->c5_tp_ManualBoostMode = 0U;
    }

    if (chartInstance->c5_is_c5_DCDCconverter == c5_IN_ManualBuckMode) {
      chartInstance->c5_tp_ManualBuckMode = 1U;
    } else {
      chartInstance->c5_tp_ManualBuckMode = 0U;
    }

    if (chartInstance->c5_is_c5_DCDCconverter == c5_IN_Off) {
      chartInstance->c5_tp_Off = 1U;
    } else {
      chartInstance->c5_tp_Off = 0U;
    }

    chartInstance->c5_doSetSimStateSideEffects = 0U;
  }
}

static void finalize_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct
  *chartInstance)
{
  sf_mex_destroy(&chartInstance->c5_setSimStateSideEffectsInfo);
}

static void sf_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct *chartInstance)
{
  c5_set_sim_state_side_effects_c5_DCDCconverter(chartInstance);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 4U, chartInstance->c5_sfEvent);
  chartInstance->c5_sfEvent = CALL_EVENT;
  c5_chartstep_c5_DCDCconverter(chartInstance);
  sf_debug_check_for_state_inconsistency(_DCDCconverterMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber);
}

static void c5_chartstep_c5_DCDCconverter(SFc5_DCDCconverterInstanceStruct
  *chartInstance)
{
  boolean_T c5_out;
  boolean_T c5_b_out;
  boolean_T c5_c_out;
  boolean_T c5_d_out;
  boolean_T c5_e_out;
  boolean_T c5_temp;
  boolean_T c5_f_out;
  real_T c5_d0;
  real_T c5_d1;
  boolean_T c5_b0;
  real_T c5_d2;
  real_T c5_d3;
  real_T c5_d4;
  real_T c5_d5;
  boolean_T c5_g_out;
  boolean_T c5_h_out;
  boolean_T c5_i_out;
  boolean_T c5_j_out;
  boolean_T c5_k_out;
  boolean_T c5_b_temp;
  boolean_T c5_l_out;
  real_T c5_d6;
  real_T c5_d7;
  boolean_T c5_b1;
  real_T c5_d8;
  real_T c5_d9;
  real_T c5_d10;
  real_T c5_d11;
  boolean_T c5_c_temp;
  boolean_T c5_m_out;
  real_T *c5_ManualControlBuckMode;
  real_T *c5_EnableAutomaticControl;
  boolean_T *c5_Error;
  real_T *c5_TurnOnSystem;
  real_T *c5_IGBT_Top_State;
  real_T *c5_IGBT_Bot_State;
  boolean_T *c5_AutomaticController;
  real_T *c5_ChargingRelay;
  real_T *c5_DischargingRelay;
  real_T *c5_BatteryRelay;
  real_T *c5_UltracapacitorRelay;
  c5_BatteryRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
  c5_DischargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c5_ChargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c5_UltracapacitorRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c5_AutomaticController = (boolean_T *)ssGetOutputPortSignal(chartInstance->S,
    3);
  c5_IGBT_Bot_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c5_IGBT_Top_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c5_Error = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c5_ManualControlBuckMode = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c5_EnableAutomaticControl = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c5_TurnOnSystem = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 4U, chartInstance->c5_sfEvent);
  if (chartInstance->c5_is_active_c5_DCDCconverter == 0U) {
    _SFD_CC_CALL(CHART_ENTER_ENTRY_FUNCTION_TAG, 4U, chartInstance->c5_sfEvent);
    chartInstance->c5_is_active_c5_DCDCconverter = 1U;
    _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 4U, chartInstance->c5_sfEvent);
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 0U, chartInstance->c5_sfEvent);
    chartInstance->c5_is_c5_DCDCconverter = c5_IN_Off;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 6U, chartInstance->c5_sfEvent);
    chartInstance->c5_tp_Off = 1U;
    c5_enter_atomic_Off(chartInstance);
  } else {
    switch (chartInstance->c5_is_c5_DCDCconverter) {
     case c5_IN_AutomaticControlMode:
      CV_CHART_EVAL(4, 0, 1);
      c5_AutomaticControlMode(chartInstance);
      break;

     case c5_IN_ChargingRail:
      CV_CHART_EVAL(4, 0, 2);
      c5_ChargingRail(chartInstance);
      break;

     case c5_IN_DischargingRail:
      CV_CHART_EVAL(4, 0, 3);
      c5_DischargingRail(chartInstance);
      break;

     case c5_IN_FinishedCharging:
      CV_CHART_EVAL(4, 0, 4);
      c5_FinishedCharging(chartInstance);
      break;

     case c5_IN_ManualBoostMode:
      CV_CHART_EVAL(4, 0, 5);
      _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 4U,
                   chartInstance->c5_sfEvent);
      c5_out = (CV_TRANSITION_EVAL(4U, (int32_T)_SFD_CCP_CALL(4U, 0,
                  *c5_ManualControlBuckMode == 1.0 != 0U,
                  chartInstance->c5_sfEvent)) != 0);
      if (c5_out) {
        if (sf_debug_transition_conflict_check_enabled()) {
          unsigned int transitionList[3];
          unsigned int numTransitions = 1;
          transitionList[0] = 4;
          sf_debug_transition_conflict_check_begin();
          c5_b_out = (*c5_EnableAutomaticControl == 1.0);
          if (c5_b_out) {
            transitionList[numTransitions] = 5;
            numTransitions++;
          }

          c5_c_out = (((int16_T)*c5_Error == 1) || (*c5_TurnOnSystem == 0.0));
          if (c5_c_out) {
            transitionList[numTransitions] = 14;
            numTransitions++;
          }

          sf_debug_transition_conflict_check_end();
          if (numTransitions > 1) {
            _SFD_TRANSITION_CONFLICT(&(transitionList[0]),numTransitions);
          }
        }

        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 4U, chartInstance->c5_sfEvent);
        chartInstance->c5_tp_ManualBoostMode = 0U;
        _SFD_CS_CALL(STATE_INACTIVE_TAG, 4U, chartInstance->c5_sfEvent);
        chartInstance->c5_is_c5_DCDCconverter = c5_IN_ManualBuckMode;
        _SFD_CS_CALL(STATE_ACTIVE_TAG, 5U, chartInstance->c5_sfEvent);
        chartInstance->c5_tp_ManualBuckMode = 1U;
      } else {
        _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 5U,
                     chartInstance->c5_sfEvent);
        c5_d_out = (CV_TRANSITION_EVAL(5U, (int32_T)_SFD_CCP_CALL(5U, 0,
          *c5_EnableAutomaticControl == 1.0 != 0U, chartInstance->c5_sfEvent))
                    != 0);
        if (c5_d_out) {
          if (sf_debug_transition_conflict_check_enabled()) {
            unsigned int transitionList[2];
            unsigned int numTransitions = 1;
            transitionList[0] = 5;
            sf_debug_transition_conflict_check_begin();
            c5_e_out = (((int16_T)*c5_Error == 1) || (*c5_TurnOnSystem == 0.0));
            if (c5_e_out) {
              transitionList[numTransitions] = 14;
              numTransitions++;
            }

            sf_debug_transition_conflict_check_end();
            if (numTransitions > 1) {
              _SFD_TRANSITION_CONFLICT(&(transitionList[0]),numTransitions);
            }
          }

          _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 5U, chartInstance->c5_sfEvent);
          chartInstance->c5_tp_ManualBoostMode = 0U;
          _SFD_CS_CALL(STATE_INACTIVE_TAG, 4U, chartInstance->c5_sfEvent);
          chartInstance->c5_is_c5_DCDCconverter = c5_IN_AutomaticControlMode;
          _SFD_CS_CALL(STATE_ACTIVE_TAG, 0U, chartInstance->c5_sfEvent);
          chartInstance->c5_tp_AutomaticControlMode = 1U;
        } else {
          _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 14U,
                       chartInstance->c5_sfEvent);
          c5_temp = (_SFD_CCP_CALL(14U, 0, (int16_T)*c5_Error == 1 != 0U,
                      chartInstance->c5_sfEvent) != 0);
          if (!c5_temp) {
            c5_temp = (_SFD_CCP_CALL(14U, 1, *c5_TurnOnSystem == 0.0 != 0U,
                        chartInstance->c5_sfEvent) != 0);
          }

          c5_f_out = (CV_TRANSITION_EVAL(14U, (int32_T)c5_temp) != 0);
          if (c5_f_out) {
            _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 14U, chartInstance->c5_sfEvent);
            chartInstance->c5_tp_ManualBoostMode = 0U;
            _SFD_CS_CALL(STATE_INACTIVE_TAG, 4U, chartInstance->c5_sfEvent);
            chartInstance->c5_is_c5_DCDCconverter = c5_IN_DischargingRail;
            _SFD_CS_CALL(STATE_ACTIVE_TAG, 2U, chartInstance->c5_sfEvent);
            chartInstance->c5_tp_DischargingRail = 1U;
          } else {
            _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 4U,
                         chartInstance->c5_sfEvent);
            *c5_IGBT_Top_State = 0.0;
            c5_d0 = *c5_IGBT_Top_State;
            sf_mex_printf("%s =\\n", "IGBT_Top_State");
            sf_mex_call_debug("disp", 0U, 1U, 6, c5_d0);
            *c5_IGBT_Bot_State = 2.0;
            c5_d1 = *c5_IGBT_Bot_State;
            sf_mex_printf("%s =\\n", "IGBT_Bot_State");
            sf_mex_call_debug("disp", 0U, 1U, 6, c5_d1);
            *c5_AutomaticController = FALSE;
            c5_b0 = *c5_AutomaticController;
            sf_mex_printf("%s =\\n", "AutomaticController");
            sf_mex_call_debug("disp", 0U, 1U, 3, c5_b0);
            *c5_ChargingRelay = 0.0;
            c5_d2 = *c5_ChargingRelay;
            sf_mex_printf("%s =\\n", "ChargingRelay");
            sf_mex_call_debug("disp", 0U, 1U, 6, c5_d2);
            *c5_DischargingRelay = 0.0;
            c5_d3 = *c5_DischargingRelay;
            sf_mex_printf("%s =\\n", "DischargingRelay");
            sf_mex_call_debug("disp", 0U, 1U, 6, c5_d3);
            *c5_BatteryRelay = 1.0;
            c5_d4 = *c5_BatteryRelay;
            sf_mex_printf("%s =\\n", "BatteryRelay");
            sf_mex_call_debug("disp", 0U, 1U, 6, c5_d4);
            *c5_UltracapacitorRelay = 1.0;
            c5_d5 = *c5_UltracapacitorRelay;
            sf_mex_printf("%s =\\n", "UltracapacitorRelay");
            sf_mex_call_debug("disp", 0U, 1U, 6, c5_d5);
          }
        }
      }

      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 4U, chartInstance->c5_sfEvent);
      break;

     case c5_IN_ManualBuckMode:
      CV_CHART_EVAL(4, 0, 6);
      _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 3U,
                   chartInstance->c5_sfEvent);
      c5_g_out = (CV_TRANSITION_EVAL(3U, (int32_T)_SFD_CCP_CALL(3U, 0,
        *c5_ManualControlBuckMode == 0.0 != 0U, chartInstance->c5_sfEvent)) != 0);
      if (c5_g_out) {
        if (sf_debug_transition_conflict_check_enabled()) {
          unsigned int transitionList[3];
          unsigned int numTransitions = 1;
          transitionList[0] = 3;
          sf_debug_transition_conflict_check_begin();
          c5_h_out = (*c5_EnableAutomaticControl == 1.0);
          if (c5_h_out) {
            transitionList[numTransitions] = 7;
            numTransitions++;
          }

          c5_i_out = (((int16_T)*c5_Error == 1) || (*c5_TurnOnSystem == 0.0));
          if (c5_i_out) {
            transitionList[numTransitions] = 13;
            numTransitions++;
          }

          sf_debug_transition_conflict_check_end();
          if (numTransitions > 1) {
            _SFD_TRANSITION_CONFLICT(&(transitionList[0]),numTransitions);
          }
        }

        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 3U, chartInstance->c5_sfEvent);
        chartInstance->c5_tp_ManualBuckMode = 0U;
        _SFD_CS_CALL(STATE_INACTIVE_TAG, 5U, chartInstance->c5_sfEvent);
        chartInstance->c5_is_c5_DCDCconverter = c5_IN_ManualBoostMode;
        _SFD_CS_CALL(STATE_ACTIVE_TAG, 4U, chartInstance->c5_sfEvent);
        chartInstance->c5_tp_ManualBoostMode = 1U;
      } else {
        _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 7U,
                     chartInstance->c5_sfEvent);
        c5_j_out = (CV_TRANSITION_EVAL(7U, (int32_T)_SFD_CCP_CALL(7U, 0,
          *c5_EnableAutomaticControl == 1.0 != 0U, chartInstance->c5_sfEvent))
                    != 0);
        if (c5_j_out) {
          if (sf_debug_transition_conflict_check_enabled()) {
            unsigned int transitionList[2];
            unsigned int numTransitions = 1;
            transitionList[0] = 7;
            sf_debug_transition_conflict_check_begin();
            c5_k_out = (((int16_T)*c5_Error == 1) || (*c5_TurnOnSystem == 0.0));
            if (c5_k_out) {
              transitionList[numTransitions] = 13;
              numTransitions++;
            }

            sf_debug_transition_conflict_check_end();
            if (numTransitions > 1) {
              _SFD_TRANSITION_CONFLICT(&(transitionList[0]),numTransitions);
            }
          }

          _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 7U, chartInstance->c5_sfEvent);
          chartInstance->c5_tp_ManualBuckMode = 0U;
          _SFD_CS_CALL(STATE_INACTIVE_TAG, 5U, chartInstance->c5_sfEvent);
          chartInstance->c5_is_c5_DCDCconverter = c5_IN_AutomaticControlMode;
          _SFD_CS_CALL(STATE_ACTIVE_TAG, 0U, chartInstance->c5_sfEvent);
          chartInstance->c5_tp_AutomaticControlMode = 1U;
        } else {
          _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 13U,
                       chartInstance->c5_sfEvent);
          c5_b_temp = (_SFD_CCP_CALL(13U, 0, (int16_T)*c5_Error == 1 != 0U,
            chartInstance->c5_sfEvent) != 0);
          if (!c5_b_temp) {
            c5_b_temp = (_SFD_CCP_CALL(13U, 1, *c5_TurnOnSystem == 0.0 != 0U,
              chartInstance->c5_sfEvent) != 0);
          }

          c5_l_out = (CV_TRANSITION_EVAL(13U, (int32_T)c5_b_temp) != 0);
          if (c5_l_out) {
            _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 13U, chartInstance->c5_sfEvent);
            chartInstance->c5_tp_ManualBuckMode = 0U;
            _SFD_CS_CALL(STATE_INACTIVE_TAG, 5U, chartInstance->c5_sfEvent);
            chartInstance->c5_is_c5_DCDCconverter = c5_IN_DischargingRail;
            _SFD_CS_CALL(STATE_ACTIVE_TAG, 2U, chartInstance->c5_sfEvent);
            chartInstance->c5_tp_DischargingRail = 1U;
          } else {
            _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 5U,
                         chartInstance->c5_sfEvent);
            *c5_IGBT_Top_State = 2.0;
            c5_d6 = *c5_IGBT_Top_State;
            sf_mex_printf("%s =\\n", "IGBT_Top_State");
            sf_mex_call_debug("disp", 0U, 1U, 6, c5_d6);
            *c5_IGBT_Bot_State = 0.0;
            c5_d7 = *c5_IGBT_Bot_State;
            sf_mex_printf("%s =\\n", "IGBT_Bot_State");
            sf_mex_call_debug("disp", 0U, 1U, 6, c5_d7);
            *c5_AutomaticController = FALSE;
            c5_b1 = *c5_AutomaticController;
            sf_mex_printf("%s =\\n", "AutomaticController");
            sf_mex_call_debug("disp", 0U, 1U, 3, c5_b1);
            *c5_ChargingRelay = 0.0;
            c5_d8 = *c5_ChargingRelay;
            sf_mex_printf("%s =\\n", "ChargingRelay");
            sf_mex_call_debug("disp", 0U, 1U, 6, c5_d8);
            *c5_DischargingRelay = 0.0;
            c5_d9 = *c5_DischargingRelay;
            sf_mex_printf("%s =\\n", "DischargingRelay");
            sf_mex_call_debug("disp", 0U, 1U, 6, c5_d9);
            *c5_BatteryRelay = 1.0;
            c5_d10 = *c5_BatteryRelay;
            sf_mex_printf("%s =\\n", "BatteryRelay");
            sf_mex_call_debug("disp", 0U, 1U, 6, c5_d10);
            *c5_UltracapacitorRelay = 1.0;
            c5_d11 = *c5_UltracapacitorRelay;
            sf_mex_printf("%s =\\n", "UltracapacitorRelay");
            sf_mex_call_debug("disp", 0U, 1U, 6, c5_d11);
          }
        }
      }

      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 5U, chartInstance->c5_sfEvent);
      break;

     case c5_IN_Off:
      CV_CHART_EVAL(4, 0, 7);
      _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 1U,
                   chartInstance->c5_sfEvent);
      c5_c_temp = (_SFD_CCP_CALL(1U, 0, *c5_TurnOnSystem == 1.0 != 0U,
        chartInstance->c5_sfEvent) != 0);
      if (c5_c_temp) {
        c5_c_temp = (_SFD_CCP_CALL(1U, 1, (int16_T)*c5_Error == 0 != 0U,
          chartInstance->c5_sfEvent) != 0);
      }

      c5_m_out = (CV_TRANSITION_EVAL(1U, (int32_T)c5_c_temp) != 0);
      if (c5_m_out) {
        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 1U, chartInstance->c5_sfEvent);
        chartInstance->c5_tp_Off = 0U;
        _SFD_CS_CALL(STATE_INACTIVE_TAG, 6U, chartInstance->c5_sfEvent);
        chartInstance->c5_is_c5_DCDCconverter = c5_IN_ChargingRail;
        _SFD_CS_CALL(STATE_ACTIVE_TAG, 1U, chartInstance->c5_sfEvent);
        chartInstance->c5_tp_ChargingRail = 1U;
      } else {
        _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 6U,
                     chartInstance->c5_sfEvent);
      }

      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 6U, chartInstance->c5_sfEvent);
      break;

     default:
      CV_CHART_EVAL(4, 0, 0);
      chartInstance->c5_is_c5_DCDCconverter = c5_IN_NO_ACTIVE_CHILD;
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 0U, chartInstance->c5_sfEvent);
      break;
    }
  }

  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 4U, chartInstance->c5_sfEvent);
}

static void initSimStructsc5_DCDCconverter(SFc5_DCDCconverterInstanceStruct
  *chartInstance)
{
}

static void c5_enter_atomic_Off(SFc5_DCDCconverterInstanceStruct *chartInstance)
{
  real_T c5_d12;
  real_T c5_d13;
  boolean_T c5_b2;
  real_T c5_d14;
  real_T c5_d15;
  real_T c5_d16;
  real_T c5_d17;
  real_T c5_d18;
  real_T *c5_IGBT_Top_State;
  real_T *c5_IGBT_Bot_State;
  boolean_T *c5_AutomaticController;
  real_T *c5_ChargingRelay;
  real_T *c5_DischargingRelay;
  real_T *c5_BatteryRelay;
  real_T *c5_UltracapacitorRelay;
  c5_BatteryRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
  c5_DischargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c5_ChargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c5_UltracapacitorRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c5_AutomaticController = (boolean_T *)ssGetOutputPortSignal(chartInstance->S,
    3);
  c5_IGBT_Bot_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c5_IGBT_Top_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  *c5_IGBT_Top_State = 0.0;
  c5_d12 = *c5_IGBT_Top_State;
  sf_mex_printf("%s =\\n", "IGBT_Top_State");
  sf_mex_call_debug("disp", 0U, 1U, 6, c5_d12);
  *c5_IGBT_Bot_State = 0.0;
  c5_d13 = *c5_IGBT_Bot_State;
  sf_mex_printf("%s =\\n", "IGBT_Bot_State");
  sf_mex_call_debug("disp", 0U, 1U, 6, c5_d13);
  *c5_AutomaticController = FALSE;
  c5_b2 = *c5_AutomaticController;
  sf_mex_printf("%s =\\n", "AutomaticController");
  sf_mex_call_debug("disp", 0U, 1U, 3, c5_b2);
  *c5_ChargingRelay = 0.0;
  c5_d14 = *c5_ChargingRelay;
  sf_mex_printf("%s =\\n", "ChargingRelay");
  sf_mex_call_debug("disp", 0U, 1U, 6, c5_d14);
  *c5_DischargingRelay = 1.0;
  c5_d15 = *c5_DischargingRelay;
  sf_mex_printf("%s =\\n", "DischargingRelay");
  sf_mex_call_debug("disp", 0U, 1U, 6, c5_d15);
  *c5_BatteryRelay = 0.0;
  c5_d16 = *c5_BatteryRelay;
  sf_mex_printf("%s =\\n", "BatteryRelay");
  sf_mex_call_debug("disp", 0U, 1U, 6, c5_d16);
  *c5_UltracapacitorRelay = 0.0;
  c5_d17 = *c5_UltracapacitorRelay;
  sf_mex_printf("%s =\\n", "UltracapacitorRelay");
  sf_mex_call_debug("disp", 0U, 1U, 6, c5_d17);
  chartInstance->c5_dVrail_dT_threshold = 0.01;
  c5_d18 = chartInstance->c5_dVrail_dT_threshold;
  sf_mex_printf("%s =\\n", "dVrail_dT_threshold");
  sf_mex_call_debug("disp", 0U, 1U, 6, c5_d18);
}

static void c5_DischargingRail(SFc5_DCDCconverterInstanceStruct *chartInstance)
{
  boolean_T c5_temp;
  boolean_T c5_out;
  boolean_T c5_b_temp;
  boolean_T c5_b_out;
  real_T c5_d19;
  real_T c5_d20;
  boolean_T c5_b3;
  real_T c5_d21;
  real_T c5_d22;
  real_T c5_d23;
  real_T c5_d24;
  real_T *c5_TurnOnSystem;
  boolean_T *c5_Error;
  real_T *c5_Vrail;
  real_T *c5_Vrail_rated;
  real_T *c5_dVrail_dT;
  real_T *c5_IGBT_Top_State;
  real_T *c5_IGBT_Bot_State;
  boolean_T *c5_AutomaticController;
  real_T *c5_ChargingRelay;
  real_T *c5_DischargingRelay;
  real_T *c5_BatteryRelay;
  real_T *c5_UltracapacitorRelay;
  c5_BatteryRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
  c5_DischargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c5_ChargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c5_UltracapacitorRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c5_AutomaticController = (boolean_T *)ssGetOutputPortSignal(chartInstance->S,
    3);
  c5_Vrail_rated = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
  c5_dVrail_dT = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
  c5_Vrail = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c5_IGBT_Bot_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c5_IGBT_Top_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c5_Error = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c5_TurnOnSystem = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 2U, chartInstance->c5_sfEvent);
  c5_temp = (_SFD_CCP_CALL(2U, 0, *c5_TurnOnSystem == 1.0 != 0U,
              chartInstance->c5_sfEvent) != 0);
  if (c5_temp) {
    c5_temp = (_SFD_CCP_CALL(2U, 1, (int16_T)*c5_Error == 0 != 0U,
                chartInstance->c5_sfEvent) != 0);
  }

  c5_out = (CV_TRANSITION_EVAL(2U, (int32_T)c5_temp) != 0);
  if (c5_out) {
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 2U, chartInstance->c5_sfEvent);
    chartInstance->c5_tp_DischargingRail = 0U;
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 2U, chartInstance->c5_sfEvent);
    chartInstance->c5_is_c5_DCDCconverter = c5_IN_ChargingRail;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 1U, chartInstance->c5_sfEvent);
    chartInstance->c5_tp_ChargingRail = 1U;
  } else {
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 9U, chartInstance->c5_sfEvent);
    c5_b_temp = (_SFD_CCP_CALL(9U, 0, *c5_Vrail <= *c5_Vrail_rated * 0.15 != 0U,
      chartInstance->c5_sfEvent) != 0);
    if (c5_b_temp) {
      c5_b_temp = (_SFD_CCP_CALL(9U, 1, muDoubleScalarAbs(*c5_dVrail_dT) <=
        chartInstance->c5_dVrail_dT_threshold != 0U, chartInstance->c5_sfEvent)
                   != 0);
    }

    c5_b_out = (CV_TRANSITION_EVAL(9U, (int32_T)c5_b_temp) != 0);
    if (c5_b_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 9U, chartInstance->c5_sfEvent);
      chartInstance->c5_tp_DischargingRail = 0U;
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 2U, chartInstance->c5_sfEvent);
      chartInstance->c5_is_c5_DCDCconverter = c5_IN_Off;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 6U, chartInstance->c5_sfEvent);
      chartInstance->c5_tp_Off = 1U;
      c5_enter_atomic_Off(chartInstance);
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 2U,
                   chartInstance->c5_sfEvent);
      *c5_IGBT_Top_State = 0.0;
      c5_d19 = *c5_IGBT_Top_State;
      sf_mex_printf("%s =\\n", "IGBT_Top_State");
      sf_mex_call_debug("disp", 0U, 1U, 6, c5_d19);
      *c5_IGBT_Bot_State = 0.0;
      c5_d20 = *c5_IGBT_Bot_State;
      sf_mex_printf("%s =\\n", "IGBT_Bot_State");
      sf_mex_call_debug("disp", 0U, 1U, 6, c5_d20);
      *c5_AutomaticController = FALSE;
      c5_b3 = *c5_AutomaticController;
      sf_mex_printf("%s =\\n", "AutomaticController");
      sf_mex_call_debug("disp", 0U, 1U, 3, c5_b3);
      *c5_ChargingRelay = 0.0;
      c5_d21 = *c5_ChargingRelay;
      sf_mex_printf("%s =\\n", "ChargingRelay");
      sf_mex_call_debug("disp", 0U, 1U, 6, c5_d21);
      *c5_DischargingRelay = 1.0;
      c5_d22 = *c5_DischargingRelay;
      sf_mex_printf("%s =\\n", "DischargingRelay");
      sf_mex_call_debug("disp", 0U, 1U, 6, c5_d22);
      *c5_BatteryRelay = 0.0;
      c5_d23 = *c5_BatteryRelay;
      sf_mex_printf("%s =\\n", "BatteryRelay");
      sf_mex_call_debug("disp", 0U, 1U, 6, c5_d23);
      *c5_UltracapacitorRelay = 0.0;
      c5_d24 = *c5_UltracapacitorRelay;
      sf_mex_printf("%s =\\n", "UltracapacitorRelay");
      sf_mex_call_debug("disp", 0U, 1U, 6, c5_d24);
    }
  }

  _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 2U, chartInstance->c5_sfEvent);
}

static void c5_ChargingRail(SFc5_DCDCconverterInstanceStruct *chartInstance)
{
  boolean_T c5_temp;
  boolean_T c5_out;
  boolean_T c5_b_out;
  boolean_T c5_b_temp;
  boolean_T c5_c_out;
  real_T c5_d25;
  real_T c5_d26;
  boolean_T c5_b4;
  real_T c5_d27;
  real_T c5_d28;
  real_T c5_d29;
  real_T c5_d30;
  real_T *c5_Vrail;
  real_T *c5_Vrail_rated;
  real_T *c5_dVrail_dT;
  boolean_T *c5_Error;
  real_T *c5_TurnOnSystem;
  real_T *c5_IGBT_Top_State;
  real_T *c5_IGBT_Bot_State;
  boolean_T *c5_AutomaticController;
  real_T *c5_ChargingRelay;
  real_T *c5_DischargingRelay;
  real_T *c5_BatteryRelay;
  real_T *c5_UltracapacitorRelay;
  c5_BatteryRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
  c5_DischargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c5_ChargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c5_UltracapacitorRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c5_AutomaticController = (boolean_T *)ssGetOutputPortSignal(chartInstance->S,
    3);
  c5_Vrail_rated = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
  c5_dVrail_dT = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
  c5_Vrail = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c5_IGBT_Bot_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c5_IGBT_Top_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c5_Error = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c5_TurnOnSystem = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 11U, chartInstance->c5_sfEvent);
  c5_temp = (_SFD_CCP_CALL(11U, 0, *c5_Vrail >= *c5_Vrail_rated * 0.85 != 0U,
              chartInstance->c5_sfEvent) != 0);
  if (c5_temp) {
    c5_temp = (_SFD_CCP_CALL(11U, 1, muDoubleScalarAbs(*c5_dVrail_dT) <=
                chartInstance->c5_dVrail_dT_threshold != 0U,
                chartInstance->c5_sfEvent) != 0);
  }

  c5_out = (CV_TRANSITION_EVAL(11U, (int32_T)c5_temp) != 0);
  if (c5_out) {
    if (sf_debug_transition_conflict_check_enabled()) {
      unsigned int transitionList[2];
      unsigned int numTransitions = 1;
      transitionList[0] = 11;
      sf_debug_transition_conflict_check_begin();
      c5_b_out = (((int16_T)*c5_Error == 1) || (*c5_TurnOnSystem == 0.0));
      if (c5_b_out) {
        transitionList[numTransitions] = 18;
        numTransitions++;
      }

      sf_debug_transition_conflict_check_end();
      if (numTransitions > 1) {
        _SFD_TRANSITION_CONFLICT(&(transitionList[0]),numTransitions);
      }
    }

    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 11U, chartInstance->c5_sfEvent);
    chartInstance->c5_tp_ChargingRail = 0U;
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 1U, chartInstance->c5_sfEvent);
    chartInstance->c5_is_c5_DCDCconverter = c5_IN_FinishedCharging;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 3U, chartInstance->c5_sfEvent);
    chartInstance->c5_tp_FinishedCharging = 1U;
  } else {
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 18U,
                 chartInstance->c5_sfEvent);
    c5_b_temp = (_SFD_CCP_CALL(18U, 0, (int16_T)*c5_Error == 1 != 0U,
      chartInstance->c5_sfEvent) != 0);
    if (!c5_b_temp) {
      c5_b_temp = (_SFD_CCP_CALL(18U, 1, *c5_TurnOnSystem == 0.0 != 0U,
        chartInstance->c5_sfEvent) != 0);
    }

    c5_c_out = (CV_TRANSITION_EVAL(18U, (int32_T)c5_b_temp) != 0);
    if (c5_c_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 18U, chartInstance->c5_sfEvent);
      chartInstance->c5_tp_ChargingRail = 0U;
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 1U, chartInstance->c5_sfEvent);
      chartInstance->c5_is_c5_DCDCconverter = c5_IN_DischargingRail;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 2U, chartInstance->c5_sfEvent);
      chartInstance->c5_tp_DischargingRail = 1U;
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 1U,
                   chartInstance->c5_sfEvent);
      *c5_IGBT_Top_State = 0.0;
      c5_d25 = *c5_IGBT_Top_State;
      sf_mex_printf("%s =\\n", "IGBT_Top_State");
      sf_mex_call_debug("disp", 0U, 1U, 6, c5_d25);
      *c5_IGBT_Bot_State = 0.0;
      c5_d26 = *c5_IGBT_Bot_State;
      sf_mex_printf("%s =\\n", "IGBT_Bot_State");
      sf_mex_call_debug("disp", 0U, 1U, 6, c5_d26);
      *c5_AutomaticController = FALSE;
      c5_b4 = *c5_AutomaticController;
      sf_mex_printf("%s =\\n", "AutomaticController");
      sf_mex_call_debug("disp", 0U, 1U, 3, c5_b4);
      *c5_ChargingRelay = 1.0;
      c5_d27 = *c5_ChargingRelay;
      sf_mex_printf("%s =\\n", "ChargingRelay");
      sf_mex_call_debug("disp", 0U, 1U, 6, c5_d27);
      *c5_DischargingRelay = 0.0;
      c5_d28 = *c5_DischargingRelay;
      sf_mex_printf("%s =\\n", "DischargingRelay");
      sf_mex_call_debug("disp", 0U, 1U, 6, c5_d28);
      *c5_BatteryRelay = 0.0;
      c5_d29 = *c5_BatteryRelay;
      sf_mex_printf("%s =\\n", "BatteryRelay");
      sf_mex_call_debug("disp", 0U, 1U, 6, c5_d29);
      *c5_UltracapacitorRelay = 0.0;
      c5_d30 = *c5_UltracapacitorRelay;
      sf_mex_printf("%s =\\n", "UltracapacitorRelay");
      sf_mex_call_debug("disp", 0U, 1U, 6, c5_d30);
    }
  }

  _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 1U, chartInstance->c5_sfEvent);
}

static void c5_FinishedCharging(SFc5_DCDCconverterInstanceStruct *chartInstance)
{
  boolean_T c5_out;
  boolean_T c5_b_out;
  boolean_T c5_c_out;
  boolean_T c5_d_out;
  boolean_T c5_temp;
  boolean_T c5_e_out;
  boolean_T c5_f_out;
  boolean_T c5_g_out;
  boolean_T c5_b_temp;
  boolean_T c5_h_out;
  boolean_T c5_i_out;
  boolean_T c5_c_temp;
  boolean_T c5_j_out;
  real_T c5_d31;
  real_T c5_d32;
  boolean_T c5_b5;
  real_T c5_d33;
  real_T c5_d34;
  real_T c5_d35;
  real_T c5_d36;
  real_T *c5_EnableAutomaticControl;
  boolean_T *c5_Error;
  real_T *c5_TurnOnSystem;
  real_T *c5_ManualControlBuckMode;
  real_T *c5_IGBT_Top_State;
  real_T *c5_IGBT_Bot_State;
  boolean_T *c5_AutomaticController;
  real_T *c5_ChargingRelay;
  real_T *c5_DischargingRelay;
  real_T *c5_BatteryRelay;
  real_T *c5_UltracapacitorRelay;
  c5_BatteryRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
  c5_DischargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c5_ChargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c5_UltracapacitorRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c5_AutomaticController = (boolean_T *)ssGetOutputPortSignal(chartInstance->S,
    3);
  c5_IGBT_Bot_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c5_IGBT_Top_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c5_Error = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c5_ManualControlBuckMode = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c5_EnableAutomaticControl = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c5_TurnOnSystem = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 10U, chartInstance->c5_sfEvent);
  c5_out = (CV_TRANSITION_EVAL(10U, (int32_T)_SFD_CCP_CALL(10U, 0,
              *c5_EnableAutomaticControl == 1.0 != 0U, chartInstance->c5_sfEvent))
            != 0);
  if (c5_out) {
    if (sf_debug_transition_conflict_check_enabled()) {
      unsigned int transitionList[4];
      unsigned int numTransitions = 1;
      transitionList[0] = 10;
      sf_debug_transition_conflict_check_begin();
      c5_b_out = (((int16_T)*c5_Error == 1) || (*c5_TurnOnSystem == 0.0));
      if (c5_b_out) {
        transitionList[numTransitions] = 12;
        numTransitions++;
      }

      c5_c_out = ((*c5_EnableAutomaticControl == 0.0) &&
                  (*c5_ManualControlBuckMode == 0.0));
      if (c5_c_out) {
        transitionList[numTransitions] = 16;
        numTransitions++;
      }

      c5_d_out = ((*c5_EnableAutomaticControl == 0.0) &&
                  (*c5_ManualControlBuckMode == 1.0));
      if (c5_d_out) {
        transitionList[numTransitions] = 17;
        numTransitions++;
      }

      sf_debug_transition_conflict_check_end();
      if (numTransitions > 1) {
        _SFD_TRANSITION_CONFLICT(&(transitionList[0]),numTransitions);
      }
    }

    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 10U, chartInstance->c5_sfEvent);
    chartInstance->c5_tp_FinishedCharging = 0U;
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 3U, chartInstance->c5_sfEvent);
    chartInstance->c5_is_c5_DCDCconverter = c5_IN_AutomaticControlMode;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 0U, chartInstance->c5_sfEvent);
    chartInstance->c5_tp_AutomaticControlMode = 1U;
  } else {
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 12U,
                 chartInstance->c5_sfEvent);
    c5_temp = (_SFD_CCP_CALL(12U, 0, (int16_T)*c5_Error == 1 != 0U,
                chartInstance->c5_sfEvent) != 0);
    if (!c5_temp) {
      c5_temp = (_SFD_CCP_CALL(12U, 1, *c5_TurnOnSystem == 0.0 != 0U,
                  chartInstance->c5_sfEvent) != 0);
    }

    c5_e_out = (CV_TRANSITION_EVAL(12U, (int32_T)c5_temp) != 0);
    if (c5_e_out) {
      if (sf_debug_transition_conflict_check_enabled()) {
        unsigned int transitionList[3];
        unsigned int numTransitions = 1;
        transitionList[0] = 12;
        sf_debug_transition_conflict_check_begin();
        c5_f_out = ((*c5_EnableAutomaticControl == 0.0) &&
                    (*c5_ManualControlBuckMode == 0.0));
        if (c5_f_out) {
          transitionList[numTransitions] = 16;
          numTransitions++;
        }

        c5_g_out = ((*c5_EnableAutomaticControl == 0.0) &&
                    (*c5_ManualControlBuckMode == 1.0));
        if (c5_g_out) {
          transitionList[numTransitions] = 17;
          numTransitions++;
        }

        sf_debug_transition_conflict_check_end();
        if (numTransitions > 1) {
          _SFD_TRANSITION_CONFLICT(&(transitionList[0]),numTransitions);
        }
      }

      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 12U, chartInstance->c5_sfEvent);
      chartInstance->c5_tp_FinishedCharging = 0U;
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 3U, chartInstance->c5_sfEvent);
      chartInstance->c5_is_c5_DCDCconverter = c5_IN_DischargingRail;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 2U, chartInstance->c5_sfEvent);
      chartInstance->c5_tp_DischargingRail = 1U;
    } else {
      _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 16U,
                   chartInstance->c5_sfEvent);
      c5_b_temp = (_SFD_CCP_CALL(16U, 0, *c5_EnableAutomaticControl == 0.0 != 0U,
        chartInstance->c5_sfEvent) != 0);
      if (c5_b_temp) {
        c5_b_temp = (_SFD_CCP_CALL(16U, 1, *c5_ManualControlBuckMode == 0.0 !=
          0U, chartInstance->c5_sfEvent) != 0);
      }

      c5_h_out = (CV_TRANSITION_EVAL(16U, (int32_T)c5_b_temp) != 0);
      if (c5_h_out) {
        if (sf_debug_transition_conflict_check_enabled()) {
          unsigned int transitionList[2];
          unsigned int numTransitions = 1;
          transitionList[0] = 16;
          sf_debug_transition_conflict_check_begin();
          c5_i_out = ((*c5_EnableAutomaticControl == 0.0) &&
                      (*c5_ManualControlBuckMode == 1.0));
          if (c5_i_out) {
            transitionList[numTransitions] = 17;
            numTransitions++;
          }

          sf_debug_transition_conflict_check_end();
          if (numTransitions > 1) {
            _SFD_TRANSITION_CONFLICT(&(transitionList[0]),numTransitions);
          }
        }

        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 16U, chartInstance->c5_sfEvent);
        chartInstance->c5_tp_FinishedCharging = 0U;
        _SFD_CS_CALL(STATE_INACTIVE_TAG, 3U, chartInstance->c5_sfEvent);
        chartInstance->c5_is_c5_DCDCconverter = c5_IN_ManualBoostMode;
        _SFD_CS_CALL(STATE_ACTIVE_TAG, 4U, chartInstance->c5_sfEvent);
        chartInstance->c5_tp_ManualBoostMode = 1U;
      } else {
        _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 17U,
                     chartInstance->c5_sfEvent);
        c5_c_temp = (_SFD_CCP_CALL(17U, 0, *c5_EnableAutomaticControl == 0.0 !=
          0U, chartInstance->c5_sfEvent) != 0);
        if (c5_c_temp) {
          c5_c_temp = (_SFD_CCP_CALL(17U, 1, *c5_ManualControlBuckMode == 1.0 !=
            0U, chartInstance->c5_sfEvent) != 0);
        }

        c5_j_out = (CV_TRANSITION_EVAL(17U, (int32_T)c5_c_temp) != 0);
        if (c5_j_out) {
          _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 17U, chartInstance->c5_sfEvent);
          chartInstance->c5_tp_FinishedCharging = 0U;
          _SFD_CS_CALL(STATE_INACTIVE_TAG, 3U, chartInstance->c5_sfEvent);
          chartInstance->c5_is_c5_DCDCconverter = c5_IN_ManualBuckMode;
          _SFD_CS_CALL(STATE_ACTIVE_TAG, 5U, chartInstance->c5_sfEvent);
          chartInstance->c5_tp_ManualBuckMode = 1U;
        } else {
          _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 3U,
                       chartInstance->c5_sfEvent);
          *c5_IGBT_Top_State = 0.0;
          c5_d31 = *c5_IGBT_Top_State;
          sf_mex_printf("%s =\\n", "IGBT_Top_State");
          sf_mex_call_debug("disp", 0U, 1U, 6, c5_d31);
          *c5_IGBT_Bot_State = 0.0;
          c5_d32 = *c5_IGBT_Bot_State;
          sf_mex_printf("%s =\\n", "IGBT_Bot_State");
          sf_mex_call_debug("disp", 0U, 1U, 6, c5_d32);
          *c5_AutomaticController = FALSE;
          c5_b5 = *c5_AutomaticController;
          sf_mex_printf("%s =\\n", "AutomaticController");
          sf_mex_call_debug("disp", 0U, 1U, 3, c5_b5);
          *c5_ChargingRelay = 0.0;
          c5_d33 = *c5_ChargingRelay;
          sf_mex_printf("%s =\\n", "ChargingRelay");
          sf_mex_call_debug("disp", 0U, 1U, 6, c5_d33);
          *c5_DischargingRelay = 0.0;
          c5_d34 = *c5_DischargingRelay;
          sf_mex_printf("%s =\\n", "DischargingRelay");
          sf_mex_call_debug("disp", 0U, 1U, 6, c5_d34);
          *c5_BatteryRelay = 0.0;
          c5_d35 = *c5_BatteryRelay;
          sf_mex_printf("%s =\\n", "BatteryRelay");
          sf_mex_call_debug("disp", 0U, 1U, 6, c5_d35);
          *c5_UltracapacitorRelay = 0.0;
          c5_d36 = *c5_UltracapacitorRelay;
          sf_mex_printf("%s =\\n", "UltracapacitorRelay");
          sf_mex_call_debug("disp", 0U, 1U, 6, c5_d36);
        }
      }
    }
  }

  _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 3U, chartInstance->c5_sfEvent);
}

static void c5_AutomaticControlMode(SFc5_DCDCconverterInstanceStruct
  *chartInstance)
{
  boolean_T c5_temp;
  boolean_T c5_out;
  boolean_T c5_b_out;
  boolean_T c5_c_out;
  boolean_T c5_b_temp;
  boolean_T c5_d_out;
  boolean_T c5_e_out;
  boolean_T c5_c_temp;
  boolean_T c5_f_out;
  real_T c5_d37;
  real_T c5_d38;
  boolean_T c5_b6;
  real_T c5_d39;
  real_T c5_d40;
  real_T c5_d41;
  real_T c5_d42;
  real_T *c5_EnableAutomaticControl;
  real_T *c5_ManualControlBuckMode;
  boolean_T *c5_Error;
  real_T *c5_TurnOnSystem;
  real_T *c5_IGBT_Top_State;
  real_T *c5_IGBT_Bot_State;
  boolean_T *c5_AutomaticController;
  real_T *c5_ChargingRelay;
  real_T *c5_DischargingRelay;
  real_T *c5_BatteryRelay;
  real_T *c5_UltracapacitorRelay;
  c5_BatteryRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
  c5_DischargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c5_ChargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c5_UltracapacitorRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c5_AutomaticController = (boolean_T *)ssGetOutputPortSignal(chartInstance->S,
    3);
  c5_IGBT_Bot_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c5_IGBT_Top_State = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c5_Error = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c5_ManualControlBuckMode = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c5_EnableAutomaticControl = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c5_TurnOnSystem = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 6U, chartInstance->c5_sfEvent);
  c5_temp = (_SFD_CCP_CALL(6U, 0, *c5_EnableAutomaticControl == 0.0 != 0U,
              chartInstance->c5_sfEvent) != 0);
  if (c5_temp) {
    c5_temp = (_SFD_CCP_CALL(6U, 1, *c5_ManualControlBuckMode == 0.0 != 0U,
                chartInstance->c5_sfEvent) != 0);
  }

  c5_out = (CV_TRANSITION_EVAL(6U, (int32_T)c5_temp) != 0);
  if (c5_out) {
    if (sf_debug_transition_conflict_check_enabled()) {
      unsigned int transitionList[3];
      unsigned int numTransitions = 1;
      transitionList[0] = 6;
      sf_debug_transition_conflict_check_begin();
      c5_b_out = ((*c5_EnableAutomaticControl == 0.0) &&
                  (*c5_ManualControlBuckMode == 1.0));
      if (c5_b_out) {
        transitionList[numTransitions] = 8;
        numTransitions++;
      }

      c5_c_out = (((int16_T)*c5_Error == 1) || (*c5_TurnOnSystem == 0.0));
      if (c5_c_out) {
        transitionList[numTransitions] = 15;
        numTransitions++;
      }

      sf_debug_transition_conflict_check_end();
      if (numTransitions > 1) {
        _SFD_TRANSITION_CONFLICT(&(transitionList[0]),numTransitions);
      }
    }

    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 6U, chartInstance->c5_sfEvent);
    chartInstance->c5_tp_AutomaticControlMode = 0U;
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 0U, chartInstance->c5_sfEvent);
    chartInstance->c5_is_c5_DCDCconverter = c5_IN_ManualBoostMode;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 4U, chartInstance->c5_sfEvent);
    chartInstance->c5_tp_ManualBoostMode = 1U;
  } else {
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 8U, chartInstance->c5_sfEvent);
    c5_b_temp = (_SFD_CCP_CALL(8U, 0, *c5_EnableAutomaticControl == 0.0 != 0U,
      chartInstance->c5_sfEvent) != 0);
    if (c5_b_temp) {
      c5_b_temp = (_SFD_CCP_CALL(8U, 1, *c5_ManualControlBuckMode == 1.0 != 0U,
        chartInstance->c5_sfEvent) != 0);
    }

    c5_d_out = (CV_TRANSITION_EVAL(8U, (int32_T)c5_b_temp) != 0);
    if (c5_d_out) {
      if (sf_debug_transition_conflict_check_enabled()) {
        unsigned int transitionList[2];
        unsigned int numTransitions = 1;
        transitionList[0] = 8;
        sf_debug_transition_conflict_check_begin();
        c5_e_out = (((int16_T)*c5_Error == 1) || (*c5_TurnOnSystem == 0.0));
        if (c5_e_out) {
          transitionList[numTransitions] = 15;
          numTransitions++;
        }

        sf_debug_transition_conflict_check_end();
        if (numTransitions > 1) {
          _SFD_TRANSITION_CONFLICT(&(transitionList[0]),numTransitions);
        }
      }

      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 8U, chartInstance->c5_sfEvent);
      chartInstance->c5_tp_AutomaticControlMode = 0U;
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 0U, chartInstance->c5_sfEvent);
      chartInstance->c5_is_c5_DCDCconverter = c5_IN_ManualBuckMode;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 5U, chartInstance->c5_sfEvent);
      chartInstance->c5_tp_ManualBuckMode = 1U;
    } else {
      _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 15U,
                   chartInstance->c5_sfEvent);
      c5_c_temp = (_SFD_CCP_CALL(15U, 0, (int16_T)*c5_Error == 1 != 0U,
        chartInstance->c5_sfEvent) != 0);
      if (!c5_c_temp) {
        c5_c_temp = (_SFD_CCP_CALL(15U, 1, *c5_TurnOnSystem == 0.0 != 0U,
          chartInstance->c5_sfEvent) != 0);
      }

      c5_f_out = (CV_TRANSITION_EVAL(15U, (int32_T)c5_c_temp) != 0);
      if (c5_f_out) {
        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 15U, chartInstance->c5_sfEvent);
        chartInstance->c5_tp_AutomaticControlMode = 0U;
        _SFD_CS_CALL(STATE_INACTIVE_TAG, 0U, chartInstance->c5_sfEvent);
        chartInstance->c5_is_c5_DCDCconverter = c5_IN_DischargingRail;
        _SFD_CS_CALL(STATE_ACTIVE_TAG, 2U, chartInstance->c5_sfEvent);
        chartInstance->c5_tp_DischargingRail = 1U;
      } else {
        _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 0U,
                     chartInstance->c5_sfEvent);
        *c5_IGBT_Top_State = 1.0;
        c5_d37 = *c5_IGBT_Top_State;
        sf_mex_printf("%s =\\n", "IGBT_Top_State");
        sf_mex_call_debug("disp", 0U, 1U, 6, c5_d37);
        *c5_IGBT_Bot_State = 1.0;
        c5_d38 = *c5_IGBT_Bot_State;
        sf_mex_printf("%s =\\n", "IGBT_Bot_State");
        sf_mex_call_debug("disp", 0U, 1U, 6, c5_d38);
        *c5_AutomaticController = TRUE;
        c5_b6 = *c5_AutomaticController;
        sf_mex_printf("%s =\\n", "AutomaticController");
        sf_mex_call_debug("disp", 0U, 1U, 3, c5_b6);
        *c5_ChargingRelay = 0.0;
        c5_d39 = *c5_ChargingRelay;
        sf_mex_printf("%s =\\n", "ChargingRelay");
        sf_mex_call_debug("disp", 0U, 1U, 6, c5_d39);
        *c5_DischargingRelay = 0.0;
        c5_d40 = *c5_DischargingRelay;
        sf_mex_printf("%s =\\n", "DischargingRelay");
        sf_mex_call_debug("disp", 0U, 1U, 6, c5_d40);
        *c5_BatteryRelay = 1.0;
        c5_d41 = *c5_BatteryRelay;
        sf_mex_printf("%s =\\n", "BatteryRelay");
        sf_mex_call_debug("disp", 0U, 1U, 6, c5_d41);
        *c5_UltracapacitorRelay = 1.0;
        c5_d42 = *c5_UltracapacitorRelay;
        sf_mex_printf("%s =\\n", "UltracapacitorRelay");
        sf_mex_call_debug("disp", 0U, 1U, 6, c5_d42);
      }
    }
  }

  _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 0U, chartInstance->c5_sfEvent);
}

static void init_script_number_translation(uint32_T c5_machineNumber, uint32_T
  c5_chartNumber)
{
}

const mxArray *sf_c5_DCDCconverter_get_eml_resolved_functions_info(void)
{
  const mxArray *c5_nameCaptureInfo = NULL;
  c5_nameCaptureInfo = NULL;
  sf_mex_assign(&c5_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1), FALSE);
  return c5_nameCaptureInfo;
}

static const mxArray *c5_sf_marshallOut(void *chartInstanceVoid, void *c5_inData)
{
  const mxArray *c5_mxArrayOutData = NULL;
  int32_T c5_u;
  const mxArray *c5_y = NULL;
  SFc5_DCDCconverterInstanceStruct *chartInstance;
  chartInstance = (SFc5_DCDCconverterInstanceStruct *)chartInstanceVoid;
  c5_mxArrayOutData = NULL;
  c5_u = *(int32_T *)c5_inData;
  c5_y = NULL;
  sf_mex_assign(&c5_y, sf_mex_create("y", &c5_u, 6, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c5_mxArrayOutData, c5_y, FALSE);
  return c5_mxArrayOutData;
}

static int32_T c5_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_u, const emlrtMsgIdentifier *c5_parentId)
{
  int32_T c5_y;
  int32_T c5_i0;
  sf_mex_import(c5_parentId, sf_mex_dup(c5_u), &c5_i0, 1, 6, 0U, 0, 0U, 0);
  c5_y = c5_i0;
  sf_mex_destroy(&c5_u);
  return c5_y;
}

static void c5_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c5_mxArrayInData, const char_T *c5_varName, void *c5_outData)
{
  const mxArray *c5_b_sfEvent;
  const char_T *c5_identifier;
  emlrtMsgIdentifier c5_thisId;
  int32_T c5_y;
  SFc5_DCDCconverterInstanceStruct *chartInstance;
  chartInstance = (SFc5_DCDCconverterInstanceStruct *)chartInstanceVoid;
  c5_b_sfEvent = sf_mex_dup(c5_mxArrayInData);
  c5_identifier = c5_varName;
  c5_thisId.fIdentifier = c5_identifier;
  c5_thisId.fParent = NULL;
  c5_y = c5_emlrt_marshallIn(chartInstance, sf_mex_dup(c5_b_sfEvent), &c5_thisId);
  sf_mex_destroy(&c5_b_sfEvent);
  *(int32_T *)c5_outData = c5_y;
  sf_mex_destroy(&c5_mxArrayInData);
}

static const mxArray *c5_b_sf_marshallOut(void *chartInstanceVoid, void
  *c5_inData)
{
  const mxArray *c5_mxArrayOutData = NULL;
  uint8_T c5_u;
  const mxArray *c5_y = NULL;
  SFc5_DCDCconverterInstanceStruct *chartInstance;
  chartInstance = (SFc5_DCDCconverterInstanceStruct *)chartInstanceVoid;
  c5_mxArrayOutData = NULL;
  c5_u = *(uint8_T *)c5_inData;
  c5_y = NULL;
  sf_mex_assign(&c5_y, sf_mex_create("y", &c5_u, 3, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c5_mxArrayOutData, c5_y, FALSE);
  return c5_mxArrayOutData;
}

static uint8_T c5_b_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_b_tp_Off, const char_T *c5_identifier)
{
  uint8_T c5_y;
  emlrtMsgIdentifier c5_thisId;
  c5_thisId.fIdentifier = c5_identifier;
  c5_thisId.fParent = NULL;
  c5_y = c5_c_emlrt_marshallIn(chartInstance, sf_mex_dup(c5_b_tp_Off),
    &c5_thisId);
  sf_mex_destroy(&c5_b_tp_Off);
  return c5_y;
}

static uint8_T c5_c_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_u, const emlrtMsgIdentifier *c5_parentId)
{
  uint8_T c5_y;
  uint8_T c5_u0;
  sf_mex_import(c5_parentId, sf_mex_dup(c5_u), &c5_u0, 1, 3, 0U, 0, 0U, 0);
  c5_y = c5_u0;
  sf_mex_destroy(&c5_u);
  return c5_y;
}

static void c5_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c5_mxArrayInData, const char_T *c5_varName, void *c5_outData)
{
  const mxArray *c5_b_tp_Off;
  const char_T *c5_identifier;
  emlrtMsgIdentifier c5_thisId;
  uint8_T c5_y;
  SFc5_DCDCconverterInstanceStruct *chartInstance;
  chartInstance = (SFc5_DCDCconverterInstanceStruct *)chartInstanceVoid;
  c5_b_tp_Off = sf_mex_dup(c5_mxArrayInData);
  c5_identifier = c5_varName;
  c5_thisId.fIdentifier = c5_identifier;
  c5_thisId.fParent = NULL;
  c5_y = c5_c_emlrt_marshallIn(chartInstance, sf_mex_dup(c5_b_tp_Off),
    &c5_thisId);
  sf_mex_destroy(&c5_b_tp_Off);
  *(uint8_T *)c5_outData = c5_y;
  sf_mex_destroy(&c5_mxArrayInData);
}

static const mxArray *c5_c_sf_marshallOut(void *chartInstanceVoid, void
  *c5_inData)
{
  const mxArray *c5_mxArrayOutData = NULL;
  real_T c5_u;
  const mxArray *c5_y = NULL;
  SFc5_DCDCconverterInstanceStruct *chartInstance;
  chartInstance = (SFc5_DCDCconverterInstanceStruct *)chartInstanceVoid;
  c5_mxArrayOutData = NULL;
  c5_u = *(real_T *)c5_inData;
  c5_y = NULL;
  sf_mex_assign(&c5_y, sf_mex_create("y", &c5_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c5_mxArrayOutData, c5_y, FALSE);
  return c5_mxArrayOutData;
}

static const mxArray *c5_d_sf_marshallOut(void *chartInstanceVoid, void
  *c5_inData)
{
  const mxArray *c5_mxArrayOutData = NULL;
  boolean_T c5_u;
  const mxArray *c5_y = NULL;
  SFc5_DCDCconverterInstanceStruct *chartInstance;
  chartInstance = (SFc5_DCDCconverterInstanceStruct *)chartInstanceVoid;
  c5_mxArrayOutData = NULL;
  c5_u = *(boolean_T *)c5_inData;
  c5_y = NULL;
  sf_mex_assign(&c5_y, sf_mex_create("y", &c5_u, 11, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c5_mxArrayOutData, c5_y, FALSE);
  return c5_mxArrayOutData;
}

static real_T c5_d_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_IGBT_Top_State, const char_T *c5_identifier)
{
  real_T c5_y;
  emlrtMsgIdentifier c5_thisId;
  c5_thisId.fIdentifier = c5_identifier;
  c5_thisId.fParent = NULL;
  c5_y = c5_e_emlrt_marshallIn(chartInstance, sf_mex_dup(c5_IGBT_Top_State),
    &c5_thisId);
  sf_mex_destroy(&c5_IGBT_Top_State);
  return c5_y;
}

static real_T c5_e_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_u, const emlrtMsgIdentifier *c5_parentId)
{
  real_T c5_y;
  real_T c5_d43;
  sf_mex_import(c5_parentId, sf_mex_dup(c5_u), &c5_d43, 1, 0, 0U, 0, 0U, 0);
  c5_y = c5_d43;
  sf_mex_destroy(&c5_u);
  return c5_y;
}

static void c5_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c5_mxArrayInData, const char_T *c5_varName, void *c5_outData)
{
  const mxArray *c5_IGBT_Top_State;
  const char_T *c5_identifier;
  emlrtMsgIdentifier c5_thisId;
  real_T c5_y;
  SFc5_DCDCconverterInstanceStruct *chartInstance;
  chartInstance = (SFc5_DCDCconverterInstanceStruct *)chartInstanceVoid;
  c5_IGBT_Top_State = sf_mex_dup(c5_mxArrayInData);
  c5_identifier = c5_varName;
  c5_thisId.fIdentifier = c5_identifier;
  c5_thisId.fParent = NULL;
  c5_y = c5_e_emlrt_marshallIn(chartInstance, sf_mex_dup(c5_IGBT_Top_State),
    &c5_thisId);
  sf_mex_destroy(&c5_IGBT_Top_State);
  *(real_T *)c5_outData = c5_y;
  sf_mex_destroy(&c5_mxArrayInData);
}

static boolean_T c5_f_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_AutomaticController, const char_T
  *c5_identifier)
{
  boolean_T c5_y;
  emlrtMsgIdentifier c5_thisId;
  c5_thisId.fIdentifier = c5_identifier;
  c5_thisId.fParent = NULL;
  c5_y = c5_g_emlrt_marshallIn(chartInstance, sf_mex_dup(c5_AutomaticController),
    &c5_thisId);
  sf_mex_destroy(&c5_AutomaticController);
  return c5_y;
}

static boolean_T c5_g_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_u, const emlrtMsgIdentifier *c5_parentId)
{
  boolean_T c5_y;
  boolean_T c5_b7;
  sf_mex_import(c5_parentId, sf_mex_dup(c5_u), &c5_b7, 1, 11, 0U, 0, 0U, 0);
  c5_y = c5_b7;
  sf_mex_destroy(&c5_u);
  return c5_y;
}

static void c5_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c5_mxArrayInData, const char_T *c5_varName, void *c5_outData)
{
  const mxArray *c5_AutomaticController;
  const char_T *c5_identifier;
  emlrtMsgIdentifier c5_thisId;
  boolean_T c5_y;
  SFc5_DCDCconverterInstanceStruct *chartInstance;
  chartInstance = (SFc5_DCDCconverterInstanceStruct *)chartInstanceVoid;
  c5_AutomaticController = sf_mex_dup(c5_mxArrayInData);
  c5_identifier = c5_varName;
  c5_thisId.fIdentifier = c5_identifier;
  c5_thisId.fParent = NULL;
  c5_y = c5_g_emlrt_marshallIn(chartInstance, sf_mex_dup(c5_AutomaticController),
    &c5_thisId);
  sf_mex_destroy(&c5_AutomaticController);
  *(boolean_T *)c5_outData = c5_y;
  sf_mex_destroy(&c5_mxArrayInData);
}

static const mxArray *c5_h_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_b_setSimStateSideEffectsInfo, const char_T
  *c5_identifier)
{
  const mxArray *c5_y = NULL;
  emlrtMsgIdentifier c5_thisId;
  c5_y = NULL;
  c5_thisId.fIdentifier = c5_identifier;
  c5_thisId.fParent = NULL;
  sf_mex_assign(&c5_y, c5_i_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c5_b_setSimStateSideEffectsInfo), &c5_thisId), FALSE);
  sf_mex_destroy(&c5_b_setSimStateSideEffectsInfo);
  return c5_y;
}

static const mxArray *c5_i_emlrt_marshallIn(SFc5_DCDCconverterInstanceStruct
  *chartInstance, const mxArray *c5_u, const emlrtMsgIdentifier *c5_parentId)
{
  const mxArray *c5_y = NULL;
  c5_y = NULL;
  sf_mex_assign(&c5_y, sf_mex_duplicatearraysafe(&c5_u), FALSE);
  sf_mex_destroy(&c5_u);
  return c5_y;
}

static void init_dsm_address_info(SFc5_DCDCconverterInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c5_DCDCconverter_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3346625968U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(2337114793U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(2862397175U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(2012301352U);
}

mxArray *sf_c5_DCDCconverter_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,5,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("jZAUSVZfyGTbRzmCBbwyMB");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,7,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,6,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,6,"type",mxType);
    }

    mxSetField(mxData,6,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,7,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,6,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,6,"type",mxType);
    }

    mxSetField(mxData,6,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxCreateDoubleMatrix(0,0,mxREAL));
  }

  return(mxAutoinheritanceInfo);
}

static const mxArray *sf_get_sim_state_info_c5_DCDCconverter(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x10'type','srcId','name','auxInfo'{{M[1],M[145],T\"AutomaticController\",},{M[1],M[148],T\"BatteryRelay\",},{M[1],M[146],T\"ChargingRelay\",},{M[1],M[147],T\"DischargingRelay\",},{M[1],M[106],T\"IGBT_Bot_State\",},{M[1],M[105],T\"IGBT_Top_State\",},{M[1],M[149],T\"UltracapacitorRelay\",},{M[3],M[160],T\"dVrail_dT_threshold\",},{M[8],M[0],T\"is_active_c5_DCDCconverter\",},{M[9],M[0],T\"is_c5_DCDCconverter\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 10, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c5_DCDCconverter_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc5_DCDCconverterInstanceStruct *chartInstance;
    chartInstance = (SFc5_DCDCconverterInstanceStruct *) ((ChartInfoStruct *)
      (ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_DCDCconverterMachineNumber_,
           5,
           7,
           19,
           15,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation(_DCDCconverterMachineNumber_,
            chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_DCDCconverterMachineNumber_,chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(_DCDCconverterMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,"TurnOnSystem");
          _SFD_SET_DATA_PROPS(1,1,1,0,"EnableAutomaticControl");
          _SFD_SET_DATA_PROPS(2,1,1,0,"ManualControlBuckMode");
          _SFD_SET_DATA_PROPS(3,1,1,0,"Error");
          _SFD_SET_DATA_PROPS(4,2,0,1,"IGBT_Top_State");
          _SFD_SET_DATA_PROPS(5,2,0,1,"IGBT_Bot_State");
          _SFD_SET_DATA_PROPS(6,1,1,0,"Vrail");
          _SFD_SET_DATA_PROPS(7,1,1,0,"dVrail_dT");
          _SFD_SET_DATA_PROPS(8,1,1,0,"Vrail_rated");
          _SFD_SET_DATA_PROPS(9,2,0,1,"AutomaticController");
          _SFD_SET_DATA_PROPS(10,2,0,1,"UltracapacitorRelay");
          _SFD_SET_DATA_PROPS(11,2,0,1,"ChargingRelay");
          _SFD_SET_DATA_PROPS(12,2,0,1,"DischargingRelay");
          _SFD_SET_DATA_PROPS(13,2,0,1,"BatteryRelay");
          _SFD_SET_DATA_PROPS(14,0,0,0,"dVrail_dT_threshold");
          _SFD_STATE_INFO(0,0,0);
          _SFD_STATE_INFO(1,0,0);
          _SFD_STATE_INFO(2,0,0);
          _SFD_STATE_INFO(3,0,0);
          _SFD_STATE_INFO(4,0,0);
          _SFD_STATE_INFO(5,0,0);
          _SFD_STATE_INFO(6,0,0);
          _SFD_CH_SUBSTATE_COUNT(7);
          _SFD_CH_SUBSTATE_DECOMP(0);
          _SFD_CH_SUBSTATE_INDEX(0,0);
          _SFD_CH_SUBSTATE_INDEX(1,1);
          _SFD_CH_SUBSTATE_INDEX(2,2);
          _SFD_CH_SUBSTATE_INDEX(3,3);
          _SFD_CH_SUBSTATE_INDEX(4,4);
          _SFD_CH_SUBSTATE_INDEX(5,5);
          _SFD_CH_SUBSTATE_INDEX(6,6);
          _SFD_ST_SUBSTATE_COUNT(0,0);
          _SFD_ST_SUBSTATE_COUNT(1,0);
          _SFD_ST_SUBSTATE_COUNT(2,0);
          _SFD_ST_SUBSTATE_COUNT(3,0);
          _SFD_ST_SUBSTATE_COUNT(4,0);
          _SFD_ST_SUBSTATE_COUNT(5,0);
          _SFD_ST_SUBSTATE_COUNT(6,0);
        }

        _SFD_CV_INIT_CHART(7,1,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(1,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(2,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(3,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(4,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(5,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(6,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        {
          static unsigned int sStartGuardMap[] = { 1, 30 };

          static unsigned int sEndGuardMap[] = { 26, 67 };

          static int sPostFixPredicateTree[] = { 0, 1, -3 };

          _SFD_CV_INIT_TRANS(9,2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),3,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1, 22 };

          static unsigned int sEndGuardMap[] = { 18, 32 };

          static int sPostFixPredicateTree[] = { 0, 1, -3 };

          _SFD_CV_INIT_TRANS(1,2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),3,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1, 22 };

          static unsigned int sEndGuardMap[] = { 18, 32 };

          static int sPostFixPredicateTree[] = { 0, 1, -3 };

          _SFD_CV_INIT_TRANS(2,2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),3,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1, 15 };

          static unsigned int sEndGuardMap[] = { 11, 32 };

          static int sPostFixPredicateTree[] = { 0, 1, -2 };

          _SFD_CV_INIT_TRANS(18,2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),3,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1, 15 };

          static unsigned int sEndGuardMap[] = { 11, 32 };

          static int sPostFixPredicateTree[] = { 0, 1, -2 };

          _SFD_CV_INIT_TRANS(12,2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),3,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1, 30 };

          static unsigned int sEndGuardMap[] = { 26, 67 };

          static int sPostFixPredicateTree[] = { 0, 1, -3 };

          _SFD_CV_INIT_TRANS(11,2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),3,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1, 15 };

          static unsigned int sEndGuardMap[] = { 11, 32 };

          static int sPostFixPredicateTree[] = { 0, 1, -2 };

          _SFD_CV_INIT_TRANS(13,2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),3,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1, 15 };

          static unsigned int sEndGuardMap[] = { 11, 32 };

          static int sPostFixPredicateTree[] = { 0, 1, -2 };

          _SFD_CV_INIT_TRANS(14,2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),3,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1, 15 };

          static unsigned int sEndGuardMap[] = { 11, 32 };

          static int sPostFixPredicateTree[] = { 0, 1, -2 };

          _SFD_CV_INIT_TRANS(15,2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),3,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1, 36 };

          static unsigned int sEndGuardMap[] = { 28, 62 };

          static int sPostFixPredicateTree[] = { 0, 1, -3 };

          _SFD_CV_INIT_TRANS(17,2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),3,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1, 36 };

          static unsigned int sEndGuardMap[] = { 28, 62 };

          static int sPostFixPredicateTree[] = { 0, 1, -3 };

          _SFD_CV_INIT_TRANS(16,2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),3,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 28 };

          static int sPostFixPredicateTree[] = { 0 };

          _SFD_CV_INIT_TRANS(10,1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),1,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 28 };

          static int sPostFixPredicateTree[] = { 0 };

          _SFD_CV_INIT_TRANS(5,1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),1,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 27 };

          static int sPostFixPredicateTree[] = { 0 };

          _SFD_CV_INIT_TRANS(3,1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),1,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1, 35 };

          static unsigned int sEndGuardMap[] = { 28, 61 };

          static int sPostFixPredicateTree[] = { 0, 1, -3 };

          _SFD_CV_INIT_TRANS(6,2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),3,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 27 };

          static int sPostFixPredicateTree[] = { 0 };

          _SFD_CV_INIT_TRANS(4,1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),1,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1, 32 };

          static unsigned int sEndGuardMap[] = { 28, 58 };

          static int sPostFixPredicateTree[] = { 0, 1, -3 };

          _SFD_CV_INIT_TRANS(8,2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),3,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 28 };

          static int sPostFixPredicateTree[] = { 0 };

          _SFD_CV_INIT_TRANS(7,1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),1,
                             &(sPostFixPredicateTree[0]));
        }

        _SFD_TRANS_COV_WTS(0,0,0,0,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(9,0,2,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1, 30 };

          static unsigned int sEndGuardMap[] = { 26, 67 };

          _SFD_TRANS_COV_MAPS(9,
                              0,NULL,NULL,
                              2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(1,0,2,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1, 22 };

          static unsigned int sEndGuardMap[] = { 18, 32 };

          _SFD_TRANS_COV_MAPS(1,
                              0,NULL,NULL,
                              2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(2,0,2,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1, 22 };

          static unsigned int sEndGuardMap[] = { 18, 32 };

          _SFD_TRANS_COV_MAPS(2,
                              0,NULL,NULL,
                              2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(18,0,2,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1, 15 };

          static unsigned int sEndGuardMap[] = { 11, 32 };

          _SFD_TRANS_COV_MAPS(18,
                              0,NULL,NULL,
                              2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(12,0,2,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1, 15 };

          static unsigned int sEndGuardMap[] = { 11, 32 };

          _SFD_TRANS_COV_MAPS(12,
                              0,NULL,NULL,
                              2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(11,0,2,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1, 30 };

          static unsigned int sEndGuardMap[] = { 26, 67 };

          _SFD_TRANS_COV_MAPS(11,
                              0,NULL,NULL,
                              2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(13,0,2,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1, 15 };

          static unsigned int sEndGuardMap[] = { 11, 32 };

          _SFD_TRANS_COV_MAPS(13,
                              0,NULL,NULL,
                              2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(14,0,2,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1, 15 };

          static unsigned int sEndGuardMap[] = { 11, 32 };

          _SFD_TRANS_COV_MAPS(14,
                              0,NULL,NULL,
                              2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(15,0,2,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1, 15 };

          static unsigned int sEndGuardMap[] = { 11, 32 };

          _SFD_TRANS_COV_MAPS(15,
                              0,NULL,NULL,
                              2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(17,0,2,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1, 36 };

          static unsigned int sEndGuardMap[] = { 28, 62 };

          _SFD_TRANS_COV_MAPS(17,
                              0,NULL,NULL,
                              2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(16,0,2,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1, 36 };

          static unsigned int sEndGuardMap[] = { 28, 62 };

          _SFD_TRANS_COV_MAPS(16,
                              0,NULL,NULL,
                              2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(10,0,1,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 28 };

          _SFD_TRANS_COV_MAPS(10,
                              0,NULL,NULL,
                              1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(5,0,1,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 28 };

          _SFD_TRANS_COV_MAPS(5,
                              0,NULL,NULL,
                              1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(3,0,1,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 27 };

          _SFD_TRANS_COV_MAPS(3,
                              0,NULL,NULL,
                              1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(6,0,2,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1, 35 };

          static unsigned int sEndGuardMap[] = { 28, 61 };

          _SFD_TRANS_COV_MAPS(6,
                              0,NULL,NULL,
                              2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(4,0,1,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 27 };

          _SFD_TRANS_COV_MAPS(4,
                              0,NULL,NULL,
                              1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(8,0,2,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1, 32 };

          static unsigned int sEndGuardMap[] = { 28, 58 };

          _SFD_TRANS_COV_MAPS(8,
                              0,NULL,NULL,
                              2,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_TRANS_COV_WTS(7,0,1,0,0);
        if (chartAlreadyPresent==0) {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 28 };

          _SFD_TRANS_COV_MAPS(7,
                              0,NULL,NULL,
                              1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),
                              0,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_SET_DATA_COMPILED_PROPS(0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(2,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(3,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_d_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(4,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_c_sf_marshallOut,(MexInFcnForType)c5_c_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(5,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_c_sf_marshallOut,(MexInFcnForType)c5_c_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(6,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(7,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(8,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(9,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_d_sf_marshallOut,(MexInFcnForType)c5_d_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(10,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_c_sf_marshallOut,(MexInFcnForType)c5_c_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(11,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_c_sf_marshallOut,(MexInFcnForType)c5_c_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(12,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_c_sf_marshallOut,(MexInFcnForType)c5_c_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(13,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_c_sf_marshallOut,(MexInFcnForType)c5_c_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(14,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c5_c_sf_marshallOut,(MexInFcnForType)c5_c_sf_marshallIn);

        {
          real_T *c5_TurnOnSystem;
          real_T *c5_EnableAutomaticControl;
          real_T *c5_ManualControlBuckMode;
          boolean_T *c5_Error;
          real_T *c5_IGBT_Top_State;
          real_T *c5_IGBT_Bot_State;
          real_T *c5_Vrail;
          real_T *c5_dVrail_dT;
          real_T *c5_Vrail_rated;
          boolean_T *c5_AutomaticController;
          real_T *c5_UltracapacitorRelay;
          real_T *c5_ChargingRelay;
          real_T *c5_DischargingRelay;
          real_T *c5_BatteryRelay;
          c5_BatteryRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
          c5_DischargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S,
            6);
          c5_ChargingRelay = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
          c5_UltracapacitorRelay = (real_T *)ssGetOutputPortSignal
            (chartInstance->S, 4);
          c5_AutomaticController = (boolean_T *)ssGetOutputPortSignal
            (chartInstance->S, 3);
          c5_Vrail_rated = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
          c5_dVrail_dT = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
          c5_Vrail = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
          c5_IGBT_Bot_State = (real_T *)ssGetOutputPortSignal(chartInstance->S,
            2);
          c5_IGBT_Top_State = (real_T *)ssGetOutputPortSignal(chartInstance->S,
            1);
          c5_Error = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 3);
          c5_ManualControlBuckMode = (real_T *)ssGetInputPortSignal
            (chartInstance->S, 2);
          c5_EnableAutomaticControl = (real_T *)ssGetInputPortSignal
            (chartInstance->S, 1);
          c5_TurnOnSystem = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c5_TurnOnSystem);
          _SFD_SET_DATA_VALUE_PTR(1U, c5_EnableAutomaticControl);
          _SFD_SET_DATA_VALUE_PTR(2U, c5_ManualControlBuckMode);
          _SFD_SET_DATA_VALUE_PTR(3U, c5_Error);
          _SFD_SET_DATA_VALUE_PTR(4U, c5_IGBT_Top_State);
          _SFD_SET_DATA_VALUE_PTR(5U, c5_IGBT_Bot_State);
          _SFD_SET_DATA_VALUE_PTR(6U, c5_Vrail);
          _SFD_SET_DATA_VALUE_PTR(7U, c5_dVrail_dT);
          _SFD_SET_DATA_VALUE_PTR(8U, c5_Vrail_rated);
          _SFD_SET_DATA_VALUE_PTR(9U, c5_AutomaticController);
          _SFD_SET_DATA_VALUE_PTR(10U, c5_UltracapacitorRelay);
          _SFD_SET_DATA_VALUE_PTR(11U, c5_ChargingRelay);
          _SFD_SET_DATA_VALUE_PTR(12U, c5_DischargingRelay);
          _SFD_SET_DATA_VALUE_PTR(13U, c5_BatteryRelay);
          _SFD_SET_DATA_VALUE_PTR(14U, &chartInstance->c5_dVrail_dT_threshold);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration(_DCDCconverterMachineNumber_,
        chartInstance->chartNumber,chartInstance->instanceNumber);
    }
  }
}

static const char* sf_get_instance_specialization()
{
  return "pzLnax1mwkp6YXAtZnWLRF";
}

static void sf_opaque_initialize_c5_DCDCconverter(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc5_DCDCconverterInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c5_DCDCconverter((SFc5_DCDCconverterInstanceStruct*)
    chartInstanceVar);
  initialize_c5_DCDCconverter((SFc5_DCDCconverterInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c5_DCDCconverter(void *chartInstanceVar)
{
  enable_c5_DCDCconverter((SFc5_DCDCconverterInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c5_DCDCconverter(void *chartInstanceVar)
{
  disable_c5_DCDCconverter((SFc5_DCDCconverterInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c5_DCDCconverter(void *chartInstanceVar)
{
  sf_c5_DCDCconverter((SFc5_DCDCconverterInstanceStruct*) chartInstanceVar);
}

extern const mxArray* sf_internal_get_sim_state_c5_DCDCconverter(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c5_DCDCconverter
    ((SFc5_DCDCconverterInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c5_DCDCconverter();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

extern void sf_internal_set_sim_state_c5_DCDCconverter(SimStruct* S, const
  mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c5_DCDCconverter();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c5_DCDCconverter((SFc5_DCDCconverterInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static const mxArray* sf_opaque_get_sim_state_c5_DCDCconverter(SimStruct* S)
{
  return sf_internal_get_sim_state_c5_DCDCconverter(S);
}

static void sf_opaque_set_sim_state_c5_DCDCconverter(SimStruct* S, const mxArray
  *st)
{
  sf_internal_set_sim_state_c5_DCDCconverter(S, st);
}

static void sf_opaque_terminate_c5_DCDCconverter(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc5_DCDCconverterInstanceStruct*) chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c5_DCDCconverter((SFc5_DCDCconverterInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }

  unload_DCDCconverter_optimization_info();
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc5_DCDCconverter((SFc5_DCDCconverterInstanceStruct*)
    chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c5_DCDCconverter(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c5_DCDCconverter((SFc5_DCDCconverterInstanceStruct*)
      (((ChartInfoStruct *)ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c5_DCDCconverter(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct = load_DCDCconverter_optimization_info();
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(S,sf_get_instance_specialization(),infoStruct,
      5);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop(S,sf_get_instance_specialization(),
                infoStruct,5,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop(S,
      sf_get_instance_specialization(),infoStruct,5,
      "gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 4, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 5, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 6, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,5,7);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,5,7);
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,5);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(3287453832U));
  ssSetChecksum1(S,(4180363814U));
  ssSetChecksum2(S,(4253945346U));
  ssSetChecksum3(S,(2945011631U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
  ssSupportsMultipleExecInstances(S,1);
}

static void mdlRTW_c5_DCDCconverter(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Stateflow");
  }
}

static void mdlStart_c5_DCDCconverter(SimStruct *S)
{
  SFc5_DCDCconverterInstanceStruct *chartInstance;
  chartInstance = (SFc5_DCDCconverterInstanceStruct *)malloc(sizeof
    (SFc5_DCDCconverterInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc5_DCDCconverterInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 0;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway = sf_opaque_gateway_c5_DCDCconverter;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c5_DCDCconverter;
  chartInstance->chartInfo.terminateChart = sf_opaque_terminate_c5_DCDCconverter;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c5_DCDCconverter;
  chartInstance->chartInfo.disableChart = sf_opaque_disable_c5_DCDCconverter;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c5_DCDCconverter;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c5_DCDCconverter;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c5_DCDCconverter;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c5_DCDCconverter;
  chartInstance->chartInfo.mdlStart = mdlStart_c5_DCDCconverter;
  chartInstance->chartInfo.mdlSetWorkWidths = mdlSetWorkWidths_c5_DCDCconverter;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  init_dsm_address_info(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  sf_opaque_init_subchart_simstructs(chartInstance->chartInfo.chartInstance);
  chart_debug_initialization(S,1);
}

void c5_DCDCconverter_method_dispatcher(SimStruct *S, int_T method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c5_DCDCconverter(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c5_DCDCconverter(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c5_DCDCconverter(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c5_DCDCconverter_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
