#ifndef __c2_DCDCconverter_h__
#define __c2_DCDCconverter_h__

/* Include files */
#include "sfc_sf.h"
#include "sfc_mex.h"
#include "rtwtypes.h"

/* Type Definitions */
#ifndef typedef_c2_ResolvedFunctionInfo
#define typedef_c2_ResolvedFunctionInfo

typedef struct {
  const char * context;
  const char * name;
  const char * dominantType;
  const char * resolved;
  uint32_T fileTimeLo;
  uint32_T fileTimeHi;
  uint32_T mFileTimeLo;
  uint32_T mFileTimeHi;
} c2_ResolvedFunctionInfo;

#endif                                 /*typedef_c2_ResolvedFunctionInfo*/

#ifndef typedef_SFc2_DCDCconverterInstanceStruct
#define typedef_SFc2_DCDCconverterInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  int32_T c2_sfEvent;
  boolean_T c2_isStable;
  boolean_T c2_doneDoubleBufferReInit;
  uint8_T c2_is_active_c2_DCDCconverter;
  real_T c2_LLBatCurrentAlert;
  boolean_T c2_LLBatCurrentAlert_not_empty;
  real_T c2_LLUCCurrentAlert;
  boolean_T c2_LLUCCurrentAlert_not_empty;
  real_T c2_LLBatVoltageAlert;
  boolean_T c2_LLBatVoltageAlert_not_empty;
  real_T c2_LLUCVoltageAlert;
  boolean_T c2_LLUCVoltageAlert_not_empty;
  real_T c2_LLTempAlert;
  boolean_T c2_LLTempAlert_not_empty;
  real_T c2_LLErrorHB1;
  boolean_T c2_LLErrorHB1_not_empty;
  real_T c2_LLErrorHB2;
  boolean_T c2_LLErrorHB2_not_empty;
  real_T c2_LLErrorHB3;
  boolean_T c2_LLErrorHB3_not_empty;
  real_T c2_LLOverTemp;
  boolean_T c2_LLOverTemp_not_empty;
} SFc2_DCDCconverterInstanceStruct;

#endif                                 /*typedef_SFc2_DCDCconverterInstanceStruct*/

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c2_DCDCconverter_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c2_DCDCconverter_get_check_sum(mxArray *plhs[]);
extern void c2_DCDCconverter_method_dispatcher(SimStruct *S, int_T method, void *
  data);

#endif
