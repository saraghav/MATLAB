  /*********************** dSPACE target specific file *************************

   Header file DCDCconverter_trc_ptr.h:

   Declaration of function that initializes the global TRC pointers

   RTI1103 7.1 (02-Nov-2013)
   Wed Sep 09 09:52:03 2015

   (c) Copyright 2008, dSPACE GmbH. All rights reserved.

  *****************************************************************************/
  #ifndef RTI_HEADER_DCDCconverter_trc_ptr_h_
  #define RTI_HEADER_DCDCconverter_trc_ptr_h_
  /* Include the model header file. */
  #include "DCDCconverter.h"
  #include "DCDCconverter_private.h"

  #ifdef EXTERN_C
  #undef EXTERN_C
  #endif

  #ifdef __cplusplus
  #define EXTERN_C                       extern "C"
  #else
  #define EXTERN_C                       extern
  #endif

  /*
   *  Declare the global TRC pointers
   */
              EXTERN_C volatile  real_T *p_DCDCconverter_B_real_T_0;
              EXTERN_C volatile  boolean_T *p_DCDCconverter_B_boolean_T_1;
              EXTERN_C volatile  real_T *p_DCDCconverter_B_real_T_2;
              EXTERN_C volatile  real_T *p_DCDCconverter_B_real_T_3;
              EXTERN_C volatile  real_T *p_DCDCconverter_B_real_T_4;
              EXTERN_C volatile  real_T *p_DCDCconverter_B_real_T_5;
              EXTERN_C volatile  real_T *p_DCDCconverter_B_real_T_6;
              EXTERN_C volatile  real_T *p_DCDCconverter_P_real_T_0;
              EXTERN_C volatile  uint32_T *p_DCDCconverter_P_uint32_T_1;
              EXTERN_C volatile  boolean_T *p_DCDCconverter_P_boolean_T_2;
              EXTERN_C volatile  real_T *p_DCDCconverter_P_real_T_3;
              EXTERN_C volatile  real_T *p_DCDCconverter_P_real_T_4;
              EXTERN_C volatile  real_T *p_DCDCconverter_P_real_T_5;
              EXTERN_C volatile  real_T *p_DCDCconverter_P_real_T_6;
              EXTERN_C volatile  real_T *p_DCDCconverter_P_real_T_7;
              EXTERN_C volatile  real_T *p_DCDCconverter_DWork_real_T_0;
              EXTERN_C volatile  int32_T *p_DCDCconverter_DWork_int32_T_1;
              EXTERN_C volatile  uint32_T *p_DCDCconverter_DWork_uint32_T_2;
              EXTERN_C volatile  int_T *p_DCDCconverter_DWork_int_T_3;
              EXTERN_C volatile  boolean_T *p_DCDCconverter_DWork_boolean_T_4;
              EXTERN_C volatile  int8_T *p_DCDCconverter_DWork_int8_T_5;
              EXTERN_C volatile  uint8_T *p_DCDCconverter_DWork_uint8_T_6;
              EXTERN_C volatile  boolean_T *p_DCDCconverter_DWork_boolean_T_7;

   #define RTI_INIT_TRC_POINTERS() \
              p_DCDCconverter_B_real_T_0 = &DCDCconverter_B.SFunction;\
              p_DCDCconverter_B_boolean_T_1 = &DCDCconverter_B.Delay3;\
              p_DCDCconverter_B_real_T_2 = &DCDCconverter_B.SampleandHold_o.In;\
              p_DCDCconverter_B_real_T_3 = &DCDCconverter_B.SampleandHold_dv.In;\
              p_DCDCconverter_B_real_T_4 = &DCDCconverter_B.SampleandHold_du.In;\
              p_DCDCconverter_B_real_T_5 = &DCDCconverter_B.SampleandHold_d.In;\
              p_DCDCconverter_B_real_T_6 = &DCDCconverter_B.SampleandHold.In;\
              p_DCDCconverter_P_real_T_0 = &DCDCconverter_P.DutyCycleTop_Value;\
              p_DCDCconverter_P_uint32_T_1 = &DCDCconverter_P.DLookupTable_maxIndex[0];\
              p_DCDCconverter_P_boolean_T_2 = &DCDCconverter_P.Delay3_InitialCondition;\
              p_DCDCconverter_P_real_T_3 = &DCDCconverter_P.SampleandHold_o._Y0;\
              p_DCDCconverter_P_real_T_4 = &DCDCconverter_P.SampleandHold_dv._Y0;\
              p_DCDCconverter_P_real_T_5 = &DCDCconverter_P.SampleandHold_du._Y0;\
              p_DCDCconverter_P_real_T_6 = &DCDCconverter_P.SampleandHold_d._Y0;\
              p_DCDCconverter_P_real_T_7 = &DCDCconverter_P.SampleandHold._Y0;\
              p_DCDCconverter_DWork_real_T_0 = &DCDCconverter_DWork.GeneratedFilterBlock_states[0];\
              p_DCDCconverter_DWork_int32_T_1 = &DCDCconverter_DWork.GeneratedFilterBlock_circBuf;\
              p_DCDCconverter_DWork_uint32_T_2 = &DCDCconverter_DWork.RandSeed;\
              p_DCDCconverter_DWork_int_T_3 = &DCDCconverter_DWork.SFunction1_IWORK[0];\
              p_DCDCconverter_DWork_boolean_T_4 = &DCDCconverter_DWork.Delay3_DSTATE[0];\
              p_DCDCconverter_DWork_int8_T_5 = &DCDCconverter_DWork.DiscreteTimeIntegrator_PrevRese;\
              p_DCDCconverter_DWork_uint8_T_6 = &DCDCconverter_DWork.is_active_c5_DCDCconverter;\
              p_DCDCconverter_DWork_boolean_T_7 = &DCDCconverter_DWork.Memory3_PreviousInput;\

   #endif                       /* RTI_HEADER_DCDCconverter_trc_ptr_h_ */
