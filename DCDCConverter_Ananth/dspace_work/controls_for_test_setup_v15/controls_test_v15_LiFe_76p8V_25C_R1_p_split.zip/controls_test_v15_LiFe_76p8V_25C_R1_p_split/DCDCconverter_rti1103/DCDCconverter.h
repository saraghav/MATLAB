/*
 * DCDCconverter.h
 *
 * Code generation for model "DCDCconverter".
 *
 * Model version              : 1.403
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Wed Sep 09 10:48:56 2015
 *
 * Target selection: rti1103.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_DCDCconverter_h_
#define RTW_HEADER_DCDCconverter_h_
#ifndef DCDCconverter_COMMON_INCLUDES_
# define DCDCconverter_COMMON_INCLUDES_
#include <brtenv.h>
#include <rtkernel.h>
#include <rti_assert.h>
#include <rtidefineddatatypes.h>
#include <def1103.h>
#include <slvdsp1103.h>
#include <rti_slv1103.h>
#include <math.h>
#include <string.h>
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rtGetInf.h"
#include "rtGetNaN.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
#include "rt_zcfcn.h"
#endif                                 /* DCDCconverter_COMMON_INCLUDES_ */

#include "DCDCconverter_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetBlkStateChangeFlag
# define rtmGetBlkStateChangeFlag(rtm) ((rtm)->ModelData.blkStateChange)
#endif

#ifndef rtmSetBlkStateChangeFlag
# define rtmSetBlkStateChangeFlag(rtm, val) ((rtm)->ModelData.blkStateChange = (val))
#endif

#ifndef rtmGetBlockIO
# define rtmGetBlockIO(rtm)            ((rtm)->ModelData.blockIO)
#endif

#ifndef rtmSetBlockIO
# define rtmSetBlockIO(rtm, val)       ((rtm)->ModelData.blockIO = (val))
#endif

#ifndef rtmGetChecksums
# define rtmGetChecksums(rtm)          ((rtm)->Sizes.checksums)
#endif

#ifndef rtmSetChecksums
# define rtmSetChecksums(rtm, val)     ((rtm)->Sizes.checksums = (val))
#endif

#ifndef rtmGetConstBlockIO
# define rtmGetConstBlockIO(rtm)       ((rtm)->ModelData.constBlockIO)
#endif

#ifndef rtmSetConstBlockIO
# define rtmSetConstBlockIO(rtm, val)  ((rtm)->ModelData.constBlockIO = (val))
#endif

#ifndef rtmGetContStateDisabled
# define rtmGetContStateDisabled(rtm)  ((rtm)->ModelData.contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
# define rtmSetContStateDisabled(rtm, val) ((rtm)->ModelData.contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
# define rtmGetContStates(rtm)         ((rtm)->ModelData.contStates)
#endif

#ifndef rtmSetContStates
# define rtmSetContStates(rtm, val)    ((rtm)->ModelData.contStates = (val))
#endif

#ifndef rtmGetDataMapInfo
# define rtmGetDataMapInfo(rtm)        ()
#endif

#ifndef rtmSetDataMapInfo
# define rtmSetDataMapInfo(rtm, val)   ()
#endif

#ifndef rtmGetDefaultParam
# define rtmGetDefaultParam(rtm)       ((rtm)->ModelData.defaultParam)
#endif

#ifndef rtmSetDefaultParam
# define rtmSetDefaultParam(rtm, val)  ((rtm)->ModelData.defaultParam = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
# define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->ModelData.derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
# define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->ModelData.derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetDirectFeedThrough
# define rtmGetDirectFeedThrough(rtm)  ((rtm)->Sizes.sysDirFeedThru)
#endif

#ifndef rtmSetDirectFeedThrough
# define rtmSetDirectFeedThrough(rtm, val) ((rtm)->Sizes.sysDirFeedThru = (val))
#endif

#ifndef rtmGetErrorStatusFlag
# define rtmGetErrorStatusFlag(rtm)    ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatusFlag
# define rtmSetErrorStatusFlag(rtm, val) ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetFinalTime
# define rtmSetFinalTime(rtm, val)     ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetFirstInitCondFlag
# define rtmGetFirstInitCondFlag(rtm)  ()
#endif

#ifndef rtmSetFirstInitCondFlag
# define rtmSetFirstInitCondFlag(rtm, val) ()
#endif

#ifndef rtmGetIntgData
# define rtmGetIntgData(rtm)           ()
#endif

#ifndef rtmSetIntgData
# define rtmSetIntgData(rtm, val)      ()
#endif

#ifndef rtmGetMdlRefGlobalTID
# define rtmGetMdlRefGlobalTID(rtm)    ()
#endif

#ifndef rtmSetMdlRefGlobalTID
# define rtmSetMdlRefGlobalTID(rtm, val) ()
#endif

#ifndef rtmGetMdlRefTriggerTID
# define rtmGetMdlRefTriggerTID(rtm)   ()
#endif

#ifndef rtmSetMdlRefTriggerTID
# define rtmSetMdlRefTriggerTID(rtm, val) ()
#endif

#ifndef rtmGetModelMappingInfo
# define rtmGetModelMappingInfo(rtm)   ((rtm)->SpecialInfo.mappingInfo)
#endif

#ifndef rtmSetModelMappingInfo
# define rtmSetModelMappingInfo(rtm, val) ((rtm)->SpecialInfo.mappingInfo = (val))
#endif

#ifndef rtmGetModelName
# define rtmGetModelName(rtm)          ((rtm)->modelName)
#endif

#ifndef rtmSetModelName
# define rtmSetModelName(rtm, val)     ((rtm)->modelName = (val))
#endif

#ifndef rtmGetNonInlinedSFcns
# define rtmGetNonInlinedSFcns(rtm)    ()
#endif

#ifndef rtmSetNonInlinedSFcns
# define rtmSetNonInlinedSFcns(rtm, val) ()
#endif

#ifndef rtmGetNumBlockIO
# define rtmGetNumBlockIO(rtm)         ((rtm)->Sizes.numBlockIO)
#endif

#ifndef rtmSetNumBlockIO
# define rtmSetNumBlockIO(rtm, val)    ((rtm)->Sizes.numBlockIO = (val))
#endif

#ifndef rtmGetNumBlockParams
# define rtmGetNumBlockParams(rtm)     ((rtm)->Sizes.numBlockPrms)
#endif

#ifndef rtmSetNumBlockParams
# define rtmSetNumBlockParams(rtm, val) ((rtm)->Sizes.numBlockPrms = (val))
#endif

#ifndef rtmGetNumBlocks
# define rtmGetNumBlocks(rtm)          ((rtm)->Sizes.numBlocks)
#endif

#ifndef rtmSetNumBlocks
# define rtmSetNumBlocks(rtm, val)     ((rtm)->Sizes.numBlocks = (val))
#endif

#ifndef rtmGetNumContStates
# define rtmGetNumContStates(rtm)      ((rtm)->Sizes.numContStates)
#endif

#ifndef rtmSetNumContStates
# define rtmSetNumContStates(rtm, val) ((rtm)->Sizes.numContStates = (val))
#endif

#ifndef rtmGetNumDWork
# define rtmGetNumDWork(rtm)           ((rtm)->Sizes.numDwork)
#endif

#ifndef rtmSetNumDWork
# define rtmSetNumDWork(rtm, val)      ((rtm)->Sizes.numDwork = (val))
#endif

#ifndef rtmGetNumInputPorts
# define rtmGetNumInputPorts(rtm)      ((rtm)->Sizes.numIports)
#endif

#ifndef rtmSetNumInputPorts
# define rtmSetNumInputPorts(rtm, val) ((rtm)->Sizes.numIports = (val))
#endif

#ifndef rtmGetNumNonSampledZCs
# define rtmGetNumNonSampledZCs(rtm)   ((rtm)->Sizes.numNonSampZCs)
#endif

#ifndef rtmSetNumNonSampledZCs
# define rtmSetNumNonSampledZCs(rtm, val) ((rtm)->Sizes.numNonSampZCs = (val))
#endif

#ifndef rtmGetNumOutputPorts
# define rtmGetNumOutputPorts(rtm)     ((rtm)->Sizes.numOports)
#endif

#ifndef rtmSetNumOutputPorts
# define rtmSetNumOutputPorts(rtm, val) ((rtm)->Sizes.numOports = (val))
#endif

#ifndef rtmGetNumSFcnParams
# define rtmGetNumSFcnParams(rtm)      ((rtm)->Sizes.numSFcnPrms)
#endif

#ifndef rtmSetNumSFcnParams
# define rtmSetNumSFcnParams(rtm, val) ((rtm)->Sizes.numSFcnPrms = (val))
#endif

#ifndef rtmGetNumSFunctions
# define rtmGetNumSFunctions(rtm)      ((rtm)->Sizes.numSFcns)
#endif

#ifndef rtmSetNumSFunctions
# define rtmSetNumSFunctions(rtm, val) ((rtm)->Sizes.numSFcns = (val))
#endif

#ifndef rtmGetNumSampleTimes
# define rtmGetNumSampleTimes(rtm)     ((rtm)->Sizes.numSampTimes)
#endif

#ifndef rtmSetNumSampleTimes
# define rtmSetNumSampleTimes(rtm, val) ((rtm)->Sizes.numSampTimes = (val))
#endif

#ifndef rtmGetNumU
# define rtmGetNumU(rtm)               ((rtm)->Sizes.numU)
#endif

#ifndef rtmSetNumU
# define rtmSetNumU(rtm, val)          ((rtm)->Sizes.numU = (val))
#endif

#ifndef rtmGetNumY
# define rtmGetNumY(rtm)               ((rtm)->Sizes.numY)
#endif

#ifndef rtmSetNumY
# define rtmSetNumY(rtm, val)          ((rtm)->Sizes.numY = (val))
#endif

#ifndef rtmGetOdeF
# define rtmGetOdeF(rtm)               ()
#endif

#ifndef rtmSetOdeF
# define rtmSetOdeF(rtm, val)          ()
#endif

#ifndef rtmGetOdeY
# define rtmGetOdeY(rtm)               ()
#endif

#ifndef rtmSetOdeY
# define rtmSetOdeY(rtm, val)          ()
#endif

#ifndef rtmGetOffsetTimeArray
# define rtmGetOffsetTimeArray(rtm)    ((rtm)->Timing.offsetTimesArray)
#endif

#ifndef rtmSetOffsetTimeArray
# define rtmSetOffsetTimeArray(rtm, val) ((rtm)->Timing.offsetTimesArray = (val))
#endif

#ifndef rtmGetOffsetTimePtr
# define rtmGetOffsetTimePtr(rtm)      ((rtm)->Timing.offsetTimes)
#endif

#ifndef rtmSetOffsetTimePtr
# define rtmSetOffsetTimePtr(rtm, val) ((rtm)->Timing.offsetTimes = (val))
#endif

#ifndef rtmGetOptions
# define rtmGetOptions(rtm)            ((rtm)->Sizes.options)
#endif

#ifndef rtmSetOptions
# define rtmSetOptions(rtm, val)       ((rtm)->Sizes.options = (val))
#endif

#ifndef rtmGetParamIsMalloced
# define rtmGetParamIsMalloced(rtm)    ()
#endif

#ifndef rtmSetParamIsMalloced
# define rtmSetParamIsMalloced(rtm, val) ()
#endif

#ifndef rtmGetPath
# define rtmGetPath(rtm)               ((rtm)->path)
#endif

#ifndef rtmSetPath
# define rtmSetPath(rtm, val)          ((rtm)->path = (val))
#endif

#ifndef rtmGetPerTaskSampleHits
# define rtmGetPerTaskSampleHits(rtm)  ()
#endif

#ifndef rtmSetPerTaskSampleHits
# define rtmSetPerTaskSampleHits(rtm, val) ()
#endif

#ifndef rtmGetPerTaskSampleHitsArray
# define rtmGetPerTaskSampleHitsArray(rtm) ((rtm)->Timing.perTaskSampleHitsArray)
#endif

#ifndef rtmSetPerTaskSampleHitsArray
# define rtmSetPerTaskSampleHitsArray(rtm, val) ((rtm)->Timing.perTaskSampleHitsArray = (val))
#endif

#ifndef rtmGetPerTaskSampleHitsPtr
# define rtmGetPerTaskSampleHitsPtr(rtm) ((rtm)->Timing.perTaskSampleHits)
#endif

#ifndef rtmSetPerTaskSampleHitsPtr
# define rtmSetPerTaskSampleHitsPtr(rtm, val) ((rtm)->Timing.perTaskSampleHits = (val))
#endif

#ifndef rtmGetPrevZCSigState
# define rtmGetPrevZCSigState(rtm)     ((rtm)->ModelData.prevZCSigState)
#endif

#ifndef rtmSetPrevZCSigState
# define rtmSetPrevZCSigState(rtm, val) ((rtm)->ModelData.prevZCSigState = (val))
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmSetRTWExtModeInfo
# define rtmSetRTWExtModeInfo(rtm, val) ((rtm)->extModeInfo = (val))
#endif

#ifndef rtmGetRTWGeneratedSFcn
# define rtmGetRTWGeneratedSFcn(rtm)   ((rtm)->Sizes.rtwGenSfcn)
#endif

#ifndef rtmSetRTWGeneratedSFcn
# define rtmSetRTWGeneratedSFcn(rtm, val) ((rtm)->Sizes.rtwGenSfcn = (val))
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ()
#endif

#ifndef rtmSetRTWLogInfo
# define rtmSetRTWLogInfo(rtm, val)    ()
#endif

#ifndef rtmGetRTWRTModelMethodsInfo
# define rtmGetRTWRTModelMethodsInfo(rtm) ()
#endif

#ifndef rtmSetRTWRTModelMethodsInfo
# define rtmSetRTWRTModelMethodsInfo(rtm, val) ()
#endif

#ifndef rtmGetRTWSfcnInfo
# define rtmGetRTWSfcnInfo(rtm)        ((rtm)->sfcnInfo)
#endif

#ifndef rtmSetRTWSfcnInfo
# define rtmSetRTWSfcnInfo(rtm, val)   ((rtm)->sfcnInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfo
# define rtmGetRTWSolverInfo(rtm)      ((rtm)->solverInfo)
#endif

#ifndef rtmSetRTWSolverInfo
# define rtmSetRTWSolverInfo(rtm, val) ((rtm)->solverInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfoPtr
# define rtmGetRTWSolverInfoPtr(rtm)   ((rtm)->solverInfoPtr)
#endif

#ifndef rtmSetRTWSolverInfoPtr
# define rtmSetRTWSolverInfoPtr(rtm, val) ((rtm)->solverInfoPtr = (val))
#endif

#ifndef rtmGetReservedForXPC
# define rtmGetReservedForXPC(rtm)     ((rtm)->SpecialInfo.xpcData)
#endif

#ifndef rtmSetReservedForXPC
# define rtmSetReservedForXPC(rtm, val) ((rtm)->SpecialInfo.xpcData = (val))
#endif

#ifndef rtmGetRootDWork
# define rtmGetRootDWork(rtm)          ((rtm)->Work.dwork)
#endif

#ifndef rtmSetRootDWork
# define rtmSetRootDWork(rtm, val)     ((rtm)->Work.dwork = (val))
#endif

#ifndef rtmGetSFunctions
# define rtmGetSFunctions(rtm)         ((rtm)->childSfunctions)
#endif

#ifndef rtmSetSFunctions
# define rtmSetSFunctions(rtm, val)    ((rtm)->childSfunctions = (val))
#endif

#ifndef rtmGetSampleHitArray
# define rtmGetSampleHitArray(rtm)     ((rtm)->Timing.sampleHitArray)
#endif

#ifndef rtmSetSampleHitArray
# define rtmSetSampleHitArray(rtm, val) ((rtm)->Timing.sampleHitArray = (val))
#endif

#ifndef rtmGetSampleHitPtr
# define rtmGetSampleHitPtr(rtm)       ((rtm)->Timing.sampleHits)
#endif

#ifndef rtmSetSampleHitPtr
# define rtmSetSampleHitPtr(rtm, val)  ((rtm)->Timing.sampleHits = (val))
#endif

#ifndef rtmGetSampleTimeArray
# define rtmGetSampleTimeArray(rtm)    ((rtm)->Timing.sampleTimesArray)
#endif

#ifndef rtmSetSampleTimeArray
# define rtmSetSampleTimeArray(rtm, val) ((rtm)->Timing.sampleTimesArray = (val))
#endif

#ifndef rtmGetSampleTimePtr
# define rtmGetSampleTimePtr(rtm)      ((rtm)->Timing.sampleTimes)
#endif

#ifndef rtmSetSampleTimePtr
# define rtmSetSampleTimePtr(rtm, val) ((rtm)->Timing.sampleTimes = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDArray
# define rtmGetSampleTimeTaskIDArray(rtm) ((rtm)->Timing.sampleTimeTaskIDArray)
#endif

#ifndef rtmSetSampleTimeTaskIDArray
# define rtmSetSampleTimeTaskIDArray(rtm, val) ((rtm)->Timing.sampleTimeTaskIDArray = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDPtr
# define rtmGetSampleTimeTaskIDPtr(rtm) ((rtm)->Timing.sampleTimeTaskIDPtr)
#endif

#ifndef rtmSetSampleTimeTaskIDPtr
# define rtmSetSampleTimeTaskIDPtr(rtm, val) ((rtm)->Timing.sampleTimeTaskIDPtr = (val))
#endif

#ifndef rtmGetSimMode
# define rtmGetSimMode(rtm)            ((rtm)->simMode)
#endif

#ifndef rtmSetSimMode
# define rtmSetSimMode(rtm, val)       ((rtm)->simMode = (val))
#endif

#ifndef rtmGetSimTimeStep
# define rtmGetSimTimeStep(rtm)        ((rtm)->Timing.simTimeStep)
#endif

#ifndef rtmSetSimTimeStep
# define rtmSetSimTimeStep(rtm, val)   ((rtm)->Timing.simTimeStep = (val))
#endif

#ifndef rtmGetStartTime
# define rtmGetStartTime(rtm)          ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetStartTime
# define rtmSetStartTime(rtm, val)     ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmGetStepSize
# define rtmGetStepSize(rtm)           ((rtm)->Timing.stepSize)
#endif

#ifndef rtmSetStepSize
# define rtmSetStepSize(rtm, val)      ((rtm)->Timing.stepSize = (val))
#endif

#ifndef rtmGetStopRequestedFlag
# define rtmGetStopRequestedFlag(rtm)  ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequestedFlag
# define rtmSetStopRequestedFlag(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetTaskCounters
# define rtmGetTaskCounters(rtm)       ((rtm)->Timing.TaskCounters)
#endif

#ifndef rtmSetTaskCounters
# define rtmSetTaskCounters(rtm, val)  ((rtm)->Timing.TaskCounters = (val))
#endif

#ifndef rtmGetTaskTimeArray
# define rtmGetTaskTimeArray(rtm)      ((rtm)->Timing.tArray)
#endif

#ifndef rtmSetTaskTimeArray
# define rtmSetTaskTimeArray(rtm, val) ((rtm)->Timing.tArray = (val))
#endif

#ifndef rtmGetTimePtr
# define rtmGetTimePtr(rtm)            ((rtm)->Timing.t)
#endif

#ifndef rtmSetTimePtr
# define rtmSetTimePtr(rtm, val)       ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTimingData
# define rtmGetTimingData(rtm)         ((rtm)->Timing.timingData)
#endif

#ifndef rtmSetTimingData
# define rtmSetTimingData(rtm, val)    ((rtm)->Timing.timingData = (val))
#endif

#ifndef rtmGetU
# define rtmGetU(rtm)                  ((rtm)->ModelData.inputs)
#endif

#ifndef rtmSetU
# define rtmSetU(rtm, val)             ((rtm)->ModelData.inputs = (val))
#endif

#ifndef rtmGetVarNextHitTimesListPtr
# define rtmGetVarNextHitTimesListPtr(rtm) ((rtm)->Timing.varNextHitTimesList)
#endif

#ifndef rtmSetVarNextHitTimesListPtr
# define rtmSetVarNextHitTimesListPtr(rtm, val) ((rtm)->Timing.varNextHitTimesList = (val))
#endif

#ifndef rtmGetY
# define rtmGetY(rtm)                  ((rtm)->ModelData.outputs)
#endif

#ifndef rtmSetY
# define rtmSetY(rtm, val)             ((rtm)->ModelData.outputs = (val))
#endif

#ifndef rtmGetZCCacheNeedsReset
# define rtmGetZCCacheNeedsReset(rtm)  ((rtm)->ModelData.zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
# define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->ModelData.zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetZCSignalValues
# define rtmGetZCSignalValues(rtm)     ((rtm)->ModelData.zcSignalValues)
#endif

#ifndef rtmSetZCSignalValues
# define rtmSetZCSignalValues(rtm, val) ((rtm)->ModelData.zcSignalValues = (val))
#endif

#ifndef rtmGet_TimeOfLastOutput
# define rtmGet_TimeOfLastOutput(rtm)  ((rtm)->Timing.timeOfLastOutput)
#endif

#ifndef rtmSet_TimeOfLastOutput
# define rtmSet_TimeOfLastOutput(rtm, val) ((rtm)->Timing.timeOfLastOutput = (val))
#endif

#ifndef rtmGetdX
# define rtmGetdX(rtm)                 ((rtm)->ModelData.derivs)
#endif

#ifndef rtmSetdX
# define rtmSetdX(rtm, val)            ((rtm)->ModelData.derivs = (val))
#endif

#ifndef rtmGetChecksumVal
# define rtmGetChecksumVal(rtm, idx)   ((rtm)->Sizes.checksums[idx])
#endif

#ifndef rtmSetChecksumVal
# define rtmSetChecksumVal(rtm, idx, val) ((rtm)->Sizes.checksums[idx] = (val))
#endif

#ifndef rtmGetDWork
# define rtmGetDWork(rtm, idx)         ((rtm)->Work.dwork[idx])
#endif

#ifndef rtmSetDWork
# define rtmSetDWork(rtm, idx, val)    ((rtm)->Work.dwork[idx] = (val))
#endif

#ifndef rtmGetOffsetTime
# define rtmGetOffsetTime(rtm, idx)    ((rtm)->Timing.offsetTimes[idx])
#endif

#ifndef rtmSetOffsetTime
# define rtmSetOffsetTime(rtm, idx, val) ((rtm)->Timing.offsetTimes[idx] = (val))
#endif

#ifndef rtmGetSFunction
# define rtmGetSFunction(rtm, idx)     ((rtm)->childSfunctions[idx])
#endif

#ifndef rtmSetSFunction
# define rtmSetSFunction(rtm, idx, val) ((rtm)->childSfunctions[idx] = (val))
#endif

#ifndef rtmGetSampleTime
# define rtmGetSampleTime(rtm, idx)    ((rtm)->Timing.sampleTimes[idx])
#endif

#ifndef rtmSetSampleTime
# define rtmSetSampleTime(rtm, idx, val) ((rtm)->Timing.sampleTimes[idx] = (val))
#endif

#ifndef rtmGetSampleTimeTaskID
# define rtmGetSampleTimeTaskID(rtm, idx) ((rtm)->Timing.sampleTimeTaskIDPtr[idx])
#endif

#ifndef rtmSetSampleTimeTaskID
# define rtmSetSampleTimeTaskID(rtm, idx, val) ((rtm)->Timing.sampleTimeTaskIDPtr[idx] = (val))
#endif

#ifndef rtmGetVarNextHitTimeList
# define rtmGetVarNextHitTimeList(rtm, idx) ((rtm)->Timing.varNextHitTimesList[idx])
#endif

#ifndef rtmSetVarNextHitTimeList
# define rtmSetVarNextHitTimeList(rtm, idx, val) ((rtm)->Timing.varNextHitTimesList[idx] = (val))
#endif

#ifndef rtmIsContinuousTask
# define rtmIsContinuousTask(rtm, tid) ((tid) <= 1)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmIsMajorTimeStep
# define rtmIsMajorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
# define rtmIsMinorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmIsSampleHit
# define rtmIsSampleHit(rtm, sti, tid) (((rtm)->Timing.sampleTimeTaskIDPtr[sti] == (tid)))
#endif

#ifndef rtmStepTask
# define rtmStepTask(rtm, idx)         ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmSetT
# define rtmSetT(rtm, val)                                       /* Do Nothing */
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetTFinal
# define rtmSetTFinal(rtm, val)        ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

#ifndef rtmSetTPtr
# define rtmSetTPtr(rtm, val)          ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTStart
# define rtmGetTStart(rtm)             ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetTStart
# define rtmSetTStart(rtm, val)        ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmTaskCounter
# define rtmTaskCounter(rtm, idx)      ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

#ifndef rtmGetTaskTime
# define rtmGetTaskTime(rtm, sti)      (rtmGetTPtr((rtm))[(rtm)->Timing.sampleTimeTaskIDPtr[sti]])
#endif

#ifndef rtmSetTaskTime
# define rtmSetTaskTime(rtm, sti, val) (rtmGetTPtr((rtm))[sti] = (val))
#endif

#ifndef rtmGetTimeOfLastOutput
# define rtmGetTimeOfLastOutput(rtm)   ((rtm)->Timing.timeOfLastOutput)
#endif

#ifdef rtmGetRTWSolverInfo
#undef rtmGetRTWSolverInfo
#endif

#define rtmGetRTWSolverInfo(rtm)       &((rtm)->solverInfo)

/* Definition for use in the target main file */
#define DCDCconverter_rtModel          RT_MODEL_DCDCconverter

/* Block signals for system '<S36>/Sample and Hold' */
typedef struct {
  real_T In;                           /* '<S43>/In' */
} rtB_SampleandHold_DCDCconverter;

/* Zero-crossing (trigger) state for system '<S36>/Sample and Hold' */
typedef struct {
  ZCSigState SampleandHold_Trig_ZCE;   /* '<S36>/Sample and Hold' */
} rtZCE_SampleandHold_DCDCconvert;

/* Block signals (auto storage) */
typedef struct {
  real_T SFunction;                    /* '<S41>/S-Function' */
  real_T GeneratedFilterBlock;         /* '<S42>/Generated Filter Block' */
  real_T DataStoreRead;                /* '<S36>/Data Store Read' */
  real_T Add;                          /* '<S36>/Add' */
  real_T CurrentSensorScaling;         /* '<S36>/Current Sensor Scaling' */
  real_T SFunction_k;                  /* '<S44>/S-Function' */
  real_T GeneratedFilterBlock_m;       /* '<S45>/Generated Filter Block' */
  real_T DataStoreRead_p;              /* '<S37>/Data Store Read' */
  real_T Add_d;                        /* '<S37>/Add' */
  real_T VoltageSensorScaling;         /* '<S37>/Voltage Sensor Scaling' */
  real_T SFunction_m;                  /* '<S47>/S-Function' */
  real_T GeneratedFilterBlock_l;       /* '<S48>/Generated Filter Block' */
  real_T SFunction_f;                  /* '<S50>/S-Function' */
  real_T GeneratedFilterBlock_f;       /* '<S51>/Generated Filter Block' */
  real_T DataStoreRead_o;              /* '<S39>/Data Store Read' */
  real_T Add_m;                        /* '<S39>/Add' */
  real_T CurrentSensorScaling_l;       /* '<S39>/Current Sensor Scaling' */
  real_T SFunction_n;                  /* '<S53>/S-Function' */
  real_T GeneratedFilterBlock_fb;      /* '<S54>/Generated Filter Block' */
  real_T DataStoreRead_h;              /* '<S40>/Data Store Read' */
  real_T Add_n;                        /* '<S40>/Add' */
  real_T VoltageSensorScaling_l;       /* '<S40>/Voltage Sensor Scaling' */
  real_T Delay1;                       /* '<Root>/Delay1' */
  real_T RateTransition;               /* '<S69>/Rate Transition' */
  real_T DiscreteTransferFcn3;         /* '<S31>/Discrete Transfer Fcn3' */
  real_T RateTransition_j;             /* '<S13>/Rate Transition' */
  real_T SinusoidalVDist;              /* '<S59>/Sinusoidal V Dist' */
  real_T RateTransition_i;             /* '<S60>/Rate Transition' */
  real_T RandomNoiseVDist;             /* '<S59>/Random Noise V Dist' */
  real_T SquareWaveVDist;              /* '<S59>/Square Wave V Dist' */
  real_T RateTransition_l;             /* '<S61>/Rate Transition' */
  real_T MultiportSwitchforVDist;      /* '<S59>/Multiport Switch for V Dist' */
  real_T Add_b;                        /* '<S59>/Add' */
  real_T Delay;                        /* '<S58>/Delay' */
  real_T SinusoidalVoltageCommand;     /* '<S35>/Sinusoidal Voltage Command' */
  real_T RateTransition_e;             /* '<S80>/Rate Transition' */
  real_T RandomNoiseVoltageCommand;    /* '<S35>/Random Noise Voltage Command' */
  real_T SquareWaveVoltageCommand;     /* '<S35>/Square Wave Voltage Command' */
  real_T RateTransition_g;             /* '<S81>/Rate Transition' */
  real_T MultiportSwitchforVoltageComman;/* '<S35>/Multiport Switch for Voltage Command' */
  real_T Add_by;                       /* '<S35>/Add' */
  real_T RateTransition_n;             /* '<S7>/Rate Transition' */
  real_T RateTransition_h;             /* '<S20>/Rate Transition' */
  real_T DiscreteTransferFcn;          /* '<Root>/Discrete Transfer Fcn' */
  real_T RateTransition_a;             /* '<S8>/Rate Transition' */
  real_T RateTransition_jo;            /* '<S10>/Rate Transition' */
  real_T SinusoidalCurrentCommand;     /* '<S34>/Sinusoidal Current Command' */
  real_T RateTransition_m;             /* '<S70>/Rate Transition' */
  real_T RandomNoiseCurrentCommand;    /* '<S34>/Random Noise Current Command' */
  real_T SquareWaveCurrentCommand;     /* '<S34>/Square Wave Current Command' */
  real_T RateTransition_md;            /* '<S71>/Rate Transition' */
  real_T Clock1;                       /* '<S34>/Clock1' */
  real_T RateTransition_p;             /* '<S74>/Rate Transition' */
  real_T RateTransition_ju;            /* '<S73>/Rate Transition' */
  real_T RateTransition_h0;            /* '<S72>/Rate Transition' */
  real_T Switch2;                      /* '<S34>/Switch2' */
  real_T Product;                      /* '<S34>/Product' */
  real_T Switch2_a;                    /* '<S78>/Switch2' */
  real_T RateTransition_na;            /* '<S75>/Rate Transition' */
  real_T MultiportSwitchforCurrentComman;/* '<S34>/Multiport Switch for Current Command' */
  real_T Add_e;                        /* '<S34>/Add' */
  real_T RateTransition_f;             /* '<S11>/Rate Transition' */
  real_T Gain;                         /* '<Root>/Gain' */
  real_T Add_f;                        /* '<Root>/Add' */
  real_T RateTransition_p3;            /* '<S6>/Rate Transition' */
  real_T Switch5;                      /* '<Root>/Switch5' */
  real_T RateTransition_aq;            /* '<S21>/Rate Transition' */
  real_T RateTransition_jz;            /* '<S3>/Rate Transition' */
  real_T Switch1;                      /* '<S28>/Switch1' */
  real_T Kp_vc;                        /* '<S28>/Kp_vc' */
  real_T SinusoidalIDist;              /* '<S62>/Sinusoidal I Dist' */
  real_T RateTransition_es;            /* '<S63>/Rate Transition' */
  real_T RandomNoiseIDist;             /* '<S62>/Random Noise I Dist' */
  real_T SquareWaveIDist;              /* '<S62>/Square Wave I Dist' */
  real_T RateTransition_ha;            /* '<S64>/Rate Transition' */
  real_T MultiportSwitchforIDist;      /* '<S62>/Multiport Switch for I Dist' */
  real_T Add_br;                       /* '<S62>/Add' */
  real_T Sum2;                         /* '<S28>/Sum2' */
  real_T ZeroOrderHold;                /* '<S28>/Zero-Order Hold' */
  real_T RateTransition_nl;            /* '<S1>/Rate Transition' */
  real_T RateTransition_fe;            /* '<S9>/Rate Transition' */
  real_T Switch2_h;                    /* '<Root>/Switch2' */
  real_T Saturation1;                  /* '<S27>/Saturation1' */
  real_T DiscreteTimeIntegrator;       /* '<S27>/Discrete-Time Integrator' */
  real_T RateTransition_k;             /* '<S2>/Rate Transition' */
  real_T Switch1_p;                    /* '<S27>/Switch1' */
  real_T InvertErrorForBoost;          /* '<S27>/InvertErrorForBoost' */
  real_T Switch3;                      /* '<S27>/Switch3' */
  real_T Ra;                           /* '<S27>/Ra' */
  real_T Sum2_c;                       /* '<S27>/Sum2' */
  real_T Sum1;                         /* '<S27>/Sum1' */
  real_T RateTransition_a0;            /* '<S17>/Rate Transition' */
  real_T RateTransition_hx;            /* '<S57>/Rate Transition' */
  real_T Switch;                       /* '<S27>/Switch' */
  real_T ZeroOrderHold_n;              /* '<S27>/Zero-Order Hold' */
  real_T Saturation;                   /* '<S27>/Saturation' */
  real_T Product1;                     /* '<S27>/Product1' */
  real_T RateTransition_j2;            /* '<S15>/Rate Transition' */
  real_T MultiportSwitchforIGBTTop;    /* '<Root>/Multiport Switch for IGBT Top' */
  real_T DataTypeConversion2;          /* '<Root>/Data Type Conversion2' */
  real_T Delay2;                       /* '<Root>/Delay2' */
  real_T Product2;                     /* '<S27>/Product2' */
  real_T RateTransition_hz;            /* '<S18>/Rate Transition' */
  real_T MultiportSwitchforIGBTBottom; /* '<Root>/Multiport Switch for IGBT Bottom' */
  real_T DataTypeConversion1;          /* '<Root>/Data Type Conversion1' */
  real_T RateTransition_jc;            /* '<S12>/Rate Transition' */
  real_T DiscreteTransferFcn1;         /* '<S31>/Discrete Transfer Fcn1' */
  real_T DiscreteTransferFcn2;         /* '<S31>/Discrete Transfer Fcn2' */
  real_T RateTransition_b;             /* '<S19>/Rate Transition' */
  real_T Delay4;                       /* '<Root>/Delay4' */
  real_T RateTransition_ba;            /* '<S14>/Rate Transition' */
  real_T Abs;                          /* '<S26>/Abs' */
  real_T Add1;                         /* '<S26>/Add1' */
  real_T BatteryCurrentRelay;          /* '<S26>/Battery Current Relay' */
  real_T Abs1;                         /* '<S26>/Abs1' */
  real_T Add2;                         /* '<S26>/Add2' */
  real_T UltraCapacitorCurrentRelay;   /* '<S26>/UltraCapacitor Current Relay' */
  real_T Add3;                         /* '<S26>/Add3' */
  real_T BatteryVoltageRelay;          /* '<S26>/Battery Voltage Relay' */
  real_T Add4;                         /* '<S26>/Add4' */
  real_T UltraCapacitorVoltageRelay;   /* '<S26>/Ultra Capacitor Voltage Relay' */
  real_T Add5;                         /* '<S26>/Add5' */
  real_T TemperatureRelay;             /* '<S26>/Temperature Relay' */
  real_T Ea;                           /* '<S27>/Ea' */
  real_T LUTEnabled;                   /* '<S78>/MATLAB Function1' */
  real_T UCCurrentCommand;             /* '<S78>/MATLAB Function1' */
  real_T DLookupTable;                 /* '<S78>/2-D Lookup Table' */
  real_T Ra_b;                         /* '<S78>/Ra' */
  real_T Saturation_o;                 /* '<S78>/Saturation' */
  real_T command_output;               /* '<S34>/Current_Profile_1Hz' */
  real_T command_output_o;             /* '<S34>/Current_Profile_10Hz' */
  real_T DataStoreRead_d;              /* '<S38>/Data Store Read' */
  real_T Add_o;                        /* '<S38>/Add' */
  real_T CurrentSensorScaling_i;       /* '<S38>/Current Sensor Scaling' */
  real_T IGBT_Top_State;               /* '<Root>/System Configuration State Machine1' */
  real_T IGBT_Bot_State;               /* '<Root>/System Configuration State Machine1' */
  real_T UltracapacitorRelay;          /* '<Root>/System Configuration State Machine1' */
  real_T ChargingRelay;                /* '<Root>/System Configuration State Machine1' */
  real_T DischargingRelay;             /* '<Root>/System Configuration State Machine1' */
  real_T BatteryRelay;                 /* '<Root>/System Configuration State Machine1' */
  real_T VoltageCommand;               /* '<Root>/Supervisory Control State Machine' */
  real_T EnableVoltageCommand;         /* '<Root>/Supervisory Control State Machine' */
  real_T Saturation1_g;                /* '<S28>/Saturation1' */
  real_T Sum;                          /* '<S28>/Sum' */
  real_T Divide1;                      /* '<S27>/Divide1' */
  real_T Divide;                       /* '<S27>/Divide' */
  real_T Sum_a;                        /* '<S27>/Sum' */
  real_T LBatCurrentAlert;             /* '<Root>/ErrorLatchingFunction' */
  real_T LUCCurrentAlert;              /* '<Root>/ErrorLatchingFunction' */
  real_T LBatVoltageAlert;             /* '<Root>/ErrorLatchingFunction' */
  real_T LUCVoltageAlert;              /* '<Root>/ErrorLatchingFunction' */
  real_T LTempAlert;                   /* '<Root>/ErrorLatchingFunction' */
  real_T LErrorHB1;                    /* '<Root>/ErrorLatchingFunction' */
  real_T LErrorHB2;                    /* '<Root>/ErrorLatchingFunction' */
  real_T LErrorHB3;                    /* '<Root>/ErrorLatchingFunction' */
  real_T LOverTemp;                    /* '<Root>/ErrorLatchingFunction' */
  boolean_T Delay3;                    /* '<Root>/Delay3' */
  boolean_T RateTransition_at;         /* '<S16>/Rate Transition' */
  boolean_T LogicalOperator1;          /* '<S27>/Logical Operator1' */
  boolean_T RelationalOperator1;       /* '<S58>/Relational Operator1' */
  boolean_T RateTransition_lo;         /* '<S4>/Rate Transition' */
  boolean_T LogicalOperator1_b;        /* '<Root>/Logical Operator1' */
  boolean_T LogicalOperator;           /* '<Root>/Logical Operator' */
  boolean_T RateTransition_pu;         /* '<S5>/Rate Transition' */
  boolean_T RelationalOperator;        /* '<S58>/Relational Operator' */
  boolean_T LogicalOperator_o;         /* '<S58>/Logical Operator' */
  boolean_T LogicalOperator1_f;        /* '<S58>/Logical Operator1' */
  boolean_T LogicalOperator2;          /* '<S58>/Logical Operator2' */
  boolean_T LogicalOperator3;          /* '<S58>/Logical Operator3' */
  boolean_T LogicalOperator_f;         /* '<S27>/Logical Operator' */
  boolean_T LogicalOperator2_k;        /* '<S27>/Logical Operator2' */
  boolean_T Memory3;                   /* '<S26>/Memory3' */
  boolean_T Memory1;                   /* '<S26>/Memory1' */
  boolean_T Memory2;                   /* '<S26>/Memory2' */
  boolean_T Memory4;                   /* '<S26>/Memory4' */
  boolean_T Memory5;                   /* '<S26>/Memory5' */
  boolean_T Delay_g;                   /* '<S25>/Delay' */
  boolean_T Memory3_p;                 /* '<S25>/Memory3' */
  boolean_T LogicalOperator2_e;        /* '<S25>/Logical Operator2' */
  boolean_T Delay2_i;                  /* '<S25>/Delay2' */
  boolean_T Memory1_i;                 /* '<S25>/Memory1' */
  boolean_T LogicalOperator3_j;        /* '<S25>/Logical Operator3' */
  boolean_T Delay1_i;                  /* '<S25>/Delay1' */
  boolean_T Memory2_h;                 /* '<S25>/Memory2' */
  boolean_T LogicalOperator1_o;        /* '<S25>/Logical Operator1' */
  boolean_T Delay3_m;                  /* '<S25>/Delay3' */
  boolean_T Memory;                    /* '<S25>/Memory' */
  boolean_T LogicalOperator4;          /* '<S25>/Logical Operator4' */
  boolean_T ErrorForTripNew;           /* '<Root>/ErrorForTripNew' */
  boolean_T ChargingRelay_l;           /* '<S30>/ChargingRelay' */
  boolean_T DischargingRelay_e;        /* '<S30>/DischargingRelay' */
  boolean_T UltraCapacitorRelay;       /* '<S30>/UltraCapacitorRelay' */
  boolean_T BatteryRelay_b;            /* '<S30>/BatteryRelay' */
  boolean_T SFunction1;                /* '<S56>/S-Function1' */
  boolean_T SFunction2;                /* '<S56>/S-Function2' */
  boolean_T SFunction3;                /* '<S56>/S-Function3' */
  boolean_T SFunction4;                /* '<S56>/S-Function4' */
  boolean_T SFunction5;                /* '<S56>/S-Function5' */
  boolean_T SFunction6;                /* '<S56>/S-Function6' */
  boolean_T SFunction7;                /* '<S56>/S-Function7' */
  boolean_T SFunction8;                /* '<S56>/S-Function8' */
  boolean_T DataTypeConversion;        /* '<S25>/Data Type Conversion' */
  boolean_T DataTypeConversion1_n;     /* '<S25>/Data Type Conversion1' */
  boolean_T DataTypeConversion2_e;     /* '<S25>/Data Type Conversion2' */
  boolean_T DataTypeConversion3;       /* '<S25>/Data Type Conversion3' */
  boolean_T DataTypeConversion_i;      /* '<S26>/Data Type Conversion' */
  boolean_T DataTypeConversion1_g;     /* '<S26>/Data Type Conversion1' */
  boolean_T DataTypeConversion2_i;     /* '<S26>/Data Type Conversion2' */
  boolean_T DataTypeConversion3_a;     /* '<S26>/Data Type Conversion3' */
  boolean_T DataTypeConversion4;       /* '<S26>/Data Type Conversion4' */
  boolean_T AutomaticController;       /* '<Root>/System Configuration State Machine1' */
  rtB_SampleandHold_DCDCconverter SampleandHold_o;/* '<S40>/Sample and Hold' */
  rtB_SampleandHold_DCDCconverter SampleandHold_dv;/* '<S39>/Sample and Hold' */
  rtB_SampleandHold_DCDCconverter SampleandHold_du;/* '<S38>/Sample and Hold' */
  rtB_SampleandHold_DCDCconverter SampleandHold_d;/* '<S37>/Sample and Hold' */
  rtB_SampleandHold_DCDCconverter SampleandHold;/* '<S36>/Sample and Hold' */
} BlockIO_DCDCconverter;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T GeneratedFilterBlock_states[73];/* '<S42>/Generated Filter Block' */
  real_T GeneratedFilterBlock_states_i[73];/* '<S45>/Generated Filter Block' */
  real_T GeneratedFilterBlock_states_e[73];/* '<S48>/Generated Filter Block' */
  real_T GeneratedFilterBlock_states_f[73];/* '<S51>/Generated Filter Block' */
  real_T GeneratedFilterBlock_states_o[73];/* '<S54>/Generated Filter Block' */
  real_T Delay1_DSTATE[10];            /* '<Root>/Delay1' */
  real_T DiscreteTransferFcn3_states[7];/* '<S31>/Discrete Transfer Fcn3' */
  real_T Delay_DSTATE;                 /* '<S58>/Delay' */
  real_T DiscreteTransferFcn_states[3];/* '<Root>/Discrete Transfer Fcn' */
  real_T DiscreteTimeIntegrator_DSTATE;/* '<S27>/Discrete-Time Integrator' */
  real_T Delay2_DSTATE[10];            /* '<Root>/Delay2' */
  real_T DiscreteTransferFcn1_states;  /* '<S31>/Discrete Transfer Fcn1' */
  real_T DiscreteTransferFcn2_states[7];/* '<S31>/Discrete Transfer Fcn2' */
  real_T Delay4_DSTATE;                /* '<Root>/Delay4' */
  real_T Offset;                       /* '<S36>/Data Store Memory' */
  real_T Offset_p;                     /* '<S37>/Data Store Memory' */
  real_T Offset_i;                     /* '<S38>/Data Store Memory' */
  real_T Offset_p0;                    /* '<S39>/Data Store Memory' */
  real_T Offset_iq;                    /* '<S40>/Data Store Memory' */
  real_T DiscreteTransferFcn3_tmp;     /* '<S31>/Discrete Transfer Fcn3' */
  real_T RandomNoiseVDist_NextOutput;  /* '<S59>/Random Noise V Dist' */
  real_T RandomNoiseVoltageCommand_NextO;/* '<S35>/Random Noise Voltage Command' */
  real_T DiscreteTransferFcn_tmp;      /* '<Root>/Discrete Transfer Fcn' */
  real_T RandomNoiseCurrentCommand_NextO;/* '<S34>/Random Noise Current Command' */
  real_T RandomNoiseIDist_NextOutput;  /* '<S62>/Random Noise I Dist' */
  real_T DiscreteTransferFcn1_tmp;     /* '<S31>/Discrete Transfer Fcn1' */
  real_T DiscreteTransferFcn2_tmp;     /* '<S31>/Discrete Transfer Fcn2' */
  real_T profile_on_condition;         /* '<S34>/Current_Profile_1Hz' */
  real_T index;                        /* '<S34>/Current_Profile_1Hz' */
  real_T last_time;                    /* '<S34>/Current_Profile_1Hz' */
  real_T period;                       /* '<S34>/Current_Profile_1Hz' */
  real_T command;                      /* '<S34>/Current_Profile_1Hz' */
  real_T profile[3739];                /* '<S34>/Current_Profile_1Hz' */
  real_T profile_on_condition_b;       /* '<S34>/Current_Profile_10Hz' */
  real_T index_d;                      /* '<S34>/Current_Profile_10Hz' */
  real_T last_time_k;                  /* '<S34>/Current_Profile_10Hz' */
  real_T period_h;                     /* '<S34>/Current_Profile_10Hz' */
  real_T command_d;                    /* '<S34>/Current_Profile_10Hz' */
  real_T profile_i[39461];             /* '<S34>/Current_Profile_10Hz' */
  real_T dVrail_dT_threshold;          /* '<Root>/System Configuration State Machine1' */
  real_T delta_Voltage;                /* '<Root>/Supervisory Control State Machine' */
  real_T LLBatCurrentAlert;            /* '<Root>/ErrorLatchingFunction' */
  real_T LLUCCurrentAlert;             /* '<Root>/ErrorLatchingFunction' */
  real_T LLBatVoltageAlert;            /* '<Root>/ErrorLatchingFunction' */
  real_T LLUCVoltageAlert;             /* '<Root>/ErrorLatchingFunction' */
  real_T LLTempAlert;                  /* '<Root>/ErrorLatchingFunction' */
  real_T LLErrorHB1;                   /* '<Root>/ErrorLatchingFunction' */
  real_T LLErrorHB2;                   /* '<Root>/ErrorLatchingFunction' */
  real_T LLErrorHB3;                   /* '<Root>/ErrorLatchingFunction' */
  real_T LLOverTemp;                   /* '<Root>/ErrorLatchingFunction' */
  int32_T GeneratedFilterBlock_circBuf;/* '<S42>/Generated Filter Block' */
  int32_T GeneratedFilterBlock_circBuf_c;/* '<S45>/Generated Filter Block' */
  int32_T GeneratedFilterBlock_circBuf_d;/* '<S48>/Generated Filter Block' */
  int32_T GeneratedFilterBlock_circBuf_cj;/* '<S51>/Generated Filter Block' */
  int32_T GeneratedFilterBlock_circBuf_h;/* '<S54>/Generated Filter Block' */
  uint32_T RandSeed;                   /* '<S59>/Random Noise V Dist' */
  uint32_T RandSeed_b;                 /* '<S35>/Random Noise Voltage Command' */
  uint32_T RandSeed_f;                 /* '<S34>/Random Noise Current Command' */
  uint32_T RandSeed_l;                 /* '<S62>/Random Noise I Dist' */
  int_T SFunction1_IWORK[4];           /* '<S23>/S-Function1' */
  int_T SFunction2_IWORK[4];           /* '<S23>/S-Function2' */
  int_T SFunction3_IWORK[4];           /* '<S23>/S-Function3' */
  int_T SFunction4_IWORK[4];           /* '<S23>/S-Function4' */
  boolean_T Delay3_DSTATE[10];         /* '<Root>/Delay3' */
  boolean_T Delay_DSTATE_n;            /* '<S25>/Delay' */
  boolean_T Delay2_DSTATE_d;           /* '<S25>/Delay2' */
  boolean_T Delay1_DSTATE_b;           /* '<S25>/Delay1' */
  boolean_T Delay3_DSTATE_b;           /* '<S25>/Delay3' */
  int8_T DiscreteTimeIntegrator_PrevRese;/* '<S27>/Discrete-Time Integrator' */
  uint8_T is_active_c5_DCDCconverter;  /* '<Root>/System Configuration State Machine1' */
  uint8_T is_c5_DCDCconverter;         /* '<Root>/System Configuration State Machine1' */
  uint8_T is_active_c4_DCDCconverter;  /* '<Root>/Supervisory Control State Machine' */
  uint8_T is_c4_DCDCconverter;         /* '<Root>/Supervisory Control State Machine' */
  boolean_T Memory3_PreviousInput;     /* '<S26>/Memory3' */
  boolean_T Memory1_PreviousInput;     /* '<S26>/Memory1' */
  boolean_T Memory2_PreviousInput;     /* '<S26>/Memory2' */
  boolean_T Memory4_PreviousInput;     /* '<S26>/Memory4' */
  boolean_T Memory5_PreviousInput;     /* '<S26>/Memory5' */
  boolean_T Memory3_PreviousInput_o;   /* '<S25>/Memory3' */
  boolean_T Memory1_PreviousInput_c;   /* '<S25>/Memory1' */
  boolean_T Memory2_PreviousInput_l;   /* '<S25>/Memory2' */
  boolean_T Memory_PreviousInput;      /* '<S25>/Memory' */
  boolean_T BatteryCurrentRelay_Mode;  /* '<S26>/Battery Current Relay' */
  boolean_T UltraCapacitorCurrentRelay_Mode;/* '<S26>/UltraCapacitor Current Relay' */
  boolean_T BatteryVoltageRelay_Mode;  /* '<S26>/Battery Voltage Relay' */
  boolean_T UltraCapacitorVoltageRelay_Mode;/* '<S26>/Ultra Capacitor Voltage Relay' */
  boolean_T TemperatureRelay_Mode;     /* '<S26>/Temperature Relay' */
  boolean_T last_time_not_empty;       /* '<S34>/Current_Profile_1Hz' */
  boolean_T last_time_not_empty_l;     /* '<S34>/Current_Profile_10Hz' */
} D_Work_DCDCconverter;

/* Zero-crossing (trigger) state */
typedef struct {
  rtZCE_SampleandHold_DCDCconvert SampleandHold_o;/* '<S36>/Sample and Hold' */
  rtZCE_SampleandHold_DCDCconvert SampleandHold_dv;/* '<S36>/Sample and Hold' */
  rtZCE_SampleandHold_DCDCconvert SampleandHold_du;/* '<S36>/Sample and Hold' */
  rtZCE_SampleandHold_DCDCconvert SampleandHold_d;/* '<S36>/Sample and Hold' */
  rtZCE_SampleandHold_DCDCconvert SampleandHold;/* '<S36>/Sample and Hold' */
} PrevZCSigStates_DCDCconverter;

/* Backward compatible GRT Identifiers */
#define rtB                            DCDCconverter_B
#define BlockIO                        BlockIO_DCDCconverter
#define rtP                            DCDCconverter_P
#define Parameters                     Parameters_DCDCconverter
#define rtDWork                        DCDCconverter_DWork
#define D_Work                         D_Work_DCDCconverter
#define rtPrevZCSigState               DCDCconverter_PrevZCSigState
#define PrevZCSigStates                PrevZCSigStates_DCDCconverter

/* Parameters for system: '<S36>/Sample and Hold' */
struct rtP_SampleandHold_DCDCconverter_ {
  real_T _Y0;                          /* Expression: initCond
                                        * Referenced by: '<S43>/ '
                                        */
};

/* Parameters (auto storage) */
struct Parameters_DCDCconverter_ {
  real_T DutyCycleTop_Value;           /* Expression: 0
                                        * Referenced by: '<Root>/Duty CycleTop'
                                        */
  real_T DutyCycleBot_Value;           /* Expression: 0
                                        * Referenced by: '<Root>/Duty Cycle Bot'
                                        */
  real_T Saturation1_UpperSat;         /* Expression: Vbat-1
                                        * Referenced by: '<S28>/Saturation1'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: 0
                                        * Referenced by: '<S28>/Saturation1'
                                        */
  real_T ManualLoadCurrentSetting_Value;/* Expression: 0
                                         * Referenced by: '<S34>/ManualLoadCurrentSetting'
                                         */
  real_T CurrentSensorScaling_Gain;    /* Expression: 796.1782
                                        * Referenced by: '<S38>/Current Sensor Scaling'
                                        */
  real_T DLookupTable_tableData[210];  /* Expression: RuleBasedControlLUTValues
                                        * Referenced by: '<S78>/2-D Lookup Table'
                                        */
  real_T DLookupTable_bp01Data[21];    /* Expression: RuleBasedControlHESSPowerValues
                                        * Referenced by: '<S78>/2-D Lookup Table'
                                        */
  real_T DLookupTable_bp02Data[10];    /* Expression: RuleBasedControlUCVoltageValues
                                        * Referenced by: '<S78>/2-D Lookup Table'
                                        */
  real_T Ra_Gain;                      /* Expression: -1
                                        * Referenced by: '<S78>/Ra'
                                        */
  real_T Saturation_UpperSat;          /* Expression: 0
                                        * Referenced by: '<S78>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: -Icommand_Limit
                                        * Referenced by: '<S78>/Saturation'
                                        */
  real_T Zero_Value;                   /* Expression: 0
                                        * Referenced by: '<S35>/Zero'
                                        */
  real_T GeneratedFilterBlock_InitialSta;/* Expression: 0
                                          * Referenced by: '<S42>/Generated Filter Block'
                                          */
  real_T GeneratedFilterBlock_Coefficien[74];/* Expression: [0.00028387225120269494 -0.00039401751517345108 -0.00051440691195126409 -0.00075899521627574443 -0.0010941645666664886 -0.0015047026375922569 -0.0019783528421440672 -0.0024999962120832451 -0.0030483497757197702 -0.0035960077296140411 -0.0041083697578374141 -0.0045449722259694068 -0.0048595556741518183 -0.005002396212585635 -0.0049212033541306032 -0.0045644105295144241 -0.0038825540014864241 -0.0028320966661358709 -0.0013766635178792236 0.00050903213236998929 0.0028384532311130119 0.0056092612802153413 0.00880458302290015 0.012388421653013841 0.01631021984014288 0.020504166250900041 0.024885630758212381 0.029361560221717091 0.033828170940403357 0.03817500973917367 0.042289844667114912 0.046062416914275706 0.049388306387152664 0.052173366785398176 0.054337104315716686 0.055816180296302371 0.056566862063799822 0.056566862063799822 0.055816180296302371 0.054337104315716686 0.052173366785398176 0.049388306387152664 0.046062416914275706 0.042289844667114912 0.03817500973917367 0.033828170940403357 0.029361560221717091 0.024885630758212381 0.020504166250900041 0.01631021984014288 0.012388421653013841 0.00880458302290015 0.0056092612802153413 0.0028384532311130119 0.00050903213236998929 -0.0013766635178792236 -0.0028320966661358709 -0.0038825540014864241 -0.0045644105295144241 -0.0049212033541306032 -0.005002396212585635 -0.0048595556741518183 -0.0045449722259694068 -0.0041083697578374141 -0.0035960077296140411 -0.0030483497757197702 -0.0024999962120832451 -0.0019783528421440672 -0.0015047026375922569 -0.0010941645666664886 -0.00075899521627574443 -0.00051440691195126409 -0.00039401751517345108 0.00028387225120269494]
                                              * Referenced by: '<S42>/Generated Filter Block'
                                              */
  real_T Zeroing_Value;                /* Expression: 0
                                        * Referenced by: '<Root>/Zeroing'
                                        */
  real_T CurrentSensorScaling_Gain_n;  /* Expression: 318.4713
                                        * Referenced by: '<S36>/Current Sensor Scaling'
                                        */
  real_T DataStoreMemory_InitialValue; /* Expression: 0
                                        * Referenced by: '<S36>/Data Store Memory'
                                        */
  real_T GeneratedFilterBlock_InitialS_n;/* Expression: 0
                                          * Referenced by: '<S45>/Generated Filter Block'
                                          */
  real_T GeneratedFilterBlock_Coeffici_p[74];/* Expression: [0.00028387225120269494 -0.00039401751517345108 -0.00051440691195126409 -0.00075899521627574443 -0.0010941645666664886 -0.0015047026375922569 -0.0019783528421440672 -0.0024999962120832451 -0.0030483497757197702 -0.0035960077296140411 -0.0041083697578374141 -0.0045449722259694068 -0.0048595556741518183 -0.005002396212585635 -0.0049212033541306032 -0.0045644105295144241 -0.0038825540014864241 -0.0028320966661358709 -0.0013766635178792236 0.00050903213236998929 0.0028384532311130119 0.0056092612802153413 0.00880458302290015 0.012388421653013841 0.01631021984014288 0.020504166250900041 0.024885630758212381 0.029361560221717091 0.033828170940403357 0.03817500973917367 0.042289844667114912 0.046062416914275706 0.049388306387152664 0.052173366785398176 0.054337104315716686 0.055816180296302371 0.056566862063799822 0.056566862063799822 0.055816180296302371 0.054337104315716686 0.052173366785398176 0.049388306387152664 0.046062416914275706 0.042289844667114912 0.03817500973917367 0.033828170940403357 0.029361560221717091 0.024885630758212381 0.020504166250900041 0.01631021984014288 0.012388421653013841 0.00880458302290015 0.0056092612802153413 0.0028384532311130119 0.00050903213236998929 -0.0013766635178792236 -0.0028320966661358709 -0.0038825540014864241 -0.0045644105295144241 -0.0049212033541306032 -0.005002396212585635 -0.0048595556741518183 -0.0045449722259694068 -0.0041083697578374141 -0.0035960077296140411 -0.0030483497757197702 -0.0024999962120832451 -0.0019783528421440672 -0.0015047026375922569 -0.0010941645666664886 -0.00075899521627574443 -0.00051440691195126409 -0.00039401751517345108 0.00028387225120269494]
                                              * Referenced by: '<S45>/Generated Filter Block'
                                              */
  real_T VoltageSensorScaling_Gain;    /* Expression: 859.9068
                                        * Referenced by: '<S37>/Voltage Sensor Scaling'
                                        */
  real_T DataStoreMemory_InitialValue_o;/* Expression: 0
                                         * Referenced by: '<S37>/Data Store Memory'
                                         */
  real_T GeneratedFilterBlock_InitialS_i;/* Expression: 0
                                          * Referenced by: '<S48>/Generated Filter Block'
                                          */
  real_T GeneratedFilterBlock_Coeffici_n[74];/* Expression: [0.00028387225120269494 -0.00039401751517345108 -0.00051440691195126409 -0.00075899521627574443 -0.0010941645666664886 -0.0015047026375922569 -0.0019783528421440672 -0.0024999962120832451 -0.0030483497757197702 -0.0035960077296140411 -0.0041083697578374141 -0.0045449722259694068 -0.0048595556741518183 -0.005002396212585635 -0.0049212033541306032 -0.0045644105295144241 -0.0038825540014864241 -0.0028320966661358709 -0.0013766635178792236 0.00050903213236998929 0.0028384532311130119 0.0056092612802153413 0.00880458302290015 0.012388421653013841 0.01631021984014288 0.020504166250900041 0.024885630758212381 0.029361560221717091 0.033828170940403357 0.03817500973917367 0.042289844667114912 0.046062416914275706 0.049388306387152664 0.052173366785398176 0.054337104315716686 0.055816180296302371 0.056566862063799822 0.056566862063799822 0.055816180296302371 0.054337104315716686 0.052173366785398176 0.049388306387152664 0.046062416914275706 0.042289844667114912 0.03817500973917367 0.033828170940403357 0.029361560221717091 0.024885630758212381 0.020504166250900041 0.01631021984014288 0.012388421653013841 0.00880458302290015 0.0056092612802153413 0.0028384532311130119 0.00050903213236998929 -0.0013766635178792236 -0.0028320966661358709 -0.0038825540014864241 -0.0045644105295144241 -0.0049212033541306032 -0.005002396212585635 -0.0048595556741518183 -0.0045449722259694068 -0.0041083697578374141 -0.0035960077296140411 -0.0030483497757197702 -0.0024999962120832451 -0.0019783528421440672 -0.0015047026375922569 -0.0010941645666664886 -0.00075899521627574443 -0.00051440691195126409 -0.00039401751517345108 0.00028387225120269494]
                                              * Referenced by: '<S48>/Generated Filter Block'
                                              */
  real_T DataStoreMemory_InitialValue_j;/* Expression: 0
                                         * Referenced by: '<S38>/Data Store Memory'
                                         */
  real_T GeneratedFilterBlock_InitialS_k;/* Expression: 0
                                          * Referenced by: '<S51>/Generated Filter Block'
                                          */
  real_T GeneratedFilterBlock_Coeffici_m[74];/* Expression: [0.00028387225120269494 -0.00039401751517345108 -0.00051440691195126409 -0.00075899521627574443 -0.0010941645666664886 -0.0015047026375922569 -0.0019783528421440672 -0.0024999962120832451 -0.0030483497757197702 -0.0035960077296140411 -0.0041083697578374141 -0.0045449722259694068 -0.0048595556741518183 -0.005002396212585635 -0.0049212033541306032 -0.0045644105295144241 -0.0038825540014864241 -0.0028320966661358709 -0.0013766635178792236 0.00050903213236998929 0.0028384532311130119 0.0056092612802153413 0.00880458302290015 0.012388421653013841 0.01631021984014288 0.020504166250900041 0.024885630758212381 0.029361560221717091 0.033828170940403357 0.03817500973917367 0.042289844667114912 0.046062416914275706 0.049388306387152664 0.052173366785398176 0.054337104315716686 0.055816180296302371 0.056566862063799822 0.056566862063799822 0.055816180296302371 0.054337104315716686 0.052173366785398176 0.049388306387152664 0.046062416914275706 0.042289844667114912 0.03817500973917367 0.033828170940403357 0.029361560221717091 0.024885630758212381 0.020504166250900041 0.01631021984014288 0.012388421653013841 0.00880458302290015 0.0056092612802153413 0.0028384532311130119 0.00050903213236998929 -0.0013766635178792236 -0.0028320966661358709 -0.0038825540014864241 -0.0045644105295144241 -0.0049212033541306032 -0.005002396212585635 -0.0048595556741518183 -0.0045449722259694068 -0.0041083697578374141 -0.0035960077296140411 -0.0030483497757197702 -0.0024999962120832451 -0.0019783528421440672 -0.0015047026375922569 -0.0010941645666664886 -0.00075899521627574443 -0.00051440691195126409 -0.00039401751517345108 0.00028387225120269494]
                                              * Referenced by: '<S51>/Generated Filter Block'
                                              */
  real_T CurrentSensorScaling_Gain_k;  /* Expression: 318.4713
                                        * Referenced by: '<S39>/Current Sensor Scaling'
                                        */
  real_T DataStoreMemory_InitialValue_n;/* Expression: 0
                                         * Referenced by: '<S39>/Data Store Memory'
                                         */
  real_T GeneratedFilterBlock_InitialS_j;/* Expression: 0
                                          * Referenced by: '<S54>/Generated Filter Block'
                                          */
  real_T GeneratedFilterBlock_Coeffic_mf[74];/* Expression: [0.00028387225120269494 -0.00039401751517345108 -0.00051440691195126409 -0.00075899521627574443 -0.0010941645666664886 -0.0015047026375922569 -0.0019783528421440672 -0.0024999962120832451 -0.0030483497757197702 -0.0035960077296140411 -0.0041083697578374141 -0.0045449722259694068 -0.0048595556741518183 -0.005002396212585635 -0.0049212033541306032 -0.0045644105295144241 -0.0038825540014864241 -0.0028320966661358709 -0.0013766635178792236 0.00050903213236998929 0.0028384532311130119 0.0056092612802153413 0.00880458302290015 0.012388421653013841 0.01631021984014288 0.020504166250900041 0.024885630758212381 0.029361560221717091 0.033828170940403357 0.03817500973917367 0.042289844667114912 0.046062416914275706 0.049388306387152664 0.052173366785398176 0.054337104315716686 0.055816180296302371 0.056566862063799822 0.056566862063799822 0.055816180296302371 0.054337104315716686 0.052173366785398176 0.049388306387152664 0.046062416914275706 0.042289844667114912 0.03817500973917367 0.033828170940403357 0.029361560221717091 0.024885630758212381 0.020504166250900041 0.01631021984014288 0.012388421653013841 0.00880458302290015 0.0056092612802153413 0.0028384532311130119 0.00050903213236998929 -0.0013766635178792236 -0.0028320966661358709 -0.0038825540014864241 -0.0045644105295144241 -0.0049212033541306032 -0.005002396212585635 -0.0048595556741518183 -0.0045449722259694068 -0.0041083697578374141 -0.0035960077296140411 -0.0030483497757197702 -0.0024999962120832451 -0.0019783528421440672 -0.0015047026375922569 -0.0010941645666664886 -0.00075899521627574443 -0.00051440691195126409 -0.00039401751517345108 0.00028387225120269494]
                                              * Referenced by: '<S54>/Generated Filter Block'
                                              */
  real_T VoltageSensorScaling_Gain_g;  /* Expression: -859.9068
                                        * Referenced by: '<S40>/Voltage Sensor Scaling'
                                        */
  real_T DataStoreMemory_InitialValue_i;/* Expression: 0
                                         * Referenced by: '<S40>/Data Store Memory'
                                         */
  real_T Sink_Temperature_Value;       /* Expression: 1
                                        * Referenced by: '<S22>/Sink_Temperature'
                                        */
  real_T Delay1_InitialCondition;      /* Expression: 0.0
                                        * Referenced by: '<Root>/Delay1'
                                        */
  real_T DiscreteTransferFcn3_NumCoef[8];/* Expression: [1 1 1 1 1 1 1 1]
                                          * Referenced by: '<S31>/Discrete Transfer Fcn3'
                                          */
  real_T DiscreteTransferFcn3_DenCoef[8];/* Expression: [8 0 0 0 0 0 0 0]
                                          * Referenced by: '<S31>/Discrete Transfer Fcn3'
                                          */
  real_T DiscreteTransferFcn3_InitialSta;/* Expression: 0
                                          * Referenced by: '<S31>/Discrete Transfer Fcn3'
                                          */
  real_T DCOffsetVDist_Value;          /* Expression: 0
                                        * Referenced by: '<S59>/DC Offset V Dist'
                                        */
  real_T VoltageDisturbanceType_Value; /* Expression: 4
                                        * Referenced by: '<S59>/Voltage Disturbance Type'
                                        */
  real_T SinusoidalVDist_Amplitude;    /* Expression: 0
                                        * Referenced by: '<S59>/Sinusoidal V Dist'
                                        */
  real_T SinusoidalVDist_Frequency;    /* Expression: 1
                                        * Referenced by: '<S59>/Sinusoidal V Dist'
                                        */
  real_T RandomNoiseVDist_Minimum;     /* Expression: 0
                                        * Referenced by: '<S59>/Random Noise V Dist'
                                        */
  real_T RandomNoiseVDist_Maximum;     /* Expression: 1
                                        * Referenced by: '<S59>/Random Noise V Dist'
                                        */
  real_T RandomNoiseVDist_Seed;        /* Expression: 0
                                        * Referenced by: '<S59>/Random Noise V Dist'
                                        */
  real_T SquareWaveVDist_Amplitude;    /* Expression: 0
                                        * Referenced by: '<S59>/Square Wave V Dist'
                                        */
  real_T SquareWaveVDist_Frequency;    /* Expression: 1
                                        * Referenced by: '<S59>/Square Wave V Dist'
                                        */
  real_T Zero_Value_o;                 /* Expression: 0
                                        * Referenced by: '<S59>/Zero'
                                        */
  real_T Delay_InitialCondition;       /* Expression: 0.0
                                        * Referenced by: '<S58>/Delay'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S58>/Constant1'
                                        */
  real_T DCOffsetVoltageCommand_Value; /* Expression: 0
                                        * Referenced by: '<S35>/DC Offset Voltage Command'
                                        */
  real_T VoltageCommandType_Value;     /* Expression: 4
                                        * Referenced by: '<S35>/Voltage Command Type'
                                        */
  real_T SinusoidalVoltageCommand_Amplit;/* Expression: 0
                                          * Referenced by: '<S35>/Sinusoidal Voltage Command'
                                          */
  real_T SinusoidalVoltageCommand_Freque;/* Expression: 1
                                          * Referenced by: '<S35>/Sinusoidal Voltage Command'
                                          */
  real_T RandomNoiseVoltageCommand_Minim;/* Expression: 0
                                          * Referenced by: '<S35>/Random Noise Voltage Command'
                                          */
  real_T RandomNoiseVoltageCommand_Maxim;/* Expression: 1
                                          * Referenced by: '<S35>/Random Noise Voltage Command'
                                          */
  real_T RandomNoiseVoltageCommand_Seed;/* Expression: 0
                                         * Referenced by: '<S35>/Random Noise Voltage Command'
                                         */
  real_T SquareWaveVoltageCommand_Amplit;/* Expression: 0
                                          * Referenced by: '<S35>/Square Wave Voltage Command'
                                          */
  real_T SquareWaveVoltageCommand_Freque;/* Expression: 1
                                          * Referenced by: '<S35>/Square Wave Voltage Command'
                                          */
  real_T SwitchToVoltageControl_Value; /* Expression: 0
                                        * Referenced by: '<Root>/SwitchToVoltageControl'
                                        */
  real_T DiscreteTransferFcn_NumCoef[4];/* Expression: [1 1 1 1]
                                         * Referenced by: '<Root>/Discrete Transfer Fcn'
                                         */
  real_T DiscreteTransferFcn_DenCoef[4];/* Expression: [4 0 0 0]
                                         * Referenced by: '<Root>/Discrete Transfer Fcn'
                                         */
  real_T DiscreteTransferFcn_InitialStat;/* Expression: 0
                                          * Referenced by: '<Root>/Discrete Transfer Fcn'
                                          */
  real_T DCOffsetCurrentCommand_Value; /* Expression: 0
                                        * Referenced by: '<S34>/DC Offset Current Command'
                                        */
  real_T CurrentCommandType_Value;     /* Expression: 7
                                        * Referenced by: '<S34>/Current Command Type'
                                        */
  real_T SinusoidalCurrentCommand_Amplit;/* Expression: 0
                                          * Referenced by: '<S34>/Sinusoidal Current Command'
                                          */
  real_T SinusoidalCurrentCommand_Freque;/* Expression: 1
                                          * Referenced by: '<S34>/Sinusoidal Current Command'
                                          */
  real_T RandomNoiseCurrentCommand_Minim;/* Expression: 0
                                          * Referenced by: '<S34>/Random Noise Current Command'
                                          */
  real_T RandomNoiseCurrentCommand_Maxim;/* Expression: 1
                                          * Referenced by: '<S34>/Random Noise Current Command'
                                          */
  real_T RandomNoiseCurrentCommand_Seed;/* Expression: 0
                                         * Referenced by: '<S34>/Random Noise Current Command'
                                         */
  real_T SquareWaveCurrentCommand_Amplit;/* Expression: 0
                                          * Referenced by: '<S34>/Square Wave Current Command'
                                          */
  real_T SquareWaveCurrentCommand_Freque;/* Expression: 1
                                          * Referenced by: '<S34>/Square Wave Current Command'
                                          */
  real_T ManualLoadCurrentSettingEnable_;/* Expression: 0
                                          * Referenced by: '<S34>/ManualLoadCurrentSettingEnable'
                                          */
  real_T Switch2_Threshold;            /* Expression: 1
                                        * Referenced by: '<S34>/Switch2'
                                        */
  real_T Pmin_Value;                   /* Expression: 0
                                        * Referenced by: '<S78>/Pmin'
                                        */
  real_T PowerShareRatio_Value;        /* Expression: 0.8
                                        * Referenced by: '<S78>/PowerShareRatio'
                                        */
  real_T Switch2_Threshold_n;          /* Expression: 1
                                        * Referenced by: '<S78>/Switch2'
                                        */
  real_T Zero_Value_k;                 /* Expression: 0
                                        * Referenced by: '<S34>/Zero'
                                        */
  real_T Gain_Gain;                    /* Expression: Ts2/C
                                        * Referenced by: '<Root>/Gain'
                                        */
  real_T BatVoltageLowerThresh_Value;  /* Expression: BatVoltageLowerThresh
                                        * Referenced by: '<Root>/BatVoltageLowerThresh'
                                        */
  real_T BatVoltageUpperThresh_Value;  /* Expression: BatVoltageUpperThresh
                                        * Referenced by: '<Root>/BatVoltageUpperThresh'
                                        */
  real_T UCVoltageLowerThresh_Value;   /* Expression: UCVoltageLowerThresh
                                        * Referenced by: '<Root>/UCVoltageLowerThresh'
                                        */
  real_T UCVoltageUpperThresh_Value;   /* Expression: UCVoltageUpperThresh
                                        * Referenced by: '<Root>/UCVoltageUpperThresh'
                                        */
  real_T Kp_vc_Value;                  /* Expression: Kp_vc
                                        * Referenced by: '<Root>/Kp_vc'
                                        */
  real_T Switch5_Threshold;            /* Expression: 1
                                        * Referenced by: '<Root>/Switch5'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S28>/Constant'
                                        */
  real_T Kp_vc_Gain;                   /* Expression: Kp_vc
                                        * Referenced by: '<S28>/Kp_vc'
                                        */
  real_T DCOffsetIDist_Value;          /* Expression: 0
                                        * Referenced by: '<S62>/DC Offset I Dist'
                                        */
  real_T CurrentDisturbanceType_Value; /* Expression: 4
                                        * Referenced by: '<S62>/Current Disturbance Type'
                                        */
  real_T SinusoidalIDist_Amplitude;    /* Expression: 0
                                        * Referenced by: '<S62>/Sinusoidal I Dist'
                                        */
  real_T SinusoidalIDist_Frequency;    /* Expression: 1
                                        * Referenced by: '<S62>/Sinusoidal I Dist'
                                        */
  real_T RandomNoiseIDist_Minimum;     /* Expression: 0
                                        * Referenced by: '<S62>/Random Noise I Dist'
                                        */
  real_T RandomNoiseIDist_Maximum;     /* Expression: 1
                                        * Referenced by: '<S62>/Random Noise I Dist'
                                        */
  real_T RandomNoiseIDist_Seed;        /* Expression: 0
                                        * Referenced by: '<S62>/Random Noise I Dist'
                                        */
  real_T SquareWaveIDist_Amplitude;    /* Expression: 0
                                        * Referenced by: '<S62>/Square Wave I Dist'
                                        */
  real_T SquareWaveIDist_Frequency;    /* Expression: 1
                                        * Referenced by: '<S62>/Square Wave I Dist'
                                        */
  real_T Zero_Value_f;                 /* Expression: 0
                                        * Referenced by: '<S62>/Zero'
                                        */
  real_T EnableStateMachine_Value;     /* Expression: 1
                                        * Referenced by: '<Root>/EnableStateMachine'
                                        */
  real_T Saturation1_UpperSat_c;       /* Expression: Icommand_Limit
                                        * Referenced by: '<S27>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_o;       /* Expression: -Icommand_Limit
                                        * Referenced by: '<S27>/Saturation1'
                                        */
  real_T DiscreteTimeIntegrator_gainval;/* Computed Parameter: DiscreteTimeIntegrator_gainval
                                         * Referenced by: '<S27>/Discrete-Time Integrator'
                                         */
  real_T DiscreteTimeIntegrator_IC;    /* Expression: 0
                                        * Referenced by: '<S27>/Discrete-Time Integrator'
                                        */
  real_T DiscreteTimeIntegrator_UpperSat;/* Expression: Ireg_Integ_Limit
                                          * Referenced by: '<S27>/Discrete-Time Integrator'
                                          */
  real_T DiscreteTimeIntegrator_LowerSat;/* Expression: -Ireg_Integ_Limit
                                          * Referenced by: '<S27>/Discrete-Time Integrator'
                                          */
  real_T Constant_Value_c;             /* Expression: 0
                                        * Referenced by: '<S27>/Constant'
                                        */
  real_T InvertErrorForBoost_Gain;     /* Expression: -1
                                        * Referenced by: '<S27>/InvertErrorForBoost'
                                        */
  real_T Ra_Gain_o;                    /* Expression: Ra
                                        * Referenced by: '<S27>/Ra'
                                        */
  real_T SwitchToEnableDID_Value;      /* Expression: 0
                                        * Referenced by: '<Root>/SwitchToEnableDID'
                                        */
  real_T Vrail_rated_Value;            /* Expression: Vrail_rated
                                        * Referenced by: '<Root>/Vrail_rated'
                                        */
  real_T Switch_Threshold;             /* Expression: 1
                                        * Referenced by: '<S27>/Switch'
                                        */
  real_T Saturation_UpperSat_m;        /* Expression: 1
                                        * Referenced by: '<S27>/Saturation'
                                        */
  real_T Saturation_LowerSat_k;        /* Expression: 0
                                        * Referenced by: '<S27>/Saturation'
                                        */
  real_T DutyCycleTopEnable_Value;     /* Expression: 0
                                        * Referenced by: '<Root>/Duty CycleTopEnable'
                                        */
  real_T Delay2_InitialCondition;      /* Expression: 0.0
                                        * Referenced by: '<Root>/Delay2'
                                        */
  real_T DutyCycleBotEnable_Value;     /* Expression: 0
                                        * Referenced by: '<Root>/Duty CycleBotEnable'
                                        */
  real_T TurnOnSystem_Value;           /* Expression: 0
                                        * Referenced by: '<Root>/TurnOnSystem'
                                        */
  real_T EnableAutomaticControl_Value; /* Expression: 0
                                        * Referenced by: '<Root>/EnableAutomaticControl'
                                        */
  real_T ModeSelection_Value;          /* Expression: 0
                                        * Referenced by: '<Root>/Mode Selection'
                                        */
  real_T Error_Reset_Value;            /* Expression: 1
                                        * Referenced by: '<Root>/Error_Reset'
                                        */
  real_T DiscreteTransferFcn1_NumCoef[2];/* Expression: [1 -1]
                                          * Referenced by: '<S31>/Discrete Transfer Fcn1'
                                          */
  real_T DiscreteTransferFcn1_DenCoef[2];/* Expression: [Ts2 0]
                                          * Referenced by: '<S31>/Discrete Transfer Fcn1'
                                          */
  real_T DiscreteTransferFcn1_InitialSta;/* Expression: 0
                                          * Referenced by: '<S31>/Discrete Transfer Fcn1'
                                          */
  real_T DiscreteTransferFcn2_NumCoef[8];/* Expression: [1 1 1 1 1 1 1 1]
                                          * Referenced by: '<S31>/Discrete Transfer Fcn2'
                                          */
  real_T DiscreteTransferFcn2_DenCoef[8];/* Expression: [8 0 0 0 0 0 0 0]
                                          * Referenced by: '<S31>/Discrete Transfer Fcn2'
                                          */
  real_T DiscreteTransferFcn2_InitialSta;/* Expression: 0
                                          * Referenced by: '<S31>/Discrete Transfer Fcn2'
                                          */
  real_T Delay4_InitialCondition;      /* Expression: 0.0
                                        * Referenced by: '<Root>/Delay4'
                                        */
  real_T MaximumBatteryCurrent_Value;  /* Expression: MaxBatCurrent
                                        * Referenced by: '<S26>/Maximum Battery Current'
                                        */
  real_T BatteryCurrentRelay_OnVal;    /* Expression: 0
                                        * Referenced by: '<S26>/Battery Current Relay'
                                        */
  real_T BatteryCurrentRelay_OffVal;   /* Expression: 0
                                        * Referenced by: '<S26>/Battery Current Relay'
                                        */
  real_T BatteryCurrentRelay_YOn;      /* Expression: 1
                                        * Referenced by: '<S26>/Battery Current Relay'
                                        */
  real_T BatteryCurrentRelay_YOff;     /* Expression: 0
                                        * Referenced by: '<S26>/Battery Current Relay'
                                        */
  real_T MaximumUltraCapacitorCurrent_Va;/* Expression: MaxUCCurrent
                                          * Referenced by: '<S26>/Maximum UltraCapacitor Current'
                                          */
  real_T UltraCapacitorCurrentRelay_OnVa;/* Expression: 0
                                          * Referenced by: '<S26>/UltraCapacitor Current Relay'
                                          */
  real_T UltraCapacitorCurrentRelay_OffV;/* Expression: 0
                                          * Referenced by: '<S26>/UltraCapacitor Current Relay'
                                          */
  real_T UltraCapacitorCurrentRelay_YOn;/* Expression: 1
                                         * Referenced by: '<S26>/UltraCapacitor Current Relay'
                                         */
  real_T UltraCapacitorCurrentRelay_YOff;/* Expression: 0
                                          * Referenced by: '<S26>/UltraCapacitor Current Relay'
                                          */
  real_T MaximumBatteryVoltage_Value;  /* Expression: MaxBatVoltage
                                        * Referenced by: '<S26>/Maximum Battery Voltage'
                                        */
  real_T BatteryVoltageRelay_OnVal;    /* Expression: 0
                                        * Referenced by: '<S26>/Battery Voltage Relay'
                                        */
  real_T BatteryVoltageRelay_OffVal;   /* Expression: 0
                                        * Referenced by: '<S26>/Battery Voltage Relay'
                                        */
  real_T BatteryVoltageRelay_YOn;      /* Expression: 1
                                        * Referenced by: '<S26>/Battery Voltage Relay'
                                        */
  real_T BatteryVoltageRelay_YOff;     /* Expression: 0
                                        * Referenced by: '<S26>/Battery Voltage Relay'
                                        */
  real_T MaximumUltracapacitorVoltage_Va;/* Expression: MaxUCVoltage
                                          * Referenced by: '<S26>/Maximum Ultracapacitor Voltage'
                                          */
  real_T UltraCapacitorVoltageRelay_OnVa;/* Expression: 0
                                          * Referenced by: '<S26>/Ultra Capacitor Voltage Relay'
                                          */
  real_T UltraCapacitorVoltageRelay_OffV;/* Expression: 0
                                          * Referenced by: '<S26>/Ultra Capacitor Voltage Relay'
                                          */
  real_T UltraCapacitorVoltageRelay_YOn;/* Expression: 1
                                         * Referenced by: '<S26>/Ultra Capacitor Voltage Relay'
                                         */
  real_T UltraCapacitorVoltageRelay_YOff;/* Expression: 0
                                          * Referenced by: '<S26>/Ultra Capacitor Voltage Relay'
                                          */
  real_T MaximumTemperature_Value;     /* Expression: MaxTemperature
                                        * Referenced by: '<S26>/Maximum Temperature'
                                        */
  real_T TemperatureRelay_OnVal;       /* Expression: 0
                                        * Referenced by: '<S26>/Temperature Relay'
                                        */
  real_T TemperatureRelay_OffVal;      /* Expression: 0
                                        * Referenced by: '<S26>/Temperature Relay'
                                        */
  real_T TemperatureRelay_YOn;         /* Expression: 1
                                        * Referenced by: '<S26>/Temperature Relay'
                                        */
  real_T TemperatureRelay_YOff;        /* Expression: 0
                                        * Referenced by: '<S26>/Temperature Relay'
                                        */
  real_T Ea_Gain;                      /* Expression: Ea
                                        * Referenced by: '<S27>/Ea'
                                        */
  uint32_T DLookupTable_maxIndex[2];   /* Computed Parameter: DLookupTable_maxIndex
                                        * Referenced by: '<S78>/2-D Lookup Table'
                                        */
  uint32_T Delay1_DelayLength;         /* Computed Parameter: Delay1_DelayLength
                                        * Referenced by: '<Root>/Delay1'
                                        */
  uint32_T Delay3_DelayLength;         /* Computed Parameter: Delay3_DelayLength
                                        * Referenced by: '<Root>/Delay3'
                                        */
  uint32_T Delay_DelayLength;          /* Computed Parameter: Delay_DelayLength
                                        * Referenced by: '<S58>/Delay'
                                        */
  uint32_T Delay2_DelayLength;         /* Computed Parameter: Delay2_DelayLength
                                        * Referenced by: '<Root>/Delay2'
                                        */
  uint32_T Delay_DelayLength_l;        /* Computed Parameter: Delay_DelayLength_l
                                        * Referenced by: '<S25>/Delay'
                                        */
  uint32_T Delay2_DelayLength_m;       /* Computed Parameter: Delay2_DelayLength_m
                                        * Referenced by: '<S25>/Delay2'
                                        */
  uint32_T Delay1_DelayLength_n;       /* Computed Parameter: Delay1_DelayLength_n
                                        * Referenced by: '<S25>/Delay1'
                                        */
  uint32_T Delay3_DelayLength_f;       /* Computed Parameter: Delay3_DelayLength_f
                                        * Referenced by: '<S25>/Delay3'
                                        */
  uint32_T Delay4_DelayLength;         /* Computed Parameter: Delay4_DelayLength
                                        * Referenced by: '<Root>/Delay4'
                                        */
  boolean_T Delay3_InitialCondition;   /* Computed Parameter: Delay3_InitialCondition
                                        * Referenced by: '<Root>/Delay3'
                                        */
  boolean_T Memory3_X0;                /* Computed Parameter: Memory3_X0
                                        * Referenced by: '<S26>/Memory3'
                                        */
  boolean_T Memory1_X0;                /* Computed Parameter: Memory1_X0
                                        * Referenced by: '<S26>/Memory1'
                                        */
  boolean_T Memory2_X0;                /* Computed Parameter: Memory2_X0
                                        * Referenced by: '<S26>/Memory2'
                                        */
  boolean_T Memory4_X0;                /* Computed Parameter: Memory4_X0
                                        * Referenced by: '<S26>/Memory4'
                                        */
  boolean_T Memory5_X0;                /* Computed Parameter: Memory5_X0
                                        * Referenced by: '<S26>/Memory5'
                                        */
  boolean_T Delay_InitialCondition_c;  /* Computed Parameter: Delay_InitialCondition_c
                                        * Referenced by: '<S25>/Delay'
                                        */
  boolean_T Memory3_X0_e;              /* Computed Parameter: Memory3_X0_e
                                        * Referenced by: '<S25>/Memory3'
                                        */
  boolean_T Delay2_InitialCondition_k; /* Computed Parameter: Delay2_InitialCondition_k
                                        * Referenced by: '<S25>/Delay2'
                                        */
  boolean_T Memory1_X0_m;              /* Computed Parameter: Memory1_X0_m
                                        * Referenced by: '<S25>/Memory1'
                                        */
  boolean_T Delay1_InitialCondition_f; /* Computed Parameter: Delay1_InitialCondition_f
                                        * Referenced by: '<S25>/Delay1'
                                        */
  boolean_T Memory2_X0_n;              /* Computed Parameter: Memory2_X0_n
                                        * Referenced by: '<S25>/Memory2'
                                        */
  boolean_T Delay3_InitialCondition_i; /* Computed Parameter: Delay3_InitialCondition_i
                                        * Referenced by: '<S25>/Delay3'
                                        */
  boolean_T Memory_X0;                 /* Computed Parameter: Memory_X0
                                        * Referenced by: '<S25>/Memory'
                                        */
  rtP_SampleandHold_DCDCconverter SampleandHold_o;/* '<S40>/Sample and Hold' */
  rtP_SampleandHold_DCDCconverter SampleandHold_dv;/* '<S39>/Sample and Hold' */
  rtP_SampleandHold_DCDCconverter SampleandHold_du;/* '<S38>/Sample and Hold' */
  rtP_SampleandHold_DCDCconverter SampleandHold_d;/* '<S37>/Sample and Hold' */
  rtP_SampleandHold_DCDCconverter SampleandHold;/* '<S36>/Sample and Hold' */
};

/* Real-time Model Data Structure */
struct tag_RTM_DCDCconverter {
  const char_T *path;
  const char_T *modelName;
  struct SimStruct_tag * *childSfunctions;
  const char_T *errorStatus;
  SS_SimMode simMode;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;
  RTWSolverInfo *solverInfoPtr;
  void *sfcnInfo;

  /*
   * ModelData:
   * The following substructure contains information regarding
   * the data used in the model.
   */
  struct {
    void *blockIO;
    const void *constBlockIO;
    void *defaultParam;
    ZCSigState *prevZCSigState;
    real_T *contStates;
    real_T *derivs;
    void *zcSignalValues;
    void *inputs;
    void *outputs;
    boolean_T *contStateDisabled;
    boolean_T zCCacheNeedsReset;
    boolean_T derivCacheNeedsReset;
    boolean_T blkStateChange;
  } ModelData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
    uint32_T options;
    int_T numContStates;
    int_T numU;
    int_T numY;
    int_T numSampTimes;
    int_T numBlocks;
    int_T numBlockIO;
    int_T numBlockPrms;
    int_T numDwork;
    int_T numSFcnPrms;
    int_T numSFcns;
    int_T numIports;
    int_T numOports;
    int_T numNonSampZCs;
    int_T sysDirFeedThru;
    int_T rtwGenSfcn;
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
    void *xpcData;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T stepSize1;
    uint32_T clockTick2;
    uint32_T clockTickH2;
    time_T stepSize2;
    uint32_T clockTick3;
    uint32_T clockTickH3;
    time_T stepSize3;
    uint32_T clockTick4;
    uint32_T clockTickH4;
    time_T stepSize4;
    struct {
      uint16_T TID[5];
    } TaskCounters;

    time_T tStart;
    time_T tFinal;
    time_T timeOfLastOutput;
    void *timingData;
    real_T *varNextHitTimesList;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *sampleTimes;
    time_T *offsetTimes;
    int_T *sampleTimeTaskIDPtr;
    int_T *sampleHits;
    int_T *perTaskSampleHits;
    time_T *t;
    time_T sampleTimesArray[5];
    time_T offsetTimesArray[5];
    int_T sampleTimeTaskIDArray[5];
    int_T sampleHitArray[5];
    int_T perTaskSampleHitsArray[25];
    time_T tArray[5];
  } Timing;

  /*
   * Work:
   * The following substructure contains information regarding
   * the work vectors in the model.
   */
  struct {
    void *dwork;
  } Work;
};

/* Block parameters (auto storage) */
extern Parameters_DCDCconverter DCDCconverter_P;

/* Block signals (auto storage) */
extern BlockIO_DCDCconverter DCDCconverter_B;

/* Block states (auto storage) */
extern D_Work_DCDCconverter DCDCconverter_DWork;

/* External function called from main */
extern time_T rt_SimUpdateDiscreteEvents(
  int_T rtmNumSampTimes, void *rtmTimingData, int_T *rtmSampleHitPtr, int_T
  *rtmPerTaskSampleHits )
  ;

/* External data declarations for dependent source files */

/* Zero-crossing (trigger) state */
extern PrevZCSigStates_DCDCconverter DCDCconverter_PrevZCSigState;

/* Real-time Model object */
extern RT_MODEL_DCDCconverter *const DCDCconverter_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'DCDCconverter'
 * '<S1>'   : 'DCDCconverter/Async Rate Transition'
 * '<S2>'   : 'DCDCconverter/Async Rate Transition1'
 * '<S3>'   : 'DCDCconverter/Async Rate Transition10'
 * '<S4>'   : 'DCDCconverter/Async Rate Transition11'
 * '<S5>'   : 'DCDCconverter/Async Rate Transition12'
 * '<S6>'   : 'DCDCconverter/Async Rate Transition13'
 * '<S7>'   : 'DCDCconverter/Async Rate Transition14'
 * '<S8>'   : 'DCDCconverter/Async Rate Transition15'
 * '<S9>'   : 'DCDCconverter/Async Rate Transition16'
 * '<S10>'  : 'DCDCconverter/Async Rate Transition17'
 * '<S11>'  : 'DCDCconverter/Async Rate Transition18'
 * '<S12>'  : 'DCDCconverter/Async Rate Transition19'
 * '<S13>'  : 'DCDCconverter/Async Rate Transition2'
 * '<S14>'  : 'DCDCconverter/Async Rate Transition20'
 * '<S15>'  : 'DCDCconverter/Async Rate Transition3'
 * '<S16>'  : 'DCDCconverter/Async Rate Transition4'
 * '<S17>'  : 'DCDCconverter/Async Rate Transition5'
 * '<S18>'  : 'DCDCconverter/Async Rate Transition6'
 * '<S19>'  : 'DCDCconverter/Async Rate Transition7'
 * '<S20>'  : 'DCDCconverter/Async Rate Transition8'
 * '<S21>'  : 'DCDCconverter/Async Rate Transition9'
 * '<S22>'  : 'DCDCconverter/Circuit Outputs'
 * '<S23>'  : 'DCDCconverter/DS1103SL_DSP_PWM'
 * '<S24>'  : 'DCDCconverter/ErrorLatchingFunction'
 * '<S25>'  : 'DCDCconverter/Gate Driver Errors'
 * '<S26>'  : 'DCDCconverter/Over Ratings Detection'
 * '<S27>'  : 'DCDCconverter/PI Current Regulator'
 * '<S28>'  : 'DCDCconverter/PI Voltage Regulator'
 * '<S29>'  : 'DCDCconverter/RTI Data'
 * '<S30>'  : 'DCDCconverter/Relays Control'
 * '<S31>'  : 'DCDCconverter/Subsystem'
 * '<S32>'  : 'DCDCconverter/Supervisory Control State Machine'
 * '<S33>'  : 'DCDCconverter/System Configuration State Machine1'
 * '<S34>'  : 'DCDCconverter/Test Icmd'
 * '<S35>'  : 'DCDCconverter/Test Vcmd'
 * '<S36>'  : 'DCDCconverter/Circuit Outputs/Battery_Current'
 * '<S37>'  : 'DCDCconverter/Circuit Outputs/Battery_Voltage'
 * '<S38>'  : 'DCDCconverter/Circuit Outputs/Load_Current'
 * '<S39>'  : 'DCDCconverter/Circuit Outputs/UltraCapacitor_Current'
 * '<S40>'  : 'DCDCconverter/Circuit Outputs/UltraCapacitor_Voltage'
 * '<S41>'  : 'DCDCconverter/Circuit Outputs/Battery_Current/C18 '
 * '<S42>'  : 'DCDCconverter/Circuit Outputs/Battery_Current/Lowpass Filter'
 * '<S43>'  : 'DCDCconverter/Circuit Outputs/Battery_Current/Sample and Hold'
 * '<S44>'  : 'DCDCconverter/Circuit Outputs/Battery_Voltage/C19'
 * '<S45>'  : 'DCDCconverter/Circuit Outputs/Battery_Voltage/Lowpass Filter'
 * '<S46>'  : 'DCDCconverter/Circuit Outputs/Battery_Voltage/Sample and Hold'
 * '<S47>'  : 'DCDCconverter/Circuit Outputs/Load_Current/C13'
 * '<S48>'  : 'DCDCconverter/Circuit Outputs/Load_Current/Lowpass Filter'
 * '<S49>'  : 'DCDCconverter/Circuit Outputs/Load_Current/Sample and Hold'
 * '<S50>'  : 'DCDCconverter/Circuit Outputs/UltraCapacitor_Current/C17'
 * '<S51>'  : 'DCDCconverter/Circuit Outputs/UltraCapacitor_Current/Lowpass Filter'
 * '<S52>'  : 'DCDCconverter/Circuit Outputs/UltraCapacitor_Current/Sample and Hold'
 * '<S53>'  : 'DCDCconverter/Circuit Outputs/UltraCapacitor_Voltage/C20'
 * '<S54>'  : 'DCDCconverter/Circuit Outputs/UltraCapacitor_Voltage/Lowpass Filter'
 * '<S55>'  : 'DCDCconverter/Circuit Outputs/UltraCapacitor_Voltage/Sample and Hold'
 * '<S56>'  : 'DCDCconverter/Gate Driver Errors/DS1103BIT_IN_G3'
 * '<S57>'  : 'DCDCconverter/PI Current Regulator/Async Rate Transition1'
 * '<S58>'  : 'DCDCconverter/PI Current Regulator/ModeSwitchingLogic'
 * '<S59>'  : 'DCDCconverter/PI Current Regulator/Test Vdist'
 * '<S60>'  : 'DCDCconverter/PI Current Regulator/Test Vdist/Async Rate Transition1'
 * '<S61>'  : 'DCDCconverter/PI Current Regulator/Test Vdist/Async Rate Transition2'
 * '<S62>'  : 'DCDCconverter/PI Voltage Regulator/Test Idist'
 * '<S63>'  : 'DCDCconverter/PI Voltage Regulator/Test Idist/Async Rate Transition1'
 * '<S64>'  : 'DCDCconverter/PI Voltage Regulator/Test Idist/Async Rate Transition2'
 * '<S65>'  : 'DCDCconverter/RTI Data/RTI Data Store'
 * '<S66>'  : 'DCDCconverter/RTI Data/RTI Data Store/RTI Data Store'
 * '<S67>'  : 'DCDCconverter/RTI Data/RTI Data Store/RTI Data Store/RTI Data Store'
 * '<S68>'  : 'DCDCconverter/Relays Control/DS1103BIT_OUT_G0'
 * '<S69>'  : 'DCDCconverter/Subsystem/Async Rate Transition19'
 * '<S70>'  : 'DCDCconverter/Test Icmd/Async Rate Transition1'
 * '<S71>'  : 'DCDCconverter/Test Icmd/Async Rate Transition2'
 * '<S72>'  : 'DCDCconverter/Test Icmd/Async Rate Transition3'
 * '<S73>'  : 'DCDCconverter/Test Icmd/Async Rate Transition4'
 * '<S74>'  : 'DCDCconverter/Test Icmd/Async Rate Transition5'
 * '<S75>'  : 'DCDCconverter/Test Icmd/Async Rate Transition6'
 * '<S76>'  : 'DCDCconverter/Test Icmd/Current_Profile_10Hz'
 * '<S77>'  : 'DCDCconverter/Test Icmd/Current_Profile_1Hz'
 * '<S78>'  : 'DCDCconverter/Test Icmd/RuleBasedControlWithLUT'
 * '<S79>'  : 'DCDCconverter/Test Icmd/RuleBasedControlWithLUT/MATLAB Function1'
 * '<S80>'  : 'DCDCconverter/Test Vcmd/Async Rate Transition1'
 * '<S81>'  : 'DCDCconverter/Test Vcmd/Async Rate Transition2'
 */
#endif                                 /* RTW_HEADER_DCDCconverter_h_ */
