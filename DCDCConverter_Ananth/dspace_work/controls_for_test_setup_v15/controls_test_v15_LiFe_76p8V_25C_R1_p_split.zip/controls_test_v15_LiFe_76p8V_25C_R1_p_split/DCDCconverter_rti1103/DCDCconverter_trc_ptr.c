/***************************************************************************

   Source file DCDCconverter_trc_ptr.c:

   Definition of function that initializes the global TRC pointers

   RTI1103 7.1 (02-Nov-2013)
   Wed Sep 09 10:48:56 2015

   (c) Copyright 2008, dSPACE GmbH. All rights reserved.

 *****************************************************************************/

/* Include header file. */
#include "DCDCconverter_trc_ptr.h"

/* Definition of Global pointers to data type transitions (for TRC-file access) */
volatile real_T *p_DCDCconverter_B_real_T_0 = 0;
volatile boolean_T *p_DCDCconverter_B_boolean_T_1 = 0;
volatile real_T *p_DCDCconverter_B_real_T_2 = 0;
volatile real_T *p_DCDCconverter_B_real_T_3 = 0;
volatile real_T *p_DCDCconverter_B_real_T_4 = 0;
volatile real_T *p_DCDCconverter_B_real_T_5 = 0;
volatile real_T *p_DCDCconverter_B_real_T_6 = 0;
volatile real_T *p_DCDCconverter_P_real_T_0 = 0;
volatile uint32_T *p_DCDCconverter_P_uint32_T_1 = 0;
volatile boolean_T *p_DCDCconverter_P_boolean_T_2 = 0;
volatile real_T *p_DCDCconverter_P_real_T_3 = 0;
volatile real_T *p_DCDCconverter_P_real_T_4 = 0;
volatile real_T *p_DCDCconverter_P_real_T_5 = 0;
volatile real_T *p_DCDCconverter_P_real_T_6 = 0;
volatile real_T *p_DCDCconverter_P_real_T_7 = 0;
volatile real_T *p_DCDCconverter_DWork_real_T_0 = 0;
volatile int32_T *p_DCDCconverter_DWork_int32_T_1 = 0;
volatile uint32_T *p_DCDCconverter_DWork_uint32_T_2 = 0;
volatile int_T *p_DCDCconverter_DWork_int_T_3 = 0;
volatile boolean_T *p_DCDCconverter_DWork_boolean_T_4 = 0;
volatile int8_T *p_DCDCconverter_DWork_int8_T_5 = 0;
volatile uint8_T *p_DCDCconverter_DWork_uint8_T_6 = 0;
volatile boolean_T *p_DCDCconverter_DWork_boolean_T_7 = 0;
