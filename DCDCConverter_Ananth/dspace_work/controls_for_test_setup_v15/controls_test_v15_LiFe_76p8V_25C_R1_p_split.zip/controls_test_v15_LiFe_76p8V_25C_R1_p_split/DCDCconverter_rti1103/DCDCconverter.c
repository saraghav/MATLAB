/*
 * DCDCconverter.c
 *
 * Code generation for model "DCDCconverter".
 *
 * Model version              : 1.403
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Wed Sep 09 10:48:56 2015
 *
 * Target selection: rti1103.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "DCDCconverter_trc_ptr.h"
#include "DCDCconverter.h"
#include "DCDCconverter_private.h"

/* Named constants for Chart: '<Root>/Supervisory Control State Machine' */
#define DCDCconv_IN_CurrentControlState ((uint8_T)3U)
#define DCDCconverte_IN_ChargeDownState ((uint8_T)1U)
#define DCDCconverte_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define DCDCconverter_IN_ChargeUpState ((uint8_T)2U)
#define DCDCconverter_IN_InitState     ((uint8_T)4U)

/* Named constants for Chart: '<Root>/System Configuration State Machine1' */
#define DCDCcon_IN_AutomaticControlMode ((uint8_T)1U)
#define DCDCconvert_IN_FinishedCharging ((uint8_T)4U)
#define DCDCconverte_IN_DischargingRail ((uint8_T)3U)
#define DCDCconverte_IN_ManualBoostMode ((uint8_T)5U)
#define DCDCconverter_IN_ChargingRail  ((uint8_T)2U)
#define DCDCconverter_IN_ManualBuckMode ((uint8_T)6U)
#define DCDCconverter_IN_Off           ((uint8_T)7U)

/* Block signals (auto storage) */
BlockIO_DCDCconverter DCDCconverter_B;

/* Block states (auto storage) */
D_Work_DCDCconverter DCDCconverter_DWork;

/* Previous zero-crossings (trigger) states */
PrevZCSigStates_DCDCconverter DCDCconverter_PrevZCSigState;

/* Real-time model */
RT_MODEL_DCDCconverter DCDCconverter_M_;
RT_MODEL_DCDCconverter *const DCDCconverter_M = &DCDCconverter_M_;
static void rate_monotonic_scheduler(void);
real_T look2_binlxpw(real_T u0, real_T u1, const real_T bp0[], const real_T bp1[],
                     const real_T table[], const uint32_T maxIndex[], uint32_T
                     stride)
{
  real_T frac;
  uint32_T bpIndices[2];
  real_T fractions[2];
  real_T yL_1d;
  uint32_T iRght;
  uint32_T bpIdx;
  uint32_T iLeft;

  /* Lookup 2-D
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear'
     Extrapolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Linear'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0U]) {
    iLeft = 0U;
    frac = (u0 - bp0[0U]) / (bp0[1U] - bp0[0U]);
  } else if (u0 < bp0[maxIndex[0U]]) {
    /* Binary Search */
    bpIdx = maxIndex[0U] >> 1U;
    iLeft = 0U;
    iRght = maxIndex[0U];
    while (iRght - iLeft > 1U) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1U;
    }

    frac = (u0 - bp0[iLeft]) / (bp0[iLeft + 1U] - bp0[iLeft]);
  } else {
    iLeft = maxIndex[0U] - 1U;
    frac = (u0 - bp0[maxIndex[0U] - 1U]) / (bp0[maxIndex[0U]] - bp0[maxIndex[0U]
      - 1U]);
  }

  fractions[0U] = frac;
  bpIndices[0U] = iLeft;

  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Linear'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u1 <= bp1[0U]) {
    iLeft = 0U;
    frac = (u1 - bp1[0U]) / (bp1[1U] - bp1[0U]);
  } else if (u1 < bp1[maxIndex[1U]]) {
    /* Binary Search */
    bpIdx = maxIndex[1U] >> 1U;
    iLeft = 0U;
    iRght = maxIndex[1U];
    while (iRght - iLeft > 1U) {
      if (u1 < bp1[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1U;
    }

    frac = (u1 - bp1[iLeft]) / (bp1[iLeft + 1U] - bp1[iLeft]);
  } else {
    iLeft = maxIndex[1U] - 1U;
    frac = (u1 - bp1[maxIndex[1U] - 1U]) / (bp1[maxIndex[1U]] - bp1[maxIndex[1U]
      - 1U]);
  }

  /* Interpolation 2-D
     Interpolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'off'
     Overflow mode: 'portable wrapping'
   */
  bpIdx = iLeft * stride + bpIndices[0U];
  yL_1d = (table[bpIdx + 1U] - table[bpIdx]) * fractions[0U] + table[bpIdx];
  bpIdx += stride;
  return (((table[bpIdx + 1U] - table[bpIdx]) * fractions[0U] + table[bpIdx]) -
          yL_1d) * frac + yL_1d;
}

time_T rt_SimUpdateDiscreteEvents(
  int_T rtmNumSampTimes, void *rtmTimingData, int_T *rtmSampleHitPtr, int_T
  *rtmPerTaskSampleHits )
{
  rtmSampleHitPtr[1] = rtmStepTask(DCDCconverter_M, 1);
  rtmSampleHitPtr[2] = rtmStepTask(DCDCconverter_M, 2);
  rtmSampleHitPtr[3] = rtmStepTask(DCDCconverter_M, 3);
  rtmSampleHitPtr[4] = rtmStepTask(DCDCconverter_M, 4);
  UNUSED_PARAMETER(rtmNumSampTimes);
  UNUSED_PARAMETER(rtmTimingData);
  UNUSED_PARAMETER(rtmPerTaskSampleHits);
  return(-1);
}

/*
 *   This function updates active task flag for each subrate
 * and rate transition flags for tasks that exchange data.
 * The function assumes rate-monotonic multitasking scheduler.
 * The function must be called at model base rate so that
 * the generated code self-manages all its subrates and rate
 * transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (DCDCconverter_M->Timing.TaskCounters.TID[2])++;
  if ((DCDCconverter_M->Timing.TaskCounters.TID[2]) > 9) {/* Sample time: [0.0002s, 0.0s] */
    DCDCconverter_M->Timing.TaskCounters.TID[2] = 0;
  }

  (DCDCconverter_M->Timing.TaskCounters.TID[3])++;
  if ((DCDCconverter_M->Timing.TaskCounters.TID[3]) > 2499) {/* Sample time: [0.05s, 0.0s] */
    DCDCconverter_M->Timing.TaskCounters.TID[3] = 0;
  }

  (DCDCconverter_M->Timing.TaskCounters.TID[4])++;
  if ((DCDCconverter_M->Timing.TaskCounters.TID[4]) > 24999) {/* Sample time: [0.5s, 0.0s] */
    DCDCconverter_M->Timing.TaskCounters.TID[4] = 0;
  }
}

/*
 * Start for trigger system:
 *    '<S36>/Sample and Hold'
 *    '<S37>/Sample and Hold'
 *    '<S38>/Sample and Hold'
 *    '<S39>/Sample and Hold'
 *    '<S40>/Sample and Hold'
 */
void DCDCconvert_SampleandHold_Start(rtB_SampleandHold_DCDCconverter *localB,
  rtP_SampleandHold_DCDCconverter *localP)
{
  /* VirtualOutportStart for Outport: '<S43>/ ' */
  localB->In = localP->_Y0;
}

/*
 * Output and update for trigger system:
 *    '<S36>/Sample and Hold'
 *    '<S37>/Sample and Hold'
 *    '<S38>/Sample and Hold'
 *    '<S39>/Sample and Hold'
 *    '<S40>/Sample and Hold'
 */
void DCDCconverter_SampleandHold(real_T rtu_0, real_T rtu_1,
  rtB_SampleandHold_DCDCconverter *localB, rtZCE_SampleandHold_DCDCconvert
  *localZCE)
{
  ZCEventType zcEvent;

  /* Outputs for Triggered SubSystem: '<S36>/Sample and Hold' incorporates:
   *  TriggerPort: '<S43>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->SampleandHold_Trig_ZCE,
                     (rtu_0));
  if (zcEvent != NO_ZCEVENT) {
    /* Inport: '<S43>/In' */
    localB->In = rtu_1;
  }

  /* End of Outputs for SubSystem: '<S36>/Sample and Hold' */
}

real_T rt_urand_Upu32_Yd_f_pw_snf(uint32_T *u)
{
  uint32_T lo;
  uint32_T hi;

  /* Uniform random number generator (random number between 0 and 1)

     #define IA      16807                      magic multiplier = 7^5
     #define IM      2147483647                 modulus = 2^31-1
     #define IQ      127773                     IM div IA
     #define IR      2836                       IM modulo IA
     #define S       4.656612875245797e-10      reciprocal of 2^31-1
     test = IA * (seed % IQ) - IR * (seed/IQ)
     seed = test < 0 ? (test + IM) : test
     return (seed*S)
   */
  lo = *u % 127773U * 16807U;
  hi = *u / 127773U * 2836U;
  if (lo < hi) {
    *u = 2147483647U - (hi - lo);
  } else {
    *u = lo - hi;
  }

  return (real_T)*u * 4.6566128752457969E-10;
}

/* Model output function for TID0 */
static void DCDCconverter_output0(void) /* Sample time: [0.0s, 0.0s] */
{
  int32_T idxN;
  int32_T cff;
  real_T acc;
  int32_T j;
  real_T u;
  real_T u_0;

  {                                    /* Sample time: [0.0s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* S-Function (rti_commonblock): '<S41>/S-Function' */
  /* This comment workarounds a code generation problem */

  /* DiscreteFir: '<S42>/Generated Filter Block' */
  idxN = DCDCconverter_DWork.GeneratedFilterBlock_circBuf;
  cff = 1;
  acc = DCDCconverter_B.SFunction *
    DCDCconverter_P.GeneratedFilterBlock_Coefficien[0];
  for (j = idxN; j < 73; j++) {
    acc += DCDCconverter_DWork.GeneratedFilterBlock_states[j] *
      DCDCconverter_P.GeneratedFilterBlock_Coefficien[cff];
    cff++;
  }

  for (j = 0; j < idxN; j++) {
    acc += DCDCconverter_DWork.GeneratedFilterBlock_states[j] *
      DCDCconverter_P.GeneratedFilterBlock_Coefficien[cff];
    cff++;
  }

  DCDCconverter_B.GeneratedFilterBlock = acc;

  /* End of DiscreteFir: '<S42>/Generated Filter Block' */

  /* Outputs for Triggered SubSystem: '<S36>/Sample and Hold' */

  /* Constant: '<Root>/Zeroing' */
  DCDCconverter_SampleandHold(DCDCconverter_P.Zeroing_Value,
    DCDCconverter_B.GeneratedFilterBlock, &DCDCconverter_B.SampleandHold,
    &DCDCconverter_PrevZCSigState.SampleandHold);

  /* End of Outputs for SubSystem: '<S36>/Sample and Hold' */

  /* DataStoreWrite: '<S36>/Zeroing' */
  DCDCconverter_DWork.Offset = DCDCconverter_B.SampleandHold.In;

  /* DataStoreRead: '<S36>/Data Store Read' */
  DCDCconverter_B.DataStoreRead = DCDCconverter_DWork.Offset;

  /* Sum: '<S36>/Add' */
  DCDCconverter_B.Add = DCDCconverter_B.GeneratedFilterBlock -
    DCDCconverter_B.DataStoreRead;

  /* Gain: '<S36>/Current Sensor Scaling' */
  DCDCconverter_B.CurrentSensorScaling =
    DCDCconverter_P.CurrentSensorScaling_Gain_n * DCDCconverter_B.Add;

  /* S-Function (rti_commonblock): '<S44>/S-Function' */
  /* This comment workarounds a code generation problem */

  /* DiscreteFir: '<S45>/Generated Filter Block' */
  idxN = DCDCconverter_DWork.GeneratedFilterBlock_circBuf_c;
  cff = 1;
  acc = DCDCconverter_B.SFunction_k *
    DCDCconverter_P.GeneratedFilterBlock_Coeffici_p[0];
  for (j = idxN; j < 73; j++) {
    acc += DCDCconverter_DWork.GeneratedFilterBlock_states_i[j] *
      DCDCconverter_P.GeneratedFilterBlock_Coeffici_p[cff];
    cff++;
  }

  for (j = 0; j < idxN; j++) {
    acc += DCDCconverter_DWork.GeneratedFilterBlock_states_i[j] *
      DCDCconverter_P.GeneratedFilterBlock_Coeffici_p[cff];
    cff++;
  }

  DCDCconverter_B.GeneratedFilterBlock_m = acc;

  /* End of DiscreteFir: '<S45>/Generated Filter Block' */

  /* Outputs for Triggered SubSystem: '<S37>/Sample and Hold' */

  /* Constant: '<Root>/Zeroing' */
  DCDCconverter_SampleandHold(DCDCconverter_P.Zeroing_Value,
    DCDCconverter_B.GeneratedFilterBlock_m, &DCDCconverter_B.SampleandHold_d,
    &DCDCconverter_PrevZCSigState.SampleandHold_d);

  /* End of Outputs for SubSystem: '<S37>/Sample and Hold' */

  /* DataStoreWrite: '<S37>/Zeroing' */
  DCDCconverter_DWork.Offset_p = DCDCconverter_B.SampleandHold_d.In;

  /* DataStoreRead: '<S37>/Data Store Read' */
  DCDCconverter_B.DataStoreRead_p = DCDCconverter_DWork.Offset_p;

  /* Sum: '<S37>/Add' */
  DCDCconverter_B.Add_d = DCDCconverter_B.GeneratedFilterBlock_m -
    DCDCconverter_B.DataStoreRead_p;

  /* Gain: '<S37>/Voltage Sensor Scaling' */
  DCDCconverter_B.VoltageSensorScaling =
    DCDCconverter_P.VoltageSensorScaling_Gain * DCDCconverter_B.Add_d;

  /* S-Function (rti_commonblock): '<S47>/S-Function' */
  /* This comment workarounds a code generation problem */

  /* DiscreteFir: '<S48>/Generated Filter Block' */
  idxN = DCDCconverter_DWork.GeneratedFilterBlock_circBuf_d;
  cff = 1;
  acc = DCDCconverter_B.SFunction_m *
    DCDCconverter_P.GeneratedFilterBlock_Coeffici_n[0];
  for (j = idxN; j < 73; j++) {
    acc += DCDCconverter_DWork.GeneratedFilterBlock_states_e[j] *
      DCDCconverter_P.GeneratedFilterBlock_Coeffici_n[cff];
    cff++;
  }

  for (j = 0; j < idxN; j++) {
    acc += DCDCconverter_DWork.GeneratedFilterBlock_states_e[j] *
      DCDCconverter_P.GeneratedFilterBlock_Coeffici_n[cff];
    cff++;
  }

  DCDCconverter_B.GeneratedFilterBlock_l = acc;

  /* End of DiscreteFir: '<S48>/Generated Filter Block' */

  /* Outputs for Triggered SubSystem: '<S38>/Sample and Hold' */

  /* Constant: '<Root>/Zeroing' */
  DCDCconverter_SampleandHold(DCDCconverter_P.Zeroing_Value,
    DCDCconverter_B.GeneratedFilterBlock_l, &DCDCconverter_B.SampleandHold_du,
    &DCDCconverter_PrevZCSigState.SampleandHold_du);

  /* End of Outputs for SubSystem: '<S38>/Sample and Hold' */

  /* DataStoreWrite: '<S38>/Zeroing' */
  DCDCconverter_DWork.Offset_i = DCDCconverter_B.SampleandHold_du.In;

  /* S-Function (rti_commonblock): '<S50>/S-Function' */
  /* This comment workarounds a code generation problem */

  /* DiscreteFir: '<S51>/Generated Filter Block' */
  idxN = DCDCconverter_DWork.GeneratedFilterBlock_circBuf_cj;
  cff = 1;
  acc = DCDCconverter_B.SFunction_f *
    DCDCconverter_P.GeneratedFilterBlock_Coeffici_m[0];
  for (j = idxN; j < 73; j++) {
    acc += DCDCconverter_DWork.GeneratedFilterBlock_states_f[j] *
      DCDCconverter_P.GeneratedFilterBlock_Coeffici_m[cff];
    cff++;
  }

  for (j = 0; j < idxN; j++) {
    acc += DCDCconverter_DWork.GeneratedFilterBlock_states_f[j] *
      DCDCconverter_P.GeneratedFilterBlock_Coeffici_m[cff];
    cff++;
  }

  DCDCconverter_B.GeneratedFilterBlock_f = acc;

  /* End of DiscreteFir: '<S51>/Generated Filter Block' */

  /* Outputs for Triggered SubSystem: '<S39>/Sample and Hold' */

  /* Constant: '<Root>/Zeroing' */
  DCDCconverter_SampleandHold(DCDCconverter_P.Zeroing_Value,
    DCDCconverter_B.GeneratedFilterBlock_f, &DCDCconverter_B.SampleandHold_dv,
    &DCDCconverter_PrevZCSigState.SampleandHold_dv);

  /* End of Outputs for SubSystem: '<S39>/Sample and Hold' */

  /* DataStoreWrite: '<S39>/Zeroing' */
  DCDCconverter_DWork.Offset_p0 = DCDCconverter_B.SampleandHold_dv.In;

  /* DataStoreRead: '<S39>/Data Store Read' */
  DCDCconverter_B.DataStoreRead_o = DCDCconverter_DWork.Offset_p0;

  /* Sum: '<S39>/Add' */
  DCDCconverter_B.Add_m = DCDCconverter_B.GeneratedFilterBlock_f -
    DCDCconverter_B.DataStoreRead_o;

  /* Gain: '<S39>/Current Sensor Scaling' */
  DCDCconverter_B.CurrentSensorScaling_l =
    DCDCconverter_P.CurrentSensorScaling_Gain_k * DCDCconverter_B.Add_m;

  /* S-Function (rti_commonblock): '<S53>/S-Function' */
  /* This comment workarounds a code generation problem */

  /* DiscreteFir: '<S54>/Generated Filter Block' */
  idxN = DCDCconverter_DWork.GeneratedFilterBlock_circBuf_h;
  cff = 1;
  acc = DCDCconverter_B.SFunction_n *
    DCDCconverter_P.GeneratedFilterBlock_Coeffic_mf[0];
  for (j = idxN; j < 73; j++) {
    acc += DCDCconverter_DWork.GeneratedFilterBlock_states_o[j] *
      DCDCconverter_P.GeneratedFilterBlock_Coeffic_mf[cff];
    cff++;
  }

  for (j = 0; j < idxN; j++) {
    acc += DCDCconverter_DWork.GeneratedFilterBlock_states_o[j] *
      DCDCconverter_P.GeneratedFilterBlock_Coeffic_mf[cff];
    cff++;
  }

  DCDCconverter_B.GeneratedFilterBlock_fb = acc;

  /* End of DiscreteFir: '<S54>/Generated Filter Block' */

  /* Outputs for Triggered SubSystem: '<S40>/Sample and Hold' */

  /* Constant: '<Root>/Zeroing' */
  DCDCconverter_SampleandHold(DCDCconverter_P.Zeroing_Value,
    DCDCconverter_B.GeneratedFilterBlock_fb, &DCDCconverter_B.SampleandHold_o,
    &DCDCconverter_PrevZCSigState.SampleandHold_o);

  /* End of Outputs for SubSystem: '<S40>/Sample and Hold' */

  /* DataStoreWrite: '<S40>/Zeroing' */
  DCDCconverter_DWork.Offset_iq = DCDCconverter_B.SampleandHold_o.In;

  /* DataStoreRead: '<S40>/Data Store Read' */
  DCDCconverter_B.DataStoreRead_h = DCDCconverter_DWork.Offset_iq;

  /* Sum: '<S40>/Add' */
  DCDCconverter_B.Add_n = DCDCconverter_B.GeneratedFilterBlock_fb -
    DCDCconverter_B.DataStoreRead_h;

  /* Gain: '<S40>/Voltage Sensor Scaling' */
  DCDCconverter_B.VoltageSensorScaling_l =
    DCDCconverter_P.VoltageSensorScaling_Gain_g * DCDCconverter_B.Add_n;

  /* Delay: '<Root>/Delay1' */
  DCDCconverter_B.Delay1 = DCDCconverter_DWork.Delay1_DSTATE[0];

  /* SignalGenerator: '<S59>/Sinusoidal V Dist' */
  acc = 6.2831853071795862 * DCDCconverter_M->Timing.t[0];
  DCDCconverter_B.SinusoidalVDist = sin
    (DCDCconverter_P.SinusoidalVDist_Frequency * acc) *
    DCDCconverter_P.SinusoidalVDist_Amplitude;

  /* SignalGenerator: '<S59>/Square Wave V Dist' */
  acc = DCDCconverter_P.SquareWaveVDist_Frequency * DCDCconverter_M->Timing.t[0];
  if (acc - floor(acc) >= 0.5) {
    DCDCconverter_B.SquareWaveVDist = DCDCconverter_P.SquareWaveVDist_Amplitude;
  } else {
    DCDCconverter_B.SquareWaveVDist = -DCDCconverter_P.SquareWaveVDist_Amplitude;
  }

  /* End of SignalGenerator: '<S59>/Square Wave V Dist' */

  /* Delay: '<Root>/Delay3' */
  DCDCconverter_B.Delay3 = DCDCconverter_DWork.Delay3_DSTATE[0];

  /* SignalGenerator: '<S35>/Sinusoidal Voltage Command' */
  acc = 6.2831853071795862 * DCDCconverter_M->Timing.t[0];
  DCDCconverter_B.SinusoidalVoltageCommand = sin
    (DCDCconverter_P.SinusoidalVoltageCommand_Freque * acc) *
    DCDCconverter_P.SinusoidalVoltageCommand_Amplit;

  /* SignalGenerator: '<S35>/Square Wave Voltage Command' */
  acc = DCDCconverter_P.SquareWaveVoltageCommand_Freque *
    DCDCconverter_M->Timing.t[0];
  if (acc - floor(acc) >= 0.5) {
    DCDCconverter_B.SquareWaveVoltageCommand =
      DCDCconverter_P.SquareWaveVoltageCommand_Amplit;
  } else {
    DCDCconverter_B.SquareWaveVoltageCommand =
      -DCDCconverter_P.SquareWaveVoltageCommand_Amplit;
  }

  /* End of SignalGenerator: '<S35>/Square Wave Voltage Command' */

  /* RateTransition: '<S8>/Rate Transition' */
  DCDCconverter_B.RateTransition_a = DCDCconverter_B.DiscreteTransferFcn;

  /* RateTransition: '<S10>/Rate Transition' */
  DCDCconverter_B.RateTransition_jo = DCDCconverter_B.DiscreteTransferFcn3;

  /* SignalGenerator: '<S34>/Sinusoidal Current Command' */
  acc = 6.2831853071795862 * DCDCconverter_M->Timing.t[0];
  DCDCconverter_B.SinusoidalCurrentCommand = sin
    (DCDCconverter_P.SinusoidalCurrentCommand_Freque * acc) *
    DCDCconverter_P.SinusoidalCurrentCommand_Amplit;

  /* SignalGenerator: '<S34>/Square Wave Current Command' */
  acc = DCDCconverter_P.SquareWaveCurrentCommand_Freque *
    DCDCconverter_M->Timing.t[0];
  if (acc - floor(acc) >= 0.5) {
    DCDCconverter_B.SquareWaveCurrentCommand =
      DCDCconverter_P.SquareWaveCurrentCommand_Amplit;
  } else {
    DCDCconverter_B.SquareWaveCurrentCommand =
      -DCDCconverter_P.SquareWaveCurrentCommand_Amplit;
  }

  /* End of SignalGenerator: '<S34>/Square Wave Current Command' */

  /* Clock: '<S34>/Clock1' */
  DCDCconverter_B.Clock1 = DCDCconverter_M->Timing.t[0];

  /* Switch: '<S34>/Switch2' incorporates:
   *  Constant: '<S34>/ManualLoadCurrentSetting'
   *  Constant: '<S34>/ManualLoadCurrentSettingEnable'
   */
  if (DCDCconverter_P.ManualLoadCurrentSettingEnable_ >=
      DCDCconverter_P.Switch2_Threshold) {
    /* DataStoreRead: '<S38>/Data Store Read' */
    DCDCconverter_B.DataStoreRead_d = DCDCconverter_DWork.Offset_i;

    /* Sum: '<S38>/Add' */
    DCDCconverter_B.Add_o = DCDCconverter_B.GeneratedFilterBlock_l -
      DCDCconverter_B.DataStoreRead_d;

    /* Gain: '<S38>/Current Sensor Scaling' */
    DCDCconverter_B.CurrentSensorScaling_i =
      DCDCconverter_P.CurrentSensorScaling_Gain * DCDCconverter_B.Add_o;
    DCDCconverter_B.Switch2 = DCDCconverter_B.CurrentSensorScaling_i;
  } else {
    DCDCconverter_B.Switch2 = DCDCconverter_P.ManualLoadCurrentSetting_Value;
  }

  /* End of Switch: '<S34>/Switch2' */

  /* Product: '<S34>/Product' */
  DCDCconverter_B.Product = DCDCconverter_B.Switch2 *
    DCDCconverter_B.VoltageSensorScaling;

  /* MATLAB Function: '<S78>/MATLAB Function1' incorporates:
   *  Constant: '<S78>/Pmin'
   *  Constant: '<S78>/PowerShareRatio'
   */
  /* MATLAB Function 'Test Icmd/RuleBasedControlWithLUT/MATLAB Function1': '<S79>:1' */
  if (DCDCconverter_B.Product >= DCDCconverter_P.Pmin_Value) {
    /* '<S79>:1:3' */
    /* '<S79>:1:4' */
    DCDCconverter_B.LUTEnabled = 1.0;

    /* '<S79>:1:5' */
    DCDCconverter_B.UCCurrentCommand = 0.0;
  } else {
    /* '<S79>:1:8' */
    DCDCconverter_B.LUTEnabled = 0.0;
    if (DCDCconverter_B.Product >= 0.0) {
      /* '<S79>:1:10' */
      /* '<S79>:1:11' */
      DCDCconverter_B.UCCurrentCommand = 0.0;
    } else {
      /* '<S79>:1:13' */
      /*  Ultracap must draw power, so polarity is reversed */
      /* '<S79>:1:14' */
      DCDCconverter_B.UCCurrentCommand = -DCDCconverter_B.Product *
        DCDCconverter_P.PowerShareRatio_Value /
        DCDCconverter_B.VoltageSensorScaling_l;
    }
  }

  /* End of MATLAB Function: '<S78>/MATLAB Function1' */

  /* Switch: '<S78>/Switch2' */
  if (DCDCconverter_B.LUTEnabled >= DCDCconverter_P.Switch2_Threshold_n) {
    /* Lookup_n-D: '<S78>/2-D Lookup Table' */
    DCDCconverter_B.DLookupTable = look2_binlxpw(DCDCconverter_B.Product,
      DCDCconverter_B.VoltageSensorScaling_l,
      DCDCconverter_P.DLookupTable_bp01Data,
      DCDCconverter_P.DLookupTable_bp02Data,
      DCDCconverter_P.DLookupTable_tableData,
      DCDCconverter_P.DLookupTable_maxIndex, 21U);

    /* Gain: '<S78>/Ra' */
    DCDCconverter_B.Ra_b = DCDCconverter_P.Ra_Gain *
      DCDCconverter_B.DLookupTable;

    /* Saturate: '<S78>/Saturation' */
    acc = DCDCconverter_B.Ra_b;
    u = DCDCconverter_P.Saturation_LowerSat;
    u_0 = DCDCconverter_P.Saturation_UpperSat;
    if (acc >= u_0) {
      DCDCconverter_B.Saturation_o = u_0;
    } else if (acc <= u) {
      DCDCconverter_B.Saturation_o = u;
    } else {
      DCDCconverter_B.Saturation_o = acc;
    }

    /* End of Saturate: '<S78>/Saturation' */
    DCDCconverter_B.Switch2_a = DCDCconverter_B.Saturation_o;
  } else {
    DCDCconverter_B.Switch2_a = DCDCconverter_B.UCCurrentCommand;
  }

  /* End of Switch: '<S78>/Switch2' */

  /* RateTransition: '<S11>/Rate Transition' */
  DCDCconverter_B.RateTransition_f = DCDCconverter_B.Add_e;

  /* Gain: '<Root>/Gain' */
  DCDCconverter_B.Gain = DCDCconverter_P.Gain_Gain *
    DCDCconverter_B.RateTransition_f;

  /* Sum: '<Root>/Add' */
  DCDCconverter_B.Add_f = DCDCconverter_B.RateTransition_a +
    DCDCconverter_B.Gain;

  /* Chart: '<Root>/Supervisory Control State Machine' incorporates:
   *  Constant: '<Root>/BatVoltageLowerThresh'
   *  Constant: '<Root>/BatVoltageUpperThresh'
   *  Constant: '<Root>/UCVoltageLowerThresh'
   *  Constant: '<Root>/UCVoltageUpperThresh'
   */
  /* Gateway: Supervisory Control State Machine */
  /* During: Supervisory Control State Machine */
  if (DCDCconverter_DWork.is_active_c4_DCDCconverter == 0U) {
    /* Entry: Supervisory Control State Machine */
    DCDCconverter_DWork.is_active_c4_DCDCconverter = 1U;

    /* Entry Internal: Supervisory Control State Machine */
    /* Transition: '<S32>:2' */
    DCDCconverter_DWork.is_c4_DCDCconverter = DCDCconverter_IN_InitState;

    /* Entry 'InitState': '<S32>:1' */
    DCDCconverter_DWork.delta_Voltage = 0.1;
    DCDCconverter_B.VoltageCommand = DCDCconverter_B.RateTransition_a;
    DCDCconverter_B.EnableVoltageCommand = 0.0;
  } else {
    switch (DCDCconverter_DWork.is_c4_DCDCconverter) {
     case DCDCconverte_IN_ChargeDownState:
      /* During 'ChargeDownState': '<S32>:6' */
      if (DCDCconverter_B.RateTransition_f < 0.0) {
        /* Transition: '<S32>:15' */
        DCDCconverter_DWork.is_c4_DCDCconverter =
          DCDCconv_IN_CurrentControlState;
      } else if (DCDCconverter_B.Delay3 == 0) {
        /* Transition: '<S32>:34' */
        DCDCconverter_DWork.is_c4_DCDCconverter = DCDCconverter_IN_InitState;

        /* Entry 'InitState': '<S32>:1' */
        DCDCconverter_DWork.delta_Voltage = 0.1;
        DCDCconverter_B.VoltageCommand = DCDCconverter_B.RateTransition_a;
        DCDCconverter_B.EnableVoltageCommand = 0.0;
      } else {
        DCDCconverter_B.VoltageCommand =
          DCDCconverter_P.UCVoltageUpperThresh_Value -
          DCDCconverter_DWork.delta_Voltage;
        DCDCconverter_B.EnableVoltageCommand = 1.0;
      }
      break;

     case DCDCconverter_IN_ChargeUpState:
      /* During 'ChargeUpState': '<S32>:7' */
      if (DCDCconverter_B.RateTransition_f > 0.0) {
        /* Transition: '<S32>:16' */
        DCDCconverter_DWork.is_c4_DCDCconverter =
          DCDCconv_IN_CurrentControlState;
      } else if (DCDCconverter_B.Delay3 == 0) {
        /* Transition: '<S32>:36' */
        DCDCconverter_DWork.is_c4_DCDCconverter = DCDCconverter_IN_InitState;

        /* Entry 'InitState': '<S32>:1' */
        DCDCconverter_DWork.delta_Voltage = 0.1;
        DCDCconverter_B.VoltageCommand = DCDCconverter_B.RateTransition_a;
        DCDCconverter_B.EnableVoltageCommand = 0.0;
      } else {
        DCDCconverter_B.VoltageCommand =
          DCDCconverter_P.UCVoltageLowerThresh_Value +
          DCDCconverter_DWork.delta_Voltage;
        DCDCconverter_B.EnableVoltageCommand = 1.0;
      }
      break;

     case DCDCconv_IN_CurrentControlState:
      /* During 'CurrentControlState': '<S32>:8' */
      if (((DCDCconverter_B.RateTransition_a >=
            DCDCconverter_P.UCVoltageUpperThresh_Value) ||
           (DCDCconverter_B.Add_f >= DCDCconverter_P.UCVoltageUpperThresh_Value)
           || (DCDCconverter_B.RateTransition_jo <=
               DCDCconverter_P.BatVoltageLowerThresh_Value)) &&
          (DCDCconverter_B.RateTransition_f >= 0.0)) {
        /* Transition: '<S32>:17' */
        DCDCconverter_DWork.is_c4_DCDCconverter =
          DCDCconverte_IN_ChargeDownState;
      } else if (((DCDCconverter_B.RateTransition_a <=
                   DCDCconverter_P.UCVoltageLowerThresh_Value) ||
                  (DCDCconverter_B.Add_f <=
                   DCDCconverter_P.UCVoltageLowerThresh_Value) ||
                  (DCDCconverter_B.RateTransition_jo >=
                   DCDCconverter_P.BatVoltageUpperThresh_Value)) &&
                 (DCDCconverter_B.RateTransition_f <= 0.0)) {
        /* Transition: '<S32>:18' */
        DCDCconverter_DWork.is_c4_DCDCconverter = DCDCconverter_IN_ChargeUpState;
      } else if (DCDCconverter_B.Delay3 == 0) {
        /* Transition: '<S32>:35' */
        DCDCconverter_DWork.is_c4_DCDCconverter = DCDCconverter_IN_InitState;

        /* Entry 'InitState': '<S32>:1' */
        DCDCconverter_DWork.delta_Voltage = 0.1;
        DCDCconverter_B.VoltageCommand = DCDCconverter_B.RateTransition_a;
        DCDCconverter_B.EnableVoltageCommand = 0.0;
      } else {
        DCDCconverter_B.EnableVoltageCommand = 0.0;
      }
      break;

     default:
      /* During 'InitState': '<S32>:1' */
      if (((DCDCconverter_B.RateTransition_a <=
            DCDCconverter_P.UCVoltageLowerThresh_Value) ||
           (DCDCconverter_B.RateTransition_jo >=
            DCDCconverter_P.BatVoltageUpperThresh_Value)) &&
          (DCDCconverter_B.Delay3 == 1)) {
        /* Transition: '<S32>:10' */
        DCDCconverter_DWork.is_c4_DCDCconverter = DCDCconverter_IN_ChargeUpState;
      } else if (((DCDCconverter_B.RateTransition_a >=
                   DCDCconverter_P.UCVoltageUpperThresh_Value) ||
                  (DCDCconverter_B.RateTransition_jo <=
                   DCDCconverter_P.BatVoltageLowerThresh_Value)) &&
                 (DCDCconverter_B.Delay3 == 1)) {
        /* Transition: '<S32>:9' */
        DCDCconverter_DWork.is_c4_DCDCconverter =
          DCDCconverte_IN_ChargeDownState;
      } else {
        if ((DCDCconverter_B.RateTransition_a <
             DCDCconverter_P.UCVoltageUpperThresh_Value) &&
            (DCDCconverter_B.RateTransition_a >
             DCDCconverter_P.UCVoltageLowerThresh_Value) &&
            (DCDCconverter_B.RateTransition_jo >
             DCDCconverter_P.BatVoltageLowerThresh_Value) &&
            (DCDCconverter_B.RateTransition_jo <
             DCDCconverter_P.BatVoltageUpperThresh_Value) &&
            (DCDCconverter_B.Delay3 == 1)) {
          /* Transition: '<S32>:12' */
          DCDCconverter_DWork.is_c4_DCDCconverter =
            DCDCconv_IN_CurrentControlState;
        }
      }
      break;
    }
  }

  /* End of Chart: '<Root>/Supervisory Control State Machine' */

  /* SignalGenerator: '<S62>/Sinusoidal I Dist' */
  acc = 6.2831853071795862 * DCDCconverter_M->Timing.t[0];
  DCDCconverter_B.SinusoidalIDist = sin
    (DCDCconverter_P.SinusoidalIDist_Frequency * acc) *
    DCDCconverter_P.SinusoidalIDist_Amplitude;

  /* SignalGenerator: '<S62>/Square Wave I Dist' */
  acc = DCDCconverter_P.SquareWaveIDist_Frequency * DCDCconverter_M->Timing.t[0];
  if (acc - floor(acc) >= 0.5) {
    DCDCconverter_B.SquareWaveIDist = DCDCconverter_P.SquareWaveIDist_Amplitude;
  } else {
    DCDCconverter_B.SquareWaveIDist = -DCDCconverter_P.SquareWaveIDist_Amplitude;
  }

  /* End of SignalGenerator: '<S62>/Square Wave I Dist' */

  /* RateTransition: '<S15>/Rate Transition' */
  DCDCconverter_B.RateTransition_j2 = DCDCconverter_B.Product1;

  /* MultiPortSwitch: '<Root>/Multiport Switch for IGBT Top' incorporates:
   *  Constant: '<Root>/Duty CycleTop'
   */
  switch ((int32_T)DCDCconverter_B.Delay1) {
   case 1:
    DCDCconverter_B.MultiportSwitchforIGBTTop =
      DCDCconverter_B.RateTransition_j2;
    break;

   case 2:
    DCDCconverter_B.MultiportSwitchforIGBTTop =
      DCDCconverter_P.DutyCycleTop_Value;
    break;

   default:
    DCDCconverter_B.MultiportSwitchforIGBTTop = 0.0;
    break;
  }

  /* End of MultiPortSwitch: '<Root>/Multiport Switch for IGBT Top' */

  /* DataTypeConversion: '<Root>/Data Type Conversion2' incorporates:
   *  Constant: '<Root>/Duty CycleTopEnable'
   */
  DCDCconverter_B.DataTypeConversion2 = DCDCconverter_P.DutyCycleTopEnable_Value;

  /* S-Function (rti_commonblock): '<S23>/S-Function1' */
  /* This comment workarounds a code generation problem */

  /* dSPACE I/O Board DS1103 #1 Unit:PWM */
  DCDCconverter_DWork.SFunction1_IWORK[0] = DCDCconverter_B.DataTypeConversion2;

  /* write the duty cycle down */
  ds1103_slave_dsp_pwm_duty_write(0, rti_slv1103_fcn_index[6],
    DCDCconverter_B.MultiportSwitchforIGBTTop);

  /* set outputs to TTL-level or retrigger PWM generation */
  if (DCDCconverter_DWork.SFunction1_IWORK[0] == 1 ) {
    /*  if (flag == RUN)||(flag == UNDEF) */
    if ((slaveDSPPwmStopFlagCh1 == 1)||(slaveDSPPwmStopFlagCh1 == 2))/* PWM Stop signal from Input Port -> set outputs to TTL-level */
    {
      slaveDSPPwmStopFlagCh1 = 0;
      ds1103_slave_dsp_pwm_output_set(0, SLVDSP1103_PWM_CH1_MSK,
        SLVDSP1103_PWM_TTL_LOW);
    }
  } else if (DCDCconverter_DWork.SFunction1_IWORK[0] == 0 ) {
    /* PWM Stop signal disabled -> trigger PWM generation once */
    if ((slaveDSPPwmStopFlagCh1 == 0)||(slaveDSPPwmStopFlagCh1 == 2)) {
      slaveDSPPwmStopFlagCh1 = 1;
      ds1103_slave_dsp_pwm_start(0, SLVDSP1103_PWM_CH1_MSK);
    }
  }

  /* Delay: '<Root>/Delay2' */
  DCDCconverter_B.Delay2 = DCDCconverter_DWork.Delay2_DSTATE[0];

  /* RateTransition: '<S18>/Rate Transition' */
  DCDCconverter_B.RateTransition_hz = DCDCconverter_B.Product2;

  /* MultiPortSwitch: '<Root>/Multiport Switch for IGBT Bottom' incorporates:
   *  Constant: '<Root>/Duty Cycle Bot'
   */
  switch ((int32_T)DCDCconverter_B.Delay2) {
   case 1:
    DCDCconverter_B.MultiportSwitchforIGBTBottom =
      DCDCconverter_B.RateTransition_hz;
    break;

   case 2:
    DCDCconverter_B.MultiportSwitchforIGBTBottom =
      DCDCconverter_P.DutyCycleBot_Value;
    break;

   default:
    DCDCconverter_B.MultiportSwitchforIGBTBottom = 0.0;
    break;
  }

  /* End of MultiPortSwitch: '<Root>/Multiport Switch for IGBT Bottom' */

  /* DataTypeConversion: '<Root>/Data Type Conversion1' incorporates:
   *  Constant: '<Root>/Duty CycleBotEnable'
   */
  DCDCconverter_B.DataTypeConversion1 = DCDCconverter_P.DutyCycleBotEnable_Value;

  /* S-Function (rti_commonblock): '<S23>/S-Function2' */
  /* This comment workarounds a code generation problem */

  /* dSPACE I/O Board DS1103 #1 Unit:PWM */
  DCDCconverter_DWork.SFunction2_IWORK[1] = DCDCconverter_B.DataTypeConversion1;

  /* write the duty cycle down */
  ds1103_slave_dsp_pwm_duty_write(0, rti_slv1103_fcn_index[7],
    DCDCconverter_B.MultiportSwitchforIGBTBottom);

  /* set outputs to TTL-level or retrigger PWM generation */
  if (DCDCconverter_DWork.SFunction2_IWORK[1] == 1 ) {
    /*  if (flag == RUN)||(flag == UNDEF) */
    if ((slaveDSPPwmStopFlagCh2 == 1)||(slaveDSPPwmStopFlagCh2 == 2))/* PWM Stop signal from Input Port -> set outputs to TTL-level */
    {
      slaveDSPPwmStopFlagCh2 = 0;
      ds1103_slave_dsp_pwm_output_set(0, SLVDSP1103_PWM_CH2_MSK,
        SLVDSP1103_PWM_TTL_LOW);
    }
  } else if (DCDCconverter_DWork.SFunction2_IWORK[1] == 0 ) {
    /* PWM Stop signal disabled -> trigger PWM generation once */
    if ((slaveDSPPwmStopFlagCh2 == 0)||(slaveDSPPwmStopFlagCh2 == 2)) {
      slaveDSPPwmStopFlagCh2 = 1;
      ds1103_slave_dsp_pwm_start(0, SLVDSP1103_PWM_CH2_MSK);
    }
  }

  /* S-Function (rti_commonblock): '<S23>/S-Function3' */
  /* This comment workarounds a code generation problem */

  /* S-Function (rti_commonblock): '<S23>/S-Function4' */
  /* This comment workarounds a code generation problem */

  /* Memory: '<S26>/Memory3' */
  DCDCconverter_B.Memory3 = DCDCconverter_DWork.Memory3_PreviousInput;

  /* Memory: '<S26>/Memory1' */
  DCDCconverter_B.Memory1 = DCDCconverter_DWork.Memory1_PreviousInput;

  /* Memory: '<S26>/Memory2' */
  DCDCconverter_B.Memory2 = DCDCconverter_DWork.Memory2_PreviousInput;

  /* Memory: '<S26>/Memory4' */
  DCDCconverter_B.Memory4 = DCDCconverter_DWork.Memory4_PreviousInput;

  /* Memory: '<S26>/Memory5' */
  DCDCconverter_B.Memory5 = DCDCconverter_DWork.Memory5_PreviousInput;

  /* Delay: '<S25>/Delay' */
  DCDCconverter_B.Delay_g = DCDCconverter_DWork.Delay_DSTATE_n;

  /* Memory: '<S25>/Memory3' */
  DCDCconverter_B.Memory3_p = DCDCconverter_DWork.Memory3_PreviousInput_o;

  /* Logic: '<S25>/Logical Operator2' */
  DCDCconverter_B.LogicalOperator2_e = (DCDCconverter_B.Delay_g &&
    DCDCconverter_B.Memory3_p);

  /* Delay: '<S25>/Delay2' */
  DCDCconverter_B.Delay2_i = DCDCconverter_DWork.Delay2_DSTATE_d;

  /* Memory: '<S25>/Memory1' */
  DCDCconverter_B.Memory1_i = DCDCconverter_DWork.Memory1_PreviousInput_c;

  /* Logic: '<S25>/Logical Operator3' */
  DCDCconverter_B.LogicalOperator3_j = (DCDCconverter_B.Delay2_i &&
    DCDCconverter_B.Memory1_i);

  /* Delay: '<S25>/Delay1' */
  DCDCconverter_B.Delay1_i = DCDCconverter_DWork.Delay1_DSTATE_b;

  /* Memory: '<S25>/Memory2' */
  DCDCconverter_B.Memory2_h = DCDCconverter_DWork.Memory2_PreviousInput_l;

  /* Logic: '<S25>/Logical Operator1' */
  DCDCconverter_B.LogicalOperator1_o = (DCDCconverter_B.Delay1_i &&
    DCDCconverter_B.Memory2_h);

  /* Delay: '<S25>/Delay3' */
  DCDCconverter_B.Delay3_m = DCDCconverter_DWork.Delay3_DSTATE_b;

  /* Memory: '<S25>/Memory' */
  DCDCconverter_B.Memory = DCDCconverter_DWork.Memory_PreviousInput;

  /* Logic: '<S25>/Logical Operator4' */
  DCDCconverter_B.LogicalOperator4 = (DCDCconverter_B.Delay3_m &&
    DCDCconverter_B.Memory);

  /* MATLAB Function: '<Root>/ErrorLatchingFunction' incorporates:
   *  Constant: '<Root>/Error_Reset'
   */
  /* MATLAB Function 'ErrorLatchingFunction': '<S24>:1' */
  if (DCDCconverter_P.Error_Reset_Value == 0.0) {
    /* '<S24>:1:33' */
    /* '<S24>:1:34' */
    DCDCconverter_DWork.LLBatCurrentAlert = 0.0;

    /* '<S24>:1:35' */
    DCDCconverter_DWork.LLUCCurrentAlert = 0.0;

    /* '<S24>:1:36' */
    DCDCconverter_DWork.LLBatVoltageAlert = 0.0;

    /* '<S24>:1:37' */
    DCDCconverter_DWork.LLUCVoltageAlert = 0.0;

    /* '<S24>:1:38' */
    DCDCconverter_DWork.LLTempAlert = 0.0;

    /* '<S24>:1:39' */
    DCDCconverter_DWork.LLErrorHB1 = 0.0;

    /* '<S24>:1:40' */
    DCDCconverter_DWork.LLErrorHB2 = 0.0;

    /* '<S24>:1:41' */
    DCDCconverter_DWork.LLErrorHB3 = 0.0;

    /* '<S24>:1:42' */
    DCDCconverter_DWork.LLOverTemp = 0.0;
  }

  /* '<S24>:1:45' */
  if ((DCDCconverter_DWork.LLBatCurrentAlert < (real_T)DCDCconverter_B.Memory3) ||
      rtIsNaN(DCDCconverter_DWork.LLBatCurrentAlert)) {
    DCDCconverter_DWork.LLBatCurrentAlert = (real_T)DCDCconverter_B.Memory3;
  }

  /* '<S24>:1:46' */
  if ((DCDCconverter_DWork.LLUCCurrentAlert < (real_T)DCDCconverter_B.Memory1) ||
      rtIsNaN(DCDCconverter_DWork.LLUCCurrentAlert)) {
    DCDCconverter_DWork.LLUCCurrentAlert = (real_T)DCDCconverter_B.Memory1;
  }

  /* '<S24>:1:47' */
  if ((DCDCconverter_DWork.LLBatVoltageAlert < (real_T)DCDCconverter_B.Memory2) ||
      rtIsNaN(DCDCconverter_DWork.LLBatVoltageAlert)) {
    DCDCconverter_DWork.LLBatVoltageAlert = (real_T)DCDCconverter_B.Memory2;
  }

  /* '<S24>:1:48' */
  if ((DCDCconverter_DWork.LLUCVoltageAlert < (real_T)DCDCconverter_B.Memory4) ||
      rtIsNaN(DCDCconverter_DWork.LLUCVoltageAlert)) {
    DCDCconverter_DWork.LLUCVoltageAlert = (real_T)DCDCconverter_B.Memory4;
  }

  /* '<S24>:1:49' */
  if ((DCDCconverter_DWork.LLTempAlert < (real_T)DCDCconverter_B.Memory5) ||
      rtIsNaN(DCDCconverter_DWork.LLTempAlert)) {
    DCDCconverter_DWork.LLTempAlert = (real_T)DCDCconverter_B.Memory5;
  }

  /* '<S24>:1:50' */
  if ((DCDCconverter_DWork.LLErrorHB1 < (real_T)
       DCDCconverter_B.LogicalOperator2_e) || rtIsNaN
      (DCDCconverter_DWork.LLErrorHB1)) {
    DCDCconverter_DWork.LLErrorHB1 = (real_T)DCDCconverter_B.LogicalOperator2_e;
  }

  /* '<S24>:1:51' */
  if ((DCDCconverter_DWork.LLErrorHB2 < (real_T)
       DCDCconverter_B.LogicalOperator3_j) || rtIsNaN
      (DCDCconverter_DWork.LLErrorHB2)) {
    DCDCconverter_DWork.LLErrorHB2 = (real_T)DCDCconverter_B.LogicalOperator3_j;
  }

  /* '<S24>:1:52' */
  if ((DCDCconverter_DWork.LLErrorHB3 < (real_T)
       DCDCconverter_B.LogicalOperator1_o) || rtIsNaN
      (DCDCconverter_DWork.LLErrorHB3)) {
    DCDCconverter_DWork.LLErrorHB3 = (real_T)DCDCconverter_B.LogicalOperator1_o;
  }

  /* '<S24>:1:53' */
  if ((DCDCconverter_DWork.LLOverTemp < (real_T)DCDCconverter_B.LogicalOperator4)
      || rtIsNaN(DCDCconverter_DWork.LLOverTemp)) {
    DCDCconverter_DWork.LLOverTemp = (real_T)DCDCconverter_B.LogicalOperator4;
  }

  /* '<S24>:1:55' */
  DCDCconverter_B.LBatCurrentAlert = DCDCconverter_DWork.LLBatCurrentAlert;

  /* '<S24>:1:56' */
  DCDCconverter_B.LUCCurrentAlert = DCDCconverter_DWork.LLUCCurrentAlert;

  /* '<S24>:1:57' */
  DCDCconverter_B.LBatVoltageAlert = DCDCconverter_DWork.LLBatVoltageAlert;

  /* '<S24>:1:58' */
  DCDCconverter_B.LUCVoltageAlert = DCDCconverter_DWork.LLUCVoltageAlert;

  /* '<S24>:1:59' */
  DCDCconverter_B.LTempAlert = DCDCconverter_DWork.LLTempAlert;

  /* '<S24>:1:60' */
  DCDCconverter_B.LErrorHB1 = DCDCconverter_DWork.LLErrorHB1;

  /* '<S24>:1:61' */
  DCDCconverter_B.LErrorHB2 = DCDCconverter_DWork.LLErrorHB2;

  /* '<S24>:1:62' */
  DCDCconverter_B.LErrorHB3 = DCDCconverter_DWork.LLErrorHB3;

  /* '<S24>:1:63' */
  DCDCconverter_B.LOverTemp = DCDCconverter_DWork.LLOverTemp;

  /* End of MATLAB Function: '<Root>/ErrorLatchingFunction' */

  /* Logic: '<Root>/ErrorForTripNew' */
  DCDCconverter_B.ErrorForTripNew = ((DCDCconverter_B.LBatCurrentAlert != 0.0) ||
                                     (DCDCconverter_B.LUCCurrentAlert != 0.0) ||
                                     (DCDCconverter_B.LBatVoltageAlert != 0.0) ||
                                     (DCDCconverter_B.LUCVoltageAlert != 0.0) ||
                                     (DCDCconverter_B.LTempAlert != 0.0) ||
    (DCDCconverter_B.LErrorHB1 != 0.0) || (DCDCconverter_B.LErrorHB2 != 0.0) ||
                                     (DCDCconverter_B.LErrorHB3 != 0.0) ||
    (DCDCconverter_B.LOverTemp != 0.0));

  /* RateTransition: '<S12>/Rate Transition' */
  DCDCconverter_B.RateTransition_jc = DCDCconverter_B.DiscreteTransferFcn3;

  /* RateTransition: '<S19>/Rate Transition' */
  DCDCconverter_B.RateTransition_b = DCDCconverter_B.DiscreteTransferFcn2;

  /* Chart: '<Root>/System Configuration State Machine1' incorporates:
   *  Constant: '<Root>/EnableAutomaticControl'
   *  Constant: '<Root>/Mode Selection'
   *  Constant: '<Root>/TurnOnSystem'
   *  Constant: '<Root>/Vrail_rated'
   */
  /* Gateway: System Configuration State Machine1 */
  /* During: System Configuration State Machine1 */
  if (DCDCconverter_DWork.is_active_c5_DCDCconverter == 0U) {
    /* Entry: System Configuration State Machine1 */
    DCDCconverter_DWork.is_active_c5_DCDCconverter = 1U;

    /* Entry Internal: System Configuration State Machine1 */
    /* Transition: '<S33>:43' */
    DCDCconverter_DWork.is_c5_DCDCconverter = DCDCconverter_IN_Off;

    /* Entry 'Off': '<S33>:42' */
    DCDCconverter_B.IGBT_Top_State = 0.0;
    DCDCconverter_B.IGBT_Bot_State = 0.0;
    DCDCconverter_B.AutomaticController = FALSE;
    DCDCconverter_B.ChargingRelay = 0.0;
    DCDCconverter_B.DischargingRelay = 1.0;
    DCDCconverter_B.BatteryRelay = 0.0;
    DCDCconverter_B.UltracapacitorRelay = 0.0;
    DCDCconverter_DWork.dVrail_dT_threshold = 0.01;
  } else {
    switch (DCDCconverter_DWork.is_c5_DCDCconverter) {
     case DCDCcon_IN_AutomaticControlMode:
      /* During 'AutomaticControlMode': '<S33>:111' */
      if ((DCDCconverter_P.EnableAutomaticControl_Value == 0.0) &&
          (DCDCconverter_P.ModeSelection_Value == 0.0)) {
        /* Transition: '<S33>:120' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCconverte_IN_ManualBoostMode;
      } else if ((DCDCconverter_P.EnableAutomaticControl_Value == 0.0) &&
                 (DCDCconverter_P.ModeSelection_Value == 1.0)) {
        /* Transition: '<S33>:122' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCconverter_IN_ManualBuckMode;
      } else if ((DCDCconverter_B.ErrorForTripNew == 1) ||
                 (DCDCconverter_P.TurnOnSystem_Value == 0.0)) {
        /* Transition: '<S33>:140' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCconverte_IN_DischargingRail;
      } else {
        DCDCconverter_B.IGBT_Top_State = 1.0;
        DCDCconverter_B.IGBT_Bot_State = 1.0;
        DCDCconverter_B.AutomaticController = TRUE;
        DCDCconverter_B.ChargingRelay = 0.0;
        DCDCconverter_B.DischargingRelay = 0.0;
        DCDCconverter_B.BatteryRelay = 1.0;
        DCDCconverter_B.UltracapacitorRelay = 1.0;
      }
      break;

     case DCDCconverter_IN_ChargingRail:
      /* During 'ChargingRail': '<S33>:107' */
      if ((DCDCconverter_B.RateTransition_jc >=
           DCDCconverter_P.Vrail_rated_Value * 0.85) && (fabs
           (DCDCconverter_B.RateTransition_b) <=
           DCDCconverter_DWork.dVrail_dT_threshold)) {
        /* Transition: '<S33>:134' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCconvert_IN_FinishedCharging;
      } else if ((DCDCconverter_B.ErrorForTripNew == 1) ||
                 (DCDCconverter_P.TurnOnSystem_Value == 0.0)) {
        /* Transition: '<S33>:156' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCconverte_IN_DischargingRail;
      } else {
        DCDCconverter_B.IGBT_Top_State = 0.0;
        DCDCconverter_B.IGBT_Bot_State = 0.0;
        DCDCconverter_B.AutomaticController = FALSE;
        DCDCconverter_B.ChargingRelay = 1.0;
        DCDCconverter_B.DischargingRelay = 0.0;
        DCDCconverter_B.BatteryRelay = 0.0;
        DCDCconverter_B.UltracapacitorRelay = 0.0;
      }
      break;

     case DCDCconverte_IN_DischargingRail:
      /* During 'DischargingRail': '<S33>:108' */
      if ((DCDCconverter_P.TurnOnSystem_Value == 1.0) &&
          (DCDCconverter_B.ErrorForTripNew == 0)) {
        /* Transition: '<S33>:113' */
        DCDCconverter_DWork.is_c5_DCDCconverter = DCDCconverter_IN_ChargingRail;
      } else if ((DCDCconverter_B.RateTransition_jc <=
                  DCDCconverter_P.Vrail_rated_Value * 0.15) && (fabs
                  (DCDCconverter_B.RateTransition_b) <=
                  DCDCconverter_DWork.dVrail_dT_threshold)) {
        /* Transition: '<S33>:126' */
        DCDCconverter_DWork.is_c5_DCDCconverter = DCDCconverter_IN_Off;

        /* Entry 'Off': '<S33>:42' */
        DCDCconverter_B.IGBT_Top_State = 0.0;
        DCDCconverter_B.IGBT_Bot_State = 0.0;
        DCDCconverter_B.AutomaticController = FALSE;
        DCDCconverter_B.ChargingRelay = 0.0;
        DCDCconverter_B.DischargingRelay = 1.0;
        DCDCconverter_B.BatteryRelay = 0.0;
        DCDCconverter_B.UltracapacitorRelay = 0.0;
        DCDCconverter_DWork.dVrail_dT_threshold = 0.01;
      } else {
        DCDCconverter_B.IGBT_Top_State = 0.0;
        DCDCconverter_B.IGBT_Bot_State = 0.0;
        DCDCconverter_B.AutomaticController = FALSE;
        DCDCconverter_B.ChargingRelay = 0.0;
        DCDCconverter_B.DischargingRelay = 1.0;
        DCDCconverter_B.BatteryRelay = 0.0;
        DCDCconverter_B.UltracapacitorRelay = 0.0;
      }
      break;

     case DCDCconvert_IN_FinishedCharging:
      /* During 'FinishedCharging': '<S33>:130' */
      if (DCDCconverter_P.EnableAutomaticControl_Value == 1.0) {
        /* Transition: '<S33>:133' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCcon_IN_AutomaticControlMode;
      } else if ((DCDCconverter_B.ErrorForTripNew == 1) ||
                 (DCDCconverter_P.TurnOnSystem_Value == 0.0)) {
        /* Transition: '<S33>:135' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCconverte_IN_DischargingRail;
      } else if ((DCDCconverter_P.EnableAutomaticControl_Value == 0.0) &&
                 (DCDCconverter_P.ModeSelection_Value == 0.0)) {
        /* Transition: '<S33>:141' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCconverte_IN_ManualBoostMode;
      } else if ((DCDCconverter_P.EnableAutomaticControl_Value == 0.0) &&
                 (DCDCconverter_P.ModeSelection_Value == 1.0)) {
        /* Transition: '<S33>:142' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCconverter_IN_ManualBuckMode;
      } else {
        DCDCconverter_B.IGBT_Top_State = 0.0;
        DCDCconverter_B.IGBT_Bot_State = 0.0;
        DCDCconverter_B.AutomaticController = FALSE;
        DCDCconverter_B.ChargingRelay = 0.0;
        DCDCconverter_B.DischargingRelay = 0.0;
        DCDCconverter_B.BatteryRelay = 0.0;
        DCDCconverter_B.UltracapacitorRelay = 0.0;
      }
      break;

     case DCDCconverte_IN_ManualBoostMode:
      /* During 'ManualBoostMode': '<S33>:110' */
      if (DCDCconverter_P.ModeSelection_Value == 1.0) {
        /* Transition: '<S33>:118' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCconverter_IN_ManualBuckMode;
      } else if (DCDCconverter_P.EnableAutomaticControl_Value == 1.0) {
        /* Transition: '<S33>:119' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCcon_IN_AutomaticControlMode;
      } else if ((DCDCconverter_B.ErrorForTripNew == 1) ||
                 (DCDCconverter_P.TurnOnSystem_Value == 0.0)) {
        /* Transition: '<S33>:137' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCconverte_IN_DischargingRail;
      } else {
        DCDCconverter_B.IGBT_Top_State = 0.0;
        DCDCconverter_B.IGBT_Bot_State = 2.0;
        DCDCconverter_B.AutomaticController = FALSE;
        DCDCconverter_B.ChargingRelay = 0.0;
        DCDCconverter_B.DischargingRelay = 0.0;
        DCDCconverter_B.BatteryRelay = 1.0;
        DCDCconverter_B.UltracapacitorRelay = 1.0;
      }
      break;

     case DCDCconverter_IN_ManualBuckMode:
      /* During 'ManualBuckMode': '<S33>:109' */
      if (DCDCconverter_P.ModeSelection_Value == 0.0) {
        /* Transition: '<S33>:117' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCconverte_IN_ManualBoostMode;
      } else if (DCDCconverter_P.EnableAutomaticControl_Value == 1.0) {
        /* Transition: '<S33>:121' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCcon_IN_AutomaticControlMode;
      } else if ((DCDCconverter_B.ErrorForTripNew == 1) ||
                 (DCDCconverter_P.TurnOnSystem_Value == 0.0)) {
        /* Transition: '<S33>:136' */
        DCDCconverter_DWork.is_c5_DCDCconverter =
          DCDCconverte_IN_DischargingRail;
      } else {
        DCDCconverter_B.IGBT_Top_State = 2.0;
        DCDCconverter_B.IGBT_Bot_State = 0.0;
        DCDCconverter_B.AutomaticController = FALSE;
        DCDCconverter_B.ChargingRelay = 0.0;
        DCDCconverter_B.DischargingRelay = 0.0;
        DCDCconverter_B.BatteryRelay = 1.0;
        DCDCconverter_B.UltracapacitorRelay = 1.0;
      }
      break;

     default:
      /* During 'Off': '<S33>:42' */
      if ((DCDCconverter_P.TurnOnSystem_Value == 1.0) &&
          (DCDCconverter_B.ErrorForTripNew == 0)) {
        /* Transition: '<S33>:112' */
        DCDCconverter_DWork.is_c5_DCDCconverter = DCDCconverter_IN_ChargingRail;
      }
      break;
    }
  }

  /* End of Chart: '<Root>/System Configuration State Machine1' */

  /* DataTypeConversion: '<S30>/ChargingRelay' */
  DCDCconverter_B.ChargingRelay_l = (DCDCconverter_B.ChargingRelay != 0.0);

  /* S-Function (rti_commonblock): '<S68>/S-Function1' */
  /* This comment workarounds a code generation problem */

  /* dSPACE I/O Board DS1103 #1 Unit:BIT_IO Group:BIT_OUT */
  if (DCDCconverter_B.ChargingRelay_l > 0) {
    ds1103_bit_io_set(DS1103_DIO0_SET);
  } else {
    ds1103_bit_io_clear(DS1103_DIO0_CLEAR);
  }

  /* DataTypeConversion: '<S30>/DischargingRelay' */
  DCDCconverter_B.DischargingRelay_e = (DCDCconverter_B.DischargingRelay != 0.0);

  /* S-Function (rti_commonblock): '<S68>/S-Function2' */
  /* This comment workarounds a code generation problem */

  /* dSPACE I/O Board DS1103 #1 Unit:BIT_IO Group:BIT_OUT */
  if (DCDCconverter_B.DischargingRelay_e > 0) {
    ds1103_bit_io_set(DS1103_DIO1_SET);
  } else {
    ds1103_bit_io_clear(DS1103_DIO1_CLEAR);
  }

  /* DataTypeConversion: '<S30>/BatteryRelay' */
  DCDCconverter_B.BatteryRelay_b = (DCDCconverter_B.BatteryRelay != 0.0);

  /* S-Function (rti_commonblock): '<S68>/S-Function4' */
  /* This comment workarounds a code generation problem */

  /* dSPACE I/O Board DS1103 #1 Unit:BIT_IO Group:BIT_OUT */
  if (DCDCconverter_B.BatteryRelay_b > 0) {
    ds1103_bit_io_set(DS1103_DIO3_SET);
  } else {
    ds1103_bit_io_clear(DS1103_DIO3_CLEAR);
  }

  /* S-Function (rti_commonblock): '<S68>/S-Function5' */
  /* This comment workarounds a code generation problem */

  /* S-Function (rti_commonblock): '<S68>/S-Function6' */
  /* This comment workarounds a code generation problem */

  /* S-Function (rti_commonblock): '<S68>/S-Function7' */
  /* This comment workarounds a code generation problem */

  /* S-Function (rti_commonblock): '<S68>/S-Function8' */
  /* This comment workarounds a code generation problem */

  /* S-Function (rti_commonblock): '<S56>/S-Function1' */
  /* This comment workarounds a code generation problem */

  /* S-Function (rti_commonblock): '<S56>/S-Function2' */
  /* This comment workarounds a code generation problem */

  /* S-Function (rti_commonblock): '<S56>/S-Function3' */
  /* This comment workarounds a code generation problem */

  /* S-Function (rti_commonblock): '<S56>/S-Function4' */
  /* This comment workarounds a code generation problem */

  /* S-Function (rti_commonblock): '<S56>/S-Function5' */
  /* This comment workarounds a code generation problem */

  /* S-Function (rti_commonblock): '<S56>/S-Function6' */
  /* This comment workarounds a code generation problem */

  /* S-Function (rti_commonblock): '<S56>/S-Function7' */
  /* This comment workarounds a code generation problem */

  /* S-Function (rti_commonblock): '<S56>/S-Function8' */
  /* This comment workarounds a code generation problem */

  /* DataTypeConversion: '<S25>/Data Type Conversion' */
  DCDCconverter_B.DataTypeConversion = DCDCconverter_B.SFunction5;

  /* DataTypeConversion: '<S25>/Data Type Conversion1' */
  DCDCconverter_B.DataTypeConversion1_n = DCDCconverter_B.SFunction6;

  /* DataTypeConversion: '<S25>/Data Type Conversion2' */
  DCDCconverter_B.DataTypeConversion2_e = DCDCconverter_B.SFunction7;

  /* DataTypeConversion: '<S25>/Data Type Conversion3' */
  DCDCconverter_B.DataTypeConversion3 = DCDCconverter_B.SFunction8;

  /* Abs: '<S26>/Abs' */
  DCDCconverter_B.Abs = fabs(DCDCconverter_B.CurrentSensorScaling);

  /* Sum: '<S26>/Add1' incorporates:
   *  Constant: '<S26>/Maximum Battery Current'
   */
  DCDCconverter_B.Add1 = DCDCconverter_B.Abs -
    DCDCconverter_P.MaximumBatteryCurrent_Value;

  /* Relay: '<S26>/Battery Current Relay' */
  if (DCDCconverter_B.Add1 >= DCDCconverter_P.BatteryCurrentRelay_OnVal) {
    DCDCconverter_DWork.BatteryCurrentRelay_Mode = TRUE;
  } else {
    if (DCDCconverter_B.Add1 <= DCDCconverter_P.BatteryCurrentRelay_OffVal) {
      DCDCconverter_DWork.BatteryCurrentRelay_Mode = FALSE;
    }
  }

  if (DCDCconverter_DWork.BatteryCurrentRelay_Mode) {
    DCDCconverter_B.BatteryCurrentRelay =
      DCDCconverter_P.BatteryCurrentRelay_YOn;
  } else {
    DCDCconverter_B.BatteryCurrentRelay =
      DCDCconverter_P.BatteryCurrentRelay_YOff;
  }

  /* End of Relay: '<S26>/Battery Current Relay' */

  /* DataTypeConversion: '<S26>/Data Type Conversion' */
  DCDCconverter_B.DataTypeConversion_i = (DCDCconverter_B.BatteryCurrentRelay !=
    0.0);

  /* Abs: '<S26>/Abs1' */
  DCDCconverter_B.Abs1 = fabs(DCDCconverter_B.CurrentSensorScaling_l);

  /* Sum: '<S26>/Add2' incorporates:
   *  Constant: '<S26>/Maximum UltraCapacitor Current'
   */
  DCDCconverter_B.Add2 = DCDCconverter_B.Abs1 -
    DCDCconverter_P.MaximumUltraCapacitorCurrent_Va;

  /* Relay: '<S26>/UltraCapacitor Current Relay' */
  if (DCDCconverter_B.Add2 >= DCDCconverter_P.UltraCapacitorCurrentRelay_OnVa) {
    DCDCconverter_DWork.UltraCapacitorCurrentRelay_Mode = TRUE;
  } else {
    if (DCDCconverter_B.Add2 <= DCDCconverter_P.UltraCapacitorCurrentRelay_OffV)
    {
      DCDCconverter_DWork.UltraCapacitorCurrentRelay_Mode = FALSE;
    }
  }

  if (DCDCconverter_DWork.UltraCapacitorCurrentRelay_Mode) {
    DCDCconverter_B.UltraCapacitorCurrentRelay =
      DCDCconverter_P.UltraCapacitorCurrentRelay_YOn;
  } else {
    DCDCconverter_B.UltraCapacitorCurrentRelay =
      DCDCconverter_P.UltraCapacitorCurrentRelay_YOff;
  }

  /* End of Relay: '<S26>/UltraCapacitor Current Relay' */

  /* DataTypeConversion: '<S26>/Data Type Conversion1' */
  DCDCconverter_B.DataTypeConversion1_g =
    (DCDCconverter_B.UltraCapacitorCurrentRelay != 0.0);

  /* Sum: '<S26>/Add3' incorporates:
   *  Constant: '<S26>/Maximum Battery Voltage'
   */
  DCDCconverter_B.Add3 = DCDCconverter_B.VoltageSensorScaling -
    DCDCconverter_P.MaximumBatteryVoltage_Value;

  /* Relay: '<S26>/Battery Voltage Relay' */
  if (DCDCconverter_B.Add3 >= DCDCconverter_P.BatteryVoltageRelay_OnVal) {
    DCDCconverter_DWork.BatteryVoltageRelay_Mode = TRUE;
  } else {
    if (DCDCconverter_B.Add3 <= DCDCconverter_P.BatteryVoltageRelay_OffVal) {
      DCDCconverter_DWork.BatteryVoltageRelay_Mode = FALSE;
    }
  }

  if (DCDCconverter_DWork.BatteryVoltageRelay_Mode) {
    DCDCconverter_B.BatteryVoltageRelay =
      DCDCconverter_P.BatteryVoltageRelay_YOn;
  } else {
    DCDCconverter_B.BatteryVoltageRelay =
      DCDCconverter_P.BatteryVoltageRelay_YOff;
  }

  /* End of Relay: '<S26>/Battery Voltage Relay' */

  /* DataTypeConversion: '<S26>/Data Type Conversion2' */
  DCDCconverter_B.DataTypeConversion2_i = (DCDCconverter_B.BatteryVoltageRelay
    != 0.0);

  /* Sum: '<S26>/Add4' incorporates:
   *  Constant: '<S26>/Maximum Ultracapacitor Voltage'
   */
  DCDCconverter_B.Add4 = DCDCconverter_B.VoltageSensorScaling_l -
    DCDCconverter_P.MaximumUltracapacitorVoltage_Va;

  /* Relay: '<S26>/Ultra Capacitor Voltage Relay' */
  if (DCDCconverter_B.Add4 >= DCDCconverter_P.UltraCapacitorVoltageRelay_OnVa) {
    DCDCconverter_DWork.UltraCapacitorVoltageRelay_Mode = TRUE;
  } else {
    if (DCDCconverter_B.Add4 <= DCDCconverter_P.UltraCapacitorVoltageRelay_OffV)
    {
      DCDCconverter_DWork.UltraCapacitorVoltageRelay_Mode = FALSE;
    }
  }

  if (DCDCconverter_DWork.UltraCapacitorVoltageRelay_Mode) {
    DCDCconverter_B.UltraCapacitorVoltageRelay =
      DCDCconverter_P.UltraCapacitorVoltageRelay_YOn;
  } else {
    DCDCconverter_B.UltraCapacitorVoltageRelay =
      DCDCconverter_P.UltraCapacitorVoltageRelay_YOff;
  }

  /* End of Relay: '<S26>/Ultra Capacitor Voltage Relay' */

  /* DataTypeConversion: '<S26>/Data Type Conversion3' */
  DCDCconverter_B.DataTypeConversion3_a =
    (DCDCconverter_B.UltraCapacitorVoltageRelay != 0.0);

  /* Sum: '<S26>/Add5' incorporates:
   *  Constant: '<S22>/Sink_Temperature'
   *  Constant: '<S26>/Maximum Temperature'
   */
  DCDCconverter_B.Add5 = DCDCconverter_P.Sink_Temperature_Value -
    DCDCconverter_P.MaximumTemperature_Value;

  /* Relay: '<S26>/Temperature Relay' */
  if (DCDCconverter_B.Add5 >= DCDCconverter_P.TemperatureRelay_OnVal) {
    DCDCconverter_DWork.TemperatureRelay_Mode = TRUE;
  } else {
    if (DCDCconverter_B.Add5 <= DCDCconverter_P.TemperatureRelay_OffVal) {
      DCDCconverter_DWork.TemperatureRelay_Mode = FALSE;
    }
  }

  if (DCDCconverter_DWork.TemperatureRelay_Mode) {
    DCDCconverter_B.TemperatureRelay = DCDCconverter_P.TemperatureRelay_YOn;
  } else {
    DCDCconverter_B.TemperatureRelay = DCDCconverter_P.TemperatureRelay_YOff;
  }

  /* End of Relay: '<S26>/Temperature Relay' */

  /* DataTypeConversion: '<S26>/Data Type Conversion4' */
  DCDCconverter_B.DataTypeConversion4 = (DCDCconverter_B.TemperatureRelay != 0.0);
}

/* Model update function for TID0 */
static void DCDCconverter_update0(void) /* Sample time: [0.0s, 0.0s] */
{
  int32_T k;

  /* Update for DiscreteFir: '<S42>/Generated Filter Block' */
  DCDCconverter_DWork.GeneratedFilterBlock_circBuf--;
  if (DCDCconverter_DWork.GeneratedFilterBlock_circBuf < 0) {
    DCDCconverter_DWork.GeneratedFilterBlock_circBuf = 72;
  }

  DCDCconverter_DWork.GeneratedFilterBlock_states[DCDCconverter_DWork.GeneratedFilterBlock_circBuf]
    = DCDCconverter_B.SFunction;

  /* End of Update for DiscreteFir: '<S42>/Generated Filter Block' */

  /* Update for DiscreteFir: '<S45>/Generated Filter Block' */
  DCDCconverter_DWork.GeneratedFilterBlock_circBuf_c--;
  if (DCDCconverter_DWork.GeneratedFilterBlock_circBuf_c < 0) {
    DCDCconverter_DWork.GeneratedFilterBlock_circBuf_c = 72;
  }

  DCDCconverter_DWork.GeneratedFilterBlock_states_i[DCDCconverter_DWork.GeneratedFilterBlock_circBuf_c]
    = DCDCconverter_B.SFunction_k;

  /* End of Update for DiscreteFir: '<S45>/Generated Filter Block' */

  /* Update for DiscreteFir: '<S48>/Generated Filter Block' */
  DCDCconverter_DWork.GeneratedFilterBlock_circBuf_d--;
  if (DCDCconverter_DWork.GeneratedFilterBlock_circBuf_d < 0) {
    DCDCconverter_DWork.GeneratedFilterBlock_circBuf_d = 72;
  }

  DCDCconverter_DWork.GeneratedFilterBlock_states_e[DCDCconverter_DWork.GeneratedFilterBlock_circBuf_d]
    = DCDCconverter_B.SFunction_m;

  /* End of Update for DiscreteFir: '<S48>/Generated Filter Block' */

  /* Update for DiscreteFir: '<S51>/Generated Filter Block' */
  DCDCconverter_DWork.GeneratedFilterBlock_circBuf_cj--;
  if (DCDCconverter_DWork.GeneratedFilterBlock_circBuf_cj < 0) {
    DCDCconverter_DWork.GeneratedFilterBlock_circBuf_cj = 72;
  }

  DCDCconverter_DWork.GeneratedFilterBlock_states_f[DCDCconverter_DWork.GeneratedFilterBlock_circBuf_cj]
    = DCDCconverter_B.SFunction_f;

  /* End of Update for DiscreteFir: '<S51>/Generated Filter Block' */

  /* Update for DiscreteFir: '<S54>/Generated Filter Block' */
  DCDCconverter_DWork.GeneratedFilterBlock_circBuf_h--;
  if (DCDCconverter_DWork.GeneratedFilterBlock_circBuf_h < 0) {
    DCDCconverter_DWork.GeneratedFilterBlock_circBuf_h = 72;
  }

  DCDCconverter_DWork.GeneratedFilterBlock_states_o[DCDCconverter_DWork.GeneratedFilterBlock_circBuf_h]
    = DCDCconverter_B.SFunction_n;

  /* End of Update for DiscreteFir: '<S54>/Generated Filter Block' */

  /* Update for Delay: '<Root>/Delay1' */
  for (k = 0; k < 9; k++) {
    DCDCconverter_DWork.Delay1_DSTATE[k] = DCDCconverter_DWork.Delay1_DSTATE[k +
      1];
  }

  DCDCconverter_DWork.Delay1_DSTATE[9] = DCDCconverter_B.IGBT_Top_State;

  /* End of Update for Delay: '<Root>/Delay1' */

  /* Update for Delay: '<Root>/Delay3' */
  for (k = 0; k < 9; k++) {
    DCDCconverter_DWork.Delay3_DSTATE[k] = DCDCconverter_DWork.Delay3_DSTATE[k +
      1];
  }

  DCDCconverter_DWork.Delay3_DSTATE[9] = DCDCconverter_B.AutomaticController;

  /* End of Update for Delay: '<Root>/Delay3' */

  /* Update for Delay: '<Root>/Delay2' */
  for (k = 0; k < 9; k++) {
    DCDCconverter_DWork.Delay2_DSTATE[k] = DCDCconverter_DWork.Delay2_DSTATE[k +
      1];
  }

  DCDCconverter_DWork.Delay2_DSTATE[9] = DCDCconverter_B.IGBT_Bot_State;

  /* End of Update for Delay: '<Root>/Delay2' */

  /* Update for Memory: '<S26>/Memory3' */
  DCDCconverter_DWork.Memory3_PreviousInput =
    DCDCconverter_B.DataTypeConversion_i;

  /* Update for Memory: '<S26>/Memory1' */
  DCDCconverter_DWork.Memory1_PreviousInput =
    DCDCconverter_B.DataTypeConversion1_g;

  /* Update for Memory: '<S26>/Memory2' */
  DCDCconverter_DWork.Memory2_PreviousInput =
    DCDCconverter_B.DataTypeConversion2_i;

  /* Update for Memory: '<S26>/Memory4' */
  DCDCconverter_DWork.Memory4_PreviousInput =
    DCDCconverter_B.DataTypeConversion3_a;

  /* Update for Memory: '<S26>/Memory5' */
  DCDCconverter_DWork.Memory5_PreviousInput =
    DCDCconverter_B.DataTypeConversion4;

  /* Update for Delay: '<S25>/Delay' */
  DCDCconverter_DWork.Delay_DSTATE_n = DCDCconverter_B.Memory3_p;

  /* Update for Memory: '<S25>/Memory3' */
  DCDCconverter_DWork.Memory3_PreviousInput_o =
    DCDCconverter_B.DataTypeConversion;

  /* Update for Delay: '<S25>/Delay2' */
  DCDCconverter_DWork.Delay2_DSTATE_d = DCDCconverter_B.Memory1_i;

  /* Update for Memory: '<S25>/Memory1' */
  DCDCconverter_DWork.Memory1_PreviousInput_c =
    DCDCconverter_B.DataTypeConversion2_e;

  /* Update for Delay: '<S25>/Delay1' */
  DCDCconverter_DWork.Delay1_DSTATE_b = DCDCconverter_B.Memory2_h;

  /* Update for Memory: '<S25>/Memory2' */
  DCDCconverter_DWork.Memory2_PreviousInput_l =
    DCDCconverter_B.DataTypeConversion1_n;

  /* Update for Delay: '<S25>/Delay3' */
  DCDCconverter_DWork.Delay3_DSTATE_b = DCDCconverter_B.Memory;

  /* Update for Memory: '<S25>/Memory' */
  DCDCconverter_DWork.Memory_PreviousInput = DCDCconverter_B.DataTypeConversion3;

  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++DCDCconverter_M->Timing.clockTick0)) {
    ++DCDCconverter_M->Timing.clockTickH0;
  }

  DCDCconverter_M->Timing.t[0] = DCDCconverter_M->Timing.clockTick0 *
    DCDCconverter_M->Timing.stepSize0 + DCDCconverter_M->Timing.clockTickH0 *
    DCDCconverter_M->Timing.stepSize0 * 4294967296.0;

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick1"
   * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick1 and the high bits
   * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++DCDCconverter_M->Timing.clockTick1)) {
    ++DCDCconverter_M->Timing.clockTickH1;
  }

  DCDCconverter_M->Timing.t[1] = DCDCconverter_M->Timing.clockTick1 *
    DCDCconverter_M->Timing.stepSize1 + DCDCconverter_M->Timing.clockTickH1 *
    DCDCconverter_M->Timing.stepSize1 * 4294967296.0;
}

/* Model output function for TID2 */
static void DCDCconverter_output2(void) /* Sample time: [0.0002s, 0.0s] */
{
  real_T u;
  real_T u_0;
  real_T u_1;

  /* RateTransition: '<S13>/Rate Transition' */
  DCDCconverter_B.RateTransition_j = DCDCconverter_B.DiscreteTransferFcn3;

  /* RateTransition: '<S60>/Rate Transition' */
  DCDCconverter_B.RateTransition_i = DCDCconverter_B.SinusoidalVDist;

  /* UniformRandomNumber: '<S59>/Random Noise V Dist' */
  DCDCconverter_B.RandomNoiseVDist =
    DCDCconverter_DWork.RandomNoiseVDist_NextOutput;

  /* RateTransition: '<S61>/Rate Transition' */
  DCDCconverter_B.RateTransition_l = DCDCconverter_B.SquareWaveVDist;

  /* MultiPortSwitch: '<S59>/Multiport Switch for V Dist' incorporates:
   *  Constant: '<S59>/Voltage Disturbance Type'
   *  Constant: '<S59>/Zero'
   */
  switch ((int32_T)DCDCconverter_P.VoltageDisturbanceType_Value) {
   case 1:
    DCDCconverter_B.MultiportSwitchforVDist = DCDCconverter_B.RateTransition_i;
    break;

   case 2:
    DCDCconverter_B.MultiportSwitchforVDist = DCDCconverter_B.RandomNoiseVDist;
    break;

   case 3:
    DCDCconverter_B.MultiportSwitchforVDist = DCDCconverter_B.RateTransition_l;
    break;

   default:
    DCDCconverter_B.MultiportSwitchforVDist = DCDCconverter_P.Zero_Value_o;
    break;
  }

  /* End of MultiPortSwitch: '<S59>/Multiport Switch for V Dist' */

  /* Sum: '<S59>/Add' incorporates:
   *  Constant: '<S59>/DC Offset V Dist'
   */
  DCDCconverter_B.Add_b = DCDCconverter_P.DCOffsetVDist_Value +
    DCDCconverter_B.MultiportSwitchforVDist;

  /* RateTransition: '<S16>/Rate Transition' */
  DCDCconverter_B.RateTransition_at = DCDCconverter_B.Delay3;

  /* Logic: '<S27>/Logical Operator1' */
  DCDCconverter_B.LogicalOperator1 = !DCDCconverter_B.RateTransition_at;

  /* Delay: '<S58>/Delay' */
  DCDCconverter_B.Delay = DCDCconverter_DWork.Delay_DSTATE;

  /* RelationalOperator: '<S58>/Relational Operator1' incorporates:
   *  Constant: '<S58>/Constant1'
   */
  DCDCconverter_B.RelationalOperator1 = (DCDCconverter_B.Delay >=
    DCDCconverter_P.Constant1_Value);

  /* RateTransition: '<S70>/Rate Transition' */
  DCDCconverter_B.RateTransition_m = DCDCconverter_B.SinusoidalCurrentCommand;

  /* UniformRandomNumber: '<S34>/Random Noise Current Command' */
  DCDCconverter_B.RandomNoiseCurrentCommand =
    DCDCconverter_DWork.RandomNoiseCurrentCommand_NextO;

  /* RateTransition: '<S71>/Rate Transition' */
  DCDCconverter_B.RateTransition_md = DCDCconverter_B.SquareWaveCurrentCommand;

  /* RateTransition: '<S74>/Rate Transition' */
  DCDCconverter_B.RateTransition_p = DCDCconverter_B.Clock1;

  /* MATLAB Function: '<S34>/Current_Profile_1Hz' incorporates:
   *  Constant: '<S34>/Current Command Type'
   */
  /* MATLAB Function 'Test Icmd/Current_Profile_1Hz': '<S77>:1' */
  if (!DCDCconverter_DWork.last_time_not_empty) {
    /* '<S77>:1:11' */
    /* '<S77>:1:12' */
    DCDCconverter_DWork.last_time = DCDCconverter_B.RateTransition_p;
    DCDCconverter_DWork.last_time_not_empty = TRUE;
  }

  if ((DCDCconverter_P.CurrentCommandType_Value ==
       DCDCconverter_DWork.profile_on_condition) &&
      (DCDCconverter_B.RateTransition_p - DCDCconverter_DWork.last_time >=
       DCDCconverter_DWork.period) && (DCDCconverter_DWork.index <= 3739.0)) {
    /* '<S77>:1:24' */
    /* '<S77>:1:25' */
    DCDCconverter_DWork.command = DCDCconverter_DWork.profile[(int32_T)
      DCDCconverter_DWork.index - 1];

    /* '<S77>:1:26' */
    DCDCconverter_DWork.index++;

    /* '<S77>:1:27' */
    DCDCconverter_DWork.last_time = DCDCconverter_B.RateTransition_p;
  } else if (DCDCconverter_P.CurrentCommandType_Value !=
             DCDCconverter_DWork.profile_on_condition) {
    /* '<S77>:1:28' */
    /* '<S77>:1:29' */
    DCDCconverter_DWork.index = 1.0;

    /* '<S77>:1:30' */
    DCDCconverter_DWork.command = 0.0;
  } else if (DCDCconverter_DWork.index > 3739.0) {
    /* '<S77>:1:31' */
    /* '<S77>:1:32' */
    DCDCconverter_DWork.command = 0.0;
  } else {
    /*  retain command value */
  }

  /* '<S77>:1:37' */
  DCDCconverter_B.command_output = DCDCconverter_DWork.command;

  /* End of MATLAB Function: '<S34>/Current_Profile_1Hz' */

  /* RateTransition: '<S73>/Rate Transition' */
  DCDCconverter_B.RateTransition_ju = DCDCconverter_B.command_output;

  /* MATLAB Function: '<S34>/Current_Profile_10Hz' incorporates:
   *  Constant: '<S34>/Current Command Type'
   */
  /* MATLAB Function 'Test Icmd/Current_Profile_10Hz': '<S76>:1' */
  if (!DCDCconverter_DWork.last_time_not_empty_l) {
    /* '<S76>:1:11' */
    /* '<S76>:1:12' */
    DCDCconverter_DWork.last_time_k = DCDCconverter_B.RateTransition_p;
    DCDCconverter_DWork.last_time_not_empty_l = TRUE;
  }

  if ((DCDCconverter_P.CurrentCommandType_Value ==
       DCDCconverter_DWork.profile_on_condition_b) &&
      (DCDCconverter_B.RateTransition_p - DCDCconverter_DWork.last_time_k >=
       DCDCconverter_DWork.period_h) && (DCDCconverter_DWork.index_d <= 39461.0))
  {
    /* '<S76>:1:24' */
    /* '<S76>:1:25' */
    DCDCconverter_DWork.command_d = DCDCconverter_DWork.profile_i[(int32_T)
      DCDCconverter_DWork.index_d - 1];

    /* '<S76>:1:26' */
    DCDCconverter_DWork.index_d++;

    /* '<S76>:1:27' */
    DCDCconverter_DWork.last_time_k = DCDCconverter_B.RateTransition_p;
  } else if (DCDCconverter_P.CurrentCommandType_Value !=
             DCDCconverter_DWork.profile_on_condition_b) {
    /* '<S76>:1:28' */
    /* '<S76>:1:29' */
    DCDCconverter_DWork.index_d = 1.0;

    /* '<S76>:1:30' */
    DCDCconverter_DWork.command_d = 0.0;
  } else if (DCDCconverter_DWork.index_d > 39461.0) {
    /* '<S76>:1:31' */
    /* '<S76>:1:32' */
    DCDCconverter_DWork.command_d = 0.0;
  } else {
    /*  retain command value */
  }

  /* '<S76>:1:37' */
  DCDCconverter_B.command_output_o = DCDCconverter_DWork.command_d;

  /* End of MATLAB Function: '<S34>/Current_Profile_10Hz' */

  /* RateTransition: '<S72>/Rate Transition' */
  DCDCconverter_B.RateTransition_h0 = DCDCconverter_B.command_output_o;

  /* RateTransition: '<S75>/Rate Transition' */
  DCDCconverter_B.RateTransition_na = DCDCconverter_B.Switch2_a;

  /* MultiPortSwitch: '<S34>/Multiport Switch for Current Command' incorporates:
   *  Constant: '<S34>/Current Command Type'
   *  Constant: '<S34>/Zero'
   */
  switch ((int32_T)DCDCconverter_P.CurrentCommandType_Value) {
   case 1:
    DCDCconverter_B.MultiportSwitchforCurrentComman =
      DCDCconverter_B.RateTransition_m;
    break;

   case 2:
    DCDCconverter_B.MultiportSwitchforCurrentComman =
      DCDCconverter_B.RandomNoiseCurrentCommand;
    break;

   case 3:
    DCDCconverter_B.MultiportSwitchforCurrentComman =
      DCDCconverter_B.RateTransition_md;
    break;

   case 4:
    DCDCconverter_B.MultiportSwitchforCurrentComman =
      DCDCconverter_B.RateTransition_ju;
    break;

   case 5:
    DCDCconverter_B.MultiportSwitchforCurrentComman =
      DCDCconverter_B.RateTransition_h0;
    break;

   case 6:
    DCDCconverter_B.MultiportSwitchforCurrentComman =
      DCDCconverter_B.RateTransition_na;
    break;

   default:
    DCDCconverter_B.MultiportSwitchforCurrentComman =
      DCDCconverter_P.Zero_Value_k;
    break;
  }

  /* End of MultiPortSwitch: '<S34>/Multiport Switch for Current Command' */

  /* Sum: '<S34>/Add' incorporates:
   *  Constant: '<S34>/DC Offset Current Command'
   */
  DCDCconverter_B.Add_e = DCDCconverter_P.DCOffsetCurrentCommand_Value +
    DCDCconverter_B.MultiportSwitchforCurrentComman;

  /* RateTransition: '<S1>/Rate Transition' */
  DCDCconverter_B.RateTransition_nl = DCDCconverter_B.ZeroOrderHold;

  /* RateTransition: '<S5>/Rate Transition' */
  DCDCconverter_B.RateTransition_pu = DCDCconverter_B.LogicalOperator;

  /* Switch: '<Root>/Switch2' */
  if (DCDCconverter_B.RateTransition_pu) {
    DCDCconverter_B.Switch2_h = DCDCconverter_B.RateTransition_nl;
  } else {
    DCDCconverter_B.Switch2_h = DCDCconverter_B.Add_e;
  }

  /* End of Switch: '<Root>/Switch2' */

  /* Saturate: '<S27>/Saturation1' */
  u = DCDCconverter_B.Switch2_h;
  u_0 = DCDCconverter_P.Saturation1_LowerSat_o;
  u_1 = DCDCconverter_P.Saturation1_UpperSat_c;
  if (u >= u_1) {
    DCDCconverter_B.Saturation1 = u_1;
  } else if (u <= u_0) {
    DCDCconverter_B.Saturation1 = u_0;
  } else {
    DCDCconverter_B.Saturation1 = u;
  }

  /* End of Saturate: '<S27>/Saturation1' */

  /* RelationalOperator: '<S58>/Relational Operator' incorporates:
   *  Constant: '<S58>/Constant1'
   */
  DCDCconverter_B.RelationalOperator = (DCDCconverter_B.Saturation1 >=
    DCDCconverter_P.Constant1_Value);

  /* Logic: '<S58>/Logical Operator' */
  DCDCconverter_B.LogicalOperator_o = (DCDCconverter_B.RelationalOperator1 &&
    DCDCconverter_B.RelationalOperator);

  /* Logic: '<S58>/Logical Operator1' */
  DCDCconverter_B.LogicalOperator1_f = !DCDCconverter_B.RelationalOperator1;

  /* Logic: '<S58>/Logical Operator2' */
  DCDCconverter_B.LogicalOperator2 = !DCDCconverter_B.RelationalOperator;

  /* Logic: '<S58>/Logical Operator3' */
  DCDCconverter_B.LogicalOperator3 = (DCDCconverter_B.LogicalOperator1_f &&
    DCDCconverter_B.LogicalOperator2);

  /* Logic: '<S27>/Logical Operator' */
  DCDCconverter_B.LogicalOperator_f = !(DCDCconverter_B.LogicalOperator_o ||
    DCDCconverter_B.LogicalOperator3);

  /* Logic: '<S27>/Logical Operator2' */
  DCDCconverter_B.LogicalOperator2_k = (DCDCconverter_B.LogicalOperator1 ||
    DCDCconverter_B.LogicalOperator_f);

  /* DiscreteIntegrator: '<S27>/Discrete-Time Integrator' */
  if ((DCDCconverter_B.LogicalOperator2_k &&
       (DCDCconverter_DWork.DiscreteTimeIntegrator_PrevRese <= 0)) ||
      ((!DCDCconverter_B.LogicalOperator2_k) &&
       (DCDCconverter_DWork.DiscreteTimeIntegrator_PrevRese == 1))) {
    DCDCconverter_DWork.DiscreteTimeIntegrator_DSTATE =
      DCDCconverter_P.DiscreteTimeIntegrator_IC;
  }

  if (DCDCconverter_DWork.DiscreteTimeIntegrator_DSTATE >=
      DCDCconverter_P.DiscreteTimeIntegrator_UpperSat) {
    DCDCconverter_DWork.DiscreteTimeIntegrator_DSTATE =
      DCDCconverter_P.DiscreteTimeIntegrator_UpperSat;
  } else {
    if (DCDCconverter_DWork.DiscreteTimeIntegrator_DSTATE <=
        DCDCconverter_P.DiscreteTimeIntegrator_LowerSat) {
      DCDCconverter_DWork.DiscreteTimeIntegrator_DSTATE =
        DCDCconverter_P.DiscreteTimeIntegrator_LowerSat;
    }
  }

  DCDCconverter_B.DiscreteTimeIntegrator =
    DCDCconverter_DWork.DiscreteTimeIntegrator_DSTATE;

  /* End of DiscreteIntegrator: '<S27>/Discrete-Time Integrator' */

  /* RateTransition: '<S2>/Rate Transition' */
  DCDCconverter_B.RateTransition_k = DCDCconverter_B.CurrentSensorScaling_l;

  /* Switch: '<S27>/Switch1' incorporates:
   *  Constant: '<S27>/Constant'
   */
  if (DCDCconverter_B.RateTransition_at) {
    /* Sum: '<S27>/Sum' */
    DCDCconverter_B.Sum_a = DCDCconverter_B.Saturation1 -
      DCDCconverter_B.RateTransition_k;
    DCDCconverter_B.Switch1_p = DCDCconverter_B.Sum_a;
  } else {
    DCDCconverter_B.Switch1_p = DCDCconverter_P.Constant_Value_c;
  }

  /* End of Switch: '<S27>/Switch1' */

  /* Gain: '<S27>/InvertErrorForBoost' */
  DCDCconverter_B.InvertErrorForBoost = DCDCconverter_P.InvertErrorForBoost_Gain
    * DCDCconverter_B.Switch1_p;

  /* Switch: '<S27>/Switch3' */
  if (DCDCconverter_B.LogicalOperator3) {
    DCDCconverter_B.Switch3 = DCDCconverter_B.InvertErrorForBoost;
  } else {
    DCDCconverter_B.Switch3 = DCDCconverter_B.Switch1_p;
  }

  /* End of Switch: '<S27>/Switch3' */

  /* Gain: '<S27>/Ra' */
  DCDCconverter_B.Ra = DCDCconverter_P.Ra_Gain_o * DCDCconverter_B.Switch3;

  /* Sum: '<S27>/Sum2' */
  DCDCconverter_B.Sum2_c = DCDCconverter_B.DiscreteTimeIntegrator +
    DCDCconverter_B.Ra;

  /* Sum: '<S27>/Sum1' */
  DCDCconverter_B.Sum1 = DCDCconverter_B.Add_b + DCDCconverter_B.Sum2_c;

  /* RateTransition: '<S17>/Rate Transition' incorporates:
   *  Constant: '<Root>/SwitchToEnableDID'
   */
  DCDCconverter_B.RateTransition_a0 = DCDCconverter_P.SwitchToEnableDID_Value;

  /* RateTransition: '<S57>/Rate Transition' incorporates:
   *  Constant: '<Root>/Vrail_rated'
   */
  DCDCconverter_B.RateTransition_hx = DCDCconverter_P.Vrail_rated_Value;

  /* Switch: '<S27>/Switch' */
  if (DCDCconverter_B.RateTransition_a0 >= DCDCconverter_P.Switch_Threshold) {
    /* Product: '<S27>/Divide1' */
    DCDCconverter_B.Divide1 = 1.0 / DCDCconverter_B.RateTransition_j *
      DCDCconverter_B.Sum1;
    DCDCconverter_B.Switch = DCDCconverter_B.Divide1;
  } else {
    /* Product: '<S27>/Divide' */
    DCDCconverter_B.Divide = DCDCconverter_B.Sum1 /
      DCDCconverter_B.RateTransition_hx;
    DCDCconverter_B.Switch = DCDCconverter_B.Divide;
  }

  /* End of Switch: '<S27>/Switch' */

  /* ZeroOrderHold: '<S27>/Zero-Order Hold' */
  DCDCconverter_B.ZeroOrderHold_n = DCDCconverter_B.Switch;

  /* Saturate: '<S27>/Saturation' */
  u = DCDCconverter_B.ZeroOrderHold_n;
  u_0 = DCDCconverter_P.Saturation_LowerSat_k;
  u_1 = DCDCconverter_P.Saturation_UpperSat_m;
  if (u >= u_1) {
    DCDCconverter_B.Saturation = u_1;
  } else if (u <= u_0) {
    DCDCconverter_B.Saturation = u_0;
  } else {
    DCDCconverter_B.Saturation = u;
  }

  /* End of Saturate: '<S27>/Saturation' */

  /* Product: '<S27>/Product1' */
  DCDCconverter_B.Product1 = DCDCconverter_B.Saturation * (real_T)
    DCDCconverter_B.LogicalOperator_o;

  /* Product: '<S27>/Product2' */
  DCDCconverter_B.Product2 = DCDCconverter_B.Saturation * (real_T)
    DCDCconverter_B.LogicalOperator3;

  /* Gain: '<S27>/Ea' */
  DCDCconverter_B.Ea = DCDCconverter_P.Ea_Gain * DCDCconverter_B.Switch3;
}

/* Model update function for TID2 */
static void DCDCconverter_update2(void) /* Sample time: [0.0002s, 0.0s] */
{
  real_T tmin;

  /* Update for UniformRandomNumber: '<S59>/Random Noise V Dist' */
  tmin = DCDCconverter_P.RandomNoiseVDist_Minimum;
  DCDCconverter_DWork.RandomNoiseVDist_NextOutput =
    (DCDCconverter_P.RandomNoiseVDist_Maximum - tmin) *
    rt_urand_Upu32_Yd_f_pw_snf(&DCDCconverter_DWork.RandSeed) + tmin;

  /* Update for Delay: '<S58>/Delay' */
  DCDCconverter_DWork.Delay_DSTATE = DCDCconverter_B.Saturation1;

  /* Update for UniformRandomNumber: '<S34>/Random Noise Current Command' */
  tmin = DCDCconverter_P.RandomNoiseCurrentCommand_Minim;
  DCDCconverter_DWork.RandomNoiseCurrentCommand_NextO =
    (DCDCconverter_P.RandomNoiseCurrentCommand_Maxim - tmin) *
    rt_urand_Upu32_Yd_f_pw_snf(&DCDCconverter_DWork.RandSeed_f) + tmin;

  /* Update for DiscreteIntegrator: '<S27>/Discrete-Time Integrator' */
  DCDCconverter_DWork.DiscreteTimeIntegrator_DSTATE +=
    DCDCconverter_P.DiscreteTimeIntegrator_gainval * DCDCconverter_B.Ea;
  if (DCDCconverter_DWork.DiscreteTimeIntegrator_DSTATE >=
      DCDCconverter_P.DiscreteTimeIntegrator_UpperSat) {
    DCDCconverter_DWork.DiscreteTimeIntegrator_DSTATE =
      DCDCconverter_P.DiscreteTimeIntegrator_UpperSat;
  } else {
    if (DCDCconverter_DWork.DiscreteTimeIntegrator_DSTATE <=
        DCDCconverter_P.DiscreteTimeIntegrator_LowerSat) {
      DCDCconverter_DWork.DiscreteTimeIntegrator_DSTATE =
        DCDCconverter_P.DiscreteTimeIntegrator_LowerSat;
    }
  }

  if (DCDCconverter_B.LogicalOperator2_k) {
    DCDCconverter_DWork.DiscreteTimeIntegrator_PrevRese = 1;
  } else {
    DCDCconverter_DWork.DiscreteTimeIntegrator_PrevRese = 0;
  }

  /* End of Update for DiscreteIntegrator: '<S27>/Discrete-Time Integrator' */

  /* Update absolute time */
  /* The "clockTick2" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick2"
   * and "Timing.stepSize2". Size of "clockTick2" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick2 and the high bits
   * Timing.clockTickH2. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++DCDCconverter_M->Timing.clockTick2)) {
    ++DCDCconverter_M->Timing.clockTickH2;
  }

  DCDCconverter_M->Timing.t[2] = DCDCconverter_M->Timing.clockTick2 *
    DCDCconverter_M->Timing.stepSize2 + DCDCconverter_M->Timing.clockTickH2 *
    DCDCconverter_M->Timing.stepSize2 * 4294967296.0;
}

/* Model output function for TID3 */
static void DCDCconverter_output3(void) /* Sample time: [0.05s, 0.0s] */
{
  real_T denAccum;
  int32_T j;
  int32_T denIdx;
  real_T u;
  real_T u_0;

  /* RateTransition: '<S69>/Rate Transition' */
  DCDCconverter_B.RateTransition = DCDCconverter_B.VoltageSensorScaling;

  /* DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn3' */
  DCDCconverter_DWork.DiscreteTransferFcn3_tmp = 0.0;
  denAccum = DCDCconverter_B.RateTransition;
  denIdx = 1;
  for (j = 0; j < 7; j++) {
    denAccum -= DCDCconverter_P.DiscreteTransferFcn3_DenCoef[denIdx] *
      DCDCconverter_DWork.DiscreteTransferFcn3_states[j];
    denIdx++;
  }

  denAccum /= DCDCconverter_P.DiscreteTransferFcn3_DenCoef[0];
  DCDCconverter_DWork.DiscreteTransferFcn3_tmp = denAccum;
  denAccum = DCDCconverter_P.DiscreteTransferFcn3_NumCoef[0] *
    DCDCconverter_DWork.DiscreteTransferFcn3_tmp;
  denIdx = 1;
  for (j = 0; j < 7; j++) {
    denAccum += DCDCconverter_P.DiscreteTransferFcn3_NumCoef[denIdx] *
      DCDCconverter_DWork.DiscreteTransferFcn3_states[j];
    denIdx++;
  }

  DCDCconverter_B.DiscreteTransferFcn3 = denAccum;

  /* End of DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn3' */

  /* RateTransition: '<S80>/Rate Transition' */
  DCDCconverter_B.RateTransition_e = DCDCconverter_B.SinusoidalVoltageCommand;

  /* UniformRandomNumber: '<S35>/Random Noise Voltage Command' */
  DCDCconverter_B.RandomNoiseVoltageCommand =
    DCDCconverter_DWork.RandomNoiseVoltageCommand_NextO;

  /* RateTransition: '<S81>/Rate Transition' */
  DCDCconverter_B.RateTransition_g = DCDCconverter_B.SquareWaveVoltageCommand;

  /* MultiPortSwitch: '<S35>/Multiport Switch for Voltage Command' incorporates:
   *  Constant: '<S35>/Voltage Command Type'
   *  Constant: '<S35>/Zero'
   */
  switch ((int32_T)DCDCconverter_P.VoltageCommandType_Value) {
   case 1:
    DCDCconverter_B.MultiportSwitchforVoltageComman =
      DCDCconverter_B.RateTransition_e;
    break;

   case 2:
    DCDCconverter_B.MultiportSwitchforVoltageComman =
      DCDCconverter_B.RandomNoiseVoltageCommand;
    break;

   case 3:
    DCDCconverter_B.MultiportSwitchforVoltageComman =
      DCDCconverter_B.RateTransition_g;
    break;

   default:
    DCDCconverter_B.MultiportSwitchforVoltageComman = DCDCconverter_P.Zero_Value;
    break;
  }

  /* End of MultiPortSwitch: '<S35>/Multiport Switch for Voltage Command' */

  /* Sum: '<S35>/Add' incorporates:
   *  Constant: '<S35>/DC Offset Voltage Command'
   */
  DCDCconverter_B.Add_by = DCDCconverter_P.DCOffsetVoltageCommand_Value +
    DCDCconverter_B.MultiportSwitchforVoltageComman;

  /* RateTransition: '<S7>/Rate Transition' incorporates:
   *  Constant: '<Root>/SwitchToVoltageControl'
   */
  DCDCconverter_B.RateTransition_n =
    DCDCconverter_P.SwitchToVoltageControl_Value;

  /* RateTransition: '<S20>/Rate Transition' */
  DCDCconverter_B.RateTransition_h = DCDCconverter_B.VoltageSensorScaling_l;

  /* DiscreteTransferFcn: '<Root>/Discrete Transfer Fcn' */
  denAccum = DCDCconverter_B.RateTransition_h;
  denAccum -= DCDCconverter_P.DiscreteTransferFcn_DenCoef[1] *
    DCDCconverter_DWork.DiscreteTransferFcn_states[0];
  denAccum -= DCDCconverter_P.DiscreteTransferFcn_DenCoef[2] *
    DCDCconverter_DWork.DiscreteTransferFcn_states[1];
  denAccum -= DCDCconverter_P.DiscreteTransferFcn_DenCoef[3] *
    DCDCconverter_DWork.DiscreteTransferFcn_states[2];
  denAccum /= DCDCconverter_P.DiscreteTransferFcn_DenCoef[0];
  DCDCconverter_DWork.DiscreteTransferFcn_tmp = denAccum;
  denAccum = DCDCconverter_P.DiscreteTransferFcn_NumCoef[0] *
    DCDCconverter_DWork.DiscreteTransferFcn_tmp;
  denAccum += DCDCconverter_P.DiscreteTransferFcn_NumCoef[1] *
    DCDCconverter_DWork.DiscreteTransferFcn_states[0];
  denAccum += DCDCconverter_P.DiscreteTransferFcn_NumCoef[2] *
    DCDCconverter_DWork.DiscreteTransferFcn_states[1];
  denAccum += DCDCconverter_P.DiscreteTransferFcn_NumCoef[3] *
    DCDCconverter_DWork.DiscreteTransferFcn_states[2];
  DCDCconverter_B.DiscreteTransferFcn = denAccum;

  /* RateTransition: '<S6>/Rate Transition' */
  DCDCconverter_B.RateTransition_p3 = DCDCconverter_B.VoltageCommand;

  /* Switch: '<Root>/Switch5' */
  if (DCDCconverter_B.RateTransition_n >= DCDCconverter_P.Switch5_Threshold) {
    DCDCconverter_B.Switch5 = DCDCconverter_B.Add_by;
  } else {
    DCDCconverter_B.Switch5 = DCDCconverter_B.RateTransition_p3;
  }

  /* End of Switch: '<Root>/Switch5' */

  /* RateTransition: '<S21>/Rate Transition' */
  DCDCconverter_B.RateTransition_aq = DCDCconverter_B.Switch5;

  /* RateTransition: '<S3>/Rate Transition' */
  DCDCconverter_B.RateTransition_jz = DCDCconverter_B.VoltageSensorScaling_l;

  /* RateTransition: '<S4>/Rate Transition' */
  DCDCconverter_B.RateTransition_lo = DCDCconverter_B.Delay3;

  /* Switch: '<S28>/Switch1' incorporates:
   *  Constant: '<S28>/Constant'
   */
  if (DCDCconverter_B.RateTransition_lo) {
    /* Saturate: '<S28>/Saturation1' */
    denAccum = DCDCconverter_B.RateTransition_aq;
    u = DCDCconverter_P.Saturation1_LowerSat;
    u_0 = DCDCconverter_P.Saturation1_UpperSat;
    if (denAccum >= u_0) {
      DCDCconverter_B.Saturation1_g = u_0;
    } else if (denAccum <= u) {
      DCDCconverter_B.Saturation1_g = u;
    } else {
      DCDCconverter_B.Saturation1_g = denAccum;
    }

    /* End of Saturate: '<S28>/Saturation1' */

    /* Sum: '<S28>/Sum' */
    DCDCconverter_B.Sum = DCDCconverter_B.Saturation1_g -
      DCDCconverter_B.RateTransition_jz;
    DCDCconverter_B.Switch1 = DCDCconverter_B.Sum;
  } else {
    DCDCconverter_B.Switch1 = DCDCconverter_P.Constant_Value;
  }

  /* End of Switch: '<S28>/Switch1' */

  /* Gain: '<S28>/Kp_vc' */
  DCDCconverter_B.Kp_vc = DCDCconverter_P.Kp_vc_Gain * DCDCconverter_B.Switch1;

  /* RateTransition: '<S63>/Rate Transition' */
  DCDCconverter_B.RateTransition_es = DCDCconverter_B.SinusoidalIDist;

  /* UniformRandomNumber: '<S62>/Random Noise I Dist' */
  DCDCconverter_B.RandomNoiseIDist =
    DCDCconverter_DWork.RandomNoiseIDist_NextOutput;

  /* RateTransition: '<S64>/Rate Transition' */
  DCDCconverter_B.RateTransition_ha = DCDCconverter_B.SquareWaveIDist;

  /* MultiPortSwitch: '<S62>/Multiport Switch for I Dist' incorporates:
   *  Constant: '<S62>/Current Disturbance Type'
   *  Constant: '<S62>/Zero'
   */
  switch ((int32_T)DCDCconverter_P.CurrentDisturbanceType_Value) {
   case 1:
    DCDCconverter_B.MultiportSwitchforIDist = DCDCconverter_B.RateTransition_es;
    break;

   case 2:
    DCDCconverter_B.MultiportSwitchforIDist = DCDCconverter_B.RandomNoiseIDist;
    break;

   case 3:
    DCDCconverter_B.MultiportSwitchforIDist = DCDCconverter_B.RateTransition_ha;
    break;

   default:
    DCDCconverter_B.MultiportSwitchforIDist = DCDCconverter_P.Zero_Value_f;
    break;
  }

  /* End of MultiPortSwitch: '<S62>/Multiport Switch for I Dist' */

  /* Sum: '<S62>/Add' incorporates:
   *  Constant: '<S62>/DC Offset I Dist'
   */
  DCDCconverter_B.Add_br = DCDCconverter_P.DCOffsetIDist_Value +
    DCDCconverter_B.MultiportSwitchforIDist;

  /* Sum: '<S28>/Sum2' */
  DCDCconverter_B.Sum2 = DCDCconverter_B.Kp_vc + DCDCconverter_B.Add_br;

  /* ZeroOrderHold: '<S28>/Zero-Order Hold' */
  DCDCconverter_B.ZeroOrderHold = DCDCconverter_B.Sum2;

  /* RateTransition: '<S9>/Rate Transition' */
  DCDCconverter_B.RateTransition_fe = DCDCconverter_B.EnableVoltageCommand;

  /* Logic: '<Root>/Logical Operator1' incorporates:
   *  Constant: '<Root>/EnableStateMachine'
   */
  DCDCconverter_B.LogicalOperator1_b = ((DCDCconverter_B.RateTransition_fe !=
    0.0) && (DCDCconverter_P.EnableStateMachine_Value != 0.0));

  /* Logic: '<Root>/Logical Operator' incorporates:
   *  Constant: '<Root>/SwitchToVoltageControl'
   */
  DCDCconverter_B.LogicalOperator =
    ((DCDCconverter_P.SwitchToVoltageControl_Value != 0.0) ||
     DCDCconverter_B.LogicalOperator1_b);

  /* DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn1' */
  denAccum = DCDCconverter_B.RateTransition;
  denAccum -= DCDCconverter_P.DiscreteTransferFcn1_DenCoef[1] *
    DCDCconverter_DWork.DiscreteTransferFcn1_states;
  denAccum /= DCDCconverter_P.DiscreteTransferFcn1_DenCoef[0];
  DCDCconverter_DWork.DiscreteTransferFcn1_tmp = denAccum;
  denAccum = DCDCconverter_P.DiscreteTransferFcn1_NumCoef[0] *
    DCDCconverter_DWork.DiscreteTransferFcn1_tmp;
  denAccum += DCDCconverter_P.DiscreteTransferFcn1_NumCoef[1] *
    DCDCconverter_DWork.DiscreteTransferFcn1_states;
  DCDCconverter_B.DiscreteTransferFcn1 = denAccum;

  /* DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn2' */
  DCDCconverter_DWork.DiscreteTransferFcn2_tmp = 0.0;
  denAccum = DCDCconverter_B.DiscreteTransferFcn1;
  denIdx = 1;
  for (j = 0; j < 7; j++) {
    denAccum -= DCDCconverter_P.DiscreteTransferFcn2_DenCoef[denIdx] *
      DCDCconverter_DWork.DiscreteTransferFcn2_states[j];
    denIdx++;
  }

  denAccum /= DCDCconverter_P.DiscreteTransferFcn2_DenCoef[0];
  DCDCconverter_DWork.DiscreteTransferFcn2_tmp = denAccum;
  denAccum = DCDCconverter_P.DiscreteTransferFcn2_NumCoef[0] *
    DCDCconverter_DWork.DiscreteTransferFcn2_tmp;
  denIdx = 1;
  for (j = 0; j < 7; j++) {
    denAccum += DCDCconverter_P.DiscreteTransferFcn2_NumCoef[denIdx] *
      DCDCconverter_DWork.DiscreteTransferFcn2_states[j];
    denIdx++;
  }

  DCDCconverter_B.DiscreteTransferFcn2 = denAccum;

  /* End of DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn2' */
}

/* Model update function for TID3 */
static void DCDCconverter_update3(void) /* Sample time: [0.05s, 0.0s] */
{
  int32_T j;
  real_T tmin;

  /* Update for DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn3' */
  for (j = 0; j < 6; j++) {
    DCDCconverter_DWork.DiscreteTransferFcn3_states[6 - j] =
      DCDCconverter_DWork.DiscreteTransferFcn3_states[5 - j];
  }

  DCDCconverter_DWork.DiscreteTransferFcn3_states[0] =
    DCDCconverter_DWork.DiscreteTransferFcn3_tmp;

  /* End of Update for DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn3' */

  /* Update for UniformRandomNumber: '<S35>/Random Noise Voltage Command' */
  tmin = DCDCconverter_P.RandomNoiseVoltageCommand_Minim;
  DCDCconverter_DWork.RandomNoiseVoltageCommand_NextO =
    (DCDCconverter_P.RandomNoiseVoltageCommand_Maxim - tmin) *
    rt_urand_Upu32_Yd_f_pw_snf(&DCDCconverter_DWork.RandSeed_b) + tmin;

  /* Update for DiscreteTransferFcn: '<Root>/Discrete Transfer Fcn' */
  DCDCconverter_DWork.DiscreteTransferFcn_states[2] =
    DCDCconverter_DWork.DiscreteTransferFcn_states[1];
  DCDCconverter_DWork.DiscreteTransferFcn_states[1] =
    DCDCconverter_DWork.DiscreteTransferFcn_states[0];
  DCDCconverter_DWork.DiscreteTransferFcn_states[0] =
    DCDCconverter_DWork.DiscreteTransferFcn_tmp;

  /* Update for UniformRandomNumber: '<S62>/Random Noise I Dist' */
  tmin = DCDCconverter_P.RandomNoiseIDist_Minimum;
  DCDCconverter_DWork.RandomNoiseIDist_NextOutput =
    (DCDCconverter_P.RandomNoiseIDist_Maximum - tmin) *
    rt_urand_Upu32_Yd_f_pw_snf(&DCDCconverter_DWork.RandSeed_l) + tmin;

  /* Update for DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn1' */
  DCDCconverter_DWork.DiscreteTransferFcn1_states =
    DCDCconverter_DWork.DiscreteTransferFcn1_tmp;

  /* Update for DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn2' */
  for (j = 0; j < 6; j++) {
    DCDCconverter_DWork.DiscreteTransferFcn2_states[6 - j] =
      DCDCconverter_DWork.DiscreteTransferFcn2_states[5 - j];
  }

  DCDCconverter_DWork.DiscreteTransferFcn2_states[0] =
    DCDCconverter_DWork.DiscreteTransferFcn2_tmp;

  /* End of Update for DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn2' */

  /* Update absolute time */
  /* The "clockTick3" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick3"
   * and "Timing.stepSize3". Size of "clockTick3" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick3 and the high bits
   * Timing.clockTickH3. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++DCDCconverter_M->Timing.clockTick3)) {
    ++DCDCconverter_M->Timing.clockTickH3;
  }

  DCDCconverter_M->Timing.t[3] = DCDCconverter_M->Timing.clockTick3 *
    DCDCconverter_M->Timing.stepSize3 + DCDCconverter_M->Timing.clockTickH3 *
    DCDCconverter_M->Timing.stepSize3 * 4294967296.0;
}

/* Model output function for TID4 */
static void DCDCconverter_output4(void) /* Sample time: [0.5s, 0.0s] */
{
  /* Delay: '<Root>/Delay4' */
  DCDCconverter_B.Delay4 = DCDCconverter_DWork.Delay4_DSTATE;

  /* DataTypeConversion: '<S30>/UltraCapacitorRelay' */
  DCDCconverter_B.UltraCapacitorRelay = (DCDCconverter_B.Delay4 != 0.0);

  /* S-Function (rti_commonblock): '<S68>/S-Function3' */
  /* This comment workarounds a code generation problem */

  /* dSPACE I/O Board DS1103 #1 Unit:BIT_IO Group:BIT_OUT */
  if (DCDCconverter_B.UltraCapacitorRelay > 0) {
    ds1103_bit_io_set(DS1103_DIO2_SET);
  } else {
    ds1103_bit_io_clear(DS1103_DIO2_CLEAR);
  }

  /* RateTransition: '<S14>/Rate Transition' */
  DCDCconverter_B.RateTransition_ba = DCDCconverter_B.UltracapacitorRelay;
}

/* Model update function for TID4 */
static void DCDCconverter_update4(void) /* Sample time: [0.5s, 0.0s] */
{
  /* Update for Delay: '<Root>/Delay4' */
  DCDCconverter_DWork.Delay4_DSTATE = DCDCconverter_B.RateTransition_ba;

  /* Update absolute time */
  /* The "clockTick4" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick4"
   * and "Timing.stepSize4". Size of "clockTick4" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick4 and the high bits
   * Timing.clockTickH4. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++DCDCconverter_M->Timing.clockTick4)) {
    ++DCDCconverter_M->Timing.clockTickH4;
  }

  DCDCconverter_M->Timing.t[4] = DCDCconverter_M->Timing.clockTick4 *
    DCDCconverter_M->Timing.stepSize4 + DCDCconverter_M->Timing.clockTickH4 *
    DCDCconverter_M->Timing.stepSize4 * 4294967296.0;
}

/* Model output wrapper function for compatibility with a static main program */
static void DCDCconverter_output(int_T tid)
{
  switch (tid) {
   case 0 :
    DCDCconverter_output0();
    break;

   case 2 :
    DCDCconverter_output2();
    break;

   case 3 :
    DCDCconverter_output3();
    break;

   case 4 :
    DCDCconverter_output4();
    break;

   default :
    break;
  }
}

/* Model update wrapper function for compatibility with a static main program */
static void DCDCconverter_update(int_T tid)
{
  switch (tid) {
   case 0 :
    DCDCconverter_update0();
    break;

   case 2 :
    DCDCconverter_update2();
    break;

   case 3 :
    DCDCconverter_update3();
    break;

   case 4 :
    DCDCconverter_update4();
    break;

   default :
    break;
  }
}

/* Model initialize function */
void DCDCconverter_initialize(void)
{
  {
    uint32_T tseed;
    int32_T r;
    int32_T t;
    real_T tmin;

    /* Start for Triggered SubSystem: '<S36>/Sample and Hold' */
    DCDCconvert_SampleandHold_Start(&DCDCconverter_B.SampleandHold,
      (rtP_SampleandHold_DCDCconverter *)&DCDCconverter_P.SampleandHold);

    /* End of Start for SubSystem: '<S36>/Sample and Hold' */

    /* Start for DataStoreMemory: '<S36>/Data Store Memory' */
    DCDCconverter_DWork.Offset = DCDCconverter_P.DataStoreMemory_InitialValue;

    /* Start for Triggered SubSystem: '<S37>/Sample and Hold' */
    DCDCconvert_SampleandHold_Start(&DCDCconverter_B.SampleandHold_d,
      (rtP_SampleandHold_DCDCconverter *)&DCDCconverter_P.SampleandHold_d);

    /* End of Start for SubSystem: '<S37>/Sample and Hold' */

    /* Start for DataStoreMemory: '<S37>/Data Store Memory' */
    DCDCconverter_DWork.Offset_p =
      DCDCconverter_P.DataStoreMemory_InitialValue_o;

    /* Start for Triggered SubSystem: '<S38>/Sample and Hold' */
    DCDCconvert_SampleandHold_Start(&DCDCconverter_B.SampleandHold_du,
      (rtP_SampleandHold_DCDCconverter *)&DCDCconverter_P.SampleandHold_du);

    /* End of Start for SubSystem: '<S38>/Sample and Hold' */

    /* Start for DataStoreMemory: '<S38>/Data Store Memory' */
    DCDCconverter_DWork.Offset_i =
      DCDCconverter_P.DataStoreMemory_InitialValue_j;

    /* Start for Triggered SubSystem: '<S39>/Sample and Hold' */
    DCDCconvert_SampleandHold_Start(&DCDCconverter_B.SampleandHold_dv,
      (rtP_SampleandHold_DCDCconverter *)&DCDCconverter_P.SampleandHold_dv);

    /* End of Start for SubSystem: '<S39>/Sample and Hold' */

    /* Start for DataStoreMemory: '<S39>/Data Store Memory' */
    DCDCconverter_DWork.Offset_p0 =
      DCDCconverter_P.DataStoreMemory_InitialValue_n;

    /* Start for Triggered SubSystem: '<S40>/Sample and Hold' */
    DCDCconvert_SampleandHold_Start(&DCDCconverter_B.SampleandHold_o,
      (rtP_SampleandHold_DCDCconverter *)&DCDCconverter_P.SampleandHold_o);

    /* End of Start for SubSystem: '<S40>/Sample and Hold' */

    /* Start for DataStoreMemory: '<S40>/Data Store Memory' */
    DCDCconverter_DWork.Offset_iq =
      DCDCconverter_P.DataStoreMemory_InitialValue_i;

    /* Start for UniformRandomNumber: '<S59>/Random Noise V Dist' */
    tmin = floor(DCDCconverter_P.RandomNoiseVDist_Seed);
    if (rtIsNaN(tmin) || rtIsInf(tmin)) {
      tmin = 0.0;
    } else {
      tmin = fmod(tmin, 4.294967296E+9);
    }

    tseed = tmin < 0.0 ? (uint32_T)-(int32_T)(uint32_T)-tmin : (uint32_T)tmin;
    r = (int32_T)(tseed >> 16U);
    t = (int32_T)(tseed & 32768U);
    tseed = ((((tseed - ((uint32_T)r << 16U)) + (uint32_T)t) << 16U) + (uint32_T)
             t) + (uint32_T)r;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else {
      if (tseed > 2147483646U) {
        tseed = 2147483646U;
      }
    }

    DCDCconverter_DWork.RandSeed = tseed;
    tmin = DCDCconverter_P.RandomNoiseVDist_Minimum;
    DCDCconverter_DWork.RandomNoiseVDist_NextOutput =
      (DCDCconverter_P.RandomNoiseVDist_Maximum - tmin) *
      rt_urand_Upu32_Yd_f_pw_snf(&DCDCconverter_DWork.RandSeed) + tmin;

    /* End of Start for UniformRandomNumber: '<S59>/Random Noise V Dist' */

    /* Start for UniformRandomNumber: '<S35>/Random Noise Voltage Command' */
    tmin = floor(DCDCconverter_P.RandomNoiseVoltageCommand_Seed);
    if (rtIsNaN(tmin) || rtIsInf(tmin)) {
      tmin = 0.0;
    } else {
      tmin = fmod(tmin, 4.294967296E+9);
    }

    tseed = tmin < 0.0 ? (uint32_T)-(int32_T)(uint32_T)-tmin : (uint32_T)tmin;
    r = (int32_T)(tseed >> 16U);
    t = (int32_T)(tseed & 32768U);
    tseed = ((((tseed - ((uint32_T)r << 16U)) + (uint32_T)t) << 16U) + (uint32_T)
             t) + (uint32_T)r;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else {
      if (tseed > 2147483646U) {
        tseed = 2147483646U;
      }
    }

    DCDCconverter_DWork.RandSeed_b = tseed;
    tmin = DCDCconverter_P.RandomNoiseVoltageCommand_Minim;
    DCDCconverter_DWork.RandomNoiseVoltageCommand_NextO =
      (DCDCconverter_P.RandomNoiseVoltageCommand_Maxim - tmin) *
      rt_urand_Upu32_Yd_f_pw_snf(&DCDCconverter_DWork.RandSeed_b) + tmin;

    /* End of Start for UniformRandomNumber: '<S35>/Random Noise Voltage Command' */

    /* Start for UniformRandomNumber: '<S34>/Random Noise Current Command' */
    tmin = floor(DCDCconverter_P.RandomNoiseCurrentCommand_Seed);
    if (rtIsNaN(tmin) || rtIsInf(tmin)) {
      tmin = 0.0;
    } else {
      tmin = fmod(tmin, 4.294967296E+9);
    }

    tseed = tmin < 0.0 ? (uint32_T)-(int32_T)(uint32_T)-tmin : (uint32_T)tmin;
    r = (int32_T)(tseed >> 16U);
    t = (int32_T)(tseed & 32768U);
    tseed = ((((tseed - ((uint32_T)r << 16U)) + (uint32_T)t) << 16U) + (uint32_T)
             t) + (uint32_T)r;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else {
      if (tseed > 2147483646U) {
        tseed = 2147483646U;
      }
    }

    DCDCconverter_DWork.RandSeed_f = tseed;
    tmin = DCDCconverter_P.RandomNoiseCurrentCommand_Minim;
    DCDCconverter_DWork.RandomNoiseCurrentCommand_NextO =
      (DCDCconverter_P.RandomNoiseCurrentCommand_Maxim - tmin) *
      rt_urand_Upu32_Yd_f_pw_snf(&DCDCconverter_DWork.RandSeed_f) + tmin;

    /* End of Start for UniformRandomNumber: '<S34>/Random Noise Current Command' */

    /* Start for UniformRandomNumber: '<S62>/Random Noise I Dist' */
    tmin = floor(DCDCconverter_P.RandomNoiseIDist_Seed);
    if (rtIsNaN(tmin) || rtIsInf(tmin)) {
      tmin = 0.0;
    } else {
      tmin = fmod(tmin, 4.294967296E+9);
    }

    tseed = tmin < 0.0 ? (uint32_T)-(int32_T)(uint32_T)-tmin : (uint32_T)tmin;
    r = (int32_T)(tseed >> 16U);
    t = (int32_T)(tseed & 32768U);
    tseed = ((((tseed - ((uint32_T)r << 16U)) + (uint32_T)t) << 16U) + (uint32_T)
             t) + (uint32_T)r;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else {
      if (tseed > 2147483646U) {
        tseed = 2147483646U;
      }
    }

    DCDCconverter_DWork.RandSeed_l = tseed;
    tmin = DCDCconverter_P.RandomNoiseIDist_Minimum;
    DCDCconverter_DWork.RandomNoiseIDist_NextOutput =
      (DCDCconverter_P.RandomNoiseIDist_Maximum - tmin) *
      rt_urand_Upu32_Yd_f_pw_snf(&DCDCconverter_DWork.RandSeed_l) + tmin;

    /* End of Start for UniformRandomNumber: '<S62>/Random Noise I Dist' */
    /* Start for S-Function (rti_commonblock): '<S23>/S-Function1' */

    /* dSPACE I/O Board DS1103 #1 Unit:PWM */
    DCDCconverter_DWork.SFunction1_IWORK[0] = 0;

    /* Start for S-Function (rti_commonblock): '<S23>/S-Function2' */

    /* dSPACE I/O Board DS1103 #1 Unit:PWM */
    DCDCconverter_DWork.SFunction2_IWORK[1] = 0;
  }

  DCDCconverter_PrevZCSigState.SampleandHold_o.SampleandHold_Trig_ZCE =
    UNINITIALIZED_ZCSIG;
  DCDCconverter_PrevZCSigState.SampleandHold_dv.SampleandHold_Trig_ZCE =
    UNINITIALIZED_ZCSIG;
  DCDCconverter_PrevZCSigState.SampleandHold_du.SampleandHold_Trig_ZCE =
    UNINITIALIZED_ZCSIG;
  DCDCconverter_PrevZCSigState.SampleandHold_d.SampleandHold_Trig_ZCE =
    UNINITIALIZED_ZCSIG;
  DCDCconverter_PrevZCSigState.SampleandHold.SampleandHold_Trig_ZCE =
    UNINITIALIZED_ZCSIG;

  {
    int32_T i;
    static const real_T tmp[3739] = { 5.2434, 5.243350783, 5.283188386,
      5.323026349, 5.362864643, 5.40270324, 5.442542113, 5.482381234,
      5.522220577, 5.562060114, 5.601897369, 5.640145017, 5.678392806,
      5.716640762, 5.754888908, 5.793137269, 5.831385868, 5.86963473,
      5.907883878, 5.946133336, 5.984383127, 6.022633274, 6.0608838, 6.099134729,
      6.137386082, 6.175637882, 6.213890153, 6.252142917, 6.290396195,
      6.32865001, 6.366904386, 6.388613775, 6.367636684, 6.367636684,
      6.367636684, 6.367636684, 6.367636684, 6.367636684, 6.533172362,
      6.51291136, 6.640085989, 6.625482529, 6.675459611, 6.694124351,
      6.725560434, 6.702564752, 6.702564752, 6.702564752, 6.735687846,
      6.920108116, 6.900106592, 6.936816343, 6.969562348, 7.242298447,
      7.779383349, 7.87326819, 7.955198544, 7.960695757, 7.958430986,
      7.969549449, 8.00531523, 8.029560392, 8.04831179, 8.081232332, 8.101435863,
      8.118535779, 8.150087167, 8.169102921, 8.185197922, 8.215925602,
      8.234217078, 8.264835485, 8.277796224, 8.275491112, 8.271979084,
      8.270792865, 8.270792865, 8.270792865, 8.270792865, 8.270792865,
      8.270792865, 8.272606336, 8.614051168, 9.175594183, 9.706425858,
      9.885708573, 9.796171015, 9.459613654, 9.2832608, 9.040881802, 8.895976506,
      8.652703276, 8.55662457, 8.384564931, 8.414498884, 8.277233872,
      8.246868991, 8.043743952, 8.102693183, 7.919503912, 7.966258325,
      7.956240544, 7.985841877, 8.198902823, 8.9530989, 9.421643407, 9.890185979,
      9.880450684, 9.736325101, 9.702867868, 9.693317998, 9.683768134,
      9.674218277, 9.664668427, 9.655118583, 9.645568746, 9.636018916,
      9.626469092, 9.616919274, 9.60278394, 9.578309777, 9.52538491, 9.284398933,
      9.019482613, 8.802814606, 8.468719835, 8.087413971, 7.646896304,
      7.16771797, 6.865020059, 6.688931555, 6.570373394, 6.477623374,
      6.562667835, 7.388543753, 7.864617728, 8.341488199, 8.818792392,
      9.289841923, 9.758397491, 9.816176206, 9.836536419, 9.782874535,
      9.768488283, 9.763667338, 9.763667338, 9.763667338, 9.763667338,
      9.763667338, 9.763667338, 9.763667338, 9.763667338, 9.763667338,
      9.763667338, 9.661811124, 9.299401219, 9.157990553, 8.91245711,
      8.695167702, 8.47304394, 8.284094032, 7.938364281, 7.780881212,
      7.591860231, 7.505706879, 7.218284574, 7.377463699, 7.32983025,
      7.266191732, 7.29812211, 7.296713952, 7.297666075, 7.295155378, 7.29608297,
      7.296087983, 7.29601443, 8.134478099, 8.589209013, 8.986899727,
      9.494690679, 9.965796301, 9.565017235, 9.441263999, 9.258757256,
      9.092038804, 8.835479373, 8.771735441, 8.430198636, 8.497863079,
      8.396615931, 8.302672069, 8.314467465, 8.34016457, 8.291349854,
      8.246984427, 8.274737312, 8.209396041, 8.165619413, 8.119214013,
      7.973176668, 7.962696149, 7.942381609, 7.758544869, 7.845791012,
      7.637071672, 7.723531402, 7.723938829, 8.570415264, 9.046061126,
      9.514615936, 9.986499279, 9.780671188, 9.690414656, 9.690414656,
      9.656513574, 9.654364422, 9.661755044, 9.679541957, 9.671308248,
      9.671308248, 9.671308248, 9.671308248, 9.671308248, 9.671308248,
      9.671308248, 9.671308248, 9.671308248, 9.671308248, 9.671308248,
      9.671308248, 9.671308248, 9.671308248, 9.671308248, 9.671308248,
      9.671308248, 9.671308248, 9.671308248, 9.671308248, 9.671308248,
      9.671308248, 9.671308248, 9.671308248, 9.671308248, 9.671308248,
      9.671308248, 9.671308248, 9.671308248, 9.671308248, 9.654364422,
      9.526231378, 9.320706188, 9.182975726, 8.992916642, 8.977386722,
      8.96110823, 8.981291752, 8.856602546, 8.932437853, 8.8584116, 8.722971869,
      8.615074399, 8.498119015, 8.551772651, 8.419147621, 8.45081608,
      8.234373867, 8.17183997, 8.071000856, 8.015694474, 7.945635334,
      7.868612296, 7.757525272, 7.77867511, 7.605893073, 7.423753113,
      7.313413654, 7.185089749, 6.984710793, 6.869129154, 6.874390935,
      6.910888541, 6.739749899, 7.622127032, 7.284582896, 7.200434287,
      7.24860765, 7.492454809, 8.221731894, 8.580098537, 7.874123277,
      8.256564136, 8.039114228, 8.433316371, 9.131725171, 9.536080267,
      9.743375266, 9.742215725, 9.815237091, 9.742649106, 9.751550618,
      9.758125998, 9.763693048, 9.768406498, 9.772397303, 9.77577631,
      9.778637345, 9.781059837, 9.783111024, 9.784847833, 9.786318456,
      9.787563698, 9.788618103, 9.789510922, 9.79026692, 9.790907067,
      9.791449117, 9.791908103, 9.792296755, 9.792625852, 9.793521564,
      9.793804401, 9.794000554, 9.794342439, 9.794500554, 9.794337007,
      9.794317014, 9.794317014, 9.70941883, 9.695660155, 9.717910908,
      9.412628065, 9.309365376, 9.125753042, 9.216955809, 9.182000097,
      9.204238714, 9.204238714, 8.922246981, 8.634950685, 8.472363163,
      8.248927049, 8.397430812, 8.404503357, 8.371994729, 8.386131811,
      8.388679031, 8.389657119, 8.542566527, 8.471330756, 8.711210092,
      8.771793383, 8.708147431, 8.941688755, 8.846393149, 8.838300264,
      8.838300264, 8.756104658, 8.75953144, 8.741175265, 8.739223715,
      8.697240331, 8.65991317, 8.685832603, 8.685832603, 8.603956696,
      8.639903737, 8.558125233, 8.593974872, 8.817363942, 9.195885604,
      8.970591568, 9.195954196, 9.246457971, 9.172678576, 9.156103359,
      9.163492803, 9.163492803, 8.964634107, 8.706190372, 8.761672618,
      8.739546227, 8.76850456, 8.76850456, 8.76850456, 8.76850456, 8.76850456,
      8.889284129, 8.832804972, 8.832804972, 8.832804972, 8.832804972,
      8.767057626, 8.664689708, 8.722575695, 8.460324604, 8.412320716,
      8.320858318, 8.245648586, 7.950085497, 8.102693518, 7.87571177, 7.93925995,
      7.952839338, 7.952839338, 7.710628664, 7.812351043, 7.57106107,
      7.671862749, 7.671862749, 7.591737184, 7.625033318, 7.538890801,
      7.57462398, 7.469812296, 7.449377437, 7.475743528, 7.475743528,
      7.610427667, 7.550670618, 7.550670618, 7.550670618, 7.550670618,
      7.550670618, 7.550670618, 7.055499275, 7.126917533, 7.039117557,
      6.955125061, 6.997168543, 6.72003376, 6.93460341, 6.891166986, 6.891166986,
      6.891166986, 6.891166986, 6.749794969, 6.791247993, 6.784309263,
      6.64860809, 6.564600895, 6.480591421, 6.521178644, 6.277665254, 6.2193554,
      6.248770863, 6.229678038, 6.210585187, 6.222603185, 6.222603185,
      6.222603185, 6.191492311, 6.172399407, 6.299917115, 6.251262797,
      6.158170434, 6.19412842, 6.178583041, 6.169033204, 6.175022012,
      6.175022012, 6.163247154, 6.157813829, 6.03738127, 5.863202591,
      5.809308734, 5.72359219, 5.745687085, 5.617913012, 5.409592997,
      5.458904837, 5.43570663, 5.319991317, 5.321512478, 5.337593399,
      5.337593399, 5.469623006, 5.565889678, 5.473546824, 5.462430544,
      5.221225342, 5.305978863, 5.106302253, 5.820223608, 5.729147544,
      5.066583218, 5.480473489, 5.435018035, 5.636667802, 6.319909544,
      6.823267176, 7.30273037, 7.778612879, 8.255371592, 8.732615072,
      9.205265447, 9.673824566, 9.986979105, 9.818373921, 9.235202262,
      8.83360555, 8.350044427, 8.067769949, 7.751584602, 7.459821733,
      7.264634035, 7.44071701, 7.158276168, 7.542797851, 7.360800547,
      7.125153455, 7.232812268, 6.917073302, 7.629881318, 7.087762502,
      7.456393968, 6.954546009, 7.131878553, 6.739243108, 6.597638563,
      6.332792324, 6.503921917, 6.206837848, 6.336498151, 7.118179089,
      7.609189471, 7.88105601, 8.446186799, 8.923556337, 9.083774828,
      9.429342249, 9.565736234, 9.708684732, 9.660792794, 9.771545596,
      9.733211169, 9.716717073, 9.734524414, 9.726270277, 9.726270277,
      9.726270277, 9.726270277, 9.709307206, 9.686981834, 9.640889588,
      9.497256282, 9.368247777, 9.311798504, 9.353247191, 9.433156695,
      9.612936756, 9.472706014, 9.421393583, 9.409492615, 9.410933582,
      9.86061915, 9.728207201, 9.695279352, 9.695279352, 9.695279352,
      9.695279352, 9.695279352, 9.695279352, 9.695279352, 9.695279352,
      9.695279352, 9.695279352, 9.695279352, 9.695279352, 9.695279352,
      9.695279352, 9.695279352, 9.695279352, 9.695279352, 9.695279352,
      9.695279352, 9.695279352, 9.695279352, 9.695279352, 9.695279352,
      9.695279352, 9.695279352, 9.695279352, 9.695279352, 9.688338574,
      9.640515347, 9.546037017, 9.261413746, 9.00658278, 8.83259602, 8.643964123,
      8.642433644, 8.439747937, 8.212876129, 8.097221664, 8.230685105,
      9.075749185, 9.544306, 9.964583095, 9.575576224, 9.309935022, 9.054863251,
      8.80319898, 8.577555582, 8.380988174, 8.065583245, 7.965367897,
      7.722487467, 7.710381397, 7.511096729, 7.624007788, 7.516282743,
      7.813982917, 7.579045788, 7.51050898, 7.379218678, 7.269477645, 6.9990462,
      6.960030093, 6.907772063, 6.803040506, 7.696934164, 8.173573998,
      8.650753952, 9.124919003, 9.593477876, 9.887540025, 9.927539817,
      9.761292762, 9.574565391, 9.300499025, 9.151997356, 8.983559346,
      8.951820112, 8.967417302, 8.993193082, 8.993193082, 8.993193082,
      8.943684399, 8.965635763, 8.965635763, 8.982969359, 8.992158822,
      8.918010722, 8.815391319, 8.725455864, 8.784475871, 8.763428054,
      8.691899208, 8.695245747, 8.680951197, 8.627714347, 8.48111517,
      8.434705432, 8.488650435, 8.505791669, 8.493182416, 8.723729786,
      8.634846587, 8.644036069, 8.80803236, 9.390645528, 9.463416354,
      9.216890815, 8.964127604, 8.792484398, 8.578926924, 8.469684587,
      8.209384021, 8.178575299, 7.926548246, 7.923325305, 7.782203949,
      7.625747969, 7.66192839, 7.441629541, 7.464632413, 7.269586332,
      7.284264589, 7.057478836, 7.150619947, 7.144809335, 7.060845728,
      7.085209105, 7.060214102, 7.356004227, 7.215695636, 7.051263848,
      7.10312882, 7.031480194, 6.978520368, 6.843863567, 6.811129472,
      6.840527781, 6.753070087, 7.088826869, 6.905681139, 6.927175038,
      6.927175038, 6.927175038, 6.927175038, 7.759009481, 7.832410517,
      7.882129227, 8.621215452, 9.09592561, 9.564483456, 9.985523874,
      9.590584709, 9.722294241, 9.597058981, 9.237267994, 8.884606931,
      8.569654054, 8.337044346, 8.253195755, 8.121134502, 8.102472692,
      7.97752205, 7.869242464, 7.807374826, 7.699688444, 7.500303946,
      7.414836549, 7.360123864, 7.210996137, 7.312362772, 7.179987867, 7.4823824,
      7.237747545, 7.30955437, 7.771735269, 8.407849433, 8.885196134,
      9.355007932, 9.320983973, 9.289211821, 9.123866258, 9.185738489,
      9.078046635, 9.487720148, 9.823400142, 9.857639416, 9.751648649,
      9.726740806, 9.717190918, 9.707641037, 9.698091164, 9.688541297,
      9.678991436, 9.669441583, 9.659891736, 9.650341896, 9.640792062,
      9.631242235, 9.621692414, 9.612142599, 9.602592791, 9.59304299,
      9.583493194, 9.573943405, 9.564393622, 9.554843845, 9.545294074,
      9.53574431, 9.526194551, 9.516644798, 9.507095051, 9.497545311,
      9.487995575, 9.478445846, 9.468896123, 9.461104496, 9.454865194,
      9.432713231, 9.276103624, 9.079963467, 8.999736084, 8.741161645,
      8.533449412, 8.415111981, 8.221358746, 8.376509781, 8.31463068,
      8.678839395, 8.864424404, 9.118538125, 8.84313383, 8.896879838,
      8.740626328, 8.709897207, 8.65454933, 8.549383926, 8.271222015,
      8.154186186, 8.043819724, 7.850727738, 7.842464668, 7.722570009,
      7.812751244, 7.622953974, 7.715972193, 7.359585611, 7.076726084,
      6.811092929, 6.487329069, 6.476035983, 6.843358788, 7.550170556,
      8.026564482, 8.131705861, 7.937620723, 7.175678164, 7.711137102,
      7.630839222, 8.467890453, 8.620881242, 8.825561148, 9.225950309,
      9.359444384, 9.793788548, 9.752407718, 9.789252265, 9.705791852,
      9.700271426, 9.69559639, 9.642594777, 9.685359735, 9.712709132,
      9.714030007, 9.705783472, 9.705783472, 9.705783472, 9.608562628,
      9.739922425, 9.752175962, 9.727433522, 9.727433522, 9.727433522,
      9.711739401, 9.718595172, 9.718595172, 9.718595172, 9.718595172,
      9.718595172, 9.718595172, 9.705308266, 9.688612667, 9.80523992,
      9.749315284, 9.719411464, 9.731955851, 9.803262533, 9.797879184,
      9.801067392, 9.793698872, 9.640821553, 9.555110634, 9.249362975,
      9.243069926, 9.04776161, 8.885143035, 8.416363084, 8.188854653,
      7.817461319, 7.679931609, 7.554109267, 7.531079472, 7.191264743,
      7.134386914, 6.98817095, 6.927435676, 6.849888986, 6.718745947,
      6.622540491, 6.457412177, 6.429615931, 6.399895893, 6.430364236,
      6.430364236, 6.430364236, 6.3053271, 6.213518861, 6.267959768, 6.267959768,
      6.267959768, 6.35059029, 6.315725788, 6.315725788, 6.315725788,
      6.315498014, 6.066170486, 6.007391667, 6.036201003, 5.784693063,
      5.88569202, 5.714059, 5.779488666, 5.717875894, 5.679713526, 5.752219856,
      5.731722646, 5.731722646, 5.731722646, 5.731722646, 5.577848213,
      5.636190606, 5.636190606, 5.636190606, 5.636190606, 5.68718586, 5.66595014,
      5.66595014, 5.66595014, 5.66595014, 5.66595014, 5.512290002, 5.5704181,
      5.525334483, 5.541782392, 5.541782392, 5.38046641, 5.377224568,
      5.399106359, 5.399106359, 6.107029069, 5.816152099, 5.816152099,
      5.754465169, 5.617913219, 5.469749283, 5.459818674, 5.497030959,
      5.494900409, 5.4967557, 5.452428192, 5.468053719, 5.468053719, 5.468053719,
      5.468053719, 5.423128726, 5.235424992, 5.105990048, 5.177214421,
      5.902203773, 5.444134065, 6.324930599, 6.80820591, 5.681133829, 6.80820591,
      7.149762111, 7.683947849, 8.160567606, 8.63773688, 8.805262921,
      7.737519118, 8.943292593, 9.41201867, 8.18738641, 9.41201867, 9.059456459,
      9.801509317, 8.855117968, 9.745412413, 9.810698133, 9.691861786,
      9.89942263, 9.79400419, 9.777078091, 9.770188657, 9.764354119, 9.752656894,
      9.709157393, 9.663562721, 9.477035788, 9.300849949, 9.064625671,
      8.924919928, 8.775446319, 8.531009352, 8.219276058, 7.913783786,
      7.777268249, 7.540929516, 7.371989856, 7.031202487, 6.771098995,
      6.588901688, 6.427312229, 6.229785676, 5.971409274, 5.922432139,
      5.799636434, 5.677067635, 5.553565719, 5.972902238, 5.660160988,
      6.068898525, 5.898231878, 6.237256293, 5.838406453, 6.514215248,
      7.098896945, 7.574276476, 8.05071367, 8.116511461, 8.377561233,
      8.549487143, 8.600594055, 8.994954471, 8.616466061, 8.874707413,
      8.653312481, 9.038509796, 9.750720439, 9.934171368, 9.80740608,
      9.741526433, 9.741526433, 9.741526433, 9.741526433, 9.741526433,
      9.741526433, 9.741526433, 9.741526433, 9.741526433, 9.741526433,
      9.741526433, 9.741526433, 9.741526433, 9.741526433, 9.741526433,
      9.741526433, 9.741526433, 9.741526433, 9.72199217, 9.594812213,
      9.472039418, 9.382404785, 9.193280651, 9.105772381, 8.946311283,
      8.776294771, 8.663342214, 8.518563667, 8.403089577, 8.342485065,
      8.261120394, 8.081986493, 8.014520838, 8.039517719, 7.873538675,
      7.750765573, 7.77949436, 7.584400233, 7.688979102, 7.651195022,
      7.918031665, 8.099604617, 8.818869456, 9.289917553, 9.758473116,
      9.957108565, 9.734459883, 9.675822564, 9.521124599, 9.290596635,
      9.153471517, 8.927745021, 8.733399184, 8.476312934, 8.236349419,
      7.925370551, 7.638586055, 7.365756743, 7.138263961, 6.877114672,
      6.721613543, 6.455114001, 6.61754999, 6.314872605, 6.434973479,
      6.734904498, 7.432368206, 7.908534124, 8.385456778, 8.862789556,
      9.333019397, 9.385856145, 9.453002825, 9.782925806, 9.873972905,
      9.785893482, 9.694191375, 9.656031574, 9.596596894, 9.417051104,
      9.09894719, 8.900104553, 8.717761723, 8.495622371, 8.279853701,
      8.124299127, 8.168835198, 8.660528154, 9.310113013, 9.77866717,
      9.954942725, 9.760414968, 9.542108784, 9.415695094, 9.318241291,
      9.320803744, 9.673075892, 9.886830981, 9.720789818, 9.720789818,
      9.656021774, 9.514825885, 9.335059999, 9.202612585, 8.890322819,
      8.81178672, 8.566911292, 8.374176315, 8.350037412, 8.200680703,
      7.907965052, 7.734134624, 7.603716826, 7.253131703, 7.057087841,
      6.894066931, 6.79639809, 6.64853744, 6.495457499, 6.50951921, 6.533220294,
      6.519154995, 6.82360053, 6.663807995, 6.660717003, 6.510745369,
      6.495377115, 6.448634385, 6.328728374, 6.228766507, 6.212484201,
      6.16480304, 6.115943018, 6.06408837, 6.010649978, 5.955870116, 5.965246652,
      5.725707818, 5.64888862, 5.691659208, 5.684908457, 5.920071823,
      6.544465921, 7.069469838, 7.544774274, 8.021158357, 8.49820142, 8.9751736,
      9.443721131, 9.515899922, 9.771702374, 9.870204077, 9.795018603,
      9.728040671, 9.708947489, 9.689854363, 9.670761292, 9.651668275,
      9.632575311, 9.613482399, 9.458960777, 9.161038964, 9.046810552,
      8.888863101, 8.777350546, 9.003364178, 9.085171588, 9.158893882,
      9.000042513, 8.900011438, 8.897851625, 8.943981212, 8.671141246,
      8.805560874, 8.738948715, 9.006280153, 9.204824503, 9.597186072,
      9.668017532, 9.715562656, 9.608646599, 9.582172545, 9.563079768,
      9.543987041, 9.524894363, 9.505801732, 9.392026541, 9.136860011,
      8.872447008, 8.57146616, 8.218071571, 7.975559515, 7.762116803,
      7.593977466, 7.398747216, 7.189436247, 6.917584527, 6.7030726, 6.859919051,
      6.66861644, 7.027698082, 7.736524478, 8.213223526, 8.690435025,
      9.119695043, 9.608175881, 9.713830403, 9.781308038, 9.802511756,
      9.764096412, 9.747579426, 9.747579426, 9.747579426, 9.747579426,
      9.747579426, 9.747579426, 9.747579426, 9.747579426, 9.747579426,
      9.747579426, 9.747579426, 9.747579426, 9.747579426, 9.747579426,
      9.747579426, 9.747579426, 9.747579426, 9.747579426, 9.747579426,
      9.747579426, 9.747579426, 9.747579426, 9.747579426, 9.747579426,
      9.747579426, 9.476051885, 9.293668795, 9.424713326, 9.424713326,
      9.424713326, 9.171889445, 8.981442361, 8.81727861, 8.582998371,
      8.600388328, 8.664199747, 8.664199747, 8.647833729, 8.469527863,
      8.306116288, 8.278139539, 8.059091953, 8.024397151, 8.089201099,
      8.089201099, 8.089201099, 8.089201099, 8.089201099, 8.008551472,
      7.861082061, 7.929571881, 7.596614314, 7.619627864, 7.667252569,
      7.66791085, 8.513336781, 8.990031345, 9.458580704, 9.928276352,
      9.460635282, 9.101779953, 8.960958418, 8.685416094, 8.425211074,
      8.265416463, 7.941723555, 7.871426408, 7.810367676, 7.616973676,
      7.713258586, 7.639713268, 7.592984935, 7.626283763, 7.546256126,
      7.499526772, 7.277175002, 7.096517869, 7.024172155, 6.886364379,
      6.958269328, 6.852035115, 7.16364603, 7.214262312, 6.975725012,
      6.858272274, 6.539180555, 6.594205807, 6.426786669, 6.496673133,
      6.782464802, 7.246850639, 7.82567366, 8.302495155, 8.110273377,
      7.948040398, 7.901313509, 7.854586591, 8.07538657, 7.926823185,
      7.916980241, 8.204709761, 8.040351703, 8.042959483, 8.260021315,
      9.018865839, 9.487418282, 9.958239997, 9.575351565, 9.584908358,
      9.382113801, 9.679339641, 9.402434085, 9.211608209, 8.908943294,
      8.835148401, 8.705147685, 9.193985276, 9.883768396, 9.909293712,
      9.69632713, 9.721534995, 9.538582915, 9.225622641, 8.990891041,
      8.688818066, 8.4177534, 8.19081397, 8.123945761, 7.861230455, 7.64797852,
      7.306068022, 6.930702088, 6.618689208, 6.364024019, 6.15409343,
      6.187596393, 5.839591707, 5.868771829, 5.517305535, 5.302263758,
      5.034922121, 5.458289952, 5.316633698, 6.015574286, 6.292394212,
      6.883425904, 7.154310788, 7.646501749, 8.153681488, 7.986635139,
      7.702123109, 7.935776463, 8.574959801, 8.770506439, 8.826338585,
      9.12135168, 9.26673282, 9.504090131, 9.593946708, 9.737274488, 9.612826564,
      9.754975711, 9.778237928, 9.786245695, 9.772287318, 9.768170825,
      9.768170825, 9.751193235, 9.741643329, 9.732093431, 9.705575866,
      9.672703043, 9.557923967, 9.428306135, 9.367912803, 9.241862138,
      9.147685853, 9.094757541, 9.274735924, 9.167397335, 9.294158396,
      9.194922027, 9.217175945, 9.172145519, 9.154139473, 8.940887911,
      8.798701088, 8.634935439, 8.705470469, 8.899830985, 8.836586782,
      8.812062803, 8.836586782, 9.087673988, 9.5383017, 9.604958159, 9.663826248,
      9.672476977, 9.623289731, 9.606362897, 9.631505511, 9.606362897,
      9.596813093, 9.588138281, 9.581540276, 9.575952548, 9.5712205, 9.567213163,
      9.563819598, 9.549949228, 9.540399461, 9.530849699, 9.523160553,
      9.516965573, 9.511719195, 9.507276248, 9.503513756, 9.500327546,
      9.497629384, 9.495344537, 9.493409705, 9.491771284, 9.49038387,
      9.489209017, 9.488214162, 9.487371732, 9.486658374, 9.486054315,
      9.48554281, 9.485109678, 9.484742911, 9.484432342, 9.484169359,
      9.483946672, 9.483758107, 9.483598434, 9.483463228, 9.483348739,
      9.483251793, 9.483169701, 9.483100189, 9.466164975, 9.389176312,
      9.255760311, 9.227114448, 9.104706258, 9.02851539, 9.001539703,
      9.164934287, 9.092996332, 9.203853979, 9.121508782, 9.136273295,
      9.097119029, 9.081418214, 8.874625211, 8.731624348, 8.585493873,
      8.647400737, 8.841412515, 8.778379693, 8.766053045, 8.785183056,
      9.035980284, 9.486236963, 9.551131282, 9.610144785, 9.618917994, 9.5698514,
      9.536035928, 9.568490349, 9.539262705, 9.530602595, 9.521447622,
      9.499413644, 9.48731074, 9.477059868, 9.468377939, 9.459237468,
      9.437189708, 9.425068264, 9.41480166, 9.406106386, 9.380121801,
      9.317428651, 9.083568837, 8.911979397, 8.747411612, 8.531394245,
      8.395359938, 8.194177714, 8.219518021, 8.612069048, 9.174072627,
      9.704681525, 9.88390789, 9.794386077, 9.4632525, 9.294133218, 9.064021208,
      8.923617648, 8.691277422, 8.595673882, 8.443088552, 8.437545264,
      8.318361203, 8.264440845, 8.079706615, 8.125338056, 7.955233754,
      7.966408348, 7.944656678, 7.986228966, 8.198670834, 8.952865526,
      9.421412459, 9.889955061, 9.880213297, 9.736089496, 9.685671774,
      9.666578715, 9.647485709, 9.628392757, 9.609299857, 9.590207008,
      9.571114209, 9.552021461, 9.532928762, 9.513836112, 9.465437402,
      9.425330108, 9.344171443, 9.113384475, 8.869595846, 8.658828825,
      8.345485902, 7.990590924, 7.5892593, 7.161864539, 6.878537418, 6.702843327,
      6.5705739, 6.476034419, 6.562588892, 7.388435614, 7.864509357, 8.341379695,
      8.818683816, 9.289735367, 9.758290942, 9.816097295, 9.8364702, 9.782796563,
      9.768432645, 9.763601386, 9.763601386, 9.763601386, 9.763601386,
      9.763601386, 9.763601386, 9.763601386, 9.763601386, 9.763601386,
      9.763601386, 9.627793283, 9.297339452, 9.163781008, 8.928392156,
      8.717713604, 8.505639399, 8.318749467, 7.996713601, 7.844686794,
      7.665580213, 7.563451339, 7.29570124, 7.424911529, 7.355127735, 7.28449058,
      7.310927391, 7.300794863, 7.307655965, 7.292592581, 7.295949875,
      7.296559145, 7.295459007, 8.134427842, 8.5891861, 8.986875092, 9.494661682,
      9.965766172, 9.564987675, 9.429739771, 9.28285691, 9.115790479,
      8.879386185, 8.814472518, 8.517113484, 8.560907509, 8.459452276,
      8.366017119, 8.360721147, 8.394035935, 8.329315006, 8.28646648,
      8.316969701, 8.240288627, 8.191783297, 8.141374373, 7.991879993,
      7.967762826, 7.928688952, 7.758721435, 7.84469993, 7.638096554,
      7.723417247, 7.723945377, 8.570414451, 9.046060328, 9.514615138,
      9.98649845, 9.780670371, 9.684796597, 9.687248003, 9.636399713, 9.62470971,
      9.622549401, 9.647703817, 9.639481983, 9.639481983, 9.639481983,
      9.639481983, 9.639481983, 9.639481983, 9.639481983, 9.639481983,
      9.639481983, 9.639481983, 9.639481983, 9.639481983, 9.639481983,
      9.639481983, 9.639481983, 9.639481983, 9.639481983, 9.639481983,
      9.639481983, 9.639481983, 9.639481983, 9.639481983, 9.639481983,
      9.639481983, 9.639481983, 9.639481983, 9.639481983, 9.639481983,
      9.639481983, 9.639481983, 9.613838206, 9.489594431, 9.295087122,
      9.169421688, 8.988633224, 8.965945574, 8.939259648, 8.947541208,
      8.830243379, 8.905981583, 8.832009551, 8.696635681, 8.588750479,
      8.479064977, 8.513096602, 8.387711059, 8.403009991, 8.19659639,
      8.142692653, 8.044853909, 7.984039293, 7.909374481, 7.834709888,
      7.716509041, 7.724474875, 7.56746177, 7.392780338, 7.296468516,
      7.176968708, 6.993410922, 6.870935839, 6.868024572, 6.907350967,
      6.742593441, 7.622388092, 7.284839844, 7.20022411, 7.248588994,
      7.492436057, 8.221712897, 8.580079576, 7.87412965, 8.256559752,
      8.039113356, 8.433317945, 9.131724981, 9.536080131, 9.743375146,
      9.742215585, 9.815236951, 9.742648967, 9.751550518, 9.758125914,
      9.763692977, 9.768406437, 9.772397252, 9.775776267, 9.778637309,
      9.781059806, 9.783110998, 9.784847811, 9.786318438, 9.787563682,
      9.788618089, 9.789510911, 9.790266911, 9.790907059, 9.79144911,
      9.791908097, 9.79229675, 9.792625848, 9.792904515, 9.793140482, 9.79334029,
      9.793509481, 9.793652746, 9.793505427, 9.793505427, 9.793505427,
      9.725560218, 9.704373187, 9.726632999, 9.45522185, 9.387781119,
      9.198759384, 9.282216287, 9.246316919, 9.258718345, 9.262755111,
      9.013458935, 8.744043534, 8.617096588, 8.387384804, 8.529814736,
      8.536944582, 8.50432124, 8.518573036, 8.518573036, 8.518573036,
      8.672952908, 8.601244993, 8.841858946, 8.902232107, 8.821703547,
      9.063562948, 8.95030437, 8.95030437, 8.95030437, 8.880042008, 8.894684354,
      8.885502367, 8.892782077, 8.859858693, 8.841502336, 8.856038984,
      8.856038984, 8.795357234, 8.822146712, 8.768764909, 8.792306086,
      9.01673577, 9.379142935, 9.159737009, 9.386084793, 9.421089035,
      9.356373403, 9.339543792, 9.346820199, 9.346820199, 9.161733643,
      8.943558025, 8.988152291, 8.961608892, 8.990933495, 8.990933495,
      8.990933495, 8.990933495, 8.990933495, 9.112339796, 9.055233907,
      9.055233907, 9.055233907, 9.055233907, 8.988915668, 8.886271223,
      8.928407071, 8.688513919, 8.63829117, 8.544782899, 8.469660634,
      8.191581944, 8.341200113, 8.145554263, 8.180159583, 8.20086607, 8.20086607,
      7.973284494, 8.069743662, 7.832307241, 7.93245976, 7.93245976, 7.851767471,
      7.885630328, 7.794633095, 7.832753358, 7.711056341, 7.697679532,
      7.724472279, 7.724472279, 7.842983955, 7.790033483, 7.790033483,
      7.790033483, 7.790033483, 7.790033483, 7.790033483, 7.307744974,
      7.373676205, 7.286288043, 7.202308479, 7.245149972, 6.989382247,
      7.184520422, 7.14594769, 7.14594769, 7.14594769, 7.130140506, 6.99435054,
      7.020748201, 7.002031056, 6.866737681, 6.770226828, 6.67666253, 6.70856263,
      6.470835331, 6.399814019, 6.421058907, 6.392430309, 6.363801651, 6.3820097,
      6.3820097, 6.3820097, 6.349570875, 6.319099399, 6.45161192, 6.402671548,
      6.277714123, 6.326245916, 6.295061339, 6.275968571, 6.2880331, 6.2880331,
      6.25687578, 6.237782965, 6.109734572, 5.930820711, 5.876844466,
      5.779539646, 5.791446065, 5.656653395, 5.453102888, 5.493540275,
      5.465047292, 5.34786189, 5.328582725, 5.352744861, 5.352744861,
      5.484800186, 5.581070487, 5.481447025, 5.453887762, 5.22197306,
      5.306037915, 5.106307053, 5.820222932, 5.729146814, 5.066582286,
      5.480472611, 5.43501716, 5.636666924, 6.319908695, 6.823266325,
      7.302729534, 7.778612041, 8.255370753, 8.732614232, 9.205264622,
      9.673823741, 9.986979202, 9.818373595, 9.23520194, 8.840376964,
      8.385592802, 8.099368642, 7.787889818, 7.499744764, 7.291689101,
      7.472271439, 7.173138507, 7.564811017, 7.382648347, 7.129795533,
      7.244636591, 6.91260675, 7.632161104, 7.089997715, 7.458658176,
      6.955604434, 7.133440911, 6.739982456, 6.598713852, 6.324220897,
      6.499229156, 6.209292729, 6.336112252, 7.11789755, 7.608863891,
      7.880819078, 8.445910436, 8.923279814, 9.083505408, 9.429149203,
      9.565508849, 9.708448806, 9.660558031, 9.771310573, 9.73297676, 9.70377112,
      9.727127056, 9.705512375, 9.700034745, 9.695395957, 9.691467613,
      9.678055726, 9.651557073, 9.615522031, 9.468369193, 9.356281223,
      9.297679311, 9.324426152, 9.409640961, 9.589349728, 9.455604555,
      9.406921964, 9.384284477, 9.393181877, 9.841017317, 9.70876062,
      9.674201427, 9.673519837, 9.672942679, 9.672453953, 9.67204011,
      9.671689678, 9.67139294, 9.671141669, 9.6709289, 9.670748732, 9.670596171,
      9.670466987, 9.670357597, 9.670264968, 9.670186533, 9.670120117,
      9.670063877, 9.670016255, 9.66997593, 9.669941784, 9.66991287, 9.669888386,
      9.669867654, 9.669850099, 9.669835234, 9.669822646, 9.669811988,
      9.65285966, 9.609438087, 9.506520811, 9.235505712, 8.984663503,
      8.814896396, 8.636255391, 8.627683483, 8.433358598, 8.211145994,
      8.102013461, 8.23052632, 9.075842052, 9.544398873, 9.964679482,
      9.570117281, 9.306910402, 9.053819053, 8.806391411, 8.593284848,
      8.391424604, 8.084289458, 7.992709707, 7.738619301, 7.724174414,
      7.524297633, 7.63843073, 7.513479001, 7.818377914, 7.577507212, 7.50283821,
      7.376209117, 7.266926828, 6.996896139, 6.967248539, 6.898975214,
      6.805177541, 7.696614526, 8.17325387, 8.650433563, 9.12460453, 9.593163395,
      9.887305088, 9.927420871, 9.761104488, 9.574377832, 9.304043437,
      9.170767847, 8.994509908, 8.962804144, 8.970439664, 8.999778621,
      8.999778621, 8.999778621, 8.950261885, 8.972221302, 8.972221302,
      8.989557543, 8.998747006, 8.924585512, 8.821955259, 8.73225453,
      8.781269411, 8.755669113, 8.688080922, 8.691422669, 8.673066616,
      8.619954276, 8.47795039, 8.427182236, 8.482273036, 8.499411694,
      8.485072612, 8.718438495, 8.628616409, 8.637805892, 8.80177955,
      9.386111735, 9.458096487, 9.211414742, 8.958889517, 8.795378599,
      8.578174839, 8.468931058, 8.208632848, 8.177805769, 7.955390059,
      7.939519271, 7.789771449, 7.636949663, 7.670222709, 7.457986215,
      7.478165172, 7.279525805, 7.295724463, 7.074304499, 7.161495029,
      7.139590006, 7.062309667, 7.086452534, 7.060532897, 7.356776182,
      7.201301769, 7.055632019, 7.102546767, 7.030816463, 6.978199994,
      6.84364203, 6.810974877, 6.84036295, 6.753027318, 7.088724759, 6.905762665,
      6.927182407, 6.927182407, 6.927182407, 6.927182407, 7.759016978,
      7.832417959, 7.8821346, 8.621221813, 9.095931854, 9.5644897, 9.985530354,
      9.590591072, 9.722300623, 9.580123794, 9.227799249, 8.881690802,
      8.58209208, 8.356534102, 8.270051966, 8.136470688, 8.117861074,
      7.988785547, 7.87878806, 7.815479683, 7.706550168, 7.506097858,
      7.418003508, 7.362335746, 7.212070333, 7.314336741, 7.178880437,
      7.482542358, 7.237657804, 7.309567201, 7.771748227, 8.407862502,
      8.885209211, 9.355020765, 9.320996658, 9.28922444, 9.123878808,
      9.185751073, 9.078059184, 9.487732833, 9.823409662, 9.857650556,
      9.751656566, 9.726750183, 9.717200295, 9.707650415, 9.698100541,
      9.688550674, 9.679000813, 9.66945096, 9.659901113, 9.650351273,
      9.640801439, 9.631251612, 9.621701791, 9.612151977, 9.602602169,
      9.593052367, 9.583502571, 9.573952782, 9.564402999, 9.554853222,
      9.545303452, 9.535753687, 9.526203928, 9.516654175, 9.507104428,
      9.497554688, 9.488004952, 9.478455223, 9.4689055, 9.459355782, 9.44980607,
      9.423389531, 9.26941858, 9.07329382, 8.993315167, 8.743690383, 8.543077653,
      8.418840094, 8.240677118, 8.389236705, 8.337675739, 8.692265433,
      8.880275834, 9.134414828, 8.840518055, 8.902402866, 8.746126615,
      8.713891613, 8.657933183, 8.55224559, 8.274543969, 8.15660481, 8.045154102,
      7.852186296, 7.843708967, 7.721364289, 7.812657969, 7.622885728,
      7.71589321, 7.35952812, 7.076694885, 6.811083156, 6.487731003, 6.47585404,
      6.84335107, 7.55015885, 8.026552755, 8.13169422, 7.937609201, 7.175672963,
      7.711129075, 7.630831231, 8.467882312, 8.620873157, 8.825553231,
      9.22594461, 9.359437686, 9.793781553, 9.752400782, 9.789247311,
      9.705787601, 9.700267825, 9.695593342, 9.642597986, 9.685359993,
      9.71270939, 9.714030265, 9.705783729, 9.705783729, 9.705783729,
      9.608562675, 9.739922565, 9.752176101, 9.727433661, 9.727433661,
      9.727433661, 9.711739502, 9.718595289, 9.718595289, 9.718595289,
      9.718595289, 9.718595289, 9.718595289, 9.705308352, 9.688612712,
      9.80523999, 9.749315334, 9.719411427, 9.731955851, 9.803262532,
      9.797879184, 9.801067391, 9.793698872, 9.640821553, 9.561741092,
      9.269996911, 9.256309667, 9.068116999, 8.915984542, 8.457256511,
      8.238732552, 7.877101008, 7.748911064, 7.616299916, 7.593519238,
      7.25565743, 7.198091736, 7.051858425, 6.99125826, 6.913739938, 6.787429728,
      6.689254473, 6.524028452, 6.494916639, 6.466402269, 6.497460949,
      6.497460949, 6.497460949, 6.357916993, 6.27181688, 6.326446712,
      6.326446712, 6.326446712, 6.409157195, 6.374212732, 6.374212732,
      6.374212732, 6.358603273, 6.114962978, 6.056292056, 6.085240137,
      5.833476453, 5.934765349, 5.750782065, 5.821042508, 5.759374445,
      5.72121249, 5.793802763, 5.773276488, 5.773276488, 5.773276488,
      5.773276488, 5.619265126, 5.677744448, 5.677744448, 5.677744448,
      5.677744448, 5.726883658, 5.70640406, 5.70640406, 5.70640406, 5.70640406,
      5.70640406, 5.55261248, 5.61087202, 5.575709596, 5.588985977, 5.588985977,
      5.429411902, 5.461132279, 5.470511399, 5.470511399, 6.167872659,
      5.879807112, 5.879807112, 5.802623382, 5.658458056, 5.50093456,
      5.484222114, 5.532869289, 5.52820314, 5.52820314, 5.469202331, 5.490376251,
      5.490376251, 5.490376251, 5.490376251, 5.42410717, 5.2337225, 5.105117449,
      5.177145228, 5.902213693, 5.444144705, 6.324941397, 5.21192095,
      5.005875601, 6.008787702, 6.434728323, 6.943552675, 7.420966138,
      7.89710851, 8.106893687, 7.04592456, 8.222809021, 8.700027928, 7.50400298,
      8.700027928, 8.797675786, 9.366415877, 9.346023894, 9.81349478,
      9.878358929, 9.791777607, 9.821893772, 9.792235135, 9.77555225,
      9.768896439, 9.763259777, 9.751383411, 9.707884792, 9.662290571,
      9.476460291, 9.299971508, 9.063748997, 8.919972454, 8.772346417,
      8.528774093, 8.216665378, 7.911846176, 7.775008213, 7.538671516,
      7.370327013, 7.029294643, 6.769689866, 6.587701458, 6.426291826,
      6.229199675, 5.960631892, 5.918985149, 5.797239198, 5.676224977,
      5.55355115, 5.972345577, 5.659550259, 6.06828254, 5.897771183, 6.23673472,
      5.838794459, 6.514253258, 7.098934404, 7.57431403, 8.050751292,
      8.116538549, 8.377584141, 8.549513866, 8.600620175, 8.994980758,
      8.616491946, 8.87472605, 8.653322358, 9.038525172, 9.750736005,
      9.934182941, 9.807419558, 9.741539871, 9.741539871, 9.741539871,
      9.741539871, 9.741539871, 9.741539871, 9.741539871, 9.741539871,
      9.741539871, 9.741539871, 9.741539871, 9.741539871, 9.741539871,
      9.741539871, 9.741539871, 9.741539871, 9.741539871, 9.741539871,
      9.722001945, 9.59482356, 9.467799016, 9.380026711, 9.183649034,
      9.099553407, 8.940100235, 8.771040315, 8.659227294, 8.515076902,
      8.401249456, 8.340425905, 8.259374772, 8.079920506, 8.013003755,
      8.03822602, 7.872450192, 7.750176958, 7.779311797, 7.584178875,
      7.688741667, 7.651354608, 7.918009136, 8.099613146, 8.818864115,
      9.289912311, 9.758467875, 9.957103153, 9.734454534, 9.675817225,
      9.521119275, 9.290591326, 9.169572976, 8.934015518, 8.740765217,
      8.483665123, 8.231665337, 7.925866502, 7.63900693, 7.366114306,
      7.138458842, 6.877250877, 6.721657338, 6.455165846, 6.617625426,
      6.314831943, 6.434979682, 6.734907333, 7.43237249, 7.908538417,
      8.385461076, 8.862793856, 9.333023617, 9.385860325, 9.453006988,
      9.782930151, 9.873977235, 9.785894101, 9.694193697, 9.656033895,
      9.596598583, 9.417051994, 9.098948173, 8.900105347, 8.717762397,
      8.495622942, 8.279853817, 8.124299389, 8.168834925, 8.660528169,
      9.310113012, 9.778667168, 9.954942724, 9.760414966, 9.542108783,
      9.415695093, 9.307670542, 9.326143899, 9.67351312, 9.887145013, 9.72115753,
      9.72115753, 9.65628896, 9.515136159, 9.335369695, 9.202838091, 8.890573863,
      8.8120386, 8.552042788, 8.368310016, 8.343147301, 8.19379998, 7.90097965,
      7.727140854, 7.590268115, 7.242463397, 7.049209153, 6.882894574,
      6.78874537, 6.629604806, 6.472656079, 6.494904861, 6.520810343,
      6.517844667, 6.817153004, 6.657400394, 6.658113373, 6.506630103,
      6.49125407, 6.444511314, 6.325587083, 6.212187563, 6.200967779,
      6.153286522, 6.105604851, 6.05598819, 6.003788971, 5.950058542,
      5.961943543, 5.72343898, 5.64730423, 5.6916314, 5.685524577, 5.920133573,
      6.544511909, 7.069521635, 7.544826202, 8.021210381, 8.498253495,
      8.97522472, 9.443772258, 9.515936066, 9.771734469, 9.870231062,
      9.795050294, 9.728072294, 9.708979112, 9.689885985, 9.670792914,
      9.651699897, 9.632606932, 9.613514021, 9.458992309, 9.147513205,
      9.041553155, 8.884407265, 8.773567216, 8.998894615, 9.080700251,
      9.154422572, 8.996825496, 8.898330681, 8.896678326, 8.942165165,
      8.670834911, 8.804579643, 8.750750928, 9.012483757, 9.211037962,
      9.603431477, 9.672659114, 9.721017644, 9.614077144, 9.587601154,
      9.568508363, 9.549415622, 9.530322929, 9.511230286, 9.395972178,
      9.140184592, 8.864903733, 8.569019274, 8.207319026, 7.970331852,
      7.759304755, 7.590877008, 7.396115832, 7.187319448, 6.916399533,
      6.703147032, 6.85924159, 6.668985917, 7.027687594, 7.736494461,
      8.213193466, 8.690404941, 9.119673788, 9.608150878, 9.713804631,
      9.781282386, 9.802486182, 9.764070904, 9.747553937, 9.747553937,
      9.747553937, 9.747553937, 9.747553937, 9.747553937, 9.747553937,
      9.747553937, 9.747553937, 9.747553937, 9.747553937, 9.747553937,
      9.747553937, 9.747553937, 9.747553937, 9.747553937, 9.747553937,
      9.747553937, 9.747553937, 9.747553937, 9.747553937, 9.747553937,
      9.747553937, 9.747553937, 9.747553937, 9.476026538, 9.29020313,
      9.422745001, 9.422745001, 9.422745001, 9.169931999, 8.967272366,
      8.80865456, 8.576779149, 8.595071915, 8.657971121, 8.657971121,
      8.641607745, 8.465028986, 8.300876053, 8.274314588, 8.039474222,
      8.014742598, 8.078005307, 8.078005307, 8.078005307, 8.078005307,
      8.078005307, 8.00034777, 7.85415827, 7.923665388, 7.593467677, 7.622356756,
      7.666972142, 7.667589006, 8.513008772, 8.989709355, 9.458258675,
      9.927941747, 9.464963451, 9.104065435, 8.956387067, 8.683903882,
      8.407249187, 8.251135018, 7.919690781, 7.853281978, 7.792175585,
      7.603644364, 7.697786196, 7.624267646, 7.578891325, 7.611595248,
      7.531599064, 7.494517353, 7.256668577, 7.080833691, 7.008446651,
      6.878808401, 6.954365412, 6.856126015, 7.163331569, 7.213948456,
      6.975494429, 6.858145282, 6.538064486, 6.594035493, 6.423541557,
      6.497786513, 6.782339852, 7.246744061, 7.82554967, 8.302371004,
      8.110184922, 7.947937436, 7.901210547, 7.854483629, 8.07528294,
      7.926720178, 7.916958939, 8.20465366, 8.040340354, 8.042945333,
      8.260011982, 9.018851342, 9.487403784, 9.958224933, 9.57533678,
      9.584893573, 9.382103092, 9.67932707, 9.402425012, 9.21160341, 8.900979529,
      8.835633051, 8.706733614, 9.194110053, 9.883894558, 9.909423505,
      9.696455713, 9.72166367, 9.538746068, 9.225769763, 8.991038061,
      8.673706016, 8.411825768, 8.183857336, 8.11681946, 7.854126639,
      7.640875272, 7.298989324, 6.925510314, 6.61426983, 6.360259487,
      6.151925816, 6.184523259, 5.838075835, 5.86664026, 5.516775706,
      5.302799724, 5.034987848, 5.458295232, 5.316639658, 6.015578787,
      6.292399098, 6.883430812, 7.154314311, 7.646504741, 8.153684959,
      7.986638562, 7.702126498, 7.935779882, 8.574962317, 8.770509303,
      8.826341435, 9.121354539, 9.266735672, 9.504092987, 9.593948835,
      9.737276286, 9.612828674, 9.754977828, 9.778240042, 9.786245999,
      9.772288132, 9.76817179, 9.76817179, 9.7511942, 9.741644295, 9.732094396,
      9.705576831, 9.672703745, 9.557924782, 9.414016609, 9.362056254,
      9.236906892, 9.143485125, 9.091366915, 9.270737669, 9.169266176,
      9.293409029, 9.194175331, 9.216428366, 9.17160566, 9.153682131, 8.94065125,
      8.798434028, 8.634709266, 8.705496021, 8.899727389, 8.836483561,
      8.811959666, 8.836483561, 9.087570185, 9.538197152, 9.604850073,
      9.663718454, 9.672369428, 9.623182424, 9.606255629, 9.631398164,
      9.606255629, 9.596705824, 9.587156027, 9.577606235, 9.56805645, 9.55850667,
      9.548956897, 9.53940713, 9.529857369, 9.522437207, 9.516352984,
      9.511200414, 9.506836918, 9.503141713, 9.50001249, 9.497362588, 9.49511861,
      9.49321839, 9.491609277, 9.490246684, 9.489092849, 9.488115792,
      9.487288433, 9.486587839, 9.485994587, 9.485492234, 9.485066851,
      9.484706646, 9.484401634, 9.484143356, 9.483924654, 9.483739462,
      9.483582646, 9.483449859, 9.483337418, 9.483242207, 9.483161584,
      9.483093315, 9.483035507, 9.482986557, 9.466068803, 9.389064799,
      9.255679212, 9.227071106, 9.104643421, 9.028469978, 9.001501149,
      9.164888927, 9.092963602, 9.203815585, 9.12147051, 9.136234993,
      9.103113644, 9.083810108, 8.875865005, 8.733020841, 8.579656403,
      8.645639372, 8.839303317, 8.776278129, 8.764527599, 8.783403514,
      9.034190699, 9.484434523, 9.549267837, 9.608286376, 9.617063831,
      9.568001422, 9.544873502, 9.572680109, 9.542313337, 9.533186277,
      9.52444955, 9.514899799, 9.505350053, 9.487682201, 9.47737448, 9.468644395,
      9.459546896, 9.449997184, 9.430452703, 9.419362114, 9.39311223,
      9.327649143, 9.093457235, 8.919413173, 8.753713285, 8.536727473,
      8.398170996, 8.194141585, 8.218340795, 8.612224221, 9.17422917,
      9.704838558, 9.884069996, 9.794546766, 9.463368224, 9.284655941,
      9.05874423, 8.913943092, 8.683691329, 8.582079637, 8.419711936,
      8.429407753, 8.309334757, 8.259640337, 8.074278208, 8.120704654,
      7.937150661, 7.965103771, 7.949877401, 7.986054594, 8.198775343,
      8.952971551, 9.421516499, 9.890059088, 9.880320237, 9.736195634,
      9.68577776, 9.6666847, 9.647591694, 9.628498742, 9.609405841, 9.590312992,
      9.571220193, 9.552127445, 9.533034746, 9.513942095, 9.477956617,
      9.444654508, 9.37124555, 9.143891505, 8.887901178, 8.674348029,
      8.358599273, 8.001681837, 7.588834623, 7.154428512, 6.86171534,
      6.698751872, 6.571025542, 6.478039712, 6.562696155, 7.388576437,
      7.864650482, 8.341520993, 8.818825208, 9.289874128, 9.758429694,
      9.816200056, 9.836556433, 9.782898102, 9.768505099, 9.763687271,
      9.763687271, 9.763687271, 9.763687271, 9.763687271, 9.763687271,
      9.763687271, 9.763687271, 9.763687271, 9.763687271, 9.627878931,
      9.292664729, 9.149164362, 8.905357741, 8.705684532, 8.49152979,
      8.298657917, 7.967977582, 7.813630067, 7.62895553, 7.533964375,
      7.272612154, 7.420146229, 7.340682658, 7.26972518, 7.303940731,
      7.298569232, 7.302203568, 7.294220544, 7.295998964, 7.296321854,
      7.295738744, 8.134453153, 8.58919764, 8.986887499, 9.494676286,
      9.965781346, 9.565002563, 9.429754616, 9.282863671, 9.102774737,
      8.859490996, 8.789612361, 8.492311066, 8.538114687, 8.442909483,
      8.348154851, 8.347229391, 8.378315184, 8.329586549, 8.281556974,
      8.311191865, 8.236063668, 8.188204862, 8.138343365, 7.989321726,
      7.966374929, 7.92826862, 7.758791036, 7.84426906, 7.638462537, 7.723391035,
      7.72394688, 8.570414264, 9.046060145, 9.514614955, 9.986498259,
      9.780670184, 9.690413655, 9.690413655, 9.639562033, 9.627873128,
      9.633076041, 9.655025561, 9.646800993, 9.646800993, 9.646800993,
      9.646800993, 9.646800993, 9.646800993, 9.646800993, 9.646800993,
      9.646800993, 9.646800993, 9.646800993, 9.646800993, 9.646800993,
      9.646800993, 9.646800993, 9.646800993, 9.646800993, 9.646800993,
      9.646800993, 9.646800993, 9.646800993, 9.646800993, 9.646800993,
      9.646800993, 9.646800993, 9.646800993, 9.646800993, 9.646800993,
      9.646800993, 9.646800993, 9.629865819, 9.501793472, 9.307254809,
      9.165509325, 8.991610083, 8.968931595, 8.941423797, 8.950076772,
      8.832772706, 8.90852024, 8.834542999, 8.699162801, 8.59127642, 8.474332437,
      8.515477532, 8.388376112, 8.404357426, 8.197641791, 8.143474814,
      8.045758061, 7.984944222, 7.910279404, 7.836559217, 7.717574023,
      7.740474332, 7.574664575, 7.398871074, 7.29980249, 7.170413021,
      6.982746548, 6.867564122, 6.865661111, 6.903955641, 6.745321602,
      7.622638654, 7.285086459, 7.200022378, 7.248571088, 7.492418059,
      8.221694664, 8.580061378, 7.874135766, 8.256555545, 8.03911252,
      8.433319455, 9.131724799, 9.53608, 9.743375031, 9.742215451, 9.815236817,
      9.742648833, 9.751550423, 9.758125833, 9.763692909, 9.76840638,
      9.772397203, 9.775776225, 9.778637273, 9.781059776, 9.783110973,
      9.784847789, 9.78631842, 9.787563666, 9.788618077, 9.7895109, 9.790266901,
      9.790907051, 9.791449103, 9.791908092, 9.792296746, 9.792625844,
      9.792904512, 9.793140479, 9.793340288, 9.793509479, 9.793652745,
      9.793505425, 9.793505425, 9.793505425, 9.725560216, 9.704373184,
      9.726632997, 9.438258651, 9.361359949, 9.17186122, 9.258650258,
      9.222776511, 9.228459435, 9.235877537, 8.970273448, 8.691904886,
      8.526363878, 8.305636962, 8.448794889, 8.456843856, 8.408889071,
      8.429911139, 8.429911139, 8.429911139, 8.58396875, 8.512583097,
      8.752695692, 8.813212317, 8.73304165, 8.97440051, 8.861642473, 8.858075075,
      8.859650274, 8.777410355, 8.780863627, 8.762507414, 8.760564775,
      8.718563463, 8.687070927, 8.710454066, 8.710454066, 8.632804737,
      8.666923779, 8.585087913, 8.620994914, 8.844525846, 9.223210923,
      8.99761161, 9.223115311, 9.273575331, 9.199698618, 9.183112668,
      9.190512845, 9.190512845, 9.008107486, 8.775173135, 8.816114683,
      8.794032789, 8.823081922, 8.823081922, 8.823081922, 8.823081922,
      8.823081922, 8.94401551, 8.887382333, 8.887382333, 8.887382333,
      8.887382333, 8.821544488, 8.719085273, 8.760739442, 8.521820786,
      8.466665047, 8.375200322, 8.300012071, 8.021532339, 8.16770691,
      7.972810383, 8.013569861, 8.031169407, 8.031169407, 7.788877482,
      7.89093189, 7.649127493, 7.750443596, 7.750443596, 7.670148166,
      7.703614164, 7.618092689, 7.653673779, 7.527925313, 7.516200879,
      7.542680557, 7.542680557, 7.677566933, 7.617607647, 7.617607647,
      7.617607647, 7.617607647, 7.617607647, 7.617607647, 7.121551524,
      7.184343898, 7.100358649, 7.016369087, 7.058607277, 6.781065041,
      6.996191247, 6.952629722, 6.952629722, 6.952629722, 6.936898106,
      6.801711781, 6.843275157, 6.833912839, 6.699041973, 6.615036294,
      6.518769546, 6.54883042, 6.311937733, 6.253801865, 6.283316861,
      6.253498243, 6.23425495, 6.247956698, 6.247956698, 6.247956698,
      6.216827862, 6.197734993, 6.325317477, 6.27661631, 6.171104298,
      6.211896962, 6.196345309, 6.186795479, 6.192790554, 6.192790554,
      6.177245646, 6.167695809, 6.037937657, 5.866931701, 5.813527116,
      5.727810756, 5.749915668, 5.621086738, 5.417330378, 5.463796444,
      5.439850283, 5.322391529, 5.323947307, 5.340303089, 5.340303089,
      5.47233729, 5.568604611, 5.474960011, 5.451447919, 5.224010285,
      5.306198868, 5.106320137, 5.820221089, 5.729144823, 5.066579746,
      5.48047022, 5.435014773, 5.636664531, 6.31990638, 6.823264006, 7.302727255,
      7.778609757, 8.255368465, 8.732611943, 9.205262376, 9.673821495,
      9.986979468, 9.818372705, 9.235201063, 8.833604355, 8.366593837,
      8.090678076, 7.77000383, 7.475256028, 7.281779165, 7.457791643,
      7.166321976, 7.554709498, 7.372622777, 7.127667856, 7.239210609,
      6.915665723, 7.631718234, 7.089563505, 7.458218333, 6.955398837,
      7.13313741, 6.739838836, 6.598504968, 6.324227877, 6.499147684,
      6.209335335, 6.336105552, 7.117892662, 7.608858239, 7.880814965,
      8.445905638, 8.923275013, 9.083500731, 9.429145852, 9.565504901,
      9.70844471, 9.660553956, 9.771306492, 9.732972691, 9.716478772,
      9.734286025, 9.726031976, 9.710719638, 9.704444646, 9.699130522,
      9.686967619, 9.670724452, 9.627133428, 9.481289331, 9.352293404,
      9.300158818, 9.343348315, 9.421650015, 9.601395203, 9.464338746,
      9.414312917, 9.40349022, 9.403960475, 9.853577314, 9.721221119,
      9.688303676, 9.688303676, 9.688303676, 9.688303676, 9.688303676,
      9.688303676, 9.688303676, 9.688303676, 9.688303676, 9.688303676,
      9.688303676, 9.688303676, 9.688303676, 9.688303676, 9.688303676,
      9.688303676, 9.688303676, 9.688303676, 9.688303676, 9.688303676,
      9.688303676, 9.688303676, 9.688303676, 9.688303676, 9.688303676,
      9.688303676, 9.688303676, 9.671353875, 9.627911138, 9.52528273,
      9.248983667, 8.996066238, 8.824103953, 8.636761515, 8.638616318,
      8.437111497, 8.212162538, 8.099199772, 8.23061957, 9.075787515,
      9.544344332, 9.964622877, 9.57560469, 9.309967921, 9.054887124,
      8.803225655, 8.577574834, 8.381004522, 8.065597059, 7.965379993,
      7.722497701, 7.710390147, 7.511098793, 7.624013259, 7.516285334,
      7.813986733, 7.579048575, 7.510511341, 7.379220675, 7.269479337,
      6.999047627, 6.96003131, 6.896570596, 6.806687838, 7.696388526,
      8.173027523, 8.650207031, 9.124382182, 9.592941041, 9.887138975,
      9.927336769, 9.760971368, 9.574245218, 9.300180015, 9.151678082,
      8.983252492, 8.951512319, 8.959120801, 8.988441357, 8.988441357,
      8.988441357, 8.938938487, 8.960884037, 8.960884037, 8.978215724,
      8.987405188, 8.913266758, 8.810655189, 8.719417823, 8.777496258,
      8.75538196, 8.684626637, 8.687964049, 8.669608001, 8.615553275,
      8.476154826, 8.422915652, 8.478656002, 8.495793198, 8.480473279,
      8.715437138, 8.625082874, 8.634272356, 8.798233177, 9.383540093,
      9.455079244, 9.208418892, 8.955918673, 8.784280031, 8.570734052,
      8.461475974, 8.200695144, 8.169903665, 7.922552501, 7.917303848,
      7.779388163, 7.621582793, 7.658528894, 7.438899709, 7.461477267,
      7.255251552, 7.275375098, 7.050693857, 7.144817271, 7.139895174,
      7.056695246, 7.081683845, 7.059309909, 7.353815774, 7.213521193,
      7.049661564, 7.101763697, 7.029923523, 6.977768967, 6.843343981,
      6.810766891, 6.840141195, 6.752969779, 7.088587388, 6.905872344,
      6.927192322, 6.927192322, 6.927192322, 6.927192322, 7.759027063,
      7.83242797, 7.882141829, 8.62123037, 9.095940254, 9.5644981, 9.985539072,
      9.590599632, 9.722309209, 9.597073889, 9.237282801, 8.884621115,
      8.569664255, 8.336594853, 8.252951771, 8.120885515, 8.102222856,
      7.977339155, 7.869087468, 7.807243226, 7.699577031, 7.500209872,
      7.414785121, 7.360087949, 7.210984933, 7.312334396, 7.180003784, 7.4823801,
      7.237748835, 7.309554186, 7.771735083, 8.407849245, 8.885195946,
      9.355007747, 9.32098379, 9.289211639, 9.123866078, 9.185738308,
      9.078046455, 9.487719966, 9.823400005, 9.857639255, 9.751648535,
      9.726740671, 9.717190783, 9.707640903, 9.698091029, 9.688541162,
      9.678991302, 9.669441448, 9.659891601, 9.650341761, 9.640791927, 9.6312421,
      9.621692279, 9.612142465, 9.602592657, 9.593042855, 9.58349306, 9.57394327,
      9.564393487, 9.55484371, 9.54529394, 9.535744175, 9.526194416, 9.516644663,
      9.507094917, 9.505841681, 9.50229891, 9.499298781, 9.496758207,
      9.494606813, 9.492784997, 9.460647021, 9.306566682, 9.110356542,
      9.028995565, 8.769346746, 8.562050869, 8.436219562, 8.239079579,
      8.39737646, 8.352418384, 8.700849904, 8.890413929, 9.144569073,
      8.864269807, 8.920111608, 8.763762534, 8.73070478, 8.686814453,
      8.569428494, 8.278141273, 8.164502167, 8.05357069, 7.858645258, 7.8492192,
      7.728284457, 7.819369411, 7.636845828, 7.726847558, 7.36750074,
      7.081020689, 6.812437864, 6.488958193, 6.474132698, 6.843278051,
      7.550048122, 8.026441825, 8.131584098, 7.937500205, 7.175623769,
      7.711053141, 7.630755638, 8.467805306, 8.620796673, 8.825478343,
      9.225890701, 9.359374326, 9.793715387, 9.752335173, 9.789200449,
      9.705747386, 9.700233769, 9.695564501, 9.633838188, 9.680407476,
      9.707755031, 9.709077752, 9.700833056, 9.700833056, 9.700833056,
      9.590656066, 9.727643127, 9.73990587, 9.715177092, 9.715177092,
      9.715177092, 9.702820903, 9.70821679, 9.70821679, 9.70821679, 9.70821679,
      9.70821679, 9.70821679, 9.697755434, 9.684608432, 9.799131426, 9.749660882,
      9.716196648, 9.730823628, 9.748636196, 9.740376832, 9.740376832,
      9.551476167, 9.017292099, 8.689268095, 8.19149012, 7.889832454,
      7.456352588, 7.040224153, 6.544722488, 6.085666217, 5.61984805,
      5.183468488, 5.023459593, 0.0 };

    static const real_T tmp_0[39461] = { 5.2254, 5.225438525, 5.229422268,
      5.233406016, 5.237389767, 5.241373521, 5.24535728, 5.249341042,
      5.253324808, 5.257308578, 5.261292351, 5.265276128, 5.269259909,
      5.273243693, 5.277227481, 5.281211272, 5.285195067, 5.289178865,
      5.293162666, 5.297146471, 5.301130279, 5.305114091, 5.309097906,
      5.313081724, 5.317065546, 5.321049371, 5.325033198, 5.32901703,
      5.333000864, 5.336984701, 5.340968542, 5.344952385, 5.348936232,
      5.352920081, 5.356903934, 5.360887789, 5.364871648, 5.368855509,
      5.372839373, 5.37682324, 5.38080711, 5.384790983, 5.388774858, 5.392758736,
      5.396742617, 5.4007265, 5.404710386, 5.408694275, 5.412678166, 5.41666206,
      5.420645957, 5.424629856, 5.428613757, 5.432597661, 5.436581567,
      5.440565476, 5.444549387, 5.4485333, 5.452517216, 5.456501134, 5.460485054,
      5.464468977, 5.468452902, 5.472436829, 5.476420758, 5.480404689,
      5.484388622, 5.488372558, 5.492356495, 5.496340434, 5.500324376,
      5.504308319, 5.508292265, 5.512276212, 5.516260161, 5.520244112,
      5.524228065, 5.52821202, 5.532195976, 5.536179935, 5.540163895,
      5.544147856, 5.54813182, 5.552115785, 5.556099752, 5.56008372, 5.56406769,
      5.568051661, 5.572035634, 5.576019608, 5.580003584, 5.583987561,
      5.58797154, 5.59195552, 5.595939502, 5.599923485, 5.603825409, 5.607650175,
      5.611474941, 5.615299709, 5.619124479, 5.62294925, 5.626774022,
      5.630598795, 5.63442357, 5.638248347, 5.642073125, 5.645897905,
      5.649722686, 5.653547469, 5.657372253, 5.661197039, 5.665021827,
      5.668846616, 5.672671407, 5.6764962, 5.680320995, 5.684145791, 5.687970589,
      5.691795389, 5.695620191, 5.699444995, 5.7032698, 5.707094608, 5.710919418,
      5.714744229, 5.718569043, 5.722393858, 5.726218676, 5.730043495,
      5.733868317, 5.737693141, 5.741517967, 5.745342795, 5.749167626,
      5.752992458, 5.756817293, 5.76064213, 5.764466969, 5.768291811,
      5.772116655, 5.775941502, 5.77976635, 5.783591202, 5.787416055,
      5.791240911, 5.79506577, 5.798890631, 5.802715495, 5.806540361, 5.81036523,
      5.814190101, 5.818014975, 5.821839852, 5.825664731, 5.829489613,
      5.833314498, 5.837139385, 5.840964276, 5.844789169, 5.848614064,
      5.852438963, 5.856263865, 5.860088769, 5.863913676, 5.867738587, 5.8715635,
      5.875388416, 5.879213335, 5.883038258, 5.886863183, 5.890688111,
      5.894513043, 5.898337977, 5.902162915, 5.905987856, 5.9098128, 5.913637747,
      5.917462698, 5.921287652, 5.925112609, 5.928937569, 5.932762533, 5.9365875,
      5.94041247, 5.944237444, 5.948062421, 5.951887402, 5.955712386,
      5.959537374, 5.963362365, 5.96718736, 5.971012358, 5.97483736, 5.978662366,
      5.982487375, 5.986312387, 5.990137404, 5.993962424, 5.997787448,
      6.001612476, 6.005437507, 6.009262542, 6.013087581, 6.016912624,
      6.020737671, 6.024562721, 6.028387776, 6.032212834, 6.036037896,
      6.039862963, 6.043688033, 6.047513107, 6.051338186, 6.055163268,
      6.058988355, 6.062813446, 6.06663854, 6.070463639, 6.074288742, 6.07811385,
      6.081938961, 6.085764077, 6.089589197, 6.093414322, 6.09723945,
      6.101064583, 6.104889721, 6.108714863, 6.112540009, 6.115928911,
      6.118980178, 6.121984581, 6.124942841, 6.131183762, 6.135008935,
      6.138834112, 6.142659293, 6.14648448, 6.150309671, 6.154134866,
      6.157960066, 6.161785271, 6.165610481, 6.169435695, 6.173260915,
      6.176979136, 6.180050377, 6.183074444, 6.186052063, 6.18898395,
      6.191870809, 6.194713331, 6.202606773, 6.206432035, 6.210257301,
      6.214082573, 6.217907849, 6.221733131, 6.225558417, 6.229383709,
      6.233209006, 6.237034308, 6.240485923, 6.243539411, 6.246545997,
      6.249506401, 6.252421337, 6.255291502, 6.258117586, 6.260900267,
      6.263640214, 6.266338084, 6.276306822, 6.280132183, 6.28395755,
      6.287782922, 6.2916083, 6.295433683, 6.299259072, 6.302746941, 6.305801817,
      6.308809767, 6.311771513, 6.314687767, 6.317559227, 6.320386585,
      6.323170519, 6.325911697, 6.328610777, 6.331268407, 6.333885224,
      6.336461857, 6.338998923, 6.341497032, 6.343956783, 6.346378766,
      6.348763562, 6.351111742, 6.353423871, 6.355700501, 6.357942181,
      6.337766555, 6.338722139, 6.337199513, 6.328196249, 6.328196249,
      6.328196249, 6.328196249, 6.328196249, 6.328196249, 6.328196249,
      6.328196249, 6.328196249, 6.328196249, 6.328196249, 6.328196249,
      6.328196249, 6.328196249, 6.328196249, 6.328196249, 6.328196249,
      6.328196249, 6.328196249, 6.328196249, 6.328196249, 6.328196249,
      6.328196249, 6.328196249, 6.328196249, 6.328196249, 6.328196249,
      6.328196249, 6.328196249, 6.328196249, 6.328196249, 6.328196249,
      6.328196249, 6.328196249, 6.328196249, 6.328196249, 6.328196249,
      6.328196249, 6.328196249, 6.328196249, 6.328196249, 6.328196249,
      6.328196249, 6.328196249, 6.328196249, 6.328196249, 6.328196249,
      6.328196249, 6.328196249, 6.328196249, 6.328196249, 6.328196249,
      6.328196249, 6.328196249, 6.328196249, 6.328196249, 6.328196249,
      6.450632633, 6.460212302, 6.469792066, 6.479371925, 6.488951879,
      6.498531931, 6.50811208, 6.517692328, 6.527272676, 6.536853123,
      6.460539904, 6.463408332, 6.466276763, 6.469145196, 6.472013633,
      6.474882072, 6.477471342, 6.479757973, 6.482009495, 6.484226449,
      6.572360288, 6.579904013, 6.581177948, 6.589758548, 6.598210567,
      6.606662664, 6.615114838, 6.623567089, 6.632019416, 6.640471818,
      6.567748008, 6.569543553, 6.571311536, 6.573052382, 6.574766508,
      6.576454325, 6.578116236, 6.579752641, 6.581363931, 6.582950492,
      6.609115815, 6.612153716, 6.615144932, 6.618090182, 6.620990173,
      6.623845602, 6.630401013, 6.634152031, 6.637903055, 6.641654085,
      6.626328074, 6.628162696, 6.629969155, 6.631747884, 6.633499309,
      6.63522385, 6.636921921, 6.638593928, 6.640240271, 6.641861347,
      6.643457542, 6.645029239, 6.658452439, 6.661143827, 6.66338243,
      6.665586654, 6.667757028, 6.669894074, 6.671998303, 6.67407022,
      6.643024729, 6.643024729, 6.643024729, 6.643024729, 6.643024729,
      6.643024729, 6.643024729, 6.643024729, 6.643024729, 6.643024729,
      6.643024729, 6.643024729, 6.643024729, 6.643024729, 6.643024729,
      6.643024729, 6.643024729, 6.643024729, 6.643024729, 6.643024729,
      6.643024729, 6.643024729, 6.643024729, 6.643024729, 6.643024729,
      6.643024729, 6.643024729, 6.643024729, 6.643024729, 6.643024729,
      6.66378253, 6.665042338, 6.666282817, 6.667504264, 6.668706971,
      6.669891227, 6.671057314, 6.672205512, 6.673336096, 6.674449336,
      6.818073345, 6.830299639, 6.842526134, 6.854752827, 6.866979717,
      6.879206802, 6.891434078, 6.891900978, 6.902630447, 6.913913962,
      6.819994593, 6.822610028, 6.825185277, 6.831901902, 6.842845953,
      6.846049714, 6.84920422, 6.852310228, 6.855368488, 6.858379735,
      6.848961419, 6.851131862, 6.863355527, 6.865380921, 6.867344007,
      6.869246708, 6.871090888, 6.872878352, 6.88074057, 6.883361868,
      6.885942887, 6.892780825, 6.894841218, 6.896838219, 6.898773786,
      6.900649816, 6.902468145, 6.904230555, 6.91834095, 6.920555297,
      7.124517737, 7.143377248, 7.162237348, 7.1804263, 7.187477911, 7.205390433,
      7.223303421, 7.241216868, 7.252601201, 7.264089487, 7.680008348,
      7.727670924, 7.762840014, 7.784511775, 7.816752054, 7.84801293,
      7.865729787, 7.894065863, 7.921424074, 7.935196141, 7.85865634,
      7.874438805, 7.890351922, 7.911492166, 7.929354589, 7.942229782,
      7.954140711, 7.965563786, 7.983606807, 7.997472976, 7.993772161,
      8.000875601, 8.0197519, 8.025889899, 8.031070483, 8.041063398, 8.051748118,
      8.055010749, 8.057319065, 8.071449835, 8.034455963, 8.044802573,
      8.042360005, 8.051762409, 8.048368322, 8.056827229, 8.052483058,
      8.059999183, 8.05470637, 8.061280432, 7.990970057, 7.991907012,
      7.992843967, 7.993780922, 7.994717877, 7.995654832, 7.996591787,
      7.984712104, 7.984712104, 7.984712104, 7.984712104, 7.984712104,
      7.984712104, 7.984712104, 7.984712104, 7.984712104, 7.984712104,
      7.984712104, 7.984712104, 7.984712104, 8.048795296, 8.053487402,
      8.045359206, 8.049111427, 8.040040411, 8.042853478, 8.032841107,
      8.034715752, 8.023763491, 8.024700447, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.012809763, 8.012809763, 8.012809763, 8.012809763, 8.012809763,
      8.004122698, 8.003575681, 7.991078639, 8.009863262, 8.009863262,
      8.001753567, 8.001242824, 7.988782753, 7.979976519, 7.973875125,
      7.965254186, 7.951528372, 7.942649232, 7.982561411, 7.974582268,
      7.969398892, 7.968433128, 7.95554941, 7.954073018, 7.943302414,
      7.938864729, 7.926427919, 7.922679523, 7.920341322, 7.906136681,
      7.903371543, 7.888756813, 7.877255247, 7.870194348, 7.860580526,
      7.851025976, 7.835228111, 7.828652581, 7.897222015, 7.885480586, 7.8840162,
      7.88309853, 7.881968169, 7.86978913, 7.868706116, 7.867672612, 7.866686369,
      7.856566968, 7.847318153, 7.847234612, 7.839813174, 7.84040207,
      7.834882065, 7.836096716, 7.832356429, 7.829820753, 7.828430175,
      7.828062027, 7.859361331, 7.859361331, 7.859361331, 7.859361331,
      7.859361331, 7.859361331, 7.859361331, 7.859361331, 7.859361331,
      7.859361331, 8.140252035, 8.161033214, 8.17043528, 8.188963885,
      8.208793389, 8.228623066, 8.248452908, 8.268282911, 8.288113068,
      8.295105718, 8.686489611, 8.720403035, 8.766208658, 8.799117083,
      8.831037496, 8.861970724, 8.90467717, 8.933806367, 8.961968032,
      8.991633953, 9.132616234, 9.179472638, 9.226329072, 9.27318542,
      9.320041566, 9.366897399, 9.413752808, 9.460607682, 9.50746191,
      9.554315382, 9.601167983, 9.648019596, 9.668415611, 9.686865757,
      9.703374629, 9.717946827, 9.730586956, 9.741299622, 9.751200464,
      9.759358011, 9.524944041, 9.538389838, 9.538459604, 9.550940171,
      9.563420696, 9.562511037, 9.574027093, 9.572144274, 9.582696612,
      9.579842119, 9.317087731, 9.301694975, 9.280490396, 9.259047863,
      9.246688258, 9.221782863, 9.203242472, 9.182240185, 9.155877216,
      9.140297533, 9.137622925, 9.120282468, 9.096381596, 9.081188486,
      9.053554045, 9.034767774, 9.009850049, 8.993410716, 8.971434457,
      8.945685779, 8.930254133, 8.905734904, 8.882660157, 8.86443589,
      8.837945578, 8.814978893, 8.783457525, 8.763428864, 8.739025695,
      8.710681113, 8.751559629, 8.730419199, 8.70603794, 8.688721233,
      8.665007179, 8.650908682, 8.624703452, 8.605630186, 8.583555776,
      8.556611499, 8.529130808, 8.505470896, 8.485313462, 8.457155031,
      8.432528442, 8.411606318, 8.383080743, 8.356971699, 8.336473356,
      8.307011817, 8.376518772, 8.362365487, 8.350117081, 8.330450709,
      8.313546409, 8.299342689, 8.276637853, 8.263876308, 8.239860845,
      8.226105385, 8.21320282, 8.188371488, 8.17513549, 8.149990155, 8.136430657,
      8.123074958, 8.097511433, 8.083498815, 8.057616811, 8.043285846,
      8.161879786, 8.144067706, 8.137659112, 8.13134784, 8.125132423,
      8.119011419, 8.112983403, 8.107046976, 8.092938812, 8.082894612,
      8.028362214, 8.019076367, 8.009930951, 7.990537721, 7.979395769,
      7.969926223, 7.960599837, 7.950265392, 7.93030574, 7.920654375,
      7.959069403, 7.952685683, 7.943316866, 7.938495145, 7.921858681,
      7.916756244, 7.911813356, 7.902229026, 7.895780266, 7.885393827,
      7.787361387, 7.775256212, 7.754837753, 7.745568051, 7.724657346,
      7.714954202, 7.694447247, 7.67882575, 7.663948397, 7.642768975,
      7.775732206, 7.773215378, 7.770775215, 7.768409395, 7.760815323,
      7.759126464, 7.75751458, 7.755976192, 7.744995943, 7.740931255,
      7.632469641, 7.615519289, 7.610271353, 7.593413178, 7.58528286,
      7.571371882, 7.556229781, 7.541640058, 7.52701522, 7.515019255,
      7.615784975, 7.603669395, 7.60352469, 7.603389822, 7.603264222,
      7.603147339, 7.595487314, 7.596061148, 7.596581279, 7.591400649,
      7.592506214, 7.593492376, 7.590351839, 7.591741917, 7.589866489,
      7.588828707, 7.590798158, 7.590552933, 7.589247921, 7.590450254,
      7.619528426, 7.620465371, 7.621402317, 7.622339263, 7.623276208,
      7.624213154, 7.6251501, 7.626087046, 7.627023991, 7.627960937, 7.793661302,
      7.806843609, 7.820025995, 7.836211599, 7.846613853, 7.859796472,
      7.884950285, 7.914751964, 7.902284505, 7.915467432, 8.386772561,
      8.43450647, 8.482243313, 8.529982894, 8.577725014, 8.625469474,
      8.673216071, 8.720964601, 8.768714859, 8.816466637, 8.864219727,
      8.911973919, 8.959680418, 9.006535615, 9.053391319, 9.100247392,
      9.147103703, 9.193960129, 9.240816549, 9.287672846, 9.334528908,
      9.381384621, 9.428239877, 9.475094563, 9.52194857, 9.568801784,
      9.615654092, 9.662505376, 9.709355513, 9.756204377, 9.803051837, 9.8366097,
      9.830124151, 9.832720685, 9.83341913, 9.831119328, 9.820217288,
      9.803765326, 9.791556888, 9.776394147, 9.637475986, 9.634600718,
      9.63075893, 9.625951715, 9.620180165, 9.613445368, 9.605748412,
      9.597090378, 9.587472351, 9.576895409, 9.539311437, 9.538356461,
      9.537401484, 9.536446509, 9.535491533, 9.534536557, 9.533581581,
      9.520026676, 9.518117414, 9.516208153, 9.514298892, 9.512389632,
      9.510480372, 9.508571113, 9.506661854, 9.504752595, 9.502843337,
      9.50093408, 9.499024823, 9.497115566, 9.49520631, 9.493297054, 9.491387799,
      9.489478545, 9.48756929, 9.485660037, 9.483750783, 9.481841531,
      9.479932278, 9.478023026, 9.476113775, 9.474204524, 9.472295273,
      9.470386023, 9.468476774, 9.466567525, 9.464658276, 9.462749028,
      9.46083978, 9.458930533, 9.457021286, 9.45511204, 9.453202794, 9.451293548,
      9.449384303, 9.447475059, 9.445565815, 9.443656571, 9.441747328,
      9.439838085, 9.437928843, 9.436019601, 9.43411036, 9.432201119,
      9.430291878, 9.428382638, 9.426473399, 9.424564159, 9.422654921,
      9.420745683, 9.418836445, 9.416927207, 9.415017971, 9.413108734,
      9.411199498, 9.409290263, 9.407381027, 9.405471793, 9.403562559,
      9.401653325, 9.399744091, 9.397834858, 9.395925626, 9.394016394,
      9.392107162, 9.390197931, 9.388288701, 9.38637947, 9.38447024, 9.382561011,
      9.380651782, 9.378742554, 9.376833325, 9.374924098, 9.373014871,
      9.371105644, 9.369196417, 9.367287191, 9.365377966, 9.363468741,
      9.361559516, 9.359650292, 9.357741068, 9.355831845, 9.353922622, 9.3520134,
      9.350104177, 9.348194956, 9.346285735, 9.344376514, 9.32993247,
      9.327069706, 9.324206944, 9.321344183, 9.318481423, 9.315618665,
      9.301771496, 9.296529463, 9.292713884, 9.288898308, 9.285082736,
      9.281267167, 9.277451602, 9.27363604, 9.269820481, 9.266004925,
      9.262189373, 9.258373824, 9.254558278, 9.250742736, 9.221910313,
      9.217083966, 9.210540371, 9.204821401, 9.190928739, 9.185862292,
      9.180905909, 9.16815314, 9.161740807, 9.153605561, 9.086455976,
      9.064955542, 9.051284466, 9.026951457, 9.011245296, 8.988515123,
      8.965228537, 8.941394701, 8.917022622, 8.89212115, 8.876003485,
      8.847183234, 8.82759921, 8.799987183, 8.769380531, 8.747031113,
      8.718524432, 8.691110808, 8.662470587, 8.632075936, 8.64724885,
      8.625592513, 8.597969222, 8.569870271, 8.543761988, 8.522837212,
      8.495832662, 8.466607833, 8.436933655, 8.406817479, 8.36398108,
      8.332330009, 8.300231994, 8.26773147, 8.234835006, 8.201549059, 8.16787998,
      8.133834014, 8.099417303, 8.064635886, 8.017366779, 7.981167365,
      7.944632098, 7.907382149, 7.86955846, 7.819338005, 7.780140884, 7.74063721,
      7.700831708, 7.660728998, 7.620333593, 7.579649905, 7.526722715,
      7.484754865, 7.442522576, 7.400029638, 7.345387924, 7.301665059,
      7.25770339, 7.210987125, 7.168919417, 7.124262507, 7.079379006,
      7.028736409, 6.976847875, 6.930001207, 6.880239461, 6.825478635,
      6.777892596, 6.730119834, 6.817704811, 6.773111677, 6.739669282,
      6.701636614, 6.661256248, 6.620681575, 6.582042603, 6.536449777,
      6.501951192, 6.456509871, 6.566833387, 6.543107441, 6.51013282,
      6.487306822, 6.460167145, 6.430400303, 6.407522839, 6.37334131,
      6.350303197, 6.322496932, 6.407078214, 6.391292076, 6.370868018,
      6.358377723, 6.336431291, 6.327244999, 6.30661104, 6.297364041,
      6.279910097, 6.268490594, 6.308342532, 6.305603264, 6.300833326,
      6.310186949, 6.309311346, 6.31624808, 6.327862846, 6.344313723,
      6.356899401, 6.364662016, 6.378945271, 6.378917923, 6.378890994,
      6.378864478, 6.379210295, 6.379210295, 6.379210295, 6.379210295,
      6.379210295, 6.379210295, 6.992104358, 7.040549833, 7.088671945,
      7.136206841, 7.183754711, 7.231315057, 7.278887391, 7.326471232,
      7.374066109, 7.421671554, 7.469287107, 7.516912313, 7.564546724,
      7.612189895, 7.659841384, 7.707500756, 7.755167575, 7.802841411,
      7.850521833, 7.898208414, 7.945900726, 7.993598341, 8.041300834,
      8.08900783, 8.136719118, 8.184434519, 8.23215385, 8.279876926, 8.327603559,
      8.37533356, 8.423066736, 8.470802893, 8.518541836, 8.566283366,
      8.614027284, 8.661773387, 8.709521472, 8.757271335, 8.805022767,
      8.852775562, 8.900529509, 8.948284398, 8.995306688, 9.042162283,
      9.08901828, 9.135874545, 9.182730955, 9.229587387, 9.276443724,
      9.323299853, 9.37015566, 9.417011035, 9.463865867, 9.510720047,
      9.557573462, 9.604425998, 9.651277537, 9.698127961, 9.744977142,
      9.791824951, 9.679267332, 9.701404761, 9.720595616, 9.734640554,
      9.750479204, 9.769034255, 9.773219331, 9.788816014, 9.801737665,
      9.809509551, 9.788769926, 9.797505014, 9.805260371, 9.812037138,
      9.814123374, 9.814817983, 9.814523806, 9.826727388, 9.825265882,
      9.822852729, 9.721776149, 9.726561654, 9.731347155, 9.722642101,
      9.726469074, 9.730296045, 9.73187394, 9.734748487, 9.727904322,
      9.730773479, 9.733642635, 9.73651179, 9.739380945, 9.728747254,
      9.730659313, 9.732571373, 9.734483431, 9.72288981, 9.723845484,
      9.724801159, 9.725756834, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.713205411, 9.713205411, 9.713205411, 9.713205411, 9.713205411,
      9.691722644, 9.673607247, 9.650175195, 9.628361191, 9.604138204,
      9.577571645, 9.531054101, 9.494348827, 9.468400177, 9.428876131,
      9.396047702, 9.357467476, 9.316620786, 9.280056851, 9.233064441,
      9.196804887, 9.310617421, 9.283787809, 9.268591985, 9.240829475,
      9.212129416, 9.194914578, 9.165407738, 9.134842757, 9.103343759,
      9.083438927, 9.082395721, 9.05513417, 9.027352494, 8.999097004,
      8.974034031, 8.942811462, 8.920694921, 8.887313451, 8.855195446,
      8.830462262, 8.857407157, 8.829077015, 8.806073317, 8.785161771,
      8.75356288, 8.727921896, 8.698986677, 8.677156792, 8.642975145,
      8.620246377, 8.628097358, 8.601694698, 8.580768507, 8.554049627,
      8.524825001, 8.495150872, 8.469485984, 8.446762239, 8.416727603,
      8.388524108, 8.416243128, 8.394021754, 8.372357685, 8.344145047,
      8.320911345, 8.29884993, 8.269971665, 8.245217921, 8.223299528,
      8.193788414, 8.115235231, 8.082000893, 8.04838291, 8.014387536,
      7.980020919, 7.944963058, 7.914708841, 7.885152964, 7.849959926,
      7.81356668, 7.90342503, 7.880753379, 7.851566499, 7.833915964, 7.804535124,
      7.782683968, 7.756858309, 7.72683244, 7.708306945, 7.678113616,
      7.704550945, 7.679560619, 7.663567558, 7.635906127, 7.619651235,
      7.591749468, 7.572937841, 7.546961271, 7.530207087, 7.50184943,
      7.567766628, 7.544367515, 7.532238126, 7.520291278, 7.496705417,
      7.484372803, 7.472225721, 7.448462198, 7.435935053, 7.411810397,
      7.316461351, 7.286809671, 7.268456573, 7.238626718, 7.220078649,
      7.190076083, 7.159617619, 7.140421063, 7.109809066, 7.090441246,
      7.350236669, 7.339075263, 7.337481147, 7.335911407, 7.334365669,
      7.333074857, 7.331941759, 7.330843298, 7.329778419, 7.328746098,
      7.281050511, 7.274880541, 7.270534536, 7.266254733, 7.256306236,
      7.252854678, 7.249508082, 7.246263283, 7.233108503, 7.228467636,
      7.212774986, 7.198901955, 7.192787311, 7.188479808, 7.184303053,
      7.175594653, 7.164459809, 7.160084372, 7.144212162, 7.143935839,
      7.195384989, 7.19439529, 7.19345089, 7.192549724, 7.191689821, 7.190869299,
      7.19008636, 7.18933929, 7.18862645, 7.187946277, 7.187297279, 7.18098874,
      7.180549957, 7.180137906, 7.17975097, 7.179387625, 7.17904644, 7.17872607,
      7.178425251, 7.174714128, 7.190474587, 7.190474587, 7.190474587,
      7.190474587, 7.190474587, 7.190474587, 7.190474587, 7.190474587,
      7.190474587, 7.190474587, 7.174645443, 7.174581908, 7.174523147,
      7.174468807, 7.174418561, 7.172247296, 7.172391174, 7.172521752,
      7.171049431, 7.171345602, 7.176681123, 7.176549077, 7.176423098,
      7.176302907, 7.176188239, 7.176078839, 7.175974465, 7.174962963,
      7.174892195, 7.174825761, 7.176271974, 7.176196463, 7.176123266,
      7.176052312, 7.175983532, 7.175916859, 7.175852229, 7.17578958, 7.17572885,
      7.175669981, 7.171745287, 7.17202978, 7.1718644, 7.171814525, 7.171861438,
      7.17198342, 7.171968987, 7.17210063, 7.17211493, 7.172294784, 7.799505218,
      7.847185194, 7.894871357, 7.942563282, 7.99026054, 8.037962706,
      8.085669394, 8.133380388, 8.181095507, 8.228814569, 8.213116988,
      8.24328965, 8.285196365, 8.403496958, 8.445247476, 8.485753546,
      8.532521325, 8.56994501, 8.612545396, 8.655713888, 8.691902476,
      8.735991756, 8.775943409, 8.812392423, 8.856258181, 8.893616092,
      8.929877318, 8.971963925, 9.00653196, 9.042596013, 9.161831645,
      9.208688082, 9.255544476, 9.302400711, 9.349256675, 9.396112256,
      9.442967345, 9.489821829, 9.536675599, 9.583528541, 9.63038054,
      9.677231477, 9.724081228, 9.770929665, 9.817776655, 9.864622055,
      9.91184834, 9.960527262, 9.989831963, 9.998340632, 9.430855209,
      9.430855209, 9.430855209, 9.430855209, 9.430855209, 9.430855209,
      9.430855209, 9.430855209, 9.430855209, 9.430855209, 9.340835541,
      9.335384805, 9.329391672, 9.312142412, 9.3061796, 9.295344716, 9.287724796,
      9.280104903, 9.272485038, 9.2648652, 9.194589957, 9.182230966, 9.169872091,
      9.152582893, 9.142419642, 9.119902669, 9.106443429, 9.09313954,
      9.080267149, 9.065873286, 9.030737736, 9.0151192, 9.000515094, 8.985911186,
      8.971307475, 8.948152453, 8.936103757, 8.91405289, 8.898543552,
      8.883034441, 8.81791018, 8.797829603, 8.770246659, 8.747394822,
      8.727367018, 8.707339686, 8.682255174, 8.654566862, 8.633639357,
      8.612712375, 8.702673216, 8.689887692, 8.677102283, 8.66431699,
      8.651531811, 8.638746748, 8.625961798, 8.606948859, 8.596433181,
      8.574612308, 8.440266979, 8.41568165, 8.392959414, 8.37023781, 8.343772295,
      8.313296472, 8.288756048, 8.263639084, 8.232602838, 8.204960527,
      8.411601532, 8.404278281, 8.39695505, 8.389631839, 8.377336529,
      8.371205776, 8.365168144, 8.35922223, 8.352218576, 8.335394029, 8.30045523,
      8.290399227, 8.276570495, 8.268332225, 8.259821054, 8.261876579,
      8.252730972, 8.237628563, 8.229980176, 8.2224477, 8.214994323, 8.195413671,
      8.187299297, 8.179307874, 8.171437559, 8.154180742, 8.14392732,
      8.135171788, 8.123536275, 8.113282972, 8.175367533, 8.170694762,
      8.163383593, 8.159470345, 8.155616731, 8.151613014, 8.146940259,
      8.142267507, 8.137594758, 8.132922012, 8.188428074, 8.188428074,
      8.188428074, 8.188428074, 8.188428074, 8.188428074, 8.188428074,
      8.188428074, 8.188428074, 8.188428074, 8.145104274, 8.142401994,
      8.139740965, 8.130342572, 8.126602751, 8.12286293, 8.119123111,
      8.115383293, 8.111643477, 8.107903661, 8.092052512, 8.08746404, 8.08279132,
      8.068776164, 8.064441932, 8.060173706, 8.055970488, 8.051831294,
      8.047755153, 8.043741112, 8.102006385, 8.102006385, 8.102006385,
      8.102006385, 8.102006385, 8.102006385, 8.102006385, 8.102006385,
      8.102006385, 8.102006385, 8.039788228, 8.035895576, 8.032062242,
      8.027699131, 8.012543409, 8.008134718, 8.00379316, 7.999517718,
      7.995307392, 7.991161195, 7.987078157, 7.983057321, 7.979097745, 7.9751985,
      7.959796067, 7.954886783, 7.950425308, 7.946031763, 7.94170512,
      7.937444366, 7.933248505, 7.929116553, 7.925047543, 7.921040522,
      7.905150429, 7.900515594, 7.89595131, 7.891456509, 7.887030142,
      7.882671173, 7.806801534, 7.792766025, 7.777262276, 7.768076255,
      7.759029128, 7.741674465, 7.728911699, 7.719532415, 7.710294901,
      7.70119704, 7.763516369, 7.751090804, 7.747464277, 7.737878651,
      7.732998683, 7.728192971, 7.723460392, 7.717612054, 7.714074092,
      7.709612434, 7.719122524, 7.716468191, 7.713894686, 7.711399564,
      7.697132924, 7.694217635, 7.691391066, 7.688650535, 7.685993441,
      7.683417262, 7.584857653, 7.568238951, 7.560101845, 7.546623363,
      7.53400316, 7.524976638, 7.508327008, 7.494301553, 7.486436346,
      7.477137857, 7.612561276, 7.612561276, 7.612561276, 7.612561276,
      7.612561276, 7.612561276, 7.612561276, 7.612561276, 7.612561276,
      7.612561276, 7.462741818, 7.44849452, 7.436341267, 7.435957293,
      7.419070281, 7.409168642, 7.399244272, 7.39262984, 7.395800519,
      7.398801484, 7.471999645, 7.472798122, 7.470210128, 7.471341333,
      7.469792993, 7.468932462, 7.468686922, 7.468955991, 7.469623457,
      7.47056884, 7.479590617, 7.479577883, 7.479566118, 7.47955525, 7.47954521,
      7.479535935, 7.479527368, 7.479519454, 7.479512144, 7.479505393,
      8.112429667, 8.160142997, 8.20786035, 8.255581543, 8.303306388,
      8.351034699, 8.398766282, 8.446500946, 8.494238496, 8.541978734,
      8.589721461, 8.637466477, 8.685213579, 8.732962562, 8.780713221,
      8.828465349, 8.876218736, 8.923973172, 8.971453577, 9.018308916,
      9.065164725, 9.11202087, 9.158877221, 9.205733657, 9.252590057,
      9.299446306, 9.34630229, 9.393157899, 9.440013021, 9.486867548,
      9.533721366, 9.580574363, 9.627426425, 9.674277432, 9.721127262,
      9.767975786, 9.814822871, 9.861668376, 9.908778938, 9.957457984,
      9.845745314, 9.842433675, 9.836137491, 9.826866936, 9.814632129,
      9.799443127, 9.78130993, 9.760242474, 9.736250642, 9.709344259,
      9.612261296, 9.615130484, 9.604543158, 9.606455233, 9.59490936,
      9.582406733, 9.582406733, 9.582406733, 9.582406733, 9.574851379,
      9.581834497, 9.581834497, 9.581834497, 9.581834497, 9.581834497,
      9.581834497, 9.581834497, 9.581834497, 9.581834497, 9.581834497,
      9.561781941, 9.555090611, 9.553181341, 9.55127207, 9.543391453,
      9.534391846, 9.531528973, 9.524333092, 9.521788536, 9.509728004,
      9.531120085, 9.527319581, 9.525682369, 9.524070197, 9.522482683,
      9.520919449, 9.51925797, 9.517348708, 9.515439447, 9.502212935,
      9.535956481, 9.535956481, 9.535956481, 9.535956481, 9.535956481,
      9.535956481, 9.535956481, 9.535956481, 9.535956481, 9.535956481,
      9.616601593, 9.608903448, 9.613689034, 9.605028015, 9.608855043,
      9.599232594, 9.602101786, 9.591519349, 9.579979079, 9.580934759,
      9.568437375, 9.568437375, 9.568437375, 9.568437375, 9.568437375,
      9.568437375, 9.568437375, 9.568437375, 9.563710073, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.568079191, 9.568079191, 9.568079191, 9.568079191, 9.568079191,
      9.555471033, 9.554516056, 9.553561079, 9.552606102, 9.551651125,
      9.550696148, 9.549741171, 9.545484367, 9.534975761, 9.533066496,
      9.505949343, 9.489531, 9.484763008, 9.467395901, 9.461676399, 9.44336193,
      9.428183539, 9.416787628, 9.39658012, 9.388010355, 9.35427888, 9.343812493,
      9.320772973, 9.296790446, 9.284430468, 9.259510715, 9.233650188,
      9.219399694, 9.192604995, 9.16487181, 9.198864709, 9.186505678,
      9.174146763, 9.155994364, 9.136475352, 9.123171147, 9.099520598,
      9.083278268, 9.069414138, 9.043247451, 9.028642959, 9.014038668,
      8.986982635, 8.971472204, 8.955962009, 8.928018744, 8.911603292,
      8.894294233, 8.866294166, 8.848974636, 8.94324953, 8.934100874,
      8.924952263, 8.915803697, 8.906655176, 8.897506699, 8.888358267,
      8.87747546, 8.857751877, 8.849788045, 8.887072796, 8.880661161,
      8.874249541, 8.867837936, 8.858688252, 8.853440629, 8.848272842,
      8.841885006, 8.825755405, 8.820097059, 8.876195897, 8.874337387,
      8.872507281, 8.870705147, 8.868930559, 8.867183095, 8.865462343,
      8.863767896, 8.862099351, 8.860456315, 8.787176349, 8.779073942,
      8.772469934, 8.765145665, 8.757821418, 8.743457821, 8.737228384,
      8.731093587, 8.715012661, 8.706776452, 8.822317894, 8.823236842,
      8.824155789, 8.825074737, 8.825993684, 8.826912632, 8.827831579,
      8.828750527, 8.829669474, 8.830588422, 8.74458327, 8.739463152, 8.73511792,
      8.73083887, 8.726624999, 8.72247532, 8.71838886, 8.714364661, 8.702514743,
      8.697017129, 8.630144545, 8.620086818, 8.610029146, 8.599971528,
      8.589913965, 8.579856455, 8.567808189, 8.559593003, 8.549535656,
      8.531471045, 8.516590763, 8.502054564, 8.493124567, 8.472111844,
      8.462728311, 8.447691063, 8.43581586, 8.423940742, 8.412065712,
      8.400190767, 8.388315909, 8.376441137, 8.362973574, 8.352572314,
      8.331814188, 8.32183408, 8.303655965, 8.290873883, 8.278091906,
      8.265310035, 8.380425319, 8.377898561, 8.375410378, 8.372960184,
      8.370547402, 8.368171461, 8.365831801, 8.363527871, 8.361259125,
      8.35902503, 8.272016119, 8.264754968, 8.257603922, 8.24462559, 8.235480053,
      8.226334554, 8.217189092, 8.207867074, 8.198541573, 8.189216108,
      8.259201446, 8.256623539, 8.246020003, 8.242280129, 8.238540257,
      8.234800387, 8.231060519, 8.227320654, 8.224006765, 8.221033129,
      8.095535618, 8.074907783, 8.063995714, 8.04342309, 8.030009473,
      8.018852889, 8.001848988, 7.987892033, 7.973935143, 7.959978311,
      7.999091067, 7.991173346, 7.974482759, 7.964229842, 7.954914336,
      7.946739959, 7.93377289, 7.923520021, 7.913267161, 7.903014307,
      7.881808733, 7.86969616, 7.858516162, 7.847336164, 7.836156164, 7.82497616,
      7.813796148, 7.802616128, 7.791436097, 7.777134435, 7.815609442,
      7.808955541, 7.791632688, 7.785006966, 7.778481805, 7.772055694,
      7.765727144, 7.759494686, 7.742023007, 7.734712353, 7.728022734,
      7.721434636, 7.714946533, 7.708556922, 7.702264322, 7.685632312,
      7.677444185, 7.670695918, 7.664050053, 7.657505052, 7.651059397,
      7.636600638, 7.628204218, 7.619807776, 7.61257888, 7.605887209, 7.59929709,
      7.592806998, 7.578949232, 7.570552642, 7.526729059, 7.516628672,
      7.507685502, 7.493526404, 7.482345169, 7.469059617, 7.459911035,
      7.448642137, 7.437460585, 7.421096863, 7.497012457, 7.492339457,
      7.487666451, 7.482758705, 7.478971101, 7.475241227, 7.471568211,
      7.467951188, 7.464389311, 7.460881743, 7.357690889, 7.341985295,
      7.331984318, 7.320982751, 7.30063842, 7.290338117, 7.280193288,
      7.270201626, 7.248660854, 7.23822165, 7.192872031, 7.171248166,
      7.156056564, 7.143324918, 7.13078476, 7.106776036, 7.093865004,
      7.081148145, 7.056984641, 7.043901931, 7.065890794, 7.043820235,
      7.032779143, 7.02190465, 7.011194292, 6.991573275, 6.97807368, 6.967101508,
      6.956294952, 6.935232472, 6.922918597, 6.911855555, 6.898335484,
      6.878501243, 6.867185309, 6.856040149, 6.841298781, 6.822471859,
      6.811078291, 6.79985668, 6.742733152, 6.727290156, 6.705234751,
      6.694428685, 6.672454804, 6.650304416, 6.639243179, 6.617110326,
      6.606195898, 6.584150161, 6.607661563, 6.587419732, 6.578313346,
      6.55804557, 6.548903118, 6.528611278, 6.517676516, 6.499030948,
      6.482130785, 6.469100045, 6.560325702, 6.557633684, 6.555064122,
      6.542382049, 6.540824205, 6.539360148, 6.533581676, 6.525218163,
      6.52377365, 6.518517141, 6.578171431, 6.578171431, 6.578171431,
      6.578171431, 6.578171431, 6.578171431, 6.578171431, 6.578171431,
      6.578171431, 6.578171431, 6.469752177, 6.459449889, 6.450045097,
      6.445265419, 6.451166737, 6.443821645, 6.440324074, 6.440871057,
      6.443345206, 6.451226746, 7.117401175, 7.164943972, 7.212499442,
      7.260067091, 7.307646438, 7.355237005, 7.402838325, 7.450449933,
      7.498071375, 7.545702198, 6.971473204, 6.971473204, 6.971473204,
      6.975332198, 6.975563697, 6.975791648, 6.984769384, 6.985706299,
      6.986643214, 6.987580128, 6.757083579, 6.739419053, 6.721754225,
      6.707828788, 6.69579842, 6.669793801, 6.652127842, 6.655016824,
      6.654221049, 6.63868353, 6.819005445, 6.819942347, 6.820879248, 6.82181615,
      6.822753051, 6.823689953, 6.824626855, 6.825563757, 6.826500659,
      6.827437561, 7.02471514, 7.037390059, 7.049868443, 7.062153354,
      7.076176497, 7.091243656, 7.106311117, 7.121378876, 7.136446929,
      7.15151527, 7.589408938, 7.637056504, 7.684712162, 7.732375474,
      7.780046008, 7.827723335, 7.875407024, 7.923096649, 7.970791782,
      8.018491996, 8.062566873, 8.101007954, 8.137630587, 8.17425019,
      8.213662794, 8.245953029, 8.289637937, 8.320759178, 8.362542917,
      8.393679891, 7.576118148, 7.552959037, 7.517922031, 7.49384654,
      7.475203833, 7.452111987, 7.422510304, 7.422850092, 7.407542037,
      7.347455758, 7.814222688, 7.827405118, 7.840587626, 7.853770211,
      7.866952871, 7.880135605, 7.893318412, 7.906501291, 7.91968424, 7.93286726,
      7.664172298, 7.66378391, 7.666511178, 7.668941089, 7.671106521,
      7.673036624, 7.674757263, 7.676291402, 7.675910286, 7.66455407,
      7.992810888, 8.013590292, 8.034369968, 8.055149909, 8.073731996,
      8.083796678, 8.103625162, 8.123453852, 8.143282741, 8.163111824,
      8.55382691, 8.601570224, 8.649315777, 8.697063365, 8.744812783,
      8.792563826, 8.840316286, 8.888069953, 8.935824617, 8.983081702,
      9.02993717, 9.076793075, 9.123649283, 9.170505667, 9.217362105,
      9.264218478, 9.311074671, 9.357930573, 9.379786053, 9.410462554,
      9.454453496, 9.484174817, 9.501871908, 9.523713037, 9.543126605,
      9.568178371, 9.579022161, 9.601200955, 9.609147668, 9.628462684,
      9.487256408, 9.493403219, 9.509400688, 9.517477991, 9.522416297,
      9.539730259, 9.543686414, 9.560032114, 9.56300764, 9.565009943,
      9.686472326, 9.695246991, 9.702758104, 9.696432273, 9.701301767,
      9.705195927, 9.694691096, 9.69567182, 9.682246433, 9.680322545,
      9.650544069, 9.644763251, 9.638019201, 9.630313003, 9.621645738,
      9.612018487, 9.608529685, 9.603848689, 9.605760764, 9.5999677, 9.595579339,
      9.596535018, 9.597490697, 9.598446375, 9.599402054, 9.600357733,
      9.601313411, 9.60226909, 9.603224768, 9.604180447, 9.605136125,
      9.606091804, 9.607047482, 9.60800316, 9.608958839, 9.609914517,
      9.610870195, 9.611825874, 9.612781552, 9.61373723, 9.614692908,
      9.615648587, 9.616604265, 9.617559943, 9.618515621, 9.619471299,
      9.620426977, 9.621382655, 9.622338333, 9.623294011, 9.624249689,
      9.625205367, 9.626161045, 9.627116723, 9.6280724, 9.629028078, 9.629983756,
      9.630939434, 9.631895111, 9.632850789, 9.633806467, 9.634762144,
      9.635717822, 9.636673499, 9.637629177, 9.638584855, 9.639540532,
      9.640496209, 9.641451887, 9.642407564, 9.643363242, 9.644318919,
      9.645274596, 9.646230274, 9.647185951, 9.648141628, 9.649097305,
      9.650052982, 9.651008659, 9.651964337, 9.652920014, 9.653875691,
      9.654831368, 9.655787045, 9.656742722, 9.657698399, 9.658654075,
      9.659609752, 9.660565429, 9.661521106, 9.662476783, 9.663432459,
      9.664388136, 9.665343813, 9.66629949, 9.667255166, 9.668210843,
      9.669166519, 9.670122196, 9.671077872, 9.672033549, 9.672989225,
      9.673944902, 9.674900578, 9.675856255, 9.676811931, 9.677767607,
      9.678723283, 9.67967896, 9.681199032, 9.681979347, 9.682747694, 9.68357608,
      9.684531756, 9.685487432, 9.686443108, 9.687398784, 9.68835446,
      9.689310136, 9.690265812, 9.691221488, 9.692177164, 9.693132839,
      9.694088515, 9.695044191, 9.695999867, 9.696955542, 9.697911218,
      9.698866894, 9.699822569, 9.700778245, 9.70173392, 9.702689596,
      9.703645271, 9.704600947, 9.705556622, 9.706512297, 9.707467973,
      9.708423648, 9.709379323, 9.710334999, 9.711290674, 9.712246349,
      9.713202024, 9.714157699, 9.715113374, 9.716069049, 9.717024724,
      9.717980399, 9.718936074, 9.719891749, 9.720847424, 9.721803099,
      9.722758774, 9.723714449, 9.724670123, 9.725625798, 9.726581473,
      9.727537147, 9.728492822, 9.732949448, 9.733892287, 9.734820661,
      9.735734794, 9.736634903, 9.737521205, 9.738393911, 9.73925323,
      9.740099368, 9.740932527, 9.741752906, 9.742560702, 9.743356108,
      9.744139314, 9.744910507, 9.745669872, 9.74641759, 9.74715384, 9.747878799,
      9.748592639, 9.749295531, 9.749987644, 9.750669142, 9.751340189,
      9.752000945, 9.752651568, 9.753292213, 9.753923035, 9.754544182,
      9.755155804, 9.755758048, 9.756351056, 9.756934971, 9.757509933,
      9.758076078, 9.758633542, 9.759182458, 9.759722957, 9.760255169,
      9.76077922, 9.761295236, 9.761803341, 9.762303654, 9.762796297,
      9.763281386, 9.763759038, 9.764229366, 9.764692484, 9.765148501,
      9.765597527, 9.766039668, 9.766475031, 9.766903719, 9.774838152,
      9.775439426, 9.776022249, 9.776587187, 9.777134789, 9.777665588, 9.7781801,
      9.778678826, 9.779162251, 9.779630844, 9.780085061, 9.780525343,
      9.78095212, 9.781365804, 9.781766798, 9.782155493, 9.782532265, 9.78289748,
      9.783251494, 9.783594649, 9.78392728, 9.78424971, 9.784562251, 9.784865207,
      9.785158872, 9.785443531, 9.785719461, 9.78598693, 9.786246197,
      9.786497513, 9.786741123, 9.786977264, 9.787206164, 9.787428045,
      9.787643123, 9.787851606, 9.790505119, 9.790686304, 9.790859152,
      9.791024046, 9.791181353, 9.791331421, 9.791474585, 9.791611163,
      9.791741457, 9.791865757, 9.791984339, 9.792097466, 9.792205389,
      9.792308348, 9.792406571, 9.792500276, 9.792589671, 9.793776633,
      9.793817599, 9.793856051, 9.793892142, 9.793070576, 9.793133743,
      9.793194005, 9.792508676, 9.792568003, 9.792625512, 9.792681259,
      9.792079425, 9.792115665, 9.79215135, 9.791560304, 9.791560304,
      9.791560304, 9.791560304, 9.791560304, 9.791560304, 9.791560304,
      9.791560304, 9.791560304, 9.791560304, 9.791560304, 9.791560304,
      9.791560304, 9.791560304, 9.791560304, 9.791560304, 9.791560304,
      9.791560304, 9.791560304, 9.791560304, 9.791560304, 9.791560304,
      9.778873611, 9.765232252, 9.763322923, 9.748728541, 9.733181464,
      9.716682682, 9.699233188, 9.685889006, 9.763281567, 9.763281567,
      9.750604607, 9.749649616, 9.736018325, 9.734109005, 9.719524704,
      9.716661717, 9.701125733, 9.697309745, 9.74417516, 9.74417516, 9.74417516,
      9.74417516, 9.74417516, 9.74417516, 9.74417516, 9.74417516, 9.741720905,
      9.731319828, 9.565655437, 9.552345989, 9.526376082, 9.499465734,
      9.480833606, 9.456164594, 9.427382447, 9.410296233, 9.380583494,
      9.34993488, 9.4444875, 9.434020433, 9.410947396, 9.399533085, 9.388118877,
      9.364111132, 9.351750467, 9.326805299, 9.313498963, 9.300192785,
      9.274316768, 9.26006574, 9.233255422, 9.218060361, 9.193685252,
      9.174433853, 9.158295855, 9.129627896, 9.112547577, 9.082950185,
      9.277608123, 9.275698917, 9.273789712, 9.271880507, 9.269971302,
      9.268062098, 9.254552038, 9.250852988, 9.247990263, 9.245127539,
      9.242264817, 9.239402095, 9.22837825, 9.220555137, 9.216739624,
      9.212924113, 9.209188784, 9.205520253, 9.198228752, 9.185445446,
      9.243209341, 9.243209341, 9.243209341, 9.243209341, 9.241362478,
      9.241254735, 9.230469884, 9.229551668, 9.228633453, 9.227715238,
      9.239265016, 9.239265016, 9.239265016, 9.239265016, 9.239265016,
      9.239265016, 9.239265016, 9.239265016, 9.239265016, 9.239265016,
      9.039777123, 9.02517268, 9.010568437, 8.991646393, 8.968599406,
      8.953089254, 8.937579336, 8.918157239, 8.893853408, 8.877438523,
      8.792815419, 8.765210826, 8.743379072, 8.716566885, 8.686980902,
      8.664250814, 8.638281624, 8.606211988, 8.582584671, 8.557991939,
      8.613091467, 8.591210365, 8.572991721, 8.55477341, 8.530931535,
      8.505646443, 8.486526371, 8.467406676, 8.446093759, 8.416763698,
      8.396743292, 8.374518805, 8.346272624, 8.32354881, 8.302629218,
      8.281710106, 8.25551521, 8.227308805, 8.205491181, 8.183674093,
      8.441121826, 8.440203648, 8.439285469, 8.43836729, 8.437449112,
      8.436530933, 8.435612754, 8.424210998, 8.422847132, 8.421504123,
      8.44177637, 8.44177637, 8.44177637, 8.44177637, 8.44177637, 8.44177637,
      8.44177637, 8.44177637, 8.44177637, 8.44177637, 8.417502493, 8.415666934,
      8.413831376, 8.411995819, 8.40219237, 8.400248729, 8.398334786,
      8.396450089, 8.388499607, 8.385747473, 8.419376931, 8.419376931,
      8.419376931, 8.419376931, 8.419376931, 8.419376931, 8.419376931,
      8.419376931, 8.419376931, 8.419376931, 8.419376931, 8.419376931,
      8.419376931, 8.419376931, 8.419376931, 8.419376931, 8.419376931,
      8.419376931, 8.419376931, 8.419376931, 8.419376931, 8.419376931,
      8.419376931, 8.419376931, 8.419376931, 8.419376931, 8.419376931,
      8.419376931, 8.419376931, 8.419376931, 8.536193882, 8.544491119,
      8.552788357, 8.561085597, 8.569382839, 8.577680082, 8.585977326,
      8.594274571, 8.602571817, 8.610869064, 8.50485095, 8.505005825,
      8.505158327, 8.505308492, 8.505456355, 8.505601952, 8.505745318,
      8.505886486, 8.506025491, 8.506162365, 8.686088976, 8.699021778,
      8.711954582, 8.724887386, 8.73782019, 8.750752994, 8.763685795,
      8.776618595, 8.789551391, 8.802484184, 8.763154037, 8.772376903,
      8.781599766, 8.790822628, 8.800045487, 8.809268344, 8.818491198,
      8.827714048, 8.836936896, 8.846159741, 8.730997641, 8.731361666,
      8.73172011, 8.732073059, 8.732420597, 8.732762807, 8.733099771,
      8.733431569, 8.73375828, 8.741402428, 8.912683481, 8.925616204,
      8.938548916, 8.951481617, 8.964414305, 8.977346981, 8.990279643,
      9.00321229, 9.016144923, 9.029077539, 8.870974045, 8.871892992,
      8.872811939, 8.873730886, 8.874649834, 8.875568781, 8.876487728,
      8.877406675, 8.878325623, 8.87924457, 8.867003195, 8.867003195,
      8.867003195, 8.867003195, 8.867003195, 8.867003195, 8.867003195,
      8.867003195, 8.867003195, 8.867003195, 8.867003195, 8.867003195,
      8.867003195, 8.867003195, 8.867003195, 8.867003195, 8.867003195,
      8.867003195, 8.867003195, 8.867003195, 8.793098598, 8.787600836,
      8.782103083, 8.776605339, 8.771107605, 8.765609879, 8.756163683,
      8.751564143, 8.747034634, 8.730705226, 8.798057272, 8.797139078,
      8.796220884, 8.79530269, 8.794384495, 8.793466301, 8.792548107,
      8.781547925, 8.780219949, 8.778912284, 8.77762462, 8.772808127,
      8.770972507, 8.769136887, 8.767301268, 8.765465649, 8.763630031,
      8.761794412, 8.759958794, 8.758123177, 8.780850687, 8.775503071,
      8.775185119, 8.774872036, 8.774563749, 8.774260184, 8.766630463,
      8.765712271, 8.764794078, 8.763875885, 8.738399265, 8.735646995,
      8.732894727, 8.730142459, 8.727390193, 8.724637928, 8.721885664,
      8.718888083, 8.716362798, 8.713610538, 8.710858278, 8.70810602,
      8.695666103, 8.69290257, 8.690181219, 8.68282116, 8.679153037, 8.675484917,
      8.671816799, 8.668148684, 8.713493641, 8.713493641, 8.713493641,
      8.713493641, 8.713493641, 8.713493641, 8.713493641, 8.713493641,
      8.713493641, 8.713493641, 8.713493641, 8.713493641, 8.713493641,
      8.713493641, 8.713493641, 8.713493641, 8.713493641, 8.713493641,
      8.713493641, 8.713493641, 8.660659726, 8.648274916, 8.643691721,
      8.639108531, 8.634525347, 8.629942167, 8.625358992, 8.620775822,
      8.616192658, 8.611609498, 8.668196919, 8.668196919, 8.668196919,
      8.668196919, 8.668196919, 8.668196919, 8.668196919, 8.668196919,
      8.668196919, 8.668196919, 8.607026344, 8.602443194, 8.597860049,
      8.59327691, 8.588693775, 8.584110646, 8.579527521, 8.57470102, 8.570343031,
      8.565759922, 8.62224976, 8.62224976, 8.62224976, 8.62224976, 8.62224976,
      8.62224976, 8.62224976, 8.62224976, 8.62224976, 8.62224976, 8.792050507,
      8.804054702, 8.816058892, 8.828063078, 8.840067259, 8.852071434,
      8.864075603, 8.876079765, 8.88808392, 8.900088068, 9.108739203,
      9.134749866, 9.16076043, 9.186770886, 9.212781222, 9.238791427,
      9.264801491, 9.290811402, 9.313996669, 9.334183855, 8.998082036,
      8.998082036, 8.998082036, 8.998082036, 8.998082036, 8.998082036,
      8.998082036, 8.998082036, 8.998082036, 8.998082036, 9.169851419,
      9.181855239, 9.193859037, 9.205862815, 9.217866571, 9.229870305,
      9.241874015, 9.253877703, 9.265881366, 9.277885005, 9.223584182,
      9.230956313, 9.238328438, 9.245700556, 9.259159304, 9.265234748,
      9.271216306, 9.289382064, 9.296852286, 9.30591848, 9.194590233,
      9.194590233, 9.194590233, 9.194590233, 9.194590233, 9.194590233,
      9.194590233, 9.194590233, 9.194590233, 9.194590233, 9.182139908,
      9.181221695, 9.180303482, 9.179385269, 9.178467056, 9.177548844,
      9.176630631, 9.175712419, 9.174794206, 9.173875994, 9.18540446, 9.18540446,
      9.18540446, 9.18540446, 9.18540446, 9.18540446, 9.18540446, 9.18540446,
      9.18540446, 9.18540446, 9.18540446, 9.18540446, 9.18540446, 9.18540446,
      9.18540446, 9.18540446, 9.18540446, 9.18540446, 9.18540446, 9.18540446,
      9.036044315, 9.025073979, 9.014103726, 9.003133555, 8.992163465,
      8.981193457, 8.969222422, 8.946764172, 8.934885061, 8.923006051,
      8.83671871, 8.819399715, 8.80208103, 8.779507408, 8.75468473, 8.736463007,
      8.718241637, 8.700020615, 8.681799941, 8.656245639, 8.817403134,
      8.809599974, 8.793913267, 8.787686906, 8.781104198, 8.774692807,
      8.76828143, 8.761870068, 8.75545872, 8.749047387, 8.767239168, 8.76265584,
      8.758072517, 8.753489199, 8.748905886, 8.744322579, 8.739739277,
      8.73515598, 8.730572688, 8.719296283, 8.782317567, 8.782317567,
      8.782317567, 8.782317567, 8.782317567, 8.782317567, 8.782317567,
      8.782317567, 8.782317567, 8.782317567, 8.782317567, 8.782317567,
      8.782317567, 8.782317567, 8.782317567, 8.782317567, 8.782317567,
      8.782317567, 8.782317567, 8.782317567, 8.782317567, 8.782317567,
      8.782317567, 8.782317567, 8.782317567, 8.782317567, 8.782317567,
      8.782317567, 8.782317567, 8.782317567, 8.782317567, 8.782317567,
      8.782317567, 8.782317567, 8.782317567, 8.782317567, 8.782317567,
      8.782317567, 8.782317567, 8.782317567, 8.782317567, 8.782317567,
      8.782317567, 8.782317567, 8.782317567, 8.782317567, 8.782317567,
      8.782317567, 8.782317567, 8.782317567, 8.874200943, 8.880649133,
      8.887097321, 8.893545507, 8.899993692, 8.906441875, 8.912890056,
      8.919338235, 8.925786413, 8.932234588, 8.846617979, 8.846617979,
      8.846617979, 8.846617979, 8.846617979, 8.846617979, 8.846617979,
      8.846617979, 8.846617979, 8.846617979, 8.846617979, 8.846617979,
      8.846617979, 8.846617979, 8.846617979, 8.846617979, 8.846617979,
      8.846617979, 8.846617979, 8.846617979, 8.846617979, 8.846617979,
      8.846617979, 8.846617979, 8.846617979, 8.846617979, 8.846617979,
      8.846617979, 8.846617979, 8.846617979, 8.846617979, 8.846617979,
      8.846617979, 8.846617979, 8.846617979, 8.846617979, 8.846617979,
      8.846617979, 8.846617979, 8.846617979, 8.785073085, 8.780489736,
      8.775906393, 8.771323055, 8.766739722, 8.762156394, 8.757573072,
      8.752989754, 8.748406442, 8.743823135, 8.702370266, 8.695046202,
      8.687722159, 8.680398138, 8.673074137, 8.665750158, 8.658426199,
      8.651102262, 8.643778345, 8.63645445, 8.727202929, 8.727202929,
      8.727202929, 8.727202929, 8.727202929, 8.727202929, 8.727202929,
      8.727202929, 8.727202929, 8.727202929, 8.543317265, 8.529625701,
      8.515934273, 8.502242981, 8.488551825, 8.470075386, 8.448588866,
      8.433991659, 8.419394615, 8.404797733, 8.463394107, 8.454247649,
      8.445101231, 8.435954852, 8.426808513, 8.417662212, 8.408515951,
      8.399369728, 8.390223545, 8.3810774, 8.371931293, 8.356838173, 8.349199734,
      8.33159816, 8.321542, 8.31148589, 8.301429831, 8.291373823, 8.281317866,
      8.27126196, 8.285438794, 8.277204092, 8.268969418, 8.260734771,
      8.252500152, 8.24426556, 8.236030995, 8.227779764, 8.219383152,
      8.210986567, 8.069609804, 8.047356781, 8.020190021, 8.000630912,
      7.981141856, 7.961653045, 7.942164459, 7.922676077, 7.902428833,
      7.87474704, 8.115549308, 8.115549308, 8.115549308, 8.115549308,
      8.115549308, 8.115549308, 8.115549308, 8.115549308, 8.115549308,
      8.115549308, 7.959497911, 7.947391458, 7.935285031, 7.923178627,
      7.911072243, 7.898965875, 7.884320582, 7.874440502, 7.852748441,
      7.837623899, 7.963399554, 7.953810144, 7.95100407, 7.948197996,
      7.945391921, 7.942585847, 7.939779772, 7.936973697, 7.934167623,
      7.931361548, 7.964368805, 7.964368805, 7.964368805, 7.964368805,
      7.964368805, 7.964368805, 7.964368805, 7.964368805, 7.964368805,
      7.964368805, 7.964368805, 7.964368805, 7.964368805, 7.964368805,
      7.964368805, 7.964368805, 7.964368805, 7.964368805, 7.964368805,
      7.964368805, 7.797239922, 7.784208053, 7.771176168, 7.758144263,
      7.745112333, 7.732080375, 7.719048384, 7.700873714, 7.69007163,
      7.667546555, 7.831713503, 7.831713503, 7.831713503, 7.831713503,
      7.831713503, 7.831713503, 7.831713503, 7.831713503, 7.831713503,
      7.831713503, 7.665396474, 7.65236425, 7.635361347, 7.624625102,
      7.602194022, 7.587129094, 7.573171726, 7.55921426, 7.545256689,
      7.531299009, 7.694645549, 7.694645549, 7.694645549, 7.694645549,
      7.694645549, 7.694645549, 7.694645549, 7.694645549, 7.694645549,
      7.694645549, 7.694645549, 7.694645549, 7.694645549, 7.694645549,
      7.694645549, 7.694645549, 7.694645549, 7.694645549, 7.694645549,
      7.694645549, 7.623723815, 7.618118836, 7.612513848, 7.606908853,
      7.601303849, 7.595698837, 7.590093817, 7.584488789, 7.578883751,
      7.573278705, 7.638450231, 7.638450231, 7.638450231, 7.638450231,
      7.638450231, 7.638450231, 7.638450231, 7.638450231, 7.638450231,
      7.638450231, 7.560575534, 7.555602941, 7.550706007, 7.537665829,
      7.531129358, 7.524592871, 7.518278959, 7.511537495, 7.50500096,
      7.498464409, 7.574308537, 7.574308537, 7.574308537, 7.574308537,
      7.574308537, 7.574308537, 7.574308537, 7.574308537, 7.574308537,
      7.574308537, 7.491927842, 7.485391257, 7.478854655, 7.472318035,
      7.465781398, 7.459244743, 7.45270807, 7.446171378, 7.439634667,
      7.433097937, 7.450042944, 7.445369876, 7.4406968, 7.436023717, 7.431350627,
      7.42667753, 7.422004425, 7.417331312, 7.412658192, 7.407985065,
      7.461917902, 7.461917902, 7.461917902, 7.461917902, 7.461917902,
      7.461917902, 7.461917902, 7.461917902, 7.461917902, 7.461917902,
      7.461917902, 7.461917902, 7.461917902, 7.461917902, 7.461917902,
      7.461917902, 7.461917902, 7.461917902, 7.461917902, 7.461917902,
      7.55022758, 7.556800956, 7.563374343, 7.569947742, 7.576521153,
      7.583094575, 7.589668008, 7.603007406, 7.615953477, 7.623468846,
      7.529853901, 7.529853901, 7.529853901, 7.529853901, 7.529853901,
      7.529853901, 7.529853901, 7.529853901, 7.529853901, 7.529853901,
      7.529853901, 7.529853901, 7.529853901, 7.529853901, 7.529853901,
      7.529853901, 7.529853901, 7.529853901, 7.529853901, 7.529853901,
      7.529853901, 7.529853901, 7.529853901, 7.529853901, 7.529853901,
      7.529853901, 7.529853901, 7.529853901, 7.529853901, 7.529853901,
      7.529853901, 7.529853901, 7.529853901, 7.529853901, 7.529853901,
      7.529853901, 7.529853901, 7.529853901, 7.529853901, 7.529853901,
      7.529853901, 7.529853901, 7.529853901, 7.529853901, 7.529853901,
      7.529853901, 7.529853901, 7.529853901, 7.529853901, 7.529853901,
      7.529853901, 7.529853901, 7.529853901, 7.529853901, 7.529853901,
      7.529853901, 7.529853901, 7.529853901, 7.529853901, 7.529853901,
      7.177359997, 7.14961834, 7.121875123, 7.088905791, 7.054268691,
      7.025607316, 6.99694394, 6.968278612, 6.938685771, 6.899225903,
      7.148782376, 7.141313787, 7.133845168, 7.126376519, 7.11890784,
      7.111439132, 7.099588262, 7.093258668, 7.087025244, 7.069282984,
      7.06248503, 7.055790298, 7.044453093, 7.036053866, 7.027654601,
      7.019255296, 7.010855953, 7.002456572, 6.994057153, 6.985657697,
      6.977258203, 6.968858673, 6.960459106, 6.952059504, 6.943659865,
      6.935260191, 6.926860481, 6.918460737, 6.910060958, 6.901661145,
      6.99581751, 6.995735086, 6.995653926, 6.995574008, 6.995495316,
      6.995417829, 6.995341529, 6.995266398, 6.995192418, 6.995119572,
      6.78851177, 6.771770761, 6.755029489, 6.738287958, 6.721546174,
      6.704804142, 6.688061867, 6.671319353, 6.654576607, 6.637833632,
      6.889474742, 6.894165555, 6.898856377, 6.903547209, 6.908238051,
      6.912928902, 6.917619763, 6.923908546, 6.939523247, 6.945154223,
      6.876357346, 6.876357346, 6.876357346, 6.876357346, 6.876357346,
      6.876357346, 6.876357346, 6.876357346, 6.876357346, 6.876357346,
      6.876357346, 6.876357346, 6.876357346, 6.876357346, 6.876357346,
      6.876357346, 6.876357346, 6.876357346, 6.876357346, 6.876357346,
      6.876357346, 6.876357346, 6.876357346, 6.876357346, 6.876357346,
      6.876357346, 6.876357346, 6.876357346, 6.876357346, 6.876357346,
      6.876357346, 6.876357346, 6.876357346, 6.876357346, 6.876357346,
      6.876357346, 6.876357346, 6.876357346, 6.876357346, 6.876357346,
      6.772968138, 6.764617353, 6.757803592, 6.747903781, 6.739503369,
      6.731102929, 6.722702462, 6.714301967, 6.705901446, 6.697500898,
      6.783532218, 6.782956475, 6.782389548, 6.781831302, 6.781281604,
      6.780740324, 6.780207332, 6.779682502, 6.779165709, 6.77865683,
      6.778155744, 6.777662331, 6.777176474, 6.776698058, 6.776226968,
      6.775763093, 6.775306321, 6.774856545, 6.774413657, 6.773977552,
      6.676852079, 6.668451441, 6.660050779, 6.651650091, 6.643249379,
      6.634848642, 6.626447881, 6.618047097, 6.60964629, 6.601245459,
      6.592844606, 6.58444373, 6.576042832, 6.567641912, 6.559240971,
      6.550840009, 6.542439025, 6.531629925, 6.524640559, 6.516973252,
      6.508572187, 6.492710216, 6.485383416, 6.478167891, 6.462170016,
      6.452838864, 6.444510214, 6.436986995, 6.425151573, 6.415820328,
      6.505224351, 6.504230544, 6.503251948, 6.502288331, 6.501339461,
      6.500405116, 6.499485071, 6.49857911, 6.497687015, 6.496808576,
      6.327028651, 6.312131717, 6.297028304, 6.281831494, 6.266634597,
      6.251437612, 6.236240534, 6.22104336, 6.204080805, 6.190500526,
      6.243127346, 6.227844382, 6.219660993, 6.211601838, 6.203665048,
      6.184562176, 6.176089209, 6.167744829, 6.159527105, 6.142741234,
      6.222421045, 6.219558136, 6.217052084, 6.214731757, 6.212446894,
      6.210196954, 6.207981406, 6.205799724, 6.203651392, 6.201535902,
      6.199452752, 6.197401451, 6.195381511, 6.193392454, 6.191433809,
      6.189505113, 6.187605908, 6.185735745, 6.183894179, 6.182080776,
      6.180295104, 6.178536741, 6.17680527, 6.165497162, 6.162634235,
      6.159771306, 6.156908376, 6.154468447, 6.152151735, 6.149870433,
      6.179417403, 6.179417403, 6.179417403, 6.179417403, 6.179417403,
      6.179417403, 6.179417403, 6.179417403, 6.179417403, 6.179417403,
      6.179417403, 6.179417403, 6.179417403, 6.179417403, 6.179417403,
      6.179417403, 6.179417403, 6.179417403, 6.179417403, 6.179417403,
      6.179417403, 6.179417403, 6.179417403, 6.179417403, 6.179417403,
      6.179417403, 6.179417403, 6.179417403, 6.179417403, 6.179417403,
      6.156934896, 6.155025601, 6.153116305, 6.151207009, 6.149297713,
      6.147388416, 6.145479119, 6.143569822, 6.141660525, 6.139751227,
      6.137841929, 6.13593263, 6.134023332, 6.132114033, 6.130204733,
      6.128295434, 6.126386134, 6.124476834, 6.122567533, 6.120658233,
      6.214366236, 6.22855464, 6.23870748, 6.245406915, 6.252106376, 6.258805865,
      6.265505381, 6.272204924, 6.278904495, 6.285604094, 6.206828126,
      6.206828126, 6.206828126, 6.206828126, 6.206828126, 6.206828126,
      6.206828126, 6.206828126, 6.206828126, 6.206828126, 6.128071688,
      6.121400971, 6.114730243, 6.108664937, 6.103241868, 6.09492204,
      6.088251263, 6.081580473, 6.07490967, 6.068238855, 6.140160259,
      6.140160259, 6.140160259, 6.140160259, 6.140160259, 6.140160259,
      6.140160259, 6.140160259, 6.140160259, 6.140160259, 6.128932797,
      6.127977811, 6.127022826, 6.12606784, 6.125112854, 6.124157869,
      6.123202883, 6.122247897, 6.121292911, 6.120337925, 6.11938294,
      6.118427954, 6.117472968, 6.116517982, 6.115562996, 6.114608009,
      6.113653023, 6.112698037, 6.111743051, 6.110788065, 6.121053851,
      6.121053851, 6.121053851, 6.121053851, 6.121053851, 6.121053851,
      6.121053851, 6.121053851, 6.121053851, 6.121053851, 6.121053851,
      6.121053851, 6.121053851, 6.121053851, 6.121053851, 6.121053851,
      6.121053851, 6.121053851, 6.121053851, 6.121053851, 6.111043229,
      6.110344593, 6.109656654, 6.108979249, 6.108312217, 6.107655398,
      6.107008636, 6.106371778, 6.105744671, 6.105127168, 6.10451912,
      6.103920383, 6.103330815, 6.102750275, 6.102178625, 6.101615729,
      6.101061453, 6.100515665, 6.099978236, 6.099449037, 6.016550532, 6.0089293,
      6.001308048, 5.993686774, 5.98606548, 5.977971516, 5.970782632,
      5.963161272, 5.955539891, 5.947918487, 5.873162757, 5.859852907,
      5.846547583, 5.835635131, 5.820127344, 5.806816988, 5.791890327,
      5.780058207, 5.766747445, 5.747873598, 5.795366844, 5.786795128,
      5.778223375, 5.771175585, 5.7642455, 5.752897952, 5.744326042, 5.735754092,
      5.7271821, 5.718143554, 5.709998027, 5.701425911, 5.692853752, 5.684281551,
      5.671803428, 5.66448771, 5.657283217, 5.649394468, 5.640822044,
      5.625012752, 5.700654516, 5.698745127, 5.696835736, 5.694926346,
      5.693016955, 5.691107563, 5.689198171, 5.684072929, 5.682275529,
      5.68050562, 5.601209072, 5.594018402, 5.585909035, 5.568820126,
      5.561173646, 5.55364339, 5.546227606, 5.538924572, 5.531732588,
      5.513596709, 5.428489814, 5.415406161, 5.394168833, 5.378202641,
      5.364345634, 5.344726886, 5.325620758, 5.311495779, 5.294086119,
      5.272597924, 5.412563641, 5.409959292, 5.407394759, 5.404869437,
      5.402382726, 5.399934037, 5.397522791, 5.395148416, 5.39281035,
      5.390508038, 5.380490367, 5.378252366, 5.376082751, 5.369047877,
      5.366115923, 5.363228783, 5.360385774, 5.357586222, 5.354829465,
      5.352114851, 5.294436169, 5.286998538, 5.270673616, 5.264853792,
      5.259210955, 5.248711865, 5.241669922, 5.23163024, 5.226010082, 5.20984722,
      5.258544469, 5.256063726, 5.25365877, 5.251327293, 5.249067056, 5.24687589,
      5.24475169, 5.242692414, 5.240696084, 5.238760781, 5.267188168,
      5.267188168, 5.267188168, 5.267188168, 5.267188168, 5.267188168,
      5.267188168, 5.267188168, 5.267188168, 5.267188168, 5.267188168,
      5.267188168, 5.267188168, 5.267188168, 5.267188168, 5.267188168,
      5.267188168, 5.267188168, 5.267188168, 5.267188168, 5.351264018,
      5.358240072, 5.365216143, 5.372192231, 5.379168336, 5.386144457,
      5.393120593, 5.410527175, 5.419960355, 5.427934823, 5.435909312,
      5.443883824, 5.451858357, 5.459832912, 5.467807486, 5.475782081,
      5.492981929, 5.504533475, 5.513506882, 5.522480316, 5.394832102,
      5.393148293, 5.391515974, 5.389933572, 5.388399565, 5.380341426,
      5.378978772, 5.377678562, 5.376437944, 5.375254195, 5.367542062,
      5.365699806, 5.363913874, 5.362182547, 5.360504159, 5.35667882,
      5.355408486, 5.35419638, 5.353039841, 5.351936327, 5.1969125, 5.180634869,
      5.164545865, 5.148452271, 5.132354345, 5.120975503, 5.099315458,
      5.085402159, 5.066986673, 5.063006367, 5.214256131, 5.214256131,
      5.214256131, 5.214256131, 5.214256131, 5.214256131, 5.214256131,
      5.214256131, 5.214256131, 5.214256131, 5.127396905, 5.128407436,
      5.12941489, 5.135594642, 5.149715729, 5.159073731, 5.165275876,
      5.169386708, 5.172111521, 5.173917682, 5.646047254, 5.685166955,
      5.72428999, 5.763416102, 5.797689754, 5.829296436, 5.87245256, 5.90591362,
      5.944039555, 5.982166988, 5.66973475, 5.678350285, 5.686965835,
      5.695581401, 5.704196985, 5.712812586, 5.724558913, 5.731711246,
      5.750823317, 5.758531555, 5.228965064, 5.19310551, 5.157242095,
      5.115333428, 5.071153006, 5.032792389, 5.00798443, 5.009014808,
      5.009881799, 5.010613184, 5.425248656, 5.436220329, 5.447192065,
      5.45816386, 5.469135715, 5.480107627, 5.491079595, 5.502534226,
      5.513063698, 5.532490584, 5.415312227, 5.416307566, 5.423231771,
      5.430828761, 5.432819866, 5.434810972, 5.436802077, 5.438793183,
      5.440784289, 5.442775396, 5.568271794, 5.578237229, 5.600097649,
      5.610573998, 5.627029386, 5.640002484, 5.652975642, 5.665948857,
      5.678922127, 5.691895449, 6.130262359, 6.173345626, 6.217531389,
      6.254865596, 6.303709215, 6.345035748, 6.389461391, 6.426069519,
      6.468262288, 6.510123847, 6.605567461, 6.653930256, 6.702301489,
      6.750681715, 6.799071482, 6.847471336, 6.895881824, 6.944303487,
      6.992736868, 7.041182507, 7.089292559, 7.136827628, 7.184375664,
      7.231936169, 7.279508657, 7.327092646, 7.374687663, 7.422293243,
      7.469908925, 7.517534254, 7.565168783, 7.612812065, 7.66046366,
      7.708123132, 7.755790045, 7.80346397, 7.851144475, 7.898831134,
      7.946523517, 7.994221199, 8.041923753, 8.089630806, 8.137342149,
      8.185057603, 8.232776984, 8.280500107, 8.328226785, 8.375956829,
      8.423690045, 8.47142624, 8.519165218, 8.566906781, 8.614650728,
      8.662396859, 8.710144968, 8.757894853, 8.805646304, 8.853399116,
      8.901153077, 8.948907976, 8.995918515, 9.042774116, 9.089630117,
      9.136486385, 9.183342796, 9.230199228, 9.277055563, 9.323911688,
      9.37076749, 9.417622858, 9.464477683, 9.511331854, 9.558185258,
      9.605037781, 9.651889307, 9.698739715, 9.74558888, 9.792436669,
      9.839282947, 9.886127569, 9.934196417, 9.974587427, 9.999725501,
      9.997178735, 9.994713212, 9.992339745, 9.990065773, 9.990591549,
      9.995158748, 9.997289715, 9.765478905, 9.774105655, 9.782732384,
      9.791318664, 9.798082144, 9.804741104, 9.811297173, 9.817751954,
      9.824107027, 9.841159545, 9.323696612, 9.287065108, 9.250063515,
      9.218326215, 9.187170815, 9.150542017, 9.112842194, 9.074789859,
      9.036390748, 9.001929382, 8.933730475, 8.89284659, 8.851661511,
      8.810180125, 8.76905263, 8.728449702, 8.687579062, 8.646445061,
      8.604990361, 8.563400483, 8.471951019, 8.427020959, 8.381892389,
      8.331843377, 8.278461814, 8.232067216, 8.185497589, 8.13486667, 8.07937516,
      8.033648615, 8.105853382, 8.064740709, 8.035542761, 7.99461831,
      7.953433133, 7.911991467, 7.870297477, 7.828037785, 7.785091254,
      7.741897842, 7.746654763, 7.705852712, 7.664769299, 7.635408767,
      7.594495446, 7.553301873, 7.511832195, 7.470090459, 7.43999853,
      7.398445172, 7.404159596, 7.364957823, 7.337301742, 7.298211488,
      7.258810099, 7.219102116, 7.190885897, 7.151303417, 7.111416177,
      7.082977014, 7.125354579, 7.093708851, 7.066989008, 7.034851536,
      7.008528214, 6.98520703, 6.950569222, 6.927196877, 6.892532482, 6.8691103,
      7.199288932, 7.199288932, 7.199288932, 7.199288932, 7.199288932,
      7.199288932, 7.199288932, 7.199288932, 7.199288932, 7.199288932,
      6.967013483, 6.948431276, 6.927574821, 6.905223961, 6.882534906,
      6.861108474, 6.841602592, 6.82209624, 6.802589429, 6.783082168,
      7.217503037, 7.233520084, 7.249537446, 7.265555117, 7.281573092,
      7.290668634, 7.303015779, 7.315857295, 7.330928721, 7.346000377,
      7.114604469, 7.110864068, 7.107123663, 7.103383255, 7.099642844,
      7.095902429, 7.09216201, 7.088421588, 7.084681163, 7.080940734,
      6.903445328, 6.884468217, 6.863312794, 6.841837054, 6.820103028,
      6.801517511, 6.782931611, 6.764345335, 6.745758691, 6.727171688,
      6.938817227, 6.938817227, 6.938817227, 6.938817227, 6.938817227,
      6.938817227, 6.938817227, 6.938817227, 6.938817227, 6.938817227,
      6.647446878, 6.621391343, 6.59521019, 6.568907224, 6.542486131,
      6.527416052, 6.501336398, 6.475131776, 6.460166997, 6.434365439,
      7.177846628, 7.205175262, 7.241210518, 7.277250348, 7.30613989,
      7.336390417, 7.371482345, 7.403040239, 7.428966319, 7.463108271,
      6.839986773, 6.820007144, 6.799724804, 6.779135214, 6.760325941,
      6.742661471, 6.724996698, 6.707331628, 6.689666267, 6.672000621,
      7.071027074, 7.086094128, 7.101161486, 7.116229144, 7.131297097,
      7.14636534, 7.161433869, 7.176502679, 7.191571765, 7.206641123,
      6.710199836, 6.683160647, 6.656025762, 6.637177485, 6.613402816,
      6.586549876, 6.559595527, 6.544018657, 6.514885576, 6.490616856,
      6.783120951, 6.784057849, 6.784994748, 6.785931646, 6.786868545,
      6.787805443, 6.788742342, 6.789679241, 6.79061614, 6.791553039,
      6.474633545, 6.452489069, 6.427515301, 6.39692881, 6.37464246, 6.352448464,
      6.33034276, 6.311683431, 6.290843976, 6.265722074, 6.30632067, 6.287727367,
      6.2701391, 6.254821043, 6.231758389, 6.212803154, 6.197299885, 6.175144345,
      6.156175182, 6.142219266, 6.069014472, 6.0444338, 6.019844084, 6.002558413,
      5.981960711, 5.954815566, 5.935890366, 5.922331662, 5.89409551,
      5.889981082, 6.128780527, 6.129736093, 6.130691659, 6.131647225,
      6.132602792, 6.133558358, 6.134513924, 6.135469491, 6.136425057,
      6.137380624, 5.93741856, 5.92561446, 5.919005389, 5.913621421, 5.908824265,
      5.911546033, 5.914164093, 5.930698092, 5.954008715, 5.969809019,
      6.023403275, 6.024358834, 6.025314392, 6.026269951, 6.027225509,
      6.028181068, 6.029136627, 6.030092186, 6.031047744, 6.032003303,
      6.628944951, 6.677311755, 6.725687267, 6.774072036, 6.822466611,
      6.870871538, 6.91928736, 6.959787047, 7.00326247, 7.038453614, 7.108802053,
      7.156342504, 7.203895718, 7.2514612, 7.299038466, 7.346627039, 7.394226447,
      7.441836229, 7.489455925, 7.537085085, 7.478394836, 7.512189024,
      7.551142794, 7.577625812, 7.615624323, 7.645268104, 7.67848164,
      7.715526996, 7.740033356, 7.776121223, 7.963029337, 8.010728753,
      8.058432896, 8.106141454, 8.153854241, 8.201571074, 8.249291771,
      8.297016146, 8.344744011, 8.392475174, 8.440209443, 8.487946624,
      8.535686519, 8.583428929, 8.631173655, 8.678920493, 8.726669241,
      8.774419691, 8.822171637, 8.86992487, 8.749597266, 8.778016025,
      8.806014303, 8.831378813, 8.859550181, 8.882937323, 8.911098406,
      8.932919657, 8.960690628, 8.981353666, 9.148437422, 9.178768213,
      9.204922402, 9.230111848, 9.254337645, 9.277600892, 9.300106913,
      9.327155695, 9.353774535, 9.375490568, 9.342132025, 9.356818245,
      9.382440017, 9.397397963, 9.410171921, 9.435241827, 9.447056661,
      9.457923666, 9.481117574, 9.491028523, 9.526577056, 9.536469641,
      9.545416723, 9.567206543, 9.576027393, 9.595554153, 9.604933481,
      9.611787432, 9.629858704, 9.63682324, 9.49442879, 9.501133803, 9.507838809,
      9.501146483, 9.506891446, 9.512636404, 9.518381358, 9.524126307,
      9.529871252, 9.535616192, 9.662073832, 9.663066975, 9.67524748,
      9.676438867, 9.675486228, 9.68700191, 9.685076222, 9.695628234, 9.69273098,
      9.697415409, 9.630821879, 9.634648895, 9.625016767, 9.627885952,
      9.630755137, 9.633624321, 9.636493504, 9.639362686, 9.642231867,
      9.631634388, 9.593989756, 9.593034776, 9.592079797, 9.591124817,
      9.590169838, 9.589214858, 9.588259879, 9.5873049, 9.586349921, 9.585394942,
      9.637449898, 9.64031908, 9.643188261, 9.632590424, 9.634502495,
      9.636414566, 9.638326637, 9.626768829, 9.627724507, 9.628680185,
      9.616164912, 9.616164912, 9.616164912, 9.603539555, 9.602584575,
      9.601629595, 9.600674615, 9.599719635, 9.598764655, 9.597809675,
      9.596854695, 9.583277082, 9.581367804, 9.579458526, 9.577549249,
      9.575639973, 9.573730697, 9.571821421, 9.569912146, 9.568002872,
      9.566093598, 9.564184324, 9.562275051, 9.560365779, 9.558456506,
      9.556547235, 9.554637964, 9.552728693, 9.550819423, 9.548910154,
      9.547000885, 9.545091616, 9.543182348, 9.54127308, 9.539363813,
      9.537454546, 9.53554528, 9.533636015, 9.531726749, 9.529817485, 9.52790822,
      9.525998957, 9.511488298, 9.508625437, 9.505762579, 9.502899721,
      9.500036866, 9.497174012, 9.494311159, 9.491448309, 9.475992348,
      9.472176602, 9.46836086, 9.451956164, 9.44718823, 9.442420303, 9.437652384,
      9.432884471, 9.428116566, 9.410770135, 9.392919439, 9.387624808,
      9.382410818, 9.36470699, 9.358892843, 9.353167195, 9.343721855,
      9.329186965, 9.322964813, 9.316837325, 9.273152626, 9.256783055,
      9.243817113, 9.222566281, 9.211818569, 9.192357317, 9.172547243,
      9.158937984, 9.144735603, 9.124496328, 9.116438203, 9.104589214,
      9.08849618, 9.06861984, 9.048445151, 9.04044288, 9.020225149, 8.9997199,
      8.990078178, 8.970797679, 9.012161176, 9.006154754, 8.996737209,
      8.980582037, 8.976035728, 8.95780214, 8.951627259, 8.940273476, 8.92719945,
      8.920015918, 9.001773533, 8.999719946, 8.997728977, 8.986628944,
      8.985161754, 8.983761444, 8.982424989, 8.9811495, 8.973064023, 8.970971901,
      9.08029073, 9.084892832, 9.089494932, 9.094097031, 9.098699129,
      9.103301225, 9.107903321, 9.112505415, 9.117107508, 9.121479522,
      9.258674778, 9.272536247, 9.279065449, 9.286493405, 9.299425529,
      9.31235762, 9.312019988, 9.324023526, 9.336027036, 9.347818716,
      9.132125859, 9.129753492, 9.127453413, 9.125223431, 9.123061423,
      9.120965325, 9.11893314, 9.116962927, 9.115052807, 9.113200953,
      9.086539044, 9.076990282, 9.075048348, 9.073194693, 9.071425348,
      9.05731288, 9.055357084, 9.053490189, 9.0517082, 9.050007293, 9.062974278,
      9.062457859, 9.061972646, 9.061516778, 9.061088504, 9.053227353,
      9.053326959, 9.05341848, 9.053502603, 9.05357995, 9.058656246, 9.058401622,
      9.058162497, 9.057937934, 9.057727051, 9.05752902, 9.05391938, 9.053963534,
      9.05400421, 9.054041687, 9.728543324, 9.748873895, 9.753982164,
      9.764265091, 9.768762283, 9.76793263, 9.763713706, 9.756513282,
      9.746341508, 9.737908052, 9.637074015, 9.639047981, 9.626640621,
      9.625706893, 9.623804433, 9.60751206, 9.60271363, 9.583522435, 9.575836753,
      9.567189982, 9.53071557, 9.518237072, 9.518237072, 9.518237072,
      9.518237072, 9.518237072, 9.505646905, 9.504691931, 9.503736957,
      9.502781983, 9.50182701, 9.500872036, 9.499917062, 9.498962088,
      9.498007115, 9.497052141, 9.496097168, 9.495142194, 9.494187221,
      9.493232248, 9.492277274, 9.491322301, 9.490367328, 9.489412355,
      9.488457382, 9.487502409, 9.486547436, 9.485592463, 9.484637491,
      9.483682518, 9.482727545, 9.481772573, 9.4808176, 9.479862628, 9.478907655,
      9.477952683, 9.47699771, 9.476042738, 9.475087766, 9.474132794,
      9.473177822, 9.47222285, 9.471267878, 9.470312906, 9.469515515,
      9.468762801, 9.46802161, 9.467291767, 9.466573097, 9.465865431,
      9.465168599, 9.464482436, 9.463806778, 9.463141466, 9.46248634,
      9.461841244, 9.461206026, 9.460580535, 9.45996462, 9.459358137, 9.45876094,
      9.458172887, 9.457593839, 9.457023658, 9.456462208, 9.455909355,
      9.455364968, 9.454828917, 9.454301075, 9.453781317, 9.453269517,
      9.452765555, 9.452269311, 9.451780666, 9.451299505, 9.450825712,
      9.450359175, 9.449899783, 9.449447426, 9.449001997, 9.44856339, 9.4481315,
      9.447706224, 9.447287462, 9.446875113, 9.44646908, 9.446069265,
      9.445675574, 9.445287913, 9.444906189, 9.444530311, 9.44416019,
      9.443795739, 9.443436869, 9.443083496, 9.442735536, 9.442392905,
      9.442055522, 9.441723307, 9.44139618, 9.441074064, 9.440756882,
      9.440444558, 9.440137018, 9.439834189, 9.439535999, 9.439242376,
      9.43895325, 9.438668554, 9.438388218, 9.438112176, 9.437840363,
      9.437572714, 9.437309164, 9.437049652, 9.436794115, 9.436542492,
      9.436294724, 9.436050751, 9.435810515, 9.43557396, 9.435341028,
      9.435111664, 9.434885814, 9.434663424, 9.434444441, 9.434228812,
      9.434016486, 9.433807413, 9.433601543, 9.433398827, 9.433199216,
      9.433002663, 9.432809121, 9.432618545, 9.432430887, 9.432246105,
      9.432064153, 9.431884989, 9.431708569, 9.431534852, 9.431363797,
      9.431195362, 9.431029507, 9.430866194, 9.430705382, 9.430547034,
      9.430391112, 9.430237578, 9.430086397, 9.429937532, 9.429790947,
      9.429646609, 9.429504481, 9.429364531, 9.429226725, 9.429091031,
      9.428957415, 9.428825846, 9.428696293, 9.428568725, 9.428443112,
      9.428319422, 9.428197628, 9.4280777, 9.427959609, 9.427843328, 9.427728828,
      9.427616082, 9.427505063, 9.427395746, 9.427288103, 9.42718211, 9.42707774,
      9.42697497, 9.426873774, 9.426774128, 9.42667601, 9.426579394, 9.426484259,
      9.426390581, 9.426298339, 9.42620751, 9.426118072, 9.426030005,
      9.425943287, 9.425857898, 9.425773817, 9.425691024, 9.4256095, 9.425529225,
      9.42545018, 9.425372345, 9.425295704, 9.425220237, 9.425145926,
      9.425072753, 9.425000702, 9.424929754, 9.424859894, 9.424791104,
      9.424723368, 9.42465667, 9.424590994, 9.424526324, 9.424462645,
      9.424399941, 9.424338199, 9.424277402, 9.424217537, 9.424158589,
      9.424100544, 9.424043389, 9.423987109, 9.423931692, 9.423877124,
      9.423823391, 9.423770483, 9.423718384, 9.423667084, 9.423616571,
      9.423566831, 9.423517853, 9.423469625, 9.423422137, 9.423375376,
      9.423329332, 9.423283993, 9.423239349, 9.423195389, 9.423152102,
      9.423109479, 9.423067509, 9.423026182, 9.422985488, 9.422945417,
      9.422905961, 9.422867109, 9.422828853, 9.422791182, 9.422754089,
      9.422717564, 9.422681599, 9.422646185, 9.422611313, 9.422576976,
      9.422543165, 9.422509872, 9.422477089, 9.422444809, 9.422413023,
      9.422381724, 9.422350905, 9.422320557, 9.422290675, 9.422261251,
      9.422232278, 9.422203748, 9.422175656, 9.422147994, 9.422120756,
      9.422093935, 9.422067526, 9.409907763, 9.408952794, 9.407997826,
      9.407198595, 9.406445443, 9.405703822, 9.404973555, 9.404254468,
      9.40354639, 9.402849153, 9.400736855, 9.399781888, 9.39882692, 9.397871952,
      9.396916985, 9.395962017, 9.385036677, 9.371119551, 9.36901092, 9.36693452,
      9.364889858, 9.357873959, 9.348045752, 9.345337102, 9.342669825,
      9.332447972, 9.328632362, 9.30887209, 9.304858363, 9.288371981,
      9.283720418, 9.266610188, 9.261340505, 9.252581041, 9.238301582,
      9.23251389, 9.219008081, 9.145643451, 9.123076149, 9.099912191, 9.07616137,
      9.052246626, 9.027966007, 9.001356738, 8.972483942, 8.942713252,
      8.912265335, 8.922018709, 8.896131198, 8.869739056, 8.842850561,
      8.81547385, 8.787616925, 8.75928765, 8.730493759, 8.701242855, 8.671542413,
      8.727873561, 8.702284855, 8.688526419, 8.662642782, 8.636255019,
      8.621688558, 8.595031412, 8.567882903, 8.552544701, 8.525151146,
      8.534110234, 8.520178882, 8.494194456, 8.479962872, 8.453697748,
      8.439174828, 8.412638138, 8.395922092, 8.370920062, 8.349424961,
      8.472327371, 8.455760305, 8.44960008, 8.44429113, 8.434375952, 8.421757516,
      8.416384213, 8.411173339, 8.393950945, 8.388512215, 8.310270247,
      8.289782339, 8.281165382, 8.260664079, 8.242881668, 8.231101175,
      8.210323243, 8.201325724, 8.183522204, 8.165628471, 8.111357338,
      8.092053874, 8.072558807, 8.048872509, 8.02127543, 8.004845601,
      7.988848085, 7.96085031, 7.944764527, 7.923600015, 7.982332666,
      7.972861727, 7.955399242, 7.943379939, 7.927208941, 7.923974579,
      7.928064208, 7.931919165, 7.940467707, 7.949329468, 8.051256482,
      8.052193438, 8.053130394, 8.054067351, 8.055004307, 8.055941263,
      8.056878219, 8.057815175, 8.058752131, 8.059689087, 8.689852373,
      8.737601528, 8.785352339, 8.833104598, 8.880858096, 8.928612623,
      8.976005607, 9.022860998, 9.069716845, 9.116573016, 9.163429381,
      9.210285818, 9.257142208, 9.303998436, 9.350854389, 9.397709956,
      9.444565025, 9.491419487, 9.538273231, 9.585126143, 9.631978107,
      9.678829005, 9.725678714, 9.772527104, 9.819374042, 9.866219385,
      9.913508253, 9.962187107, 9.984128747, 9.991402292, 9.404047469,
      9.402388583, 9.400755068, 9.399146535, 9.397562602, 9.396002896,
      9.394266527, 9.392357295, 9.390448064, 9.388538833, 9.210912854,
      9.195718123, 9.175869948, 9.15244283, 9.136305188, 9.120167804, 9.09979049,
      9.075062547, 9.057983189, 9.040981513, 8.987148567, 8.968018117,
      8.941388008, 8.916761358, 8.896729408, 8.869277156, 8.843699211,
      8.822766792, 8.795063317, 8.768008288, 8.746176454, 8.718780319,
      8.689734129, 8.667003958, 8.640461214, 8.608921657, 8.585294253,
      8.549343928, 8.524819618, 8.496646357, 8.512382027, 8.484284773,
      8.455994539, 8.433271175, 8.410548448, 8.387826356, 8.35772986,
      8.329610933, 8.305992103, 8.277325227, 8.294855697, 8.274037505,
      8.249418201, 8.220404105, 8.197988284, 8.176171378, 8.154355005,
      8.126757736, 8.098171324, 8.078866013, 8.004603112, 7.977954209,
      7.945682334, 7.911825571, 7.884090735, 7.856359321, 7.828628571,
      7.798962419, 7.764625463, 7.73264551, 7.835856205, 7.817288401, 7.79703855,
      7.780022468, 7.755173696, 7.739879484, 7.712877527, 7.697301055,
      7.673204112, 7.654385384, 7.598572602, 7.573295484, 7.553850983,
      7.525484398, 7.497023606, 7.476743354, 7.450927833, 7.427830614,
      7.404610121, 7.37874837, 7.501567583, 7.487741871, 7.475634131, 7.46061748,
      7.45067241, 7.440877521, 7.427076889, 7.414968641, 7.399935, 7.389982648,
      7.321428918, 7.303030291, 7.2828192, 7.269103016, 7.252546662, 7.230375471,
      7.216527551, 7.201750217, 7.177685602, 7.163709526, 7.360876897,
      7.360876897, 7.360876897, 7.360876897, 7.360876897, 7.360876897,
      7.360876897, 7.360876897, 7.360876897, 7.360876897, 7.255056595,
      7.248223192, 7.229821148, 7.222442898, 7.215176547, 7.20802042,
      7.200972864, 7.194032252, 7.176488293, 7.170822267, 7.473691795,
      7.488765403, 7.503839194, 7.518913164, 7.533987307, 7.54906162,
      7.564136097, 7.579210735, 7.594285529, 7.609360474, 7.31661026,
      7.309770711, 7.303034958, 7.296401441, 7.278177519, 7.270993324,
      7.263918105, 7.25695023, 7.250088088, 7.243330093, 7.236674683,
      7.223657099, 7.211584312, 7.204482683, 7.197488809, 7.190601072,
      7.183817881, 7.177137667, 7.170558882, 7.158843712, 7.099180877,
      7.089151203, 7.079273078, 7.069544252, 7.053967736, 7.038525191,
      7.028487726, 7.018601955, 7.008865625, 6.993263065, 6.97785396,
      6.967808975, 6.957915825, 6.939885577, 6.932133307, 6.916644726,
      6.905366336, 6.896627314, 6.878725925, 6.870974023, 6.751550776,
      6.735244596, 6.711106405, 6.686784025, 6.662283088, 6.649107345,
      6.624833591, 6.600379721, 6.580879118, 6.560316686, 6.654350527,
      6.64542985, 6.632791752, 6.619583901, 6.611191186, 6.594761323,
      6.589589804, 6.573223754, 6.568104373, 6.551796822, 6.58096758,
      6.567957048, 6.565782396, 6.557508178, 6.550284991, 6.545062722,
      6.533158145, 6.532433055, 6.525622646, 6.530738111, 6.52758837,
      6.526566589, 6.527330254, 6.529481509, 6.529133257, 6.528800679,
      6.532310115, 6.538111575, 6.547109951, 6.552798151, 7.179516688,
      7.227075942, 7.274647227, 7.322230063, 7.369823975, 7.417428496,
      7.465043167, 7.512667531, 7.56030114, 7.607943548, 7.655594314,
      7.703253001, 7.750919174, 7.798592402, 7.846272255, 7.893958304,
      7.941650122, 7.989347282, 8.037049358, 8.084755962, 8.132466875,
      8.180181917, 8.227900905, 8.275623655, 8.323349979, 8.371079687,
      8.418812588, 8.466548488, 8.51428719, 8.562028498, 8.609772211,
      8.657518128, 8.705266045, 8.753015757, 8.800767058, 8.84851974,
      8.896273593, 8.944028407, 8.991130899, 9.037986452, 9.084842418,
      9.131698665, 9.178555067, 9.225411502, 9.272267852, 9.319124003,
      9.365979844, 9.412835262, 9.459690147, 9.50654439, 9.553397877,
      9.600250496, 9.647102129, 9.693952657, 9.740801954, 9.772166769,
      9.781397298, 9.80181837, 9.821445639, 9.82747088, 9.938290099, 9.946367633,
      9.951228855, 9.949791531, 9.944015481, 9.951292982, 9.941890834,
      9.929525062, 9.914205709, 9.90530254, 9.646216831, 9.646216831,
      9.646216831, 9.646216831, 9.646216831, 9.646216831, 9.646216831,
      9.646216831, 9.646216831, 9.646216831, 9.570400679, 9.552046941,
      9.532744673, 9.521326236, 9.504590456, 9.483397108, 9.462742719,
      9.450903099, 9.427823843, 9.411830148, 9.366838221, 9.352585921,
      9.325740396, 9.297956031, 9.269233955, 9.240422924, 9.221614263,
      9.191027217, 9.15950598, 9.130526054, 9.189356608, 9.167094941,
      9.151900843, 9.124183487, 9.108046295, 9.079398045, 9.062318613,
      9.037846827, 9.015718739, 8.998203457, 9.005979298, 8.990468576,
      8.972429804, 8.94682167, 8.930405903, 8.909169814, 8.884800561,
      8.867480693, 8.843661639, 8.819964752, 8.925663818, 8.916515249,
      8.907366724, 8.892540899, 8.884958262, 8.866855749, 8.856796691,
      8.846737693, 8.836678752, 8.82661987, 8.890676865, 8.886093394,
      8.881509928, 8.876926467, 8.872343012, 8.867759562, 8.863176117,
      8.858592678, 8.854009244, 8.849425816, 8.906511182, 8.906511182,
      8.906511182, 8.906511182, 8.906511182, 8.906511182, 8.906511182,
      8.906511182, 8.906511182, 8.906511182, 8.906511182, 8.906511182,
      8.906511182, 8.906511182, 8.906511182, 8.906511182, 8.906511182,
      8.906511182, 8.906511182, 8.906511182, 8.906511182, 8.906511182,
      8.906511182, 8.906511182, 8.906511182, 8.906511182, 8.906511182,
      8.906511182, 8.906511182, 8.906511182, 8.857176151, 8.853507901,
      8.844796376, 8.841586675, 8.838425939, 8.835313424, 8.832248398,
      8.817910593, 8.813327207, 8.809628672, 8.865810988, 8.865810988,
      8.865810988, 8.865810988, 8.865810988, 8.865810988, 8.865810988,
      8.865810988, 8.865810988, 8.865810988, 8.865810988, 8.865810988,
      8.865810988, 8.865810988, 8.865810988, 8.865810988, 8.865810988,
      8.865810988, 8.865810988, 8.865810988, 8.87897083, 8.879889777,
      8.880808724, 8.881727672, 8.882646619, 8.883565566, 8.884484513,
      8.88540346, 8.886322407, 8.887241355, 8.888160302, 8.889079249,
      8.889998196, 8.890917143, 8.89183609, 8.892755037, 8.893673984,
      8.894592931, 8.895511879, 8.896430826, 8.822559829, 8.817976437,
      8.813393051, 8.80880967, 8.804226294, 8.799642923, 8.795059558,
      8.790476198, 8.785892843, 8.775530142, 8.739379723, 8.728817729,
      8.722810727, 8.704745289, 8.698058108, 8.69160788, 8.68039193, 8.672155848,
      8.663919797, 8.655683775, 8.635175838, 8.626028627, 8.616881458,
      8.607734329, 8.593199574, 8.585612188, 8.567386878, 8.557898299,
      8.549937601, 8.537453277, 8.649710676, 8.648792489, 8.647874301,
      8.646956114, 8.646037926, 8.645119739, 8.644201551, 8.643283364,
      8.642365176, 8.641446989, 8.616073673, 8.613321452, 8.610569232,
      8.607817013, 8.605064796, 8.602312579, 8.599560364, 8.597090776,
      8.594077155, 8.591324942, 8.539709315, 8.533298452, 8.526887602,
      8.520476766, 8.514065944, 8.503957708, 8.498635417, 8.493394067,
      8.487896147, 8.470938309, 8.523033532, 8.520281347, 8.517529164,
      8.514776981, 8.512024799, 8.509272619, 8.506520439, 8.503768261,
      8.501016083, 8.498263907, 8.492042142, 8.489641738, 8.487277989,
      8.484950337, 8.482658232, 8.480401134, 8.478108884, 8.475356717,
      8.47260455, 8.469852384, 8.418445404, 8.412034795, 8.4056242, 8.399213617,
      8.392803048, 8.386392492, 8.379981949, 8.373571419, 8.367160903,
      8.360750399, 8.281524757, 8.269650747, 8.257776821, 8.245902979,
      8.23402922, 8.222155544, 8.203713935, 8.193858528, 8.173639592,
      8.161682236, 8.208171481, 8.199774931, 8.191378406, 8.179487238,
      8.172540978, 8.165700134, 8.146893641, 8.139514736, 8.132247739,
      8.125090969, 8.229873752, 8.229873752, 8.229873752, 8.229873752,
      8.229873752, 8.229873752, 8.229873752, 8.229873752, 8.229873752,
      8.229873752, 8.229873752, 8.229873752, 8.229873752, 8.229873752,
      8.229873752, 8.229873752, 8.229873752, 8.229873752, 8.229873752,
      8.242786801, 8.230810341, 8.230810341, 8.230810341, 8.230810341,
      8.230810341, 8.230810341, 8.230810341, 8.230810341, 8.230810341,
      8.230810341, 8.411598204, 8.424782939, 8.437967695, 8.451152471,
      8.464337267, 8.477522081, 8.490706911, 8.503891756, 8.516904864,
      8.529837577, 8.374339013, 8.375257961, 8.376176909, 8.377095857,
      8.378014805, 8.378933753, 8.379852701, 8.380771649, 8.381690597,
      8.382609545, 8.383528493, 8.384447441, 8.385366389, 8.386285337,
      8.387204285, 8.388123233, 8.389042181, 8.389961129, 8.390880077,
      8.391799025, 8.509390975, 8.518613823, 8.527836674, 8.537059528,
      8.546282385, 8.555505245, 8.564728107, 8.573950972, 8.583173838,
      8.592396707, 9.017643706, 9.056878401, 9.083081222, 9.121366578,
      9.15965187, 9.184859496, 9.222195893, 9.250689444, 9.283116554,
      9.319504387, 9.158631997, 9.169834801, 9.189202514, 9.210525346,
      9.23184809, 9.253170741, 9.274493294, 9.295815744, 9.313045349,
      9.324945868, 9.004575124, 8.989343183, 8.985757406, 8.982226308,
      8.97874906, 8.975324842, 8.971952851, 8.968632293, 8.965362386,
      8.954218108, 8.813490201, 8.798888713, 8.784287406, 8.762917047,
      8.750951792, 8.72736989, 8.711863195, 8.696356711, 8.680850437,
      8.665344373, 8.649838517, 8.628406092, 8.615759719, 8.591009396,
      8.574029125, 8.557619188, 8.541209491, 8.524800033, 8.508390814,
      8.488357388, 8.4508119, 8.432595784, 8.414379989, 8.396164515, 8.377949359,
      8.353836685, 8.339014744, 8.312224533, 8.291531747, 8.272415816,
      8.326295914, 8.312606469, 8.293601562, 8.282389469, 8.259204626,
      8.247607841, 8.229906365, 8.215311547, 8.200716885, 8.186122377,
      8.098906815, 8.078892976, 8.058513448, 8.032178443, 8.005163566,
      7.983836651, 7.962510095, 7.941183869, 7.919857943, 7.893918301,
      8.008772901, 7.997872538, 7.978800232, 7.969339688, 7.96002217,
      7.939859442, 7.929132649, 7.91949901, 7.903938437, 7.891832077,
      7.807912635, 7.790265512, 7.772618402, 7.752327941, 7.737118634,
      7.711888643, 7.689312161, 7.670744288, 7.652176329, 7.633608267,
      7.745819039, 7.737422848, 7.729026644, 7.720630427, 7.712234194,
      7.703837946, 7.692101506, 7.685130876, 7.678256604, 7.669860286,
      7.614055487, 7.601948554, 7.589841558, 7.577734496, 7.565627365,
      7.553520162, 7.541412884, 7.529305527, 7.515665065, 7.504969671,
      7.47245584, 7.461409436, 7.44205989, 7.428101231, 7.416240911, 7.400349281,
      7.386390142, 7.372430832, 7.358471345, 7.344511675, 7.447951758,
      7.443278686, 7.438605607, 7.433932521, 7.427628673, 7.423749623,
      7.419726992, 7.415053876, 7.410380752, 7.40570762, 7.283832089,
      7.269871354, 7.255910403, 7.241949231, 7.227987832, 7.214026204,
      7.196591607, 7.185092265, 7.171804886, 7.150816704, 7.255703155,
      7.251649326, 7.238330771, 7.232724964, 7.227119143, 7.222396909,
      7.217919162, 7.213509615, 7.209167238, 7.204891012, 7.101553535,
      7.08538034, 7.074635304, 7.062140394, 7.04188668, 7.03087476, 7.020029008,
      6.997744354, 6.986475393, 6.975376438, 7.060401221, 7.054795019,
      7.049188805, 7.043582579, 7.038969673, 7.032450264, 7.026844005,
      7.021237735, 7.015631454, 7.010025162, 6.888777969, 6.873886483,
      6.860455549, 6.844220598, 6.829328517, 6.812821483, 6.799413481,
      6.784520831, 6.764994041, 6.752622126, 6.901516801, 6.900070857,
      6.898647031, 6.897244983, 6.895864382, 6.8945049, 6.893166215, 6.891848008,
      6.890549968, 6.889271786, 6.888013159, 6.886773788, 6.885553379,
      6.884351643, 6.883168294, 6.882003051, 6.880855637, 6.879725781,
      6.878613213, 6.87751767, 6.818969566, 6.814118709, 6.809341732,
      6.804637517, 6.800004963, 6.795442985, 6.790950516, 6.783568381,
      6.770497952, 6.765454314, 6.817846081, 6.816745083, 6.815660933,
      6.814593374, 6.813542152, 6.812507018, 6.811487725, 6.810484031,
      6.809495698, 6.808522491, 6.79609727, 6.794393963, 6.792716702,
      6.791065089, 6.789438733, 6.777227079, 6.77442051, 6.772216853, 6.77101212,
      6.769862503, 7.020899292, 7.037859231, 7.054819635, 7.071780498,
      7.088741811, 7.105703568, 7.12266576, 7.139628381, 7.156591422,
      7.173554876, 6.959633043, 6.959168613, 6.958711295, 6.958260981,
      6.957817563, 6.957380936, 6.956950996, 6.956527641, 6.956110769,
      6.955700281, 6.840092827, 6.832133502, 6.82429489, 6.816575183,
      6.808972598, 6.801485378, 6.782613365, 6.774598438, 6.766705072,
      6.758931445, 6.854628107, 6.853899676, 6.853182397, 6.852476099,
      6.851780615, 6.851095778, 6.850421427, 6.8497574, 6.84910354, 6.848459691,
      6.792478598, 6.786143515, 6.781792756, 6.777508304, 6.773289157,
      6.769134323, 6.765042828, 6.761013711, 6.755360394, 6.752271746,
      6.749131295, 6.745344814, 6.732042138, 6.728732911, 6.725524426,
      6.722413637, 6.719397587, 6.71647341, 6.706227467, 6.6990669, 6.640742703,
      6.632686751, 6.626826366, 6.621143461, 6.604204127, 6.598280648,
      6.592536545, 6.575548242, 6.569566921, 6.563766716, 6.60377323,
      6.600647196, 6.597616373, 6.589741763, 6.58756574, 6.585488902,
      6.583506766, 6.580135329, 6.568362404, 6.566660472, 6.617954894,
      6.617954894, 6.617954894, 6.617954894, 6.617954894, 6.617954894,
      6.617954894, 6.617954894, 6.617954894, 6.617954894, 6.566355263,
      6.566072294, 6.56581003, 6.557445117, 6.557922599, 6.558355165,
      6.558747123, 6.553582561, 6.554550746, 6.551016036, 6.817177549,
      6.835078289, 6.852979695, 6.868261657, 6.882412932, 6.896344802,
      6.91083876, 6.927795486, 6.944752728, 6.961710479, 6.744693233,
      6.743080894, 6.743388484, 6.743663009, 6.743908032, 6.744126728,
      6.744321931, 6.744496167, 6.744651691, 6.744790516, 6.748647576,
      6.74860617, 6.748565398, 6.748525251, 6.74848572, 6.748446794, 6.748408464,
      6.748370722, 6.748333558, 6.748296963, 6.74826093, 6.748225448, 6.74819051,
      6.748156107, 6.748122232, 6.748088875, 6.74805603, 6.748023688,
      6.747991841, 6.747960483, 6.747929604, 6.747899199, 6.74786926, 6.74783978,
      6.747810751, 6.747782167, 6.747754021, 6.747726307, 6.747699017,
      6.747672145, 6.747645685, 6.74761963, 6.747593975, 6.747568713,
      6.747543837, 6.747519343, 6.747495224, 6.747471475, 6.74744809,
      6.747425063, 7.365819521, 7.413423168, 7.461037003, 7.508660569,
      7.556293417, 7.603935102, 7.651585182, 7.699243219, 7.746908779,
      7.79458143, 7.558068103, 7.580025178, 7.605563266, 7.631102262, 7.65664213,
      7.682182834, 7.705486696, 7.725684643, 7.745566257, 7.770079644,
      7.655876956, 7.670005087, 7.684133333, 7.69826169, 7.712390158,
      7.726518736, 7.740647421, 7.754776212, 7.768905108, 7.783034107,
      8.240635315, 8.288359036, 8.336086282, 8.383816861, 8.431550581,
      8.479287248, 8.527026665, 8.574768634, 8.622512955, 8.670259426,
      8.718007842, 8.765757998, 8.813509688, 8.861262703, 8.909016833,
      8.956771868, 9.00363421, 9.050489886, 9.09734594, 9.14420224, 9.191058662,
      9.237915086, 9.284771395, 9.331627474, 9.378483212, 9.425338499,
      9.472193224, 9.519047276, 9.565900543, 9.61275291, 9.65960426, 9.706454472,
      9.753303419, 9.80015097, 9.846996985, 9.893841319, 9.942212379,
      9.979230117, 9.999308021, 9.995570062, 9.443623567, 9.442668596,
      9.441713626, 9.440758656, 9.439803686, 9.438848716, 9.437893746,
      9.436938776, 9.435983806, 9.435028836, 9.540487823, 9.547192787,
      9.553897743, 9.560602692, 9.567307633, 9.574012567, 9.580717493,
      9.587422411, 9.594127321, 9.600832223, 9.412802719, 9.405182357,
      9.397562024, 9.389941721, 9.382321448, 9.374701204, 9.367080989,
      9.359460803, 9.351840645, 9.344220517, 9.160752908, 9.139906139,
      9.111609698, 9.085114606, 9.052113839, 9.028178346, 9.003438039,
      8.972691737, 8.947090372, 8.92400065, 8.851758163, 8.822932449, 8.78647614,
      8.755606179, 8.719343043, 8.686832066, 8.650391174, 8.616634343,
      8.579652388, 8.545036758, 8.544184422, 8.511203573, 8.475284625,
      8.441069293, 8.405501861, 8.369587317, 8.33333131, 8.301523396,
      8.260097108, 8.226942916, 8.271018079, 8.242433589, 8.216125412,
      8.184108337, 8.150917662, 8.123717189, 8.095329517, 8.061506074,
      8.02933518, 8.001244777, 8.10358516, 8.087550151, 8.061715389, 8.046405968,
      8.019253988, 8.003665366, 7.980312744, 7.960823943, 7.945030918,
      7.922131878, 7.938056342, 7.921930918, 7.899181258, 7.885394625,
      7.871084138, 7.846410156, 7.83249815, 7.818795076, 7.793336397,
      7.779303472, 7.852043994, 7.841791147, 7.83262474, 7.824450943,
      7.816400924, 7.801499222, 7.791246337, 7.780993441, 7.771818429,
      7.763639715, 7.707978802, 7.689389277, 7.675432462, 7.662727299,
      7.651578469, 7.640597694, 7.620532429, 7.606687124, 7.59546126,
      7.584404585, 7.565367534, 7.550437998, 7.539138163, 7.528008606,
      7.509949351, 7.493988861, 7.482617979, 7.471418421, 7.454288906,
      7.437348221, 7.473032472, 7.464748943, 7.456590827, 7.442913118,
      7.428519193, 7.419983809, 7.411577604, 7.40329865, 7.395145047,
      7.381145095, 7.343611948, 7.321854403, 7.311233993, 7.300773802,
      7.290471456, 7.276945522, 7.258408888, 7.247822609, 7.237396054,
      7.22712686, 7.146910434, 7.132477513, 7.118261039, 7.099986116,
      7.078535008, 7.064209193, 7.044289345, 7.024191136, 7.009762038,
      6.988301681, 7.023709142, 7.004878648, 6.994977376, 6.98239294,
      6.966459626, 6.948582274, 6.937570334, 6.925883047, 6.90890242,
      6.900242394, 6.926512818, 6.920086362, 6.902305466, 6.895686779,
      6.884949884, 6.871290228, 6.864684992, 6.858279352, 6.844054882,
      6.839587326, 6.789255112, 6.772074751, 6.754756105, 6.748806488,
      6.731627648, 6.722788036, 6.708105085, 6.693391773, 6.685651722,
      6.675491156, 6.831063724, 6.832000626, 6.832937529, 6.833874432,
      6.834811334, 6.835748237, 6.83668514, 6.837622043, 6.838558946,
      6.839495849, 6.716610344, 6.704613244, 6.703590406, 6.693243224,
      6.694370625, 6.688231553, 6.679248102, 6.677543471, 6.675652914,
      6.678759535, 6.957945946, 6.973957055, 6.989968576, 7.005980504,
      7.009610069, 7.024675834, 7.039741922, 7.054808329, 7.06987505, 7.08494208,
      6.811686105, 6.809149759, 6.809090197, 6.811137528, 6.813538125,
      6.81913059, 6.821699377, 6.810424663, 6.810174273, 6.809942071,
      6.862980013, 6.863916918, 6.864853823, 6.865790729, 6.866727634,
      6.86766454, 6.868601445, 6.869538351, 6.870475256, 6.871412162,
      7.245993196, 7.273789221, 7.303131707, 7.332476339, 7.361823048,
      7.378722602, 7.407116571, 7.43551225, 7.463909581, 7.49129637, 7.770613821,
      7.818289838, 7.865972302, 7.913660787, 7.961354864, 8.009054107,
      8.056758091, 8.104466497, 8.152179138, 8.199895832, 8.247616397,
      8.295340646, 8.343068391, 8.390799442, 8.438533605, 8.486270687,
      8.53401049, 8.581752815, 8.629497463, 8.677244231, 8.724992915,
      8.772743309, 8.820495206, 8.868248397, 8.916002672, 8.963633262,
      9.010488508, 9.057344248, 9.104200346, 9.151056672, 8.859108475,
      8.881368042, 8.900242325, 8.912588963, 8.933912477, 8.955235967,
      8.967656434, 8.984160539, 9.004548673, 9.02493677, 8.874818187,
      8.883115394, 8.891412597, 8.899709797, 8.908006994, 8.916304187,
      8.913288096, 8.919150142, 8.926350908, 8.933723217, 8.762085943,
      8.756588232, 8.75109053, 8.745592837, 8.740095153, 8.734597478,
      8.729099812, 8.723602155, 8.718104507, 8.712606868, 8.793924074,
      8.794843022, 8.79576197, 8.796680918, 8.797599865, 8.798518813,
      8.799437761, 8.800356708, 8.801275656, 8.802194604, 8.71627196,
      8.710774324, 8.705276697, 8.699779079, 8.694281469, 8.688783869,
      8.683286277, 8.677788694, 8.672291121, 8.666793555, 9.075653138,
      9.098910504, 9.11073179, 9.133927682, 9.143978679, 9.166237694,
      9.175783947, 9.196688624, 9.209165284, 9.225524046, 9.509830771,
      9.53585048, 9.547678664, 9.567911316, 9.579544726, 9.599821609,
      9.607364491, 9.623384168, 9.63984875, 9.642441314, 9.723832913, 9.72904142,
      9.73226951, 9.733521725, 9.732802591, 9.730116614, 9.725468281,
      9.718862055, 9.710423624, 9.699802365, 9.647052733, 9.643206237,
      9.638394324, 9.632618083, 9.625878603, 9.618176968, 9.609514262,
      9.599891566, 9.589309959, 9.577770519, 9.552667174, 9.551712197,
      9.55075722, 9.549802243, 9.536241491, 9.534332225, 9.53242296, 9.530513695,
      9.528604431, 9.526695167, 9.524785903, 9.52287664, 9.520967378,
      9.519058116, 9.517148854, 9.515239593, 9.513330333, 9.511421072,
      9.509511813, 9.507602554, 9.505693295, 9.503784037, 9.501874779,
      9.499965522, 9.498056265, 9.496147009, 9.494237753, 9.492328497,
      9.490419242, 9.488509988, 9.486600734, 9.48469148, 9.482782227,
      9.480872975, 9.478963723, 9.477054471, 9.47514522, 9.473235969,
      9.471326719, 9.469417469, 9.46750822, 9.465598971, 9.463689722,
      9.461780474, 9.459871227, 9.45796198, 9.456052733, 9.454143487,
      9.452234241, 9.450324996, 9.448415751, 9.446506507, 9.444597263,
      9.44268802, 9.440778777, 9.438869534, 9.436960292, 9.435051051, 9.43314181,
      9.431232569, 9.429323329, 9.427414089, 9.42550485, 9.423595611,
      9.421686372, 9.419777134, 9.417867897, 9.41595866, 9.414049423,
      9.412140187, 9.410230951, 9.408321716, 9.406412481, 9.404503246,
      9.402594012, 9.400684779, 9.398775546, 9.396866313, 9.394957081,
      9.393047849, 9.391138617, 9.389229387, 9.387320156, 9.385410926,
      9.383501696, 9.381592467, 9.379683238, 9.37777401, 9.375864782,
      9.373955555, 9.372046328, 9.370137101, 9.368227875, 9.366318649,
      9.364409424, 9.362500199, 9.360590975, 9.358681751, 9.356772527,
      9.354863304, 9.352954081, 9.351044859, 9.349135637, 9.347226416,
      9.345317195, 9.343407974, 9.341498754, 9.339589534, 9.337680315,
      9.335771096, 9.333861878, 9.33195266, 9.330043442, 9.328134225,
      9.326225008, 9.324315792, 9.322406576, 9.320497361, 9.318588145,
      9.316678931, 9.314769717, 9.312860503, 9.310951289, 9.309042076,
      9.307132864, 9.305223652, 9.30331444, 9.301405229, 9.299496018,
      9.297586807, 9.295677597, 9.293768387, 9.291859178, 9.289949969,
      9.288040761, 9.286131553, 9.284222345, 9.282313138, 9.280403931,
      9.278494725, 9.276585519, 9.274676313, 9.272767108, 9.270857903,
      9.268948699, 9.267039495, 9.265130292, 9.263221089, 9.261311886,
      9.259402684, 9.257493482, 9.25558428, 9.253675079, 9.251765878,
      9.249856678, 9.247947478, 9.246038279, 9.24412908, 9.242219881,
      9.240310683, 9.238401485, 9.236492287, 9.234607813, 9.232772102,
      9.230936392, 9.229100682, 9.227264973, 9.225429264, 9.223593556,
      9.221757848, 9.21992214, 9.218086433, 9.216250726, 9.214415019,
      9.212579313, 9.210743607, 9.208907902, 9.207072197, 9.205236493,
      9.203400788, 9.201565085, 9.199729381, 9.197893678, 9.196057976,
      9.194222274, 9.192386572, 9.19055087, 9.188715169, 9.186879469,
      9.185043768, 9.183208069, 9.181372369, 9.17953667, 9.177700971,
      9.175865273, 9.174029575, 9.172193878, 9.170358181, 9.168522484,
      9.166686787, 9.164851091, 9.163015396, 9.161179701, 9.159344006,
      9.157508311, 9.155672617, 9.153836924, 9.15200123, 9.150165537,
      9.148329845, 9.146494153, 9.144658461, 9.14282277, 9.140987079,
      9.139151388, 9.137315698, 9.135480008, 9.133644318, 9.131808629,
      9.129972941, 9.128137252, 9.126301564, 9.124465877, 9.122630189,
      9.120794503, 9.118958816, 9.11712313, 9.115287444, 9.113451759,
      9.111616074, 9.109780389, 9.107944705, 9.106109021, 9.104273338,
      9.102437655, 9.100601972, 9.09876629, 9.096930608, 9.095094926,
      9.093259245, 9.091423564, 9.089587884, 9.087752204, 9.085916524,
      9.084080844, 9.082245165, 9.080409487, 9.078573809, 9.076738131,
      9.074902453, 9.073066776, 9.071231099, 9.069395423, 9.067559747,
      9.065724071, 9.063888396, 9.062052721, 9.060217046, 9.058381372,
      9.056545698, 9.054710025, 9.052874352, 9.051038679, 9.049203007,
      9.047367335, 9.045531663, 9.043695992, 9.041860321, 9.04002465, 9.03818898,
      9.03635331, 9.034517641, 9.032681971, 9.030846303, 9.029010634,
      9.027174966, 9.025339299, 9.023503631, 9.021667964, 9.019832298,
      9.017996632, 9.016160966, 9.0143253, 9.012489635, 9.01065397, 9.008818306,
      9.006982642, 9.005146978, 9.003311315, 9.001475652, 8.999639989,
      8.997804327, 8.995968665, 8.994133003, 8.992297342, 8.990461681,
      8.988626021, 8.986790361, 8.984954701, 8.983119042, 8.968908855,
      8.966156489, 8.963404124, 8.960651761, 8.957899398, 8.955147037,
      8.952394677, 8.949642318, 8.946889961, 8.934518121, 8.903582481,
      8.885723787, 8.872874704, 8.860068128, 8.84039132, 8.830361879,
      8.811439691, 8.791778857, 8.780026898, 8.757634944, 8.746666584,
      8.723374002, 8.711496715, 8.687305112, 8.667918234, 8.648941156,
      8.622950729, 8.608351533, 8.581466982, 8.561874531, 8.611515663,
      8.600548266, 8.581002197, 8.565716183, 8.553840105, 8.541964116,
      8.530088216, 8.509545825, 8.493457118, 8.480673438, 8.419003004,
      8.392905822, 8.373257433, 8.353333425, 8.327226239, 8.308106861,
      8.286142194, 8.259230853, 8.24011553, 8.208848705, 8.213118851,
      8.194906833, 8.171804412, 8.145997527, 8.126884306, 8.102360786,
      8.076134571, 8.055724936, 8.035315685, 8.002831009, 8.044796218,
      8.03157624, 8.009091406, 7.992364784, 7.975638301, 7.954252367,
      7.940556466, 7.915051202, 7.895498487, 7.877851094, 7.860203783,
      7.842556541, 7.820417034, 7.794945405, 7.779107537, 7.758021887,
      7.737515271, 7.720735744, 7.695644524, 7.680326117, 7.915307815,
      7.916244769, 7.917181722, 7.918118676, 7.919055629, 7.919992583,
      7.920929536, 7.92186649, 7.922803444, 7.923740397, 7.840400299,
      7.834795515, 7.829190728, 7.823585939, 7.817981147, 7.812376352,
      7.806771554, 7.801166754, 7.79556195, 7.789957142, 8.136553193,
      8.157334332, 8.167504595, 8.185323016, 8.205152488, 8.224982133,
      8.244811945, 8.264641919, 8.284472048, 8.291466089, 8.348875608,
      8.370611706, 8.379487461, 8.400270719, 8.421054109, 8.441837624,
      8.462621255, 8.47331563, 8.490541078, 8.510372518, 8.620675325,
      8.634255164, 8.65981302, 8.685084425, 8.704702495, 8.721871433,
      8.746005097, 8.770138812, 8.781277952, 8.804474241, 8.417199272,
      8.410788665, 8.404378072, 8.397967492, 8.391556926, 8.385146372,
      8.378735832, 8.372325305, 8.365914791, 8.35950429, 8.451028208,
      8.451947157, 8.452866105, 8.453785053, 8.454704001, 8.45562295,
      8.456541898, 8.457460846, 8.458379794, 8.459298742, 8.327409713,
      8.320217421, 8.313134207, 8.306158432, 8.290546879, 8.281401152,
      8.272588434, 8.265318604, 8.258159011, 8.251107999, 8.272904243,
      8.266493931, 8.260083632, 8.253673345, 8.247171645, 8.240635305,
      8.234098978, 8.227562662, 8.221026359, 8.214490068, 8.207953788,
      8.20141752, 8.194881262, 8.188345016, 8.18180878, 8.175272554, 8.168736338,
      8.162200132, 8.155663936, 8.149127749, 8.106433984, 8.097108819,
      8.088704879, 8.0812816, 8.073970885, 8.060445568, 8.051120513, 8.041795478,
      8.032470461, 8.024811144, 7.897309487, 7.875530187, 7.856962217,
      7.838394335, 7.819826523, 7.799075017, 7.772076117, 7.756528724,
      7.732116025, 7.71262853, 7.752784514, 7.733735406, 7.721517162,
      7.697573964, 7.684979866, 7.672575202, 7.64953348, 7.635760427,
      7.618084463, 7.602280354, 7.633323646, 7.621765715, 7.60194368,
      7.591711603, 7.581633974, 7.571708495, 7.55010437, 7.539731727,
      7.529515615, 7.519453712, 7.46231698, 7.437781701, 7.424495592,
      7.402034963, 7.386144646, 7.372715028, 7.35223526, 7.335505568,
      7.318775568, 7.302045251, 7.399382244, 7.383210386, 7.374812972,
      7.367850378, 7.36116118, 7.354573513, 7.348085851, 7.341696692,
      7.335404556, 7.31858039, 7.275613447, 7.266615446, 7.252966899,
      7.241783553, 7.230600092, 7.218961045, 7.209894747, 7.197148258,
      7.185964347, 7.171222405, 7.326829111, 7.328231933, 7.329613223,
      7.330973313, 7.33519346, 7.337068021, 7.338942582, 7.340817144,
      7.342691706, 7.344566268, 7.176537678, 7.167187909, 7.15797953,
      7.148910437, 7.139978559, 7.119541687, 7.110128834, 7.100858336,
      7.091728076, 7.082735966, 7.233252626, 7.235127167, 7.237001708,
      7.238876249, 7.240750791, 7.242625334, 7.244499876, 7.246374419,
      7.248248963, 7.250123507, 6.985858242, 6.968769311, 6.95058834,
      6.926352572, 6.910636354, 6.883569308, 6.867576695, 6.844427124,
      6.824263124, 6.808241634, 6.746270654, 6.724439614, 6.697765145,
      6.672963862, 6.647050249, 6.621006717, 6.594837203, 6.56854552,
      6.542135368, 6.515610333, 6.488973891, 6.462229414, 6.435380173,
      6.408429337, 6.381379982, 6.357554551, 6.32716562, 6.30130628, 6.278775207,
      6.245302076, 6.210903409, 6.187894902, 6.153455261, 6.126640398,
      6.094737011, 6.066627688, 6.036572371, 6.006471904, 5.976328873,
      5.946145699, 6.095233078, 6.082706339, 6.066867741, 6.059344379,
      6.049302743, 6.032666509, 6.028180451, 6.03208411, 6.037649533,
      6.034611369, 6.364345747, 6.378959058, 6.393346294, 6.407510973,
      6.424269454, 6.441547376, 6.458825786, 6.476104693, 6.493384107,
      6.510664036, 6.919559881, 6.967987207, 7.016426515, 7.064878344,
      7.112536827, 7.160078299, 7.207632494, 7.25519892, 7.302777091,
      7.350366532, 7.397966773, 7.44557735, 7.493197806, 7.54082769, 7.588466554,
      7.636113956, 7.683769458, 7.731432623, 7.779103019, 7.826780215,
      7.636277474, 7.665641919, 7.693020657, 7.716296604, 7.740416872,
      7.76882844, 7.797045112, 7.819649993, 7.840983796, 7.868441731,
      7.541950092, 7.542887035, 7.543823978, 7.544760921, 7.545697864,
      7.546634807, 7.547571751, 7.548508694, 7.549445637, 7.55038258,
      6.974505333, 6.930460482, 6.874693454, 6.829736208, 6.773285161,
      6.727236901, 6.681357481, 6.656490688, 6.597256249, 6.545812294,
      7.252844567, 7.266022186, 7.279199968, 7.292377908, 7.305556005,
      7.318734256, 7.331912659, 7.34509121, 7.356369024, 7.36674805, 7.221356602,
      7.222293532, 7.223230461, 7.224167391, 7.225104321, 7.22604125, 7.22697818,
      7.22791511, 7.22885204, 7.229788969, 7.844468614, 7.892154437, 7.939846044,
      7.987543011, 8.035244908, 8.082951345, 8.130662099, 8.178376988,
      8.22609583, 8.273818441, 8.131029699, 8.164251134, 8.19161491, 8.217521589,
      8.249784612, 8.269285149, 8.300588938, 8.331344933, 8.350358551,
      8.380704077, 8.37258147, 8.400051167, 8.422161381, 8.441741673,
      8.468254853, 8.485583611, 8.507721127, 8.533278181, 8.558835433,
      8.571477523, 8.805837772, 8.843086044, 8.869643455, 8.898985401,
      8.928600147, 8.956649037, 8.980031319, 9.014227623, 9.037790858,
      9.059237775, 9.001355286, 9.0152335, 9.041244424, 9.054162043, 9.079233875,
      9.092176895, 9.115395526, 9.139528912, 9.150520029, 9.173715778,
      9.525928452, 9.572781594, 9.600897046, 9.623339371, 9.642875988,
      9.658458474, 9.672106521, 9.697104947, 9.707844673, 9.71666147, 9.53787421,
      9.543778985, 9.548707161, 9.566020974, 9.569967024, 9.586312584,
      9.58927803, 9.597687238, 9.60614228, 9.607156758, 9.62060223, 9.620640624,
      9.633120898, 9.632184706, 9.630293678, 9.640832959, 9.637956421,
      9.647545652, 9.64369897, 9.652325998, 9.528402229, 9.527702468,
      9.527013421, 9.526334923, 9.525666814, 9.525008935, 9.524361128,
      9.51334082, 9.512403206, 9.511494271, 9.51061314, 9.509758963, 9.508930919,
      9.508128207, 9.507350056, 9.506595713, 9.505864453, 9.50515557, 9.50446838,
      9.503802219, 9.517004438, 9.517004438, 9.517004438, 9.510080442,
      9.509661242, 9.509248462, 9.508842004, 9.508441771, 9.508047668,
      9.507659601, 9.475886611, 9.474188264, 9.46746341, 9.466257329,
      9.465106385, 9.464008071, 9.450377749, 9.449002787, 9.447690634,
      9.445693136, 9.510159756, 9.51207184, 9.513983924, 9.515896008,
      9.517808092, 9.519720175, 9.521632259, 9.523544342, 9.525456425,
      9.523535436, 9.542435787, 9.545304992, 9.548174196, 9.537612044,
      9.539524125, 9.541436207, 9.543348288, 9.545260369, 9.54717245, 9.54908453,
      9.550996611, 9.552908691, 9.554820771, 9.556732851, 9.545205656,
      9.546161336, 9.547117016, 9.548072696, 9.549028376, 9.549984056,
      9.526429378, 9.525759823, 9.52510052, 9.524451311, 9.523812042,
      9.523182562, 9.52256272, 9.52195237, 9.521351365, 9.520759563, 9.529659824,
      9.529659824, 9.529659824, 9.529659824, 9.529659824, 9.529659824,
      9.529659824, 9.529659824, 9.529659824, 9.529659824, 9.510693821,
      9.509837176, 9.509006738, 9.508201707, 9.507421307, 9.498550064,
      9.497823426, 9.497130081, 9.496468507, 9.495837253, 9.463645518,
      9.45727665, 9.444734865, 9.440919955, 9.429321494, 9.428527219,
      9.417030194, 9.419838063, 9.408421724, 9.399120414, 9.560351782,
      9.567056723, 9.560964504, 9.566131306, 9.571876216, 9.577621121,
      9.58336602, 9.575680397, 9.580466004, 9.585251608, 9.603473129,
      9.609218006, 9.614962877, 9.607265349, 9.612050936, 9.603390533,
      9.607217561, 9.611044588, 9.601421317, 9.604290508, 9.566802351,
      9.566802351, 9.566802351, 9.566802351, 9.566802351, 9.566802351,
      9.566802351, 9.566802351, 9.566802351, 9.566802351, 9.562405908,
      9.562140185, 9.561878533, 9.561620888, 9.56136719, 9.561117378,
      9.560871394, 9.560629177, 9.560390671, 9.560155818, 9.556157516,
      9.555817594, 9.555488083, 9.555168663, 9.554859025, 9.554558871,
      9.554267909, 9.553985859, 9.553712448, 9.553447411, 9.550431416,
      9.550184719, 9.549949349, 9.549724788, 9.549510539, 9.549306129,
      9.547030945, 9.546910389, 9.546797205, 9.546690944, 9.566498741,
      9.567454421, 9.5684101, 9.569365779, 9.570321459, 9.571277138, 9.558783381,
      9.558783381, 9.558783381, 9.558783381, 9.553234997, 9.552984584,
      9.552741842, 9.552506535, 9.552278435, 9.552057323, 9.551842984,
      9.55163521, 9.54927129, 9.549077868, 9.54889333, 9.548717267, 9.548549292,
      9.548389032, 9.548236134, 9.54809026, 9.547951086, 9.547818307,
      9.546341005, 9.546262655, 9.564396014, 9.565351693, 9.566307373,
      9.567263052, 9.568218732, 9.569174411, 9.556681444, 9.556681444,
      9.556681444, 9.556681444, 9.551983265, 9.551771195, 9.551565621,
      9.551366344, 9.551173171, 9.550985917, 9.550804398, 9.550628441,
      9.550457874, 9.550292532, 9.550132256, 9.54997689, 9.549826283,
      9.549680291, 9.549538772, 9.549401588, 9.549268607, 9.549139701,
      9.549014744, 9.548893615, 9.54373491, 9.543857007, 9.543967859,
      9.543124858, 9.543332693, 9.542766168, 9.543047635, 9.542715625,
      9.542540109, 9.542926541, 9.542895883, 9.54326097, 9.543564512,
      9.543611194, 9.543877923, 9.544095603, 9.544273255, 9.544326989,
      9.54447335, 9.544590556, 9.693181614, 9.690285284, 9.699874381,
      9.696007959, 9.704634874, 9.699799828, 9.7074653, 9.70166309, 9.694897682,
      9.700642468, 9.706387249, 9.712132023, 9.704398052, 9.695703048,
      9.686048085, 9.675434236, 9.681536442, 9.673496786, 9.66424577,
      9.664499129, 9.658564736, 9.655695448, 9.655695448, 9.655695448,
      9.655695448, 9.655695448, 9.655695448, 9.655695448, 9.655695448,
      9.655695448, 9.661776937, 9.662021444, 9.662258453, 9.662488195,
      9.662710893, 9.662926762, 9.663136012, 9.663338847, 9.663535463,
      9.66372605, 9.704372138, 9.707720536, 9.709693773, 9.710115227,
      9.698835974, 9.700748037, 9.727083635, 9.740578133, 9.749585177,
      9.758687178, 9.770706489, 9.769078217, 9.789688471, 9.800513274,
      9.807599132, 9.809875836, 9.812046486, 9.812392301, 9.810752807,
      9.819935666, 9.817211086, 9.814776788, 9.812602035, 9.817442242,
      9.814628064, 9.817380644, 9.814221255, 9.815378987, 9.815461364,
      9.81465475, 9.802015366, 9.799130053, 9.796879961, 9.795069065,
      9.792090135, 9.790800162, 9.789556468, 9.788296745, 9.788296745,
      9.788296745, 9.788296745, 9.788296745, 9.788296745, 9.788296745,
      9.788296745, 9.762925598, 9.735646435, 9.706463197, 9.662698208,
      9.628769646, 9.757726492, 9.757726492, 9.732376409, 9.717792709,
      9.702256333, 9.685768278, 9.655659131, 9.636320041, 9.616033292,
      9.594799907, 9.559961811, 9.53589096, 9.510877634, 9.483937006,
      9.445312828, 9.416534757, 9.386819651, 9.355922731, 9.311948588,
      9.278489034, 9.458304857, 9.45163451, 9.432368623, 9.412155389,
      9.403585546, 9.382429187, 9.360327623, 9.349861191, 9.326819409,
      9.306152628, 9.303292293, 9.287393678, 9.26756785, 9.242654503,
      9.229349141, 9.203500155, 9.176711587, 9.161517352, 9.133796249,
      9.110662465, 9.138535628, 9.125231402, 9.099422623, 9.085173798,
      9.058760813, 9.042213023, 9.016945492, 8.993364766, 8.972881642,
      8.944020715, 8.789884267, 8.750230308, 8.711236012, 8.680789721,
      8.639383612, 8.597096943, 8.553931106, 8.518114899, 8.477910246,
      8.433005675, 8.53497636, 8.499048712, 8.474526097, 8.437722416,
      8.412069322, 8.37460891, 8.346514509, 8.309614071, 8.270181347,
      8.242081032, 8.201780119, 8.17278838, 8.131621357, 8.101739351,
      8.059708334, 8.019517173, 7.985342296, 7.945122627, 7.909190616,
      7.863907591, 8.010918868, 7.982014627, 7.957393108, 7.936066956,
      7.902703957, 7.880460966, 7.858218239, 7.823968025, 7.800809199,
      7.777650551, 7.838330975, 7.821605239, 7.804879527, 7.781321728,
      7.758949869, 7.741302746, 7.723655597, 7.701077737, 7.676061191,
      7.657493258, 7.769819933, 7.761423777, 7.750324416, 7.732530988,
      7.723205971, 7.713880935, 7.70455588, 7.695230804, 7.682110673,
      7.664418635, 7.499994823, 7.470341146, 7.443087887, 7.419926616,
      7.396764826, 7.361793316, 7.337714302, 7.313634559, 7.289554039,
      7.253705247, 7.393301271, 7.381192708, 7.360942865, 7.344588686,
      7.331553815, 7.318518784, 7.305483589, 7.292448226, 7.274602533,
      7.25428678, 7.240325581, 7.226364156, 7.212402501, 7.19844062, 7.184004165,
      7.161021516, 7.144094788, 7.129207274, 7.114319502, 7.099431475,
      7.154398457, 7.145070437, 7.13247569, 7.11452122, 7.10426434, 7.094007383,
      7.083750349, 7.073493238, 7.063236051, 7.05297879, 7.065925908,
      7.048184397, 7.04077865, 7.027773611, 7.018444818, 7.009115971,
      6.999787071, 6.990458119, 6.981129115, 6.97180006, 6.934312268,
      6.916186806, 6.90407311, 6.891959307, 6.879845398, 6.867731383,
      6.855617265, 6.843503044, 6.831388723, 6.811778034, 6.824506525,
      6.807405677, 6.796218548, 6.785031346, 6.77384407, 6.762656722,
      6.751469303, 6.740281815, 6.729094257, 6.70877969, 6.671552023,
      6.657583336, 6.643614524, 6.629645587, 6.615676528, 6.60170735,
      6.585221451, 6.573563834, 6.550941396, 6.533492713, 6.618303796,
      6.603180187, 6.595709933, 6.589224831, 6.580849982, 6.573379683,
      6.565909368, 6.558439039, 6.550968695, 6.543498337, 6.558815464,
      6.55320849, 6.54760151, 6.541994524, 6.536387532, 6.530780535, 6.525173532,
      6.514862907, 6.509988558, 6.496297067, 6.569363807, 6.569363807,
      6.569363807, 6.569363807, 6.569363807, 6.569363807, 6.569363807,
      6.569363807, 6.569363807, 6.569363807, 6.569363807, 6.569363807,
      6.569363807, 6.569363807, 6.569363807, 6.569363807, 6.569363807,
      6.569363807, 6.569363807, 6.569363807, 6.569363807, 6.569363807,
      6.569363807, 6.569363807, 6.569363807, 6.569363807, 6.569363807,
      6.569363807, 6.569363807, 6.569363807, 6.467013444, 6.458612269,
      6.450211076, 6.441809866, 6.433408639, 6.425007396, 6.416606136,
      6.40820486, 6.399715017, 6.391394978, 6.382981003, 6.367671157,
      6.360205268, 6.344939219, 6.335420475, 6.32590171, 6.316382922,
      6.306864111, 6.297345278, 6.28782642, 6.391474671, 6.391474671,
      6.391474671, 6.391474671, 6.391474671, 6.391474671, 6.391474671,
      6.391474671, 6.391474671, 6.391474671, 6.391474671, 6.391474671,
      6.391474671, 6.391474671, 6.391474671, 6.391474671, 6.391474671,
      6.391474671, 6.391474671, 6.391474671, 6.391474671, 6.391474671,
      6.391474671, 6.391474671, 6.391474671, 6.391474671, 6.391474671,
      6.391474671, 6.391474671, 6.391474671, 6.477304097, 6.484004614,
      6.490705166, 6.497405752, 6.504106372, 6.510807028, 6.517507718,
      6.524208444, 6.530909205, 6.537610002, 6.458347099, 6.458347099,
      6.458347099, 6.458347099, 6.458347099, 6.458347099, 6.458347099,
      6.458347099, 6.458347099, 6.458347099, 6.454919902, 6.454683749,
      6.454451213, 6.45422224, 6.453996775, 6.453774763, 6.453556153,
      6.445076678, 6.444121702, 6.443166726, 6.453550808, 6.453550808,
      6.453550808, 6.453550808, 6.453550808, 6.453550808, 6.453550808,
      6.453550808, 6.453550808, 6.453550808, 6.44221175, 6.441256775,
      6.440301799, 6.439346823, 6.438391847, 6.437436871, 6.436481895,
      6.435526919, 6.434571943, 6.433616967, 6.262627802, 6.247430792,
      6.232233689, 6.217036489, 6.20183919, 6.186641787, 6.171444278,
      6.152226338, 6.129419295, 6.115029398, 6.169625834, 6.161379557,
      6.144969416, 6.134501953, 6.124034447, 6.113566899, 6.103099307,
      6.092631671, 6.082163989, 6.071696261, 6.151173974, 6.148311042,
      6.145448108, 6.142585174, 6.139722238, 6.136859302, 6.133996365,
      6.131133427, 6.128270487, 6.125407547, 5.954048035, 5.936960856,
      5.919873454, 5.902785824, 5.88569796, 5.867741404, 5.851447914,
      5.828487278, 5.805587296, 5.788117138, 5.981848328, 5.981848328,
      5.981848328, 5.981848328, 5.981848328, 5.981848328, 5.981848328,
      5.981848328, 5.981848328, 5.981848328, 5.840411292, 5.824565522,
      5.812201598, 5.799837568, 5.787473429, 5.775109181, 5.76274482,
      5.750380346, 5.73722511, 5.725583539, 5.857914297, 5.857914297,
      5.857914297, 5.857914297, 5.857914297, 5.857914297, 5.857914297,
      5.857914297, 5.857914297, 5.857914297, 5.80226215, 5.797493574,
      5.792724992, 5.787956402, 5.783187806, 5.778419203, 5.773650592,
      5.768881975, 5.76411335, 5.759344719, 5.75457608, 5.749807434, 5.745038781,
      5.74027012, 5.735501453, 5.730732778, 5.725964095, 5.717097776, 5.71289106,
      5.708748522, 5.809960465, 5.813785336, 5.81761021, 5.821435086,
      5.825259965, 5.829084847, 5.832909731, 5.836734619, 5.840559508,
      5.844384401, 5.799771982, 5.799771982, 5.799771982, 5.799771982,
      5.799771982, 5.799771982, 5.799771982, 5.799771982, 5.799771982,
      5.799771982, 5.799771982, 5.799771982, 5.799771982, 5.799771982,
      5.799771982, 5.799771982, 5.799771982, 5.799771982, 5.799771982,
      5.799771982, 5.799771982, 5.799771982, 5.799771982, 5.799771982,
      5.799771982, 5.799771982, 5.799771982, 5.799771982, 5.799771982,
      5.799771982, 5.799771982, 5.799771982, 5.799771982, 5.799771982,
      5.799771982, 5.799771982, 5.799771982, 5.799771982, 5.799771982,
      5.799771982, 5.680452041, 5.672057317, 5.66379006, 5.655648355,
      5.637594482, 5.62793249, 5.619388101, 5.610973436, 5.596396099,
      5.585925353, 5.697304265, 5.697304265, 5.697304265, 5.697304265,
      5.697304265, 5.697304265, 5.697304265, 5.697304265, 5.697304265,
      5.697304265, 5.697304265, 5.697304265, 5.697304265, 5.697304265,
      5.697304265, 5.697304265, 5.697304265, 5.697304265, 5.697304265,
      5.697304265, 5.697304265, 5.697304265, 5.697304265, 5.697304265,
      5.697304265, 5.697304265, 5.697304265, 5.697304265, 5.697304265,
      5.697304265, 5.697304265, 5.697304265, 5.697304265, 5.697304265,
      5.697304265, 5.697304265, 5.697304265, 5.697304265, 5.697304265,
      5.697304265, 5.745645577, 5.749470408, 5.753295241, 5.757120076,
      5.768917013, 5.772509936, 5.776047663, 5.779531045, 5.782960919,
      5.786338108, 5.738294602, 5.738294602, 5.738294602, 5.738294602,
      5.738294602, 5.738294602, 5.738294602, 5.738294602, 5.738294602,
      5.738294602, 5.738294602, 5.738294602, 5.738294602, 5.738294602,
      5.738294602, 5.738294602, 5.738294602, 5.738294602, 5.738294602,
      5.738294602, 5.738294602, 5.738294602, 5.738294602, 5.738294602,
      5.738294602, 5.738294602, 5.738294602, 5.738294602, 5.738294602,
      5.738294602, 5.738294602, 5.738294602, 5.738294602, 5.738294602,
      5.738294602, 5.738294602, 5.738294602, 5.738294602, 5.738294602,
      5.738294602, 5.738294602, 5.738294602, 5.738294602, 5.738294602,
      5.738294602, 5.738294602, 5.738294602, 5.738294602, 5.738294602,
      5.738294602, 5.619038471, 5.606062025, 5.595591358, 5.585120606,
      5.573736792, 5.564100388, 5.553629377, 5.53678937, 5.527734684,
      5.518817404, 5.632223113, 5.632223113, 5.632223113, 5.632223113,
      5.632223113, 5.632223113, 5.632223113, 5.632223113, 5.632223113,
      5.632223113, 5.587998293, 5.58429017, 5.581158965, 5.578075589,
      5.575039314, 5.56930018, 5.56548378, 5.561667376, 5.557850966, 5.554034553,
      5.59439461, 5.59439461, 5.59439461, 5.59439461, 5.59439461, 5.59439461,
      5.59439461, 5.59439461, 5.59439461, 5.59439461, 5.59439461, 5.59439461,
      5.59439461, 5.59439461, 5.59439461, 5.59439461, 5.59439461, 5.59439461,
      5.59439461, 5.59439461, 5.472909303, 5.45938811, 5.450561299, 5.441132201,
      5.421842327, 5.412167959, 5.402640473, 5.393257663, 5.373643171,
      5.363110685, 5.438206607, 5.434230829, 5.430255046, 5.426279259,
      5.422303467, 5.414053383, 5.41043378, 5.406869466, 5.403359597,
      5.399903346, 5.441250437, 5.441250437, 5.441250437, 5.441250437,
      5.441250437, 5.441250437, 5.441250437, 5.441250437, 5.441250437,
      5.441250437, 5.441250437, 5.441250437, 5.441250437, 5.441250437,
      5.441250437, 5.441250437, 5.441250437, 5.441250437, 5.441250437,
      5.441250437, 5.958562732, 5.993755936, 6.04046626, 6.074295856,
      6.114804644, 6.155315318, 6.195828174, 6.236343509, 6.273974211,
      6.30651275, 5.847758453, 5.847758453, 5.847758453, 5.847758453,
      5.847758453, 5.847758453, 5.847758453, 5.847758453, 5.847758453,
      5.847758453, 5.847758453, 5.847758453, 5.847758453, 5.847758453,
      5.847758453, 5.847758453, 5.847758453, 5.847758453, 5.847758453,
      5.847758453, 5.786464151, 5.782150458, 5.777902563, 5.773719468,
      5.760466671, 5.754746241, 5.749083888, 5.744389348, 5.739766387,
      5.735213921, 5.664077806, 5.654984879, 5.646029909, 5.627322276,
      5.616734726, 5.60741365, 5.598233963, 5.589193545, 5.571546495,
      5.559829057, 5.528280595, 5.51746336, 5.500411655, 5.484806419,
      5.473702575, 5.462766832, 5.440950196, 5.429565523, 5.418353155,
      5.407249301, 5.473168884, 5.467655989, 5.451181948, 5.445014113,
      5.438940256, 5.432958955, 5.427068807, 5.421268434, 5.415556474,
      5.409931589, 5.481983149, 5.48229275, 5.482597607, 5.482897792,
      5.483193376, 5.48348443, 5.483771023, 5.484053224, 5.488401382,
      5.488823927, 5.481584074, 5.481584074, 5.481584074, 5.481584074,
      5.481584074, 5.481584074, 5.481584074, 5.481584074, 5.481584074,
      5.481584074, 5.481584074, 5.481584074, 5.481584074, 5.481584074,
      5.481584074, 5.481584074, 5.481584074, 5.481584074, 5.481584074,
      5.481584074, 5.440964725, 5.431018714, 5.42822925, 5.425524956,
      5.422903239, 5.420361588, 5.417897566, 5.415508811, 5.402172536,
      5.399272342, 5.442221941, 5.442221941, 5.442221941, 5.442221941,
      5.442221941, 5.442221941, 5.442221941, 5.442221941, 5.442221941,
      5.442221941, 5.442221941, 5.442221941, 5.442221941, 5.442221941,
      5.442221941, 5.442221941, 5.442221941, 5.442221941, 5.442221941,
      5.442221941, 5.442221941, 5.442221941, 5.442221941, 5.442221941,
      5.442221941, 5.442221941, 5.442221941, 5.442221941, 5.442221941,
      5.442221941, 5.442221941, 5.442221941, 5.442221941, 5.442221941,
      5.442221941, 5.442221941, 5.442221941, 5.442221941, 5.442221941,
      5.442221941, 5.396460686, 5.393734877, 5.391628359, 5.388562378,
      5.386077779, 5.383669074, 5.381333954, 5.379070178, 5.370054639,
      5.368171697, 5.267311306, 5.250230852, 5.242691942, 5.226895593,
      5.212690109, 5.197596959, 5.189813116, 5.176932629, 5.164047506,
      5.151158079, 5.143190318, 5.132427637, 5.119733232, 5.111653456,
      5.106108292, 5.107561981, 5.114246076, 5.116528365, 5.13708237,
      5.150701588, 5.160831412, 5.165437042, 5.169493533, 5.17218233,
      5.173964619, 5.175146044, 5.175929186, 5.176448317, 5.176792444,
      5.177020561, 5.705243252, 5.749423303, 5.789403111, 5.837217738,
      5.873285123, 5.913082175, 5.95626804, 5.99945647, 6.038627623, 6.084220199,
      5.474352336, 5.462932315, 5.451512169, 5.440091899, 5.42866262,
      5.416764435, 5.410859265, 5.404548474, 5.393638182, 5.382727791,
      6.096133184, 6.145941214, 6.19425213, 6.242566019, 6.290883475,
      6.339205091, 6.387531454, 6.435863144, 6.484200736, 6.532544801,
      6.580895904, 6.629254606, 6.677621465, 6.725997034, 6.066194754,
      5.594398219, 5.547468515, 5.500533819, 5.453593794, 5.406648095,
      5.359696374, 5.312738275, 5.265773439, 5.218801495, 5.171822071,
      5.124834784, 5.077839245, 5.030835058, 5.542021174, 5.010030265,
      6.090487335, 6.140518432, 6.188829046, 6.237142571, 6.285459597,
      6.333780717, 6.382106518, 6.430437581, 6.478774483, 6.527117793,
      6.521561362, 6.558731178, 6.602205571, 6.645686193, 6.686691167,
      6.721608886, 6.762896077, 6.802491177, 6.836588262, 6.877148399,
      7.004553002, 7.053001713, 7.100886508, 7.148424786, 7.195975908,
      7.243539381, 7.291114718, 7.338701441, 7.386299077, 7.433907164,
      7.481525241, 7.529152855, 7.57678956, 7.62443491, 7.672088467, 7.719749794,
      7.767418457, 7.815094026, 7.862776072, 7.910464166, 7.958157882,
      8.005856792, 8.05356047, 8.101268586, 8.148980949, 8.196697377,
      8.244417689, 8.292141697, 8.339869213, 8.387600048, 8.231429714,
      8.263693128, 8.295957423, 8.328222554, 8.360488481, 8.382265655,
      8.411427075, 8.44273394, 8.474041376, 8.505349344, 7.511938283,
      7.466133112, 7.420328856, 7.37452484, 7.328720388, 7.282914821,
      7.237107458, 7.191297618, 7.14548462, 7.099667784, 8.277996774, 8.32572327,
      8.373453142, 8.421186196, 8.46892224, 8.516661077, 8.564402509,
      8.612146336, 8.659892357, 8.707640368, 8.755390164, 8.803141539,
      8.850894284, 8.89864819, 8.946403046, 8.993460789, 9.040316366,
      9.087172349, 9.134028607, 9.180885013, 7.965870448, 7.92092748, 7.87598938,
      7.831056102, 7.786127602, 7.741001119, 7.695181435, 7.649365958,
      7.603554044, 7.557745039, 8.755390164, 8.803141539, 8.850894284,
      8.89864819, 8.946403046, 8.993460789, 9.040316366, 9.087172349,
      9.134028607, 9.180885013, 8.953843555, 8.980794311, 9.007745037,
      9.021620688, 9.047631599, 9.073642449, 9.091371704, 9.111960618,
      9.13703227, 9.162103828, 9.489540486, 9.536394261, 9.583247208,
      9.616897457, 9.649573491, 9.681276432, 9.714693496, 9.748522472,
      9.78180844, 9.813081679, 9.554392181, 9.569207247, 9.589429789,
      9.609652175, 9.629874397, 8.74239277, 8.695517723, 8.958061047,
      9.274293544, 9.249912337, 9.851109369, 9.881488991, 9.910863344,
      9.935109555, 9.95361538, 9.97081865, 9.82523535, 9.984311634, 9.920764402,
      9.993260328, 9.92884456, 9.95152615, 9.961175293, 9.93178648, 9.654293883,
      9.692622118, 9.964028679, 9.975215007, 9.984985214, 9.803056134,
      9.645875166, 9.730149841, 9.739524506, 9.740567578, 9.729762237,
      9.738490255, 9.739595115, 9.73973498, 9.739752686, 9.739754927,
      9.882038677, 9.73309787, 9.739924723, 9.738670859, 9.747316516,
      9.737612246, 9.73670422, 9.893572956, 9.864044923, 9.843553754,
      9.872500571, 9.849790087, 9.828231572, 9.815400745, 9.807479455,
      9.802396178, 9.79795396, 9.795709205, 9.793945135, 9.791655478,
      9.778250159, 9.777295166, 9.776340174, 9.775385181, 9.772938976,
      9.760678131, 9.758768803, 9.756859476, 9.754950149, 9.753040823,
      9.751131497, 9.749222172, 9.747312848, 9.745403524, 9.7434942, 9.741584878,
      9.739675555, 9.737766234, 9.735856913, 9.733947592, 9.732038272,
      9.730128953, 9.728219634, 9.726310316, 9.724400998, 9.722491681,
      9.720582365, 9.718673049, 9.716763733, 9.714854418, 9.700276799,
      9.697413824, 9.694550851, 9.69168788, 9.676160591, 9.672344632,
      9.668528677, 9.664712727, 9.660896781, 9.657080839, 9.640608582,
      9.635840338, 9.631072103, 9.626303875, 9.618486007, 9.603889673,
      9.598169847, 9.592450037, 9.58673024, 9.581010457, 9.575290689, 9.56187387,
      9.550637003, 9.543966363, 9.537295745, 9.530625149, 9.52295935,
      9.517208896, 9.499646659, 9.490428872, 9.437145891, 9.421300038,
      9.40663201, 9.385624373, 9.362290529, 9.347482307, 9.328586807,
      9.307864979, 9.293613499, 9.266790362, 9.26416105, 9.237349164,
      9.222154043, 9.196948843, 9.178463184, 9.16232512, 9.133655587,
      9.116575195, 9.093640597, 9.069459299, 9.05143779, 9.025887428,
      9.002973239, 8.984746438, 8.954061346, 8.934931679, 8.903359077,
      8.883327468, 8.858681592, 8.830508631, 8.863238268, 8.842194561,
      8.824875467, 8.807556684, 8.78384222, 8.760074076, 8.741852249,
      8.723630774, 8.701727225, 8.674731777, 8.69247175, 8.671255148,
      8.646970024, 8.629654318, 8.612338902, 8.595023773, 8.577708931,
      8.552380575, 8.530206308, 8.511988773, 8.456979476, 8.436056776,
      8.414726611, 8.385856627, 8.360414409, 8.33859347, 8.316773081,
      8.292339201, 8.262659845, 8.238173269, 8.177976484, 8.14556801,
      8.115316412, 8.089012814, 8.058811912, 8.025551506, 7.996923759,
      7.969440718, 7.929620686, 7.900975758, 7.865757603, 7.831136888,
      7.801583564, 7.771056599, 7.735325203, 7.70031262, 7.669851458,
      7.627422136, 7.596052265, 7.564242678, 7.658325211, 7.630751327,
      7.611042893, 7.586463977, 7.564221404, 7.541978586, 7.515944121,
      7.497195991, 7.46809129, 7.449774793, 7.408074199, 7.382160301,
      7.358081865, 7.334002742, 7.307087245, 7.285619413, 7.256359814,
      7.236636945, 7.205462121, 7.176524331, 7.21014206, 7.189726779,
      7.167672437, 7.148764268, 7.122927671, 7.106103931, 7.086968868,
      7.061378195, 7.044558505, 7.016343276, 6.906175326, 6.871832113,
      6.842581502, 6.813906482, 6.77918055, 6.744488441, 6.720118324,
      6.684965643, 6.656061182, 6.625500978, 6.624533418, 6.602353953,
      6.56900306, 6.53796999, 6.512751329, 6.478942435, 6.454548281, 6.422228627,
      6.398622187, 6.365457394, 6.399651268, 6.36941526, 6.350122881,
      6.319729943, 6.300265299, 6.269720514, 6.250088528, 6.219396829,
      6.199589895, 6.168265993, 6.19316288, 6.172930214, 6.147728493,
      6.130396287, 6.102019294, 6.084436446, 6.067117436, 6.038776334,
      6.021205837, 6.003898996, 5.975592614, 5.958033472, 5.929493661,
      5.911689474, 5.894152371, 5.865657032, 5.847873763, 5.819151029,
      5.801128649, 5.783376558, 5.709973069, 5.688909775, 5.656995223,
      5.635789558, 5.609161052, 5.582784567, 5.554124392, 5.529382206,
      5.498788339, 5.475599851, 5.576355228, 5.563866895, 5.545836884,
      5.536044563, 5.515471416, 5.50329479, 5.484936383, 5.475099275,
      5.454502348, 5.44464233, 5.424032901, 5.41415102, 5.393530051, 5.383357468,
      5.36653466, 5.351796288, 5.340279534, 5.321828635, 5.30323772, 5.288882294,
      5.276872312, 5.25836923, 5.24329549, 5.232118907, 5.213694278, 5.195968873,
      5.190539582, 5.169427843, 5.156137561, 5.142872981, 5.131945336,
      5.115053016, 5.106856303, 5.096027952, 5.088003636, 5.093423853,
      5.098509563, 5.11494538, 5.136033575, 5.150006591, 5.460047531,
      5.483043104, 5.506039374, 5.52903631, 5.552033882, 5.575032058,
      5.598030809, 5.621030103, 5.644029912, 5.663715592, 5.280684875, 5.2687851,
      5.256885197, 5.244985167, 5.23308501, 5.221184725, 5.209284314,
      5.197383775, 5.18548311, 5.173582318, 5.569757052, 5.592755674,
      5.615754846, 5.638754539, 5.659413319, 5.678010929, 5.696320647,
      5.717081081, 5.739078082, 5.761075387, 5.484535635, 5.48155294,
      5.478570243, 5.475587544, 5.472604843, 5.46962214, 5.466639435,
      5.463656728, 5.460674019, 5.457691308, 5.753076333, 5.775073819,
      5.797071569, 5.818714682, 5.838306594, 5.855264186, 5.871959049,
      5.889808809, 5.909967577, 5.930126626, 5.423344538, 5.408027787,
      5.384138487, 5.375215985, 5.355853395, 5.337652101, 5.32775453,
      5.315158235, 5.305185142, 5.3263884, 5.947128652, 5.982488329, 6.019610814,
      6.050193649, 6.080294056, 6.11594237, 6.149068797, 6.177698945, 6.2098487,
      6.244532582, 6.448892686, 6.497231967, 6.545577873, 6.59393097,
      6.642291816, 6.690660968, 6.739038979, 6.7874264, 6.835823778, 6.884231657,
      6.932650582, 6.981081094, 7.029523733, 7.077856031, 7.125387913,
      7.172932874, 7.220490424, 7.268060072, 7.315641337, 7.363233743,
      7.410836824, 7.458450116, 7.506073166, 7.553705521, 7.601346737,
      7.648996372, 7.696653988, 7.744319151, 7.791991428, 7.839670389,
      7.611458876, 7.637953173, 7.664448451, 7.682114867, 7.70419775,
      7.729739913, 7.755282808, 7.780826406, 7.80637069, 7.819289032,
      7.886995975, 7.90963621, 7.937096118, 7.964556779, 7.992018172,
      8.009128648, 8.03347271, 8.05997906, 8.086485993, 8.11299349, 8.089008702,
      8.111270046, 8.133957184, 8.156644632, 8.179332381, 8.202020419,
      8.211918256, 8.233653074, 8.25538812, 8.277123384, 8.157793196,
      8.169085093, 8.168205678, 8.21645052, 8.229634783, 8.242819087,
      8.256003429, 8.26918781, 8.279923241, 8.282509523, 8.544461434, 8.57005455,
      8.60040347, 8.629741856, 8.648107934, 8.677497817, 8.706887901,
      8.723124761, 8.750925274, 8.778816236, 8.308205298, 8.299970519,
      8.291735769, 8.283501046, 8.27526635, 8.263182824, 8.246401679,
      8.237256135, 8.228110628, 8.218965159, 8.486030354, 8.497106639,
      8.508182932, 8.519259232, 8.530335539, 8.541411852, 8.552488171,
      8.563564495, 8.574640824, 8.585717158, 8.331703967, 8.323469109,
      8.315234279, 8.306999477, 8.298764703, 8.290529956, 8.285311895,
      8.28142233, 8.278406116, 8.275526138, 8.640568187, 8.65321913, 8.672672763,
      8.692126424, 8.71158011, 8.730356863, 8.745588142, 8.756536674,
      8.775056627, 8.793576585, 9.203086405, 9.24994281, 9.29679907, 9.343655072,
      9.390510705, 9.437365858, 9.484220421, 9.531074282, 9.577927329,
      9.624779447, 9.671630517, 9.718480416, 9.765329018, 9.812176188,
      9.832438544, 9.837445996, 9.841140843, 9.841829552, 9.839520052,
      9.847609168, 9.773317879, 9.771584234, 9.767886097, 9.762227944,
      9.754614227, 9.745049373, 9.733537791, 9.720083867, 9.704691966,
      9.687366437, 9.614270974, 9.616183048, 9.618095121, 9.606544886,
      9.607500564, 9.608456243, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.595948539, 9.595948539, 9.595948539, 9.595948539,
      9.595948539, 9.583330394, 9.572270052, 9.568038424, 9.56612915,
      9.564219876, 9.553715295, 9.54713667, 9.544273789, 9.54141091, 9.532212753,
      9.504327943, 9.492181923, 9.483017628, 9.467878481, 9.460327568,
      9.441872161, 9.434251683, 9.414037757, 9.405467905, 9.384310851,
      9.383760387, 9.365952275, 9.356433897, 9.336371811, 9.324029361,
      9.307230789, 9.290055723, 9.278642469, 9.255179135, 9.242354403,
      9.267627849, 9.252982175, 9.235666053, 9.225200498, 9.214735013,
      9.204269599, 9.186602056, 9.170274485, 9.1588622, 9.147073821, 9.100425219,
      9.08439399, 9.07048669, 9.05481205, 9.031401794, 9.015946057, 8.995899008,
      8.973892362, 8.95838213, 8.942872133, 8.977074519, 8.965195148,
      8.953249371, 8.931425466, 8.921438978, 8.903990432, 8.891203015,
      8.878415723, 8.865628554, 8.846301809, 8.835790745, 8.81413443,
      8.800440048, 8.786745814, 8.768149474, 8.757009097, 8.733693349,
      8.722168874, 8.703963668, 8.689363515, 8.662444085, 8.646938268,
      8.626106076, 8.613494347, 8.588779333, 8.57126148, 8.554851584, 8.5375003,
      8.521962564, 8.499130797, 8.525421194, 8.511604434, 8.498029213,
      8.484338099, 8.466727419, 8.455615145, 8.432454291, 8.420955307,
      8.40197147, 8.387374781, 8.372778254, 8.358181887, 8.338813984,
      8.326920366, 8.303040126, 8.290782946, 8.27871037, 8.256235426,
      8.242336009, 8.225354578, 8.241997954, 8.221011129, 8.208541111,
      8.197708263, 8.180338065, 8.166649993, 8.15300801, 8.138900611,
      8.124942742, 8.107393436, 8.132974562, 8.123254136, 8.114381763,
      8.105643669, 8.089096633, 8.077916184, 8.067054666, 8.058107967,
      8.044595356, 8.033415067, 8.031354931, 8.02294856, 8.014669478,
      8.003305509, 7.986277466, 7.97762828, 7.969110005, 7.960720681,
      7.950918199, 7.932239912, 7.863581894, 7.851249566, 7.839102875,
      7.815178761, 7.802654957, 7.790319598, 7.766424128, 7.753534964,
      7.741018815, 7.716771592, 7.763450392, 7.754473218, 7.745631821,
      7.72502635, 7.71570579, 7.706526124, 7.697485249, 7.680332415, 7.667417921,
      7.65804398, 7.731851104, 7.727993705, 7.72419509, 7.720454367, 7.716770659,
      7.713143102, 7.701620173, 7.698568365, 7.695609399, 7.692740473,
      7.587619416, 7.577603566, 7.567738948, 7.549111674, 7.536068051,
      7.525907237, 7.514310152, 7.494948964, 7.487055472, 7.473655183,
      7.45990725, 7.452148054, 7.43284459, 7.424979835, 7.40558478, 7.397620388,
      7.378139582, 7.370081115, 7.354843947, 7.342583075, 7.42854507,
      7.425432547, 7.421904255, 7.419875302, 7.417938723, 7.416090353,
      7.405533625, 7.404452166, 7.403435892, 7.40248094, 7.296148802,
      7.281684162, 7.26717647, 7.254161272, 7.241993864, 7.236134986,
      7.226270203, 7.204699413, 7.204310588, 7.203573071, 7.326645756,
      7.326645756, 7.326645756, 7.326645756, 7.326645756, 7.326645756,
      7.326645756, 7.326645756, 7.326645756, 7.326645756, 7.274100778,
      7.277134995, 7.275411169, 7.274906028, 7.275421074, 7.276726427,
      7.276588573, 7.277991702, 7.281562101, 7.285560071, 7.500059816,
      7.515133741, 7.530207842, 7.545282112, 7.559956698, 7.571922402,
      7.583702244, 7.595299138, 7.606715951, 7.620706657, 7.6348345, 7.64896246,
      7.665417591, 7.677392401, 7.691520705, 7.720806271, 7.74007413,
      7.736464179, 7.801358815, 7.859272, 8.23275264, 8.280475761, 8.328202438,
      8.375932479, 8.423665694, 8.471401888, 8.519140864, 8.566882426,
      8.614626372, 8.662372501, 8.71012061, 8.757870493, 8.805621944,
      8.853374755, 8.901128715, 8.948883615, 8.995894612, 9.042750213,
      9.089606214, 9.136462482, 9.183318893, 9.230175325, 9.27703166,
      9.323887785, 9.370743587, 9.417598956, 9.464453781, 9.511307952,
      9.558161357, 9.605013881, 9.651865407, 9.698715816, 9.745564981,
      9.792412771, 9.83925905, 9.872801467, 9.87279669, 9.867620535, 9.857692947,
      9.840983447, 9.740341614, 9.736275683, 9.730641575, 9.70963151,
      9.699123321, 9.686670511, 9.658840933, 9.641549859, 9.608886424,
      9.586782412, 9.524111168, 9.522201905, 9.520292643, 9.518383381,
      9.51647412, 9.514564859, 9.512655599, 9.510746339, 9.508837079, 9.50692782,
      9.404262541, 9.387082084, 9.372058793, 9.361592274, 9.349756449,
      9.328751747, 9.31662483, 9.298024947, 9.288490337, 9.26892144, 9.219020992,
      9.203713618, 9.175976127, 9.156833941, 9.130942157, 9.105099169,
      9.07842902, 9.05267597, 9.023595526, 9.001694909, 9.042812423, 9.030155896,
      9.007134294, 8.987878488, 8.970381357, 8.956712201, 8.933292011,
      8.912684935, 8.896269738, 8.879854814, 8.838625717, 8.817524856,
      8.790541649, 8.770520638, 8.747933667, 8.720220389, 8.699661639,
      8.676175015, 8.647766508, 8.63123009, 8.630240319, 8.611117733, 8.5846393,
      8.560027275, 8.540870355, 8.520044827, 8.496874596, 8.468536737,
      8.446652218, 8.423135217, 8.380131693, 8.351624223, 8.322037852,
      8.302274295, 8.271540285, 8.251206756, 8.22162738, 8.190341368, 8.16677039,
      8.139161684, 8.119491201, 8.100114, 8.068908651, 8.044636388, 8.017789509,
      7.985581837, 7.957180234, 7.931273565, 7.899422679, 7.866958169,
      7.820737798, 7.787784443, 7.763131712, 7.728433444, 7.693356612,
      7.660707676, 7.634223525, 7.598770549, 7.562950667, 7.526769581,
      7.525951314, 7.491247735, 7.465677928, 7.433170435, 7.398066169,
      7.362588511, 7.338572479, 7.30309426, 7.26724802, 7.231039344, 7.229803958,
      7.206842113, 7.172466963, 7.137705465, 7.114291197, 7.079506679,
      7.044341596, 7.020492525, 6.985316203, 6.94976498, 6.97211445, 6.943950612,
      6.918397539, 6.888559413, 6.864375617, 6.83294505, 6.81006233, 6.777190279,
      6.755475444, 6.722524533, 6.692882444, 6.667175846, 6.636280194,
      6.61159566, 6.579507882, 6.550944255, 6.522330861, 6.493669192,
      6.464960696, 6.43620678, 6.487496205, 6.462626922, 6.437595664,
      6.412407376, 6.398474633, 6.373557001, 6.348478826, 6.327956994,
      6.306949704, 6.284379523, 6.219549675, 6.18570892, 6.162622817,
      6.139430303, 6.107393678, 6.081728076, 6.058463082, 6.029629361,
      5.999940297, 5.974240871, 6.265453117, 6.265453117, 6.265453117,
      6.265453117, 6.265453117, 6.265453117, 6.265453117, 6.265453117,
      6.265453117, 6.265453117, 6.039553972, 6.026576208, 6.006856529,
      5.990496752, 5.976348531, 5.95402355, 5.945117468, 5.935775293, 5.93609953,
      5.946550259, 6.085559249, 6.089595485, 6.089595485, 6.089595485,
      6.089595485, 6.089595485, 6.089595485, 6.089595485, 6.089595485,
      6.089595485, 6.321021996, 6.339261262, 6.357501029, 6.375741311,
      6.393982118, 6.412223462, 6.430465355, 6.448707807, 6.46695083,
      6.485099126, 6.88249953, 6.93091805, 6.979348138, 7.027790335, 7.076155679,
      7.123687087, 7.171231588, 7.218788696, 7.26635792, 7.313938777,
      7.361530793, 7.4091335, 7.456746435, 7.504369143, 7.552001173, 7.59964208,
      7.647291421, 7.694948759, 7.742613659, 7.790285689, 7.837964418,
      7.885649418, 7.933340262, 7.981036522, 8.028737772, 8.076443607,
      8.124153782, 8.171868118, 8.219586432, 8.26730854, 8.315034254,
      8.362763386, 8.410495745, 8.458231136, 8.505969365, 8.553710233,
      8.601453541, 8.649199089, 8.696946672, 8.744696086, 8.792447125,
      8.840199582, 8.887953246, 8.935707907, 8.982967192, 9.029822659,
      9.076678563, 9.12353477, 9.170391154, 9.217247592, 9.016018073,
      9.043788909, 9.060527104, 9.08822592, 9.103193108, 9.130143534,
      9.143970009, 9.169980536, 9.182846363, 9.207917725, 9.127035199,
      9.132042504, 9.148696652, 9.165350757, 9.179811862, 9.185306914,
      9.201029387, 9.216751818, 9.229553571, 9.234769068, 9.527369735,
      9.544775523, 9.557537693, 9.573921446, 9.591353714, 9.607831388,
      9.623355625, 9.638162301, 9.652830311, 9.664308895, 9.751529496,
      9.762864713, 9.765079715, 9.778717101, 9.77796335, 9.778688089,
      9.784230583, 9.77856001, 9.784372165, 9.775762877, 9.734337869,
      9.730458033, 9.721169519, 9.717295083, 9.712455281, 9.706651201,
      9.699883924, 9.692154532, 9.683464101, 9.673813707, 9.59835003,
      9.595487119, 9.59262421, 9.589761302, 9.577789619, 9.570720003,
      9.566904161, 9.563088322, 9.559272487, 9.555456657, 9.55164083,
      9.547825007, 9.544009189, 9.540193374, 9.536377563, 9.532561756,
      9.528745953, 9.524930154, 9.521114359, 9.517298568, 9.488269464,
      9.482549915, 9.476830378, 9.471110855, 9.465391345, 9.459671847,
      9.453952363, 9.435640713, 9.428970435, 9.422300178, 9.327535651,
      9.312688989, 9.289413146, 9.278121733, 9.254436426, 9.242731743,
      9.218650106, 9.19399629, 9.1813221, 9.156302798, 9.093135319, 9.064763713,
      9.035889921, 9.006522137, 8.968942351, 8.934248907, 8.903647191,
      8.872617204, 8.841165941, 8.809300278, 8.848835991, 8.82299326,
      8.794115216, 8.764781353, 8.747388336, 8.717875593, 8.687917503, 8.6615767,
      8.635779445, 8.608533656, 8.62689504, 8.59834722, 8.581654267, 8.552904659,
      8.534924418, 8.510281447, 8.485489652, 8.460553659, 8.435477948,
      8.410266858, 8.384924592, 8.35945522, 8.333862684, 8.308150805,
      8.282323281, 8.256383697, 8.230335525, 8.204182127, 8.177926763,
      8.151572589, 8.150111458, 8.123945643, 8.096193051, 8.075105648,
      8.054076436, 8.02082534, 7.999095129, 7.974825504, 7.945867672,
      7.923871061, 7.947886547, 7.923693631, 7.899504735, 7.875460995,
      7.859859741, 7.840425739, 7.817166986, 7.802308884, 7.788772899,
      7.774392206, 7.925041691, 7.932367124, 7.938453002, 7.943509746,
      7.947711853, 7.951204086, 7.95410659, 7.956519106, 7.958524459,
      7.960191439, 8.294669814, 8.318313578, 8.341957602, 8.365601873,
      8.389246379, 8.400032611, 8.422722905, 8.445413373, 8.468104004,
      8.490794787, 8.848957604, 8.896711467, 8.944466288, 8.991560528,
      9.038416086, 9.085272055, 9.132128304, 9.178984707, 9.225841141,
      9.27269749, 9.319553639, 9.366409476, 9.41326489, 9.46011977, 9.506974006,
      9.553827486, 9.600680096, 9.64753172, 9.694382237, 9.741231523,
      9.732711421, 9.751330878, 9.779160969, 9.792969995, 9.819406193,
      9.838818965, 9.855466794, 9.877922922, 9.88598228, 9.905468072,
      9.561481976, 9.566267592, 9.571053205, 9.575838815, 9.580624422,
      9.585410026, 9.590195627, 9.594981225, 9.586327244, 9.590154279,
      9.378396118, 9.367681457, 9.351358133, 9.343977235, 9.324238839,
      9.304160124, 9.296322723, 9.276155537, 9.268222876, 9.247972941,
      9.239950411, 9.223849222, 9.211706431, 9.200880853, 9.183217211,
      9.16541886, 9.147492071, 9.141959263, 9.124162855, 9.106237972, 9.11695329,
      9.108399476, 9.091664529, 9.085846058, 9.07151254, 9.057145696, 9.04860016,
      9.036654699, 9.024710838, 9.012768454, 9.087882062, 9.088090478,
      9.081042268, 9.082285218, 9.078171607, 9.080232127, 9.078615259,
      9.078524631, 9.079740902, 9.080761391, 9.382664799, 9.401183269,
      9.419701641, 9.42493702, 9.442522315, 9.460107516, 9.47769262, 9.481966906,
      9.498936362, 9.516250451, 9.62700612, 9.637759048, 9.660896474,
      9.670658261, 9.692822795, 9.70447367, 9.722994496, 9.737984774, 9.75151724,
      9.771738153, 9.509907053, 9.509907053, 9.509907053, 9.509907053,
      9.509907053, 9.509907053, 9.509907053, 9.509907053, 9.509907053,
      9.509907053, 9.509907053, 9.509907053, 9.509907053, 9.509907053,
      9.509907053, 9.509907053, 9.509907053, 9.509907053, 9.509907053,
      9.509907053, 9.472145619, 9.464372135, 9.453462691, 9.449646968,
      9.445831248, 9.442015531, 9.437029317, 9.421717409, 9.416949521,
      9.41218164, 9.357122944, 9.348553371, 9.33998384, 9.318851094, 9.309332996,
      9.299814953, 9.278659621, 9.267347796, 9.256882025, 9.241117244,
      9.219908613, 9.198830892, 9.186471862, 9.174112947, 9.149235378,
      9.135931038, 9.122211492, 9.096787531, 9.082538738, 9.064231291,
      9.079616479, 9.067736197, 9.055856023, 9.043975957, 9.019645927,
      9.00685735, 8.994068904, 8.981280589, 8.95606282, 8.942366849, 8.841741195,
      8.821711121, 8.789279249, 8.768348283, 8.739621228, 8.713538776,
      8.691708484, 8.657520416, 8.634791214, 8.599723149, 8.711722717,
      8.698029428, 8.684336282, 8.670643279, 8.651436766, 8.630547758,
      8.615948473, 8.601349358, 8.586750413, 8.569320261, 8.496213422,
      8.476888314, 8.45776881, 8.438443167, 8.407277938, 8.387257734,
      8.367237955, 8.338871686, 8.314374737, 8.293455355, 8.309091094,
      8.290877446, 8.27244318, 8.2457829, 8.22342108, 8.204306427, 8.185192129,
      8.160878867, 8.134455177, 8.114440625, 8.215442011, 8.204477059,
      8.193507661, 8.182326702, 8.171145806, 8.159964972, 8.148784197,
      8.137603479, 8.126422817, 8.115242207, 8.079937614, 8.066905075,
      8.05387261, 8.040840213, 8.027807882, 8.014775611, 8.001743398,
      7.988711237, 7.975679125, 7.954759677, 7.840962179, 7.819637268,
      7.79831249, 7.772498688, 7.743348917, 7.721107042, 7.698865176,
      7.676623285, 7.647873073, 7.619716263, 7.656092995, 7.637524956,
      7.618956799, 7.600388509, 7.575162889, 7.559816846, 7.532842847,
      7.512647444, 7.493158262, 7.473668801, 7.501473722, 7.481074988,
      7.468057643, 7.443433038, 7.425181654, 7.408453168, 7.391724424,
      7.374995411, 7.358266118, 7.341536533, 7.219033709, 7.187956286,
      7.156823888, 7.130907383, 7.104989506, 7.079070191, 7.048710184,
      7.015841674, 6.988411576, 6.961571561, 6.992945899, 6.970685695,
      6.948424667, 6.920244915, 6.901873421, 6.872178053, 6.846478305,
      6.823294904, 6.800110688, 6.776925677, 6.799947306, 6.774315065,
      6.758124575, 6.730648032, 6.714194508, 6.711924195, 6.693336555,
      6.674748577, 6.652814565, 6.626043977, 6.686660718, 6.668522304,
      6.657606101, 6.646854838, 6.624809595, 6.613629822, 6.602618927,
      6.581715851, 6.56899301, 6.557732529, 6.528797376, 6.513901893,
      6.499006283, 6.48411055, 6.469214697, 6.454318727, 6.439422642,
      6.424526447, 6.404203913, 6.391738165, 6.368091301, 6.355247803,
      6.342598003, 6.321140016, 6.305921862, 6.289402973, 6.273262248,
      6.257121419, 6.240980484, 6.224839438, 6.321900141, 6.315229718,
      6.308559286, 6.301888846, 6.295218398, 6.28854794, 6.281877474,
      6.275206999, 6.268536514, 6.261866021, 6.311676588, 6.309767314,
      6.307858039, 6.305948763, 6.304039488, 6.302130212, 6.300220936,
      6.29831166, 6.296402384, 6.294493107, 6.29258383, 6.290674553, 6.288765276,
      6.286855999, 6.284946721, 6.283037443, 6.281128165, 6.279218886,
      6.277309608, 6.275400329, 6.528517452, 6.546763106, 6.565009392,
      6.583256321, 6.601503905, 6.619752154, 6.63800108, 6.656250695,
      6.674501009, 6.692752033, 6.443523895, 6.440661039, 6.437798183,
      6.434935327, 6.43207247, 6.429209612, 6.426346754, 6.423483895,
      6.420621036, 6.417758176, 6.426232699, 6.424323436, 6.422414173,
      6.42050491, 6.418595646, 6.416713999, 6.415153954, 6.413617773, 6.41210509,
      6.410615548, 6.305464001, 6.294997092, 6.284530153, 6.270175223,
      6.261349507, 6.252640856, 6.242173783, 6.231706677, 6.215670143,
      6.20672525, 6.254378308, 6.238850377, 6.232835106, 6.227420205,
      6.222087774, 6.216836567, 6.211665354, 6.206572923, 6.201558081,
      6.196619654, 6.191756483, 6.176164085, 6.170237262, 6.164826091,
      6.159497338, 6.154249754, 6.149082111, 6.1439932, 6.138981826, 6.134046816,
      6.084195637, 6.075996031, 6.066476481, 6.056956894, 6.047437271,
      6.033873496, 6.025794595, 6.017838369, 6.008781079, 5.999261263,
      5.971971081, 5.962938668, 5.954043259, 5.9452828, 5.93543182, 5.916878042,
      5.907735226, 5.898731078, 5.889863518, 5.881130497, 5.917236572,
      5.911879974, 5.906604978, 5.90141035, 5.890050273, 5.88337905, 5.876707811,
      5.870036555, 5.863233618, 5.857749776, 5.852349466, 5.847031425,
      5.841794408, 5.836637187, 5.824774754, 5.818103364, 5.811431955,
      5.80398567, 5.798454466, 5.793007516, 5.787643544, 5.782361296,
      5.777159532, 5.772037036, 5.766992605, 5.753661969, 5.745425118,
      5.739836067, 5.734332151, 5.728912081, 5.723574586, 5.718318419,
      5.713142346, 5.708045154, 5.70302565, 5.686982516, 5.681333808,
      5.675771142, 5.670293216, 5.664898747, 5.659586472, 5.654355146,
      5.649203543, 5.644130455, 5.636051833, 5.632027809, 5.617939541,
      5.612704151, 5.608441837, 5.601678174, 5.596379029, 5.591160639,
      5.586021782, 5.57700881, 5.572884033, 5.568884834, 5.565007415,
      5.550193633, 5.5459361, 5.541808163, 5.581999118, 5.580575498, 5.57919541,
      5.577857526, 5.576560558, 5.575303257, 5.574084413, 5.572902851,
      5.571757434, 5.570647057, 5.422197533, 5.405771626, 5.396304443,
      5.379425024, 5.361151609, 5.344858356, 5.335295243, 5.317072163,
      5.298698574, 5.288347085, 5.327671678, 5.313450185, 5.299110349,
      5.295667322, 5.281426509, 5.27555433, 5.263038706, 5.256137022,
      5.256436217, 5.258998985, 5.31232612, 5.306905638, 5.306948999,
      5.306988028, 5.307023185, 5.303627997, 5.30402907, 5.301656004,
      5.302355711, 5.300867232, 5.301762796, 5.300972444, 5.301951074,
      5.302779611, 5.303481094, 5.304075018, 5.304577884, 5.305003661,
      5.30536417, 5.305669419, 5.489719044, 5.50469315, 5.519667407, 5.534641808,
      5.549616347, 5.564591021, 5.579565822, 5.594540747, 5.614191891,
      5.624878516, 6.037558562, 6.084956856, 6.123385644, 6.166618324,
      6.208991066, 6.246718048, 6.28961318, 6.329461073, 6.365975725,
      6.423598538, 6.514687564, 6.563036002, 6.611391832, 6.659755613,
      6.708127901, 6.756509246, 6.804900199, 6.853301306, 6.901713111,
      6.950136157, 6.998570985, 7.047018137, 7.095016964, 7.142553621,
      7.190103185, 7.237665159, 7.285239057, 7.332824399, 7.380420713,
      7.428027534, 7.475644402, 7.523270863, 7.570906469, 7.618550776,
      7.666203343, 7.713863734, 7.761531515, 7.809206254, 7.856887523,
      7.904574894, 7.952267938, 7.99996623, 8.047669342, 8.095376921,
      8.143088769, 8.190804705, 8.238524547, 8.286248108, 8.333975202,
      8.381705638, 8.429439223, 8.477175764, 8.524915063, 8.572656924,
      8.620401145, 8.668147525, 8.715895859, 8.763645943, 8.81139757, 8.85915053,
      8.906904616, 8.954659614, 9.001561762, 9.048417419, 9.095273459,
      9.142129751, 9.188986171, 9.235842597, 9.282698913, 9.329555004,
      9.166785235, 9.18580924, 9.216081523, 9.23365919, 9.257307861, 9.279610485,
      9.295268083, 9.311507347, 9.337030725, 9.350773686, 9.508947983,
      9.531155556, 9.552402777, 9.572690796, 9.586177134, 9.597304644,
      9.613219203, 9.628741241, 9.643758603, 9.658424422, 9.70878206,
      9.718062419, 9.728117485, 9.74078918, 9.739681342, 9.748855103,
      9.757605629, 9.765200382, 9.758727213, 9.763572824, 9.794327111,
      9.79656643, 9.789375324, 9.777830348, 9.777809059, 9.763347495,
      9.746950228, 9.736290591, 9.722390894, 9.701170531, 9.651061573,
      9.651061573, 9.651061573, 9.651061573, 9.638423834, 9.637468852,
      9.636513869, 9.635558887, 9.621967517, 9.620058228, 9.618148941,
      9.616239653, 9.614330367, 9.61242108, 9.610511795, 9.60860251, 9.606693225,
      9.604783941, 9.602874657, 9.600965374, 9.599056091, 9.597146809,
      9.595237527, 9.593328246, 9.591418966, 9.589509685, 9.587600406,
      9.585691127, 9.583781848, 9.58187257, 9.579963292, 9.578054015,
      9.576144739, 9.574235462, 9.572326187, 9.570416912, 9.568507637,
      9.566598363, 9.564689089, 9.562779816, 9.560870543, 9.558961271, 9.557052,
      9.555142728, 9.553233458, 9.551324188, 9.549414918, 9.547505649,
      9.54559638, 9.543687112, 9.541777844, 9.539868577, 9.53795931, 9.536050043,
      9.534140778, 9.532231512, 9.530322247, 9.528412983, 9.526503719,
      9.524594456, 9.522685193, 9.52077593, 9.518866668, 9.516957407,
      9.515048146, 9.513138885, 9.511229625, 9.509320366, 9.507411107,
      9.505501848, 9.415434687, 9.381683083, 9.346042373, 9.318165115,
      9.307381467, 9.284188399, 9.260408521, 9.236051451, 9.211126641,
      9.19597036, 9.135144741, 9.107063996, 9.077495295, 9.036809007,
      9.006486035, 8.975692539, 8.932294126, 8.900821023, 8.868933703,
      8.824191215, 8.902722106, 8.875321121, 8.847440158, 8.831500438,
      8.803394726, 8.787217633, 8.758894554, 8.73010676, 8.713233364, 8.68425005,
      8.679520814, 8.663405922, 8.635195565, 8.61485186, 8.590190947, 8.56592581,
      8.544544511, 8.516546797, 8.498285776, 8.469022922, 8.500641249,
      8.480035651, 8.459578643, 8.444967399, 8.423347442, 8.40374537,
      8.389073241, 8.366503878, 8.34770201, 8.332467597, 8.663225883,
      8.670598247, 8.67797061, 8.672298044, 8.678746265, 8.685194485,
      8.691642705, 8.698090924, 8.704539144, 8.710987362, 8.743561796,
      8.751859038, 8.760156279, 8.768453518, 8.776750755, 8.785047991,
      8.793345225, 8.801642457, 8.809939687, 8.817014256, 8.813351601,
      8.820723945, 8.828096287, 8.835468627, 8.842840965, 8.850213301,
      8.857585636, 8.864957968, 8.872330297, 8.879702625, 8.616802377,
      8.607043182, 8.597431537, 8.577580435, 8.570220029, 8.556136251,
      8.54638832, 8.536787757, 8.517230299, 8.509882276, 8.466063842,
      8.457552587, 8.437078278, 8.428537576, 8.408046911, 8.399478136,
      8.379257923, 8.370389582, 8.356015058, 8.341520534, 8.431000732,
      8.424590097, 8.418179475, 8.411768866, 8.405358271, 8.398947689,
      8.39253712, 8.386126565, 8.379716023, 8.373305493, 8.464877054,
      8.465796002, 8.466714951, 8.467633899, 8.468552847, 8.469471795,
      8.470390744, 8.471309692, 8.47222864, 8.473147588, 8.203562794,
      8.192152192, 8.168952472, 8.143854523, 8.124176, 8.104492719, 8.095021602,
      8.075215529, 8.051051749, 8.035013874, 8.279654872, 8.280591831,
      8.28152879, 8.282465749, 8.283402707, 8.284339666, 8.285276625,
      8.286213584, 8.287150542, 8.288087501, 8.191576228, 8.185039987,
      8.178503756, 8.171967535, 8.165431324, 8.158895123, 8.152358932,
      8.145822749, 8.139286576, 8.132750411, 8.417018572, 8.432098631,
      8.447178725, 8.462258852, 8.465161268, 8.478596794, 8.492728937,
      8.506861099, 8.52098531, 8.534847338, 8.639383452, 8.651230523,
      8.666579522, 8.686033175, 8.705486853, 8.711947682, 8.730467612,
      8.748987554, 8.767507505, 8.77300491, 9.103302211, 9.128782575,
      9.146455188, 9.167911585, 9.191209657, 9.213546342, 9.233190357,
      9.246265673, 9.260897188, 9.278456749, 9.242388398, 9.254281169,
      9.265226035, 9.275224126, 9.284276573, 9.292384505, 9.31277163,
      9.319927968, 9.326142059, 9.33141503, 9.441770124, 9.439376946,
      9.448363196, 9.44312544, 9.436002712, 9.440293713, 9.43034508, 9.418989071,
      9.418174945, 9.403659319, 9.360856231, 9.354219856, 9.346621221,
      9.338061423, 9.328541559, 9.318062726, 9.319974826, 9.308537389,
      9.296143173, 9.283635038, 9.270172301, 9.268263097, 9.266353893,
      9.26444469, 9.262535487, 9.260626284, 9.258717082, 9.25680788, 9.254898679,
      9.252989478, 9.251080278, 9.249171077, 9.247261878, 9.245352678,
      9.243443479, 9.241534281, 9.239625083, 9.237715885, 9.235806688,
      9.233948602, 9.232112892, 9.230277182, 9.228441473, 9.226605763,
      9.224770055, 9.222934346, 9.221098638, 9.219262931, 9.217427224,
      9.215591517, 9.213755811, 9.211920105, 9.210084399, 9.208248694,
      9.206412989, 9.204577285, 9.202741581, 9.200905877, 9.199070174,
      9.197234471, 9.195398768, 9.193563066, 9.191727365, 9.189891664,
      9.188055963, 9.186220262, 9.184384562, 9.182548862, 9.180713163,
      9.178877464, 9.127228792, 9.121730439, 9.103783226, 9.084924743,
      9.077025781, 9.058751808, 9.049624694, 9.041387175, 9.026806628,
      9.019914864, 8.963433127, 8.941450007, 8.916461159, 8.895645572,
      8.871986948, 8.847787373, 8.820863901, 8.792067005, 8.762372706,
      8.732404544, 8.725064089, 8.6944897, 8.663020456, 8.642994613, 8.610640548,
      8.577717045, 8.555591453, 8.521463806, 8.488221232, 8.457311256,
      8.450523166, 8.416151207, 8.389200855, 8.356420188, 8.319670702,
      8.293934116, 8.256609482, 8.228439773, 8.191667849, 8.152290842,
      8.126978757, 8.09266764, 8.057990141, 8.022952228, 7.987559769,
      7.951818533, 7.915256586, 7.878221147, 7.83818033, 7.793844922,
      7.848639964, 7.815364873, 7.781688536, 7.759619689, 7.725888118,
      7.691762479, 7.657249007, 7.634306693, 7.599763766, 7.564839404,
      7.601027829, 7.581643417, 7.550653944, 7.531108675, 7.499981898,
      7.480280016, 7.44902022, 7.417325853, 7.397032683, 7.365222743,
      7.403828592, 7.387383931, 7.367100425, 7.343188435, 7.326734968,
      7.298764056, 7.282059411, 7.257792607, 7.237160346, 7.220460863,
      7.204010752, 7.18414807, 7.160129699, 7.143461047, 7.123590087,
      7.099577661, 7.075377788, 7.054533851, 7.038263372, 7.014092106,
      6.981416157, 6.964798076, 6.940107569, 6.915250142, 6.890230868,
      6.876646128, 6.851881869, 6.826952817, 6.801863983, 6.787439927,
      6.728666564, 6.701981924, 6.676390563, 6.654265707, 6.63222592,
      6.598767001, 6.576496879, 6.554318266, 6.527093805, 6.498154468,
      6.503498376, 6.486508592, 6.458188086, 6.435437949, 6.421265098,
      6.398610068, 6.36996506, 6.349812847, 6.330185448, 6.315084316,
      6.558321329, 6.558321329, 6.558321329, 6.558321329, 6.558321329,
      6.558321329, 6.558321329, 6.558321329, 6.558321329, 6.558321329,
      6.438810222, 6.433074293, 6.43076894, 6.420126708, 6.420677453,
      6.424598697, 6.436856328, 6.444599499, 6.434091287, 6.434673897,
      6.706618029, 6.723367045, 6.736915568, 6.750254314, 6.76338653,
      6.777466175, 6.7934722, 6.809478709, 6.833185502, 6.842081692, 7.264964166,
      7.31254469, 7.360136385, 7.407738785, 7.455351427, 7.502973856,
      7.550605619, 7.598246272, 7.645895372, 7.693552482, 7.741217167,
      7.788888994, 7.836567533, 7.884252356, 7.931943034, 7.979639142,
      8.027340252, 8.075045957, 8.122756007, 8.170470224, 8.218188424,
      8.265910423, 8.313636035, 8.361365069, 8.409097336, 8.456832641,
      8.504570789, 8.552311583, 8.600054823, 8.647800307, 8.695547834,
      8.743297197, 8.791048192, 8.83880061, 8.886554242, 8.934308877,
      8.981594525, 9.028449977, 9.06232346, 9.095223772, 9.166207065,
      9.213063502, 9.259919886, 9.306776101, 9.353632034, 9.400487574,
      9.447342611, 9.494197033, 9.541050731, 9.58790359, 9.493912978,
      9.512994114, 9.53715894, 9.55658354, 9.576869844, 9.596198103, 9.614169792,
      9.631957118, 9.648077268, 9.657983492, 9.613706041, 9.63196821,
      9.645714743, 9.654505187, 9.662315748, 9.673232903, 9.688611877,
      9.694533537, 9.69940376, 9.703298646, 9.70621932, 9.716426199, 9.723168574,
      9.724138469, 9.72413751, 9.723166801, 9.734682303, 9.7327386, 9.729827356,
      9.725949664, 9.692883466, 9.686348378, 9.69113391, 9.682443861,
      9.686270853, 9.690097844, 9.680444973, 9.683314143, 9.672701314,
      9.674613381, 9.663042022, 9.663997699, 9.664953376, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.652424559, 9.652424559, 9.652424559,
      9.652424559, 9.652424559, 9.639786338, 9.613555588, 9.585418929,
      9.555380422, 9.523444148, 9.489614209, 9.451742879, 9.41612797,
      9.376642121, 9.455353922, 9.427145168, 9.404074668, 9.380060986,
      9.355105207, 9.329208428, 9.302371755, 9.273440382, 9.245796005,
      9.209182029, 9.436240533, 9.436240533, 9.436240533, 9.436240533,
      9.436240533, 9.436240533, 9.436240533, 9.436240533, 9.433043313,
      9.432849149, 9.435757904, 9.435757904, 9.435757904, 9.435757904,
      9.435757904, 9.435757904, 9.435757904, 9.435757904, 9.435757904,
      9.435757904, 9.435757904, 9.435757904, 9.435757904, 9.435757904,
      9.435757904, 9.435757904, 9.435757904, 9.435757904, 9.435757904,
      9.435757904, 9.294497425, 9.274340466, 9.262927344, 9.238966684,
      9.220241356, 9.201227218, 9.186844089, 9.163633836, 9.147881265,
      9.128468467, 9.106478684, 9.091285435, 9.063591803, 9.042436136,
      9.019375307, 9.002958293, 8.978982036, 8.957121692, 8.927357446,
      8.909132256, 8.935429652, 8.913214261, 8.897704935, 8.874189688,
      8.853695144, 8.836054167, 8.810596843, 8.791230943, 8.770916718,
      8.744658186, 8.725832215, 8.703470957, 8.67673902, 8.657615471,
      8.633807227, 8.606701664, 8.586677099, 8.561999673, 8.533988548,
      8.513064008, 8.66404497, 8.655808948, 8.646903017, 8.639287037,
      8.621509633, 8.614401843, 8.607401896, 8.592363178, 8.583216158,
      8.573715842, 8.687317965, 8.687317965, 8.687317965, 8.687317965,
      8.687317965, 8.687317965, 8.687317965, 8.687317965, 8.687317965,
      8.687317965, 8.687317965, 8.687317965, 8.687317965, 8.687317965,
      8.687317965, 8.687317965, 8.687317965, 8.687317965, 8.687317965,
      8.687317965, 8.664361599, 8.662992205, 8.661643753, 8.660315925,
      8.656105995, 8.654270396, 8.652434797, 8.650599199, 8.648763601,
      8.646928003, 8.522745468, 8.511778637, 8.498229442, 8.489357328,
      8.478663466, 8.459686346, 8.450490731, 8.432540917, 8.419788656,
      8.408725119, 8.376470154, 8.365815738, 8.345901777, 8.33225628,
      8.318525953, 8.298311643, 8.287028524, 8.264551479, 8.252152262,
      8.235526287, 8.305808248, 8.295226562, 8.288522483, 8.281920144,
      8.272722592, 8.256745054, 8.249715487, 8.242792547, 8.235974631,
      8.21791965, 8.125035159, 8.100356316, 8.087219533, 8.063569942,
      8.048806873, 8.030267054, 8.010067164, 7.996450713, 7.970999683,
      7.957052154, 8.027482936, 8.019135192, 8.02292891, 8.015576257,
      8.008335101, 7.989200589, 7.981432727, 7.973782584, 7.966248394,
      7.949759912, 8.065929484, 8.058794484, 8.058346251, 8.057904883,
      8.057470273, 8.057042319, 8.056620918, 8.056205971, 8.055797377,
      8.055395042, 8.054998867, 8.05460876, 8.054224627, 8.053846377, 8.05347392,
      8.053107167, 8.052746031, 8.052390426, 8.052040267, 8.05169547,
      8.056674949, 8.056674949, 8.056674949, 8.056674949, 8.056674949,
      8.056674949, 8.056674949, 8.056674949, 8.056674949, 8.056674949,
      8.056674949, 8.056674949, 8.056674949, 8.056674949, 8.056674949,
      8.056674949, 8.056674949, 8.056674949, 8.056674949, 8.056674949,
      8.056674949, 8.056674949, 8.056674949, 8.056674949, 8.056674949,
      8.056674949, 8.056674949, 8.056674949, 8.056674949, 8.056674949,
      7.986145969, 7.975068078, 7.970299408, 7.965603313, 7.960186325,
      7.95637477, 7.941354386, 7.937518751, 7.933799566, 7.930193329,
      7.866933999, 7.852563813, 7.842374645, 7.835985274, 7.817854378,
      7.811282752, 7.792984379, 7.786241105, 7.768898601, 7.760933745,
      7.873290214, 7.872459719, 7.871654625, 7.870874156, 7.870117561,
      7.86938411, 7.868673097, 7.867983837, 7.867315664, 7.866667936,
      7.633596492, 7.613846466, 7.594076895, 7.574288634, 7.554482494,
      7.523433215, 7.507194743, 7.482542053, 7.462922251, 7.434849179,
      7.58065476, 7.568607377, 7.556665115, 7.562380359, 7.558958875,
      7.558021292, 7.559159224, 7.556813359, 7.558456407, 7.563029017,
      7.597710548, 7.596186739, 7.596859549, 7.595949308, 7.596738724,
      7.596304108, 7.596182511, 7.596322754, 7.596665608, 7.596636673,
      7.600164292, 7.600372012, 7.600551077, 7.600705443, 7.600838515,
      7.600953233, 7.601052128, 7.601137383, 7.60121088, 7.601274239,
      8.235571995, 8.283295332, 8.331022212, 8.378752447, 8.426485843,
      8.474222206, 8.521961341, 8.569703049, 8.615694387, 8.653503335,
      8.711950684, 8.759700631, 8.807452138, 8.855204997, 8.902958997,
      8.950713928, 8.997690433, 9.044546052, 9.091402066, 9.138258342,
      9.185114755, 9.231971185, 9.278827515, 9.325683629, 9.372539417,
      9.419394767, 9.466249569, 9.513103713, 9.559957086, 9.606809574,
      9.65366106, 9.700511423, 9.747360538, 9.794208273, 9.841054491,
      9.887899047, 9.936037298, 9.975653766, 9.999629945, 9.997085948, 9.4010059,
      9.397190226, 9.393374556, 9.385643153, 9.382360424, 9.379127805,
      9.375944533, 9.372809858, 9.369614474, 9.354123992, 9.147728367,
      9.121140005, 9.094876043, 9.074031091, 9.053186698, 9.032342859,
      9.011499565, 8.984363233, 8.957842764, 8.936907172, 8.972418852,
      8.948950047, 8.932956733, 8.914405545, 8.897085129, 8.879765035,
      8.862445259, 8.845125798, 8.825970746, 8.810352837, 8.731116372,
      8.709285587, 8.687455414, 8.659938233, 8.631030825, 8.608302412,
      8.58557467, 8.562847594, 8.54012118, 8.515303022, 8.484874749, 8.458797799,
      8.435175083, 8.411553086, 8.387931805, 8.364311236, 8.335831691,
      8.304578612, 8.279981684, 8.255466194, 8.307104229, 8.285189148,
      8.266073337, 8.246957885, 8.227842793, 8.208728057, 8.189613678,
      8.170499653, 8.149187602, 8.121729267, 8.02748635, 8.000850131,
      7.967971373, 7.937380979, 7.910561061, 7.88374186, 7.856923302,
      7.830105313, 7.803271452, 7.769781356, 7.893087925, 7.877284324,
      7.861480768, 7.845677249, 7.829873756, 7.814070281, 7.798266815,
      7.779110499, 7.766209716, 7.741569931, 7.799868738, 7.791265437,
      7.782792334, 7.762535668, 7.753572328, 7.744744557, 7.736050331,
      7.718528596, 7.707348408, 7.697606932, 7.637588703, 7.622707768,
      7.605375825, 7.592753498, 7.569421103, 7.556914835, 7.544596672,
      7.520632044, 7.507939629, 7.495438054, 7.660297477, 7.659399697,
      7.658515656, 7.657645145, 7.656787956, 7.655943887, 7.655112736,
      7.654294305, 7.653488402, 7.652694833, 7.593100069, 7.588358455,
      7.581958339, 7.576353297, 7.570748247, 7.565143188, 7.559538119,
      7.553933042, 7.548327954, 7.542722857, 7.537117751, 7.531512635,
      7.526889057, 7.522429179, 7.514937623, 7.509332467, 7.503727299,
      7.498122121, 7.492516932, 7.486911732, 7.551861276, 7.551861276,
      7.551861276, 7.551861276, 7.551861276, 7.551861276, 7.551861276,
      7.551861276, 7.551861276, 7.551861276, 7.481306521, 7.475701299,
      7.470096066, 7.465556826, 7.461100002, 7.456711044, 7.452388925,
      7.448132636, 7.443941178, 7.432610798, 7.427005472, 7.421400134,
      7.415794783, 7.410189419, 7.405443523, 7.400971176, 7.396566933,
      7.392229765, 7.387958656, 7.383752606, 7.255476884, 7.23875219,
      7.225559473, 7.210673435, 7.190887458, 7.178552571, 7.165467693,
      7.142707079, 7.130176215, 7.117833894, 7.081442181, 7.064706621,
      7.043685428, 7.029882713, 7.014074737, 6.991136481, 6.977203583,
      6.96313416, 6.938344036, 6.924284645, 6.969806368, 6.958542203, 6.94878916,
      6.939183612, 6.922108765, 6.909995123, 6.89853876, 6.888768184,
      6.873944399, 6.861830334, 6.847973297, 6.838042483, 6.825393714,
      6.813279244, 6.797102246, 6.78701584, 6.777081965, 6.764403291,
      6.745975085, 6.735736988, 6.86350695, 6.862642601, 6.861791483,
      6.860953393, 6.860128132, 6.859315504, 6.858515316, 6.857727376,
      6.856951499, 6.8561875, 6.786531355, 6.781243626, 6.764557358, 6.7586738,
      6.752879734, 6.747173811, 6.7415547, 6.736021091, 6.730571692, 6.725205233,
      6.996580595, 7.011646076, 7.026711884, 7.041778015, 7.056844465,
      7.071911228, 7.0869783, 7.102045676, 7.117113351, 7.132181321, 7.072673414,
      7.082071751, 7.091470157, 7.100868632, 7.110267174, 7.119665782,
      7.129064458, 7.138463198, 7.147862003, 7.157260873, 6.916770101,
      6.908575337, 6.900504797, 6.88101665, 6.872437019, 6.863987383,
      6.855665801, 6.847470357, 6.833527096, 6.819548791, 6.797538382,
      6.790138923, 6.771943275, 6.760065288, 6.75053915, 6.738647489,
      6.731432077, 6.712953568, 6.705591003, 6.692259288, 6.545223016,
      6.526963156, 6.502892473, 6.477555953, 6.45207177, 6.426444422,
      6.401052998, 6.386203775, 6.36074184, 6.335136017, 6.508332827,
      6.498452827, 6.493882365, 6.487527229, 6.484439675, 6.47012388,
      6.466901384, 6.463825189, 6.454065939, 6.45230522, 6.375482873,
      6.368056352, 6.353875802, 6.34171765, 6.329333787, 6.316932003,
      6.304529552, 6.292683127, 6.298300258, 6.291977041, 6.374626643,
      6.374861911, 6.370840128, 6.371520157, 6.372126819, 6.369655507,
      6.370576861, 6.369065989, 6.368184226, 6.369560562, 6.593469994,
      6.609788685, 6.626107866, 6.642427546, 6.658747732, 6.675068431,
      6.691210447, 6.707213751, 6.723217574, 6.73922191, 6.992180849,
      7.023226244, 7.057323028, 7.091424292, 7.125529906, 7.159639744,
      7.19319185, 7.220449475, 7.249000836, 7.282167246, 7.501430949,
      7.549062417, 7.596702789, 7.644351623, 7.69200848, 7.739672926,
      7.787344528, 7.835022856, 7.882707482, 7.930397978, 7.978093917,
      8.025794871, 8.073500432, 8.121210345, 8.168924429, 8.216642503,
      8.264364382, 8.312089879, 8.359818806, 8.407550971, 7.951158988,
      7.958955178, 7.977510516, 7.987585666, 7.995764298, 8.003816323,
      8.011743719, 8.028223363, 8.038569957, 8.048712494, 7.858960846,
      7.854288146, 7.849615444, 7.844942742, 7.840270038, 7.835597332,
      7.830924625, 7.826251917, 7.821579207, 7.816906495, 7.812233781,
      7.807561065, 7.802888347, 7.798215628, 7.793542906, 7.788870182,
      7.784197456, 7.779524727, 7.774851996, 7.770179263, 7.765506527,
      7.760833789, 7.756161048, 7.751488304, 7.746815558, 7.742142809,
      7.737470057, 7.732797301, 7.728124543, 7.723451782, 7.918159991,
      7.928506271, 7.938852584, 7.949198928, 7.959545302, 7.969891707,
      7.980238142, 7.990584606, 8.000931098, 8.01127762, 7.833480548,
      7.829740741, 7.826000934, 7.822261125, 7.818521316, 7.814781506,
      7.811041694, 7.807301882, 7.803562068, 7.799822254, 7.796082438,
      7.792342621, 7.788602803, 7.784862983, 7.781123163, 7.777383341,
      7.773643517, 7.769903693, 7.766163867, 7.774294324, 8.011055209,
      8.026133509, 8.041211901, 8.056290384, 8.071368956, 8.086447614,
      8.101526356, 8.116605181, 8.131684086, 8.14676307, 7.92785882, 7.926915452,
      7.926015241, 7.925156221, 7.924336516, 7.923554335, 7.922807967,
      7.922095778, 7.921416208, 7.92076777, 7.920149041, 7.919558665,
      7.918995347, 7.918457849, 7.917944992, 7.91745565, 7.916988745,
      7.920895979, 7.920479112, 7.920075007, 8.068349698, 8.078696393,
      8.089043113, 8.099389858, 8.109736626, 8.120083418, 8.130430232,
      8.14077707, 8.151123929, 8.16147081, 8.67236817, 8.720116667, 8.767866896,
      8.815618649, 8.863371718, 8.911125892, 8.958848369, 9.005703556,
      9.052559252, 9.09941532, 9.146271628, 9.193128053, 9.239984474,
      9.286840774, 9.333696841, 9.380552562, 9.427407826, 9.474262523,
      9.521116543, 9.567969773, 9.614822098, 9.6616734, 9.708523559, 9.755372447,
      9.802219933, 9.849065877, 9.895910134, 9.944362246, 9.980475016,
      9.99919544, 9.416657263, 9.416657263, 9.430053031, 9.431008714,
      9.431964396, 9.432920079, 9.433875762, 9.434831445, 9.435787127,
      9.43674281, 9.437698493, 9.438654175, 9.439609858, 9.44056554, 9.441521223,
      9.442476905, 9.443432588, 9.44438827, 9.445343953, 9.446299635, 9.2607382,
      9.244985536, 9.234249382, 9.218515327, 9.205210234, 9.191905289,
      9.179405812, 9.168836427, 9.158427059, 9.139475858, 9.461535192,
      9.473051527, 9.484567833, 9.496084108, 9.507600353, 9.519116567,
      9.530632748, 9.542148897, 9.553665013, 9.565181095, 9.25276535,
      9.240405805, 9.22804638, 9.215687073, 9.203327884, 9.190968812,
      9.178609855, 9.166251013, 9.153892285, 9.14153367, 9.055708754,
      9.040635152, 9.022463549, 9.000077094, 8.989931932, 8.967636072,
      8.95756507, 8.936298011, 8.925393434, 8.903262875, 8.781544754,
      8.754798346, 8.727967321, 8.703351822, 8.681661316, 8.65977736,
      8.626163117, 8.604384815, 8.582694866, 8.548761267, 8.639288365,
      8.624072714, 8.608876568, 8.593698809, 8.578538381, 8.563394287,
      8.545769915, 8.534011659, 8.522237875, 8.505644282, 8.5078159, 8.500504273,
      8.483581514, 8.472537393, 8.467113537, 8.466735474, 8.461488494,
      8.458686294, 8.468588382, 8.479670892, 8.891001451, 8.900993236,
      8.92231676, 8.943640263, 8.964963742, 8.98628719, 9.007610604, 9.028933977,
      9.050257305, 9.068287397, 9.447169587, 9.494024012, 9.540877713,
      9.587730575, 9.634582483, 9.681433318, 9.728282957, 9.77513127,
      9.821978123, 9.868823374, 9.596243457, 9.621328717, 9.646413697,
      9.671498383, 9.696582764, 9.708287334, 9.732397235, 9.756506827,
      9.780616098, 9.804725035, 9.468052968, 9.466143719, 9.46423447,
      9.462325222, 9.460415975, 9.458506728, 9.456597481, 9.454688235,
      9.452778989, 9.450869743, 9.487526233, 9.488481914, 9.489437596,
      9.490393277, 9.491348959, 9.49230464, 9.493260321, 9.494216003,
      9.495171684, 9.496127365, 9.345308389, 9.334842066, 9.324375819,
      9.313909648, 9.303443551, 9.292977528, 9.282511579, 9.272045702,
      9.261579899, 9.251114167, 9.08604802, 9.068084711, 9.046300872,
      9.021172491, 9.002481931, 8.97381291, 8.956874882, 8.927728701,
      8.910584316, 8.882706344, 8.851554969, 8.833758486, 8.803810384,
      8.78583277, 8.758654483, 8.737740921, 8.713324079, 8.690593191,
      8.667862994, 8.645133482, 8.573768735, 8.546762931, 8.520443234,
      8.494124571, 8.467806934, 8.441490315, 8.4118006, 8.388610735, 8.357617221,
      8.335638044, 8.315598041, 8.283480945, 8.261976861, 8.231219598,
      8.204911829, 8.178605017, 8.152299154, 8.125994236, 8.099690258,
      8.067299461, 8.070865713, 8.050762332, 8.022178754, 7.999491218,
      7.972423463, 7.9475559, 7.922448712, 7.897457404, 7.872466591, 7.847476218,
      7.954680673, 7.939799963, 7.924919314, 7.910038719, 7.895158171,
      7.880277663, 7.865397189, 7.850516741, 7.835156192, 7.817299494,
      7.721908393, 7.70058383, 7.682126913, 7.658157372, 7.636135462,
      7.615453465, 7.594128413, 7.572799224, 7.551477405, 7.526645246,
      7.50928081, 7.48728244, 7.463178311, 7.444411233, 7.416864487, 7.399311444,
      7.379786084, 7.353053231, 7.335538573, 7.31528134, 7.206982324,
      7.183496507, 7.150271713, 7.115851852, 7.092757628, 7.058974527,
      7.035195671, 7.00070686, 6.977501073, 6.942980955, 6.87314028, 6.835656303,
      6.805033844, 6.771743105, 6.733981956, 6.695899577, 6.669026218,
      6.631007826, 6.592658073, 6.56550888, 6.561787026, 6.525401404,
      6.500148721, 6.463791362, 6.438542566, 6.402213051, 6.365525699,
      6.339916256, 6.303267329, 6.270701033, 6.286180017, 6.256441517,
      6.229441954, 6.198805498, 6.172535857, 6.140878859, 6.114732914,
      6.081859545, 6.056370457, 6.022723103, 6.054352011, 6.03420925, 6.00785178,
      5.981358725, 5.954734172, 5.933421452, 5.912644166, 5.886233107,
      5.859687837, 5.833012389, 6.008682494, 6.001061241, 5.993439967,
      5.985818671, 5.978197355, 5.970576017, 5.962954657, 5.955333275,
      5.94771187, 5.940090443, 5.735528556, 5.720054287, 5.693871149,
      5.667546358, 5.643777726, 5.621642941, 5.599423539, 5.573155291,
      5.555450019, 5.522460506, 5.681733395, 5.673161138, 5.664588837,
      5.656016492, 5.647444103, 5.638871668, 5.630299189, 5.621726664,
      5.613154093, 5.604581475, 5.416467262, 5.394339852, 5.372278662,
      5.350280687, 5.328343055, 5.304680281, 5.283983559, 5.25671144,
      5.237637219, 5.212123893, 5.219656407, 5.194517082, 5.180339117,
      5.151906978, 5.141394329, 5.119856147, 5.10205635, 5.087157419,
      5.068171879, 5.051365706, 5.051811933, 5.051043815, 5.07738389,
      5.111151682, 5.133520144, 5.148341061, 5.158162692, 5.164672051,
      5.168986478, 5.17184623, 5.38246643, 5.396300042, 5.409920201, 5.423330202,
      5.436991777, 5.452966713, 5.46894186, 5.484917209, 5.500892755,
      5.516868489, 5.318447783, 5.316458671, 5.314469559, 5.312480446,
      5.310491333, 5.308502219, 5.306513104, 5.304523989, 5.302534873,
      5.300545757, 5.847054026, 5.882968315, 5.924760873, 5.95589781,
      5.998073395, 6.034450286, 6.068288038, 6.107823605, 6.142852733,
      6.174506264, 6.152564873, 6.18627502, 6.211735417, 6.240927994, 6.27367266,
      6.306419299, 6.339168035, 6.359771334, 6.39155348, 6.423337869,
      6.662034729, 6.710407431, 6.758789217, 6.807180636, 6.855582235,
      6.903994557, 6.952418146, 7.000853543, 7.049301289, 7.097256603,
      7.009574894, 7.045711481, 7.075270636, 7.107466512, 7.143488584,
      7.174380407, 7.202894576, 7.237876918, 7.271400474, 7.299360992,
      7.47883433, 7.524529966, 7.561301165, 7.602807064, 7.635088024,
      7.678876682, 7.715514379, 7.753410263, 7.796247213, 7.826542623,
      7.943787784, 7.991485174, 8.03918746, 8.086894261, 8.134605363,
      8.182320586, 8.230039747, 8.277762661, 8.32548914, 8.373218995,
      7.936886693, 7.948177913, 7.959469174, 7.970760474, 7.982051814,
      7.993343193, 8.00463461, 8.015926064, 8.027217555, 8.038509082, 7.75140005,
      7.737833994, 7.71875458, 7.706648059, 7.694541502, 7.682434907, 7.67032827,
      7.658221587, 7.646114856, 7.634008074, 7.890642528, 7.899101144,
      7.907559778, 7.916018429, 7.924477096, 7.932935781, 7.941394482, 7.9498532,
      7.958311934, 7.966770684, 8.4446938, 8.478498811, 8.513417598, 8.54698631,
      8.58002047, 8.612528705, 8.648128079, 8.688115146, 8.715207134,
      8.751699667, 8.689654711, 8.708026887, 8.738268896, 8.764060595,
      8.784565979, 8.813398206, 8.832579503, 8.857372714, 8.885263925,
      8.911513376, 8.784540412, 8.801195016, 8.816082336, 8.829037765,
      8.837595933, 8.853318953, 8.869041964, 8.884764964, 8.900487953,
      8.916210928, 9.062901247, 9.087973054, 9.099928037, 9.124061475,
      9.148194829, 9.159182457, 9.182378172, 9.205573791, 9.223321543,
      9.238398559, 9.234274519, 9.25466191, 9.264057317, 9.281449814,
      9.300902502, 9.3203551, 9.326569019, 9.345087765, 9.363606423, 9.381577073,
      9.48021311, 9.49444528, 9.514496403, 9.537689816, 9.547577912, 9.56991699,
      9.58459468, 9.602232044, 9.619793746, 9.63286396, 9.600174117, 9.604465376,
      9.62081074, 9.637156009, 9.652352579, 9.656358502, 9.671736214,
      9.687113837, 9.6890687, 9.703479641, 9.764369151, 9.775945648, 9.791929834,
      9.797021918, 9.813365969, 9.817671411, 9.831723183, 9.841897712,
      9.848622968, 9.863032924, 9.675048945, 9.675048945, 9.675048945,
      9.675048945, 9.675048945, 9.675048945, 9.675048945, 9.675048945,
      9.675048945, 9.675048945, 9.809978167, 9.819566909, 9.823871674,
      9.831095576, 9.833934379, 9.842560949, 9.851187494, 9.835773206,
      9.830723139, 9.826288398, 9.805903239, 9.797365807, 9.797144482,
      9.796939746, 9.796750382, 9.796575259, 9.796413324, 9.796263602,
      9.796125185, 9.795997231, 9.792222725, 9.792359285, 9.792487428,
      9.792607677, 9.79272052, 9.790161145, 9.790358161, 9.79054611, 9.790725409,
      9.790896457, 9.788953024, 9.789121347, 9.787305007, 9.787414411,
      9.78752214, 9.787628217, 9.787732668, 9.787835519, 9.787936794,
      9.788036516, 9.788134711, 9.7882314, 9.788326608, 9.788420357, 9.788512669,
      9.788603567, 9.78709833, 9.78709833, 9.78709833, 9.78709833, 9.788693071,
      9.788781204, 9.788867986, 9.787430874, 9.787430874, 9.787430874,
      9.787430874, 9.787430874, 9.787430874, 9.787430874, 9.774745598,
      9.773790606, 9.772835614, 9.771880621, 9.770925629, 9.769970637,
      9.769015645, 9.768060653, 9.767105662, 9.76615067, 9.77787767, 9.77787767,
      9.77787767, 9.77787767, 9.774507754, 9.764941914, 9.763986922, 9.76303193,
      9.762076939, 9.761121948, 9.760166956, 9.759211965, 9.758256974,
      9.757301983, 9.756346992, 9.755392001, 9.75443701, 9.753482019,
      9.752527029, 9.751572038, 9.750617047, 9.749662057, 9.748707066,
      9.747752076, 9.739686905, 9.732631281, 9.730721961, 9.728812642,
      9.726903324, 9.724994006, 9.710412865, 9.707549884, 9.704686904,
      9.701823926, 9.686293102, 9.682477132, 9.678661165, 9.674845203,
      9.671029246, 9.654552095, 9.58648617, 9.570109976, 9.55427821, 9.541133,
      9.520495751, 9.510900903, 9.497802154, 9.480191221, 9.461876601,
      9.448254292, 9.425711405, 9.402570768, 9.391452392, 9.367897103,
      9.356360702, 9.332404054, 9.30787291, 9.295360304, 9.270458871,
      9.244998462, 9.294383053, 9.2761952, 9.262485164, 9.252544843, 9.239102725,
      9.220349869, 9.210103959, 9.200013235, 9.17754645, 9.167005213,
      9.131585415, 9.110323718, 9.095215435, 9.08309255, 9.058741559,
      9.046831752, 9.022695876, 9.010370298, 8.99828659, 8.973937304,
      8.986382935, 8.975565754, 8.952481297, 8.941271332, 8.930230654,
      8.906942887, 8.895516027, 8.884261666, 8.860780675, 8.849146424,
      8.874841748, 8.865711327, 8.85393991, 8.835329676, 8.82589041, 8.816593968,
      8.801954488, 8.785748037, 8.77615238, 8.766701872, 9.018843518,
      9.026215785, 9.021828984, 9.026950894, 9.033399033, 9.039847169,
      9.046295302, 9.052743432, 9.05919156, 9.065639685, 8.917829571,
      8.913246067, 8.908662569, 8.904079076, 8.899495589, 8.894912107,
      8.89032863, 8.885745159, 8.881161693, 8.876578233, 9.026029731, 9.03247787,
      9.038926007, 9.04537414, 9.051822271, 9.058270399, 9.064718524,
      9.071166646, 9.077614766, 9.084062882, 8.936163642, 8.931580116,
      8.926996596, 8.922413081, 8.917829571, 8.913246067, 8.908662569,
      8.904079076, 8.899495589, 8.894912107, 8.965285652, 8.953009675,
      8.953009675, 8.953009675, 8.953009675, 8.953009675, 8.953009675,
      8.953009675, 8.953009675, 8.953009675, 8.891245325, 8.886661853,
      8.882078386, 8.877494925, 8.872911469, 8.868328018, 8.863744573,
      8.859161133, 8.854577699, 8.84999427, 8.845410846, 8.840827428,
      8.836244015, 8.831660607, 8.827077205, 8.822493808, 8.817910416,
      8.81332703, 8.808743649, 8.804160273, 8.645025061, 8.629561302,
      8.613972468, 8.592326323, 8.578979702, 8.560968755, 8.539135904,
      8.517066968, 8.501915818, 8.484815289, 8.47484609, 8.452936088,
      8.430792548, 8.418639855, 8.398499204, 8.376213529, 8.362255544,
      8.343435704, 8.321137557, 8.305567595, 8.286626671, 8.267647474,
      8.248631761, 8.229581207, 8.210497413, 8.191381902, 8.172236131,
      8.164830091, 8.146312288, 8.122229798, 8.256505924, 8.25129247,
      8.248226611, 8.245683652, 8.231164368, 8.228471286, 8.225900255,
      8.223445819, 8.22110276, 8.218866087, 8.423872324, 8.434219599,
      8.438599632, 8.446420854, 8.451292726, 8.460647307, 8.469870134,
      8.479092965, 8.4883158, 8.497538639, 8.390097993, 8.391016941, 8.391935889,
      8.392854837, 8.393773785, 8.394692733, 8.395611681, 8.396530629,
      8.397449577, 8.398368525, 8.374208377, 8.373290201, 8.372372025,
      8.371453849, 8.370535673, 8.369617497, 8.368699321, 8.367781146,
      8.36686297, 8.365944794, 8.390097993, 8.391016941, 8.391935889,
      8.392854837, 8.393773785, 8.394692733, 8.395611681, 8.396530629,
      8.397449577, 8.398368525, 8.606748551, 8.622471521, 8.633325105,
      8.640585419, 8.65537761, 8.67016981, 8.684962016, 8.699754228, 8.703408979,
      8.715527117, 9.107141878, 9.13523531, 9.153864201, 9.174841412,
      9.199089453, 9.222374985, 9.24469911, 9.266062937, 9.286467582,
      9.305914167, 9.232217294, 9.24317106, 9.253178044, 9.27012848, 9.284116071,
      9.292224068, 9.306616957, 9.319347666, 9.325561991, 9.34408074,
      9.336093599, 9.339567015, 9.355215093, 9.35766501, 9.372456189,
      9.373963567, 9.374535455, 9.387467342, 9.387099691, 9.399103044,
      9.371179325, 9.367088989, 9.375402447, 9.370692304, 9.378358239,
      9.386024166, 9.380343705, 9.387048824, 9.380402451, 9.386147498,
      9.325113242, 9.326068926, 9.327024611, 9.327980296, 9.328935981,
      9.329891666, 9.317489304, 9.317489304, 9.317489304, 9.317489304,
      9.292457015, 9.290547806, 9.288638597, 9.286729389, 9.284820181,
      9.282910974, 9.281001767, 9.279092561, 9.277183355, 9.275274149,
      9.364557666, 9.356528321, 9.360355436, 9.350827069, 9.35369631,
      9.343207885, 9.345119983, 9.333672957, 9.334628642, 9.335584326,
      9.323179795, 9.310661519, 9.309706557, 9.308751594, 9.307796631,
      9.306841668, 9.301324611, 9.300283439, 9.290785087, 9.30139068,
      9.300435718, 9.299480756, 9.298525793, 9.297570831, 9.296615869,
      9.295660907, 9.294705945, 9.293750983, 9.292796021, 9.29184106,
      9.290886098, 9.289931136, 9.288976174, 9.288021213, 9.287066251,
      9.28611129, 9.285156328, 9.284201367, 9.283246406, 9.282291444,
      9.281336483, 9.280381522, 9.279426561, 9.2784716, 9.277516639, 9.276561678,
      9.275606717, 9.274651756, 9.273696795, 9.272741834, 9.271786873,
      9.270831913, 9.269876952, 9.268921991, 9.267967031, 9.26701207, 9.26605711,
      9.26510215, 9.264147189, 9.263192229, 9.262237269, 9.261282308,
      9.260327348, 9.259372388, 9.258417428, 9.257462468, 9.256507508,
      9.255552548, 9.254597589, 9.253642629, 9.252687669, 9.251732709,
      9.25077775, 9.24982279, 9.248867831, 9.247912871, 9.246968862, 9.246050645,
      9.245132429, 9.244214213, 9.243295997, 9.242377781, 9.241459565,
      9.240541349, 9.239623133, 9.238704917, 9.237786701, 9.236868485,
      9.235950269, 9.235032054, 9.234113838, 9.233195622, 9.232277407,
      9.231359191, 9.230440976, 9.229522761, 9.228604545, 9.22768633,
      9.226768115, 9.225849899, 9.224931684, 9.223566374, 9.222813118,
      9.222071392, 9.221203535, 9.22028532, 9.219367106, 9.218448891,
      9.217530676, 9.216612461, 9.215694247, 9.214776032, 9.213857817,
      9.212939603, 9.212021389, 9.211103174, 9.21018496, 9.209266745,
      9.208348531, 9.207430317, 9.206512103, 9.205593889, 9.204675675,
      9.203757461, 9.202839247, 9.201921033, 9.201002819, 9.200084605,
      9.199166391, 9.198248177, 9.197329964, 9.19641175, 9.195493537,
      9.194575323, 9.19365711, 9.192738896, 9.191820683, 9.190902469,
      9.189984256, 9.189066043, 9.18814783, 9.187229616, 9.186311403, 9.18539319,
      9.184474977, 9.183556764, 9.178338058, 9.177359522, 9.176395962,
      9.175447146, 9.174512851, 9.173592854, 9.172686937, 9.171794884,
      9.170916484, 9.170051528, 9.16919981, 9.168361128, 9.167535283,
      9.166722078, 9.16592132, 9.165132818, 9.164356387, 9.16359184, 9.162838996,
      9.162097676, 9.161217632, 9.16029942, 9.159381209, 9.158462997,
      9.157544785, 9.156626574, 9.155708362, 9.154790151, 9.153871939,
      9.152953728, 9.152035517, 9.151117305, 9.150199094, 9.149280883,
      9.148362672, 9.147444461, 9.14652625, 9.145608039, 9.144689828,
      9.143771617, 9.142853406, 9.141935195, 9.141016985, 9.140098774,
      9.139180563, 9.138262353, 9.130014677, 9.128858285, 9.127719584,
      9.126598305, 9.125494182, 9.124406952, 9.123336356, 9.122282142,
      9.121244059, 9.12022186, 9.119215302, 9.118224147, 9.117248159,
      9.116287106, 9.115340761, 9.114408898, 9.113491295, 9.112587736,
      9.111698005, 9.110821891, 9.109959185, 9.109109684, 9.108273184,
      9.107449488, 9.106638399, 9.105839724, 9.105053275, 9.104278863,
      9.103516305, 9.10276542, 9.102026029, 9.101110101, 9.100191893,
      9.099273684, 9.098355475, 9.097437267, 9.096519058, 9.09560085,
      9.094682642, 9.093764433, 9.092846225, 9.091928017, 9.091009809, 9.0900916,
      9.089173392, 9.088255184, 9.077965234, 9.076688024, 9.07543035,
      9.074191915, 9.072972425, 9.07177159, 9.070589125, 9.06942475, 9.068278189,
      9.067149169, 9.066037422, 9.064942685, 9.063864698, 9.062803205,
      9.061757953, 9.060728695, 9.059715186, 9.058717186, 9.057734457,
      9.056766767, 9.055813884, 9.054875584, 9.053951644, 9.053041842,
      9.052145965, 9.051263798, 9.050395132, 9.049539762, 9.048697482,
      9.047868094, 9.047051401, 9.046247208, 9.045455323, 9.04467556,
      9.043907732, 9.043151658, 9.042407157, 9.041564808, 9.040646602,
      9.039728397, 9.038810191, 9.037891986, 9.03697378, 9.036055575,
      9.035137369, 9.034219164, 9.033300958, 9.02200026, 9.020662139,
      9.019344485, 9.018046984, 9.01676933, 9.015511219, 9.014272354,
      9.013052439, 9.011851186, 9.010668309, 9.009503528, 9.008356567,
      9.007227153, 9.006115019, 9.005019899, 9.003941535, 9.002879671,
      9.001834054, 9.000804435, 8.999790572, 8.998792222, 8.997809149,
      8.996841119, 8.995887903, 8.994949273, 8.994025008, 8.993114888,
      8.992218695, 8.991336219, 8.990467247, 8.989611576, 8.988769, 8.98793932,
      8.987122339, 8.986317863, 8.985525699, 8.984745661, 8.983977563,
      8.983221222, 8.982476458, 8.981632161, 8.980713958, 8.979795755,
      8.978877552, 8.97795935, 8.977041147, 8.976122945, 8.964275142,
      8.962903036, 8.961551914, 8.960221458, 8.95891135, 8.957621282,
      8.956350946, 8.955100041, 8.953868271, 8.952655344, 8.951460971,
      8.950284869, 8.94912676, 8.947986368, 8.946863423, 8.945757658,
      8.944668811, 8.943596623, 8.94254084, 8.941501212, 8.94047749, 8.939469433,
      8.938476801, 8.937499359, 8.936536873, 8.935589116, 8.934655862,
      8.933736891, 8.932831982, 8.931940923, 8.9310635, 8.930199505, 8.929348734,
      8.928510984, 8.927686056, 8.926873754, 8.926073884, 8.925286258,
      8.924510687, 8.923746987, 8.922994978, 8.922254479, 8.921338236,
      8.920420036, 8.919501836, 8.918583636, 8.917665437, 8.916747237,
      8.904808165, 8.903428714, 8.90207036, 8.900732781, 8.89941566, 8.898118684,
      8.896841546, 8.895583943, 8.894345577, 8.893126154, 8.891925385,
      8.890742984, 8.889578671, 8.888432171, 8.88730321, 8.886191521,
      8.885096841, 8.884018908, 8.882957469, 8.881912269, 8.880883062,
      8.879869603, 8.878871652, 8.877888971, 8.876921326, 8.87596849,
      8.875030234, 8.874106336, 8.873196577, 8.87230074, 8.861448503,
      8.859612867, 8.857777231, 8.855941596, 8.854105961, 8.852270326,
      8.850434691, 8.848599057, 8.846763424, 8.84492779, 8.818456692,
      8.814788471, 8.801735906, 8.794440327, 8.782316973, 8.77240336,
      8.766905632, 8.757192644, 8.743294472, 8.735184178, 8.718048935,
      8.710724826, 8.693770144, 8.683072367, 8.674836276, 8.654320212,
      8.645172915, 8.635206721, 8.615622734, 8.604571365, 8.648743071,
      8.64395382, 8.631599092, 8.625188031, 8.618776985, 8.612365952,
      8.605954933, 8.599543928, 8.593132937, 8.579063714, 8.54904499,
      8.542127321, 8.525776889, 8.516630162, 8.507483474, 8.498336826,
      8.481779604, 8.474064221, 8.457733855, 8.447677045, 8.462649364,
      8.453819261, 8.445583985, 8.437348737, 8.429113519, 8.417730592,
      8.410986578, 8.392176905, 8.384911325, 8.377755931, 8.407178033,
      8.402416146, 8.397726728, 8.393108685, 8.388560936, 8.372430319,
      8.366830528, 8.361770525, 8.356787495, 8.351880273, 8.529970226,
      8.537342582, 8.544714939, 8.552087296, 8.559459655, 8.566832015,
      8.574204375, 8.581576736, 8.582464099, 8.582853064, 8.465131893,
      8.463142525, 8.461183553, 8.459254513, 8.457354951, 8.455484415,
      8.453642465, 8.451828663, 8.450042582, 8.448283799, 8.565897282,
      8.572345502, 8.578793722, 8.585241942, 8.591690163, 8.598138384,
      8.604586605, 8.611034826, 8.617483048, 8.623931269, 8.509903345,
      8.508145879, 8.506415275, 8.504711123, 8.50303302, 8.501380569,
      8.499753378, 8.498151062, 8.496573242, 8.495019544, 8.531581373,
      8.532500322, 8.53341927, 8.521317389, 8.521317389, 8.521317389,
      8.521317389, 8.521317389, 8.521317389, 8.521317389, 8.495683383,
      8.49414329, 8.492626743, 8.491133384, 8.489418824, 8.487583254,
      8.485747684, 8.483912114, 8.482076545, 8.480240975, 8.478405407,
      8.476569838, 8.465798093, 8.463798546, 8.461829551, 8.45989064,
      8.457981357, 8.456101249, 8.454249872, 8.452426788, 8.341249955,
      8.332939776, 8.324755436, 8.304554963, 8.295893076, 8.287362284,
      8.26683458, 8.257836704, 8.248799602, 8.228125304, 8.226136851,
      8.210069646, 8.201023939, 8.192093056, 8.171008021, 8.161413275,
      8.145537233, 8.130179856, 8.120278616, 8.10890398, 8.088758339, 8.0785597,
      8.068515126, 8.046574634, 8.036090219, 8.021195978, 8.003279918,
      7.992526593, 7.969916633, 7.958744695, 8.091822479, 8.089933972,
      8.088074326, 8.086243101, 8.084439862, 8.082664184, 8.080915647,
      8.079193836, 8.077498344, 8.07582877, 8.241496851, 8.2518439, 8.262190966,
      8.272538048, 8.282885147, 8.29323226, 8.290693181, 8.300095983,
      8.309498795, 8.318901617, 8.21219563, 8.213132588, 8.214069546,
      8.215006505, 8.215943463, 8.216880421, 8.217817379, 8.218754337,
      8.219691295, 8.220628254, 8.197451851, 8.196752358, 8.196063574,
      8.195385333, 8.194717476, 8.194059842, 8.193412276, 8.192774623,
      8.192146732, 8.191528454, 8.21342318, 8.214360138, 8.215297096,
      8.216234054, 8.217171012, 8.218107971, 8.219044929, 8.219981887,
      8.220918845, 8.221855804, 8.429275317, 8.445304164, 8.461333053,
      8.477361981, 8.480555834, 8.495547763, 8.510627981, 8.525708222,
      8.540640723, 8.555432823, 8.939965405, 8.961680445, 8.988875682,
      9.015105393, 9.040370612, 9.064672388, 9.08426153, 9.098818728,
      9.117656758, 9.137171423, 9.064012329, 9.076677689, 9.098346157,
      9.108411475, 9.117531109, 9.138854198, 9.14702069, 9.154243749,
      9.168767889, 9.17962336, 9.171767803, 9.188421847, 9.191875111,
      9.196915502, 9.20935897, 9.210931721, 9.224793307, 9.22542493, 9.225435876,
      9.237147718, 9.209417418, 9.205391634, 9.213688619, 9.221985596,
      9.217024293, 9.224396429, 9.218504409, 9.224952447, 9.231400481,
      9.22457665, 9.16373101, 9.164649955, 9.165568899, 9.166487843, 9.167406788,
      9.168325732, 9.155968411, 9.155968411, 9.155968411, 9.155968411,
      9.122483209, 9.120525348, 9.113760171, 9.11100774, 9.108255311,
      9.105502882, 9.102750455, 9.09999803, 9.097245605, 9.094493182,
      9.195340781, 9.18667552, 9.190355704, 9.180765621, 9.183524657,
      9.173011224, 9.174849847, 9.163414533, 9.164333477, 9.165252421,
      9.152896328, 9.140462594, 9.139544383, 9.138626172, 9.137707962,
      9.124357484, 9.122521797, 9.12068611, 9.118850424, 9.117014738,
      9.115179052, 9.113343367, 9.111507682, 9.109671997, 9.107836313,
      9.106000629, 9.104164946, 9.102329263, 9.10049358, 9.098657898,
      9.096822216, 9.094986534, 9.093150853, 9.091315172, 9.089479492,
      9.087643812, 9.085808132, 9.083972453, 9.082136774, 9.080301095,
      9.078465417, 9.076629739, 9.074794061, 9.072958384, 9.071122708,
      9.069287031, 9.067451355, 9.065615679, 9.063780004, 9.061944329,
      9.060108655, 9.058272981, 9.056437307, 9.054601633, 9.05276596,
      9.050930287, 9.049094615, 9.047258943, 9.045423271, 9.0435876, 9.041751929,
      9.039916259, 9.038080589, 9.036244919, 9.034409249, 9.03257358,
      9.030737911, 9.028902243, 9.027066575, 9.025230907, 9.02339524,
      9.021559573, 9.019723907, 9.017888241, 9.016052575, 9.014216909,
      9.012381244, 9.010545579, 9.008709915, 9.006874251, 9.005038587,
      9.003202924, 9.001367261, 8.999531598, 8.997695936, 8.995860274,
      8.994024613, 8.992188951, 8.990353291, 8.98851763, 8.98668197, 8.98484631,
      8.983010651, 8.981174992, 8.979339333, 8.977503675, 8.975668017,
      8.973832359, 8.971996702, 8.970161045, 8.968325388, 8.966489732,
      8.964654076, 8.962818421, 8.960982766, 8.959147111, 8.957311456,
      8.955475802, 8.953640148, 8.951804495, 8.949968842, 8.948133189,
      8.946297537, 8.944461885, 8.942626233, 8.940790582, 8.938954931,
      8.93711928, 8.93528363, 8.93344798, 8.931612331, 8.929776681, 8.927941033,
      8.926105384, 8.924269736, 8.922434088, 8.920598441, 8.918762793,
      8.916927147, 8.9150915, 8.912564332, 8.899022886, 8.896535523, 8.894366221,
      8.89223006, 8.890126535, 8.888055148, 8.886015411, 8.884006841,
      8.882028963, 8.863210362, 8.852497535, 8.849170364, 8.845893941,
      8.834828214, 8.826699649, 8.822851856, 8.819062711, 8.803009532,
      8.798609411, 8.745007394, 8.72553104, 8.717754614, 8.69779072, 8.677225475,
      8.656068846, 8.634330628, 8.612020441, 8.589147742, 8.565721818,
      8.578556649, 8.559960982, 8.54577474, 8.523026309, 8.499722748,
      8.488112829, 8.464444511, 8.440236289, 8.427561336, 8.403164056,
      8.414714736, 8.403483273, 8.380226635, 8.368611803, 8.344989997,
      8.329727033, 8.308832958, 8.287306722, 8.271626802, 8.256283904,
      8.234734183, 8.212940001, 8.190909035, 8.168648711, 8.146166218,
      8.135572342, 8.113198154, 8.090371511, 8.067206092, 8.043828629,
      8.080609575, 8.062623739, 8.050483866, 8.02946027, 8.020189577,
      8.002122632, 7.983959663, 7.965705089, 7.947363121, 7.932104169,
      7.904808545, 7.889338827, 7.873886707, 7.850565931, 7.830926222,
      7.814214154, 7.792318757, 7.777860888, 7.762830624, 7.732833229,
      7.884781225, 7.880686772, 7.878448915, 7.877867911, 7.878670269,
      7.88054052, 7.880432128, 7.882418486, 7.884252095, 7.890238897,
      8.191574712, 8.207996615, 8.220683389, 8.240513166, 8.260343106,
      8.280173201, 8.300003447, 8.315502915, 8.330943959, 8.345701745,
      8.737658045, 8.771553364, 8.807576575, 8.843296533, 8.880968564,
      8.911560579, 8.946007632, 8.978702973, 9.010096594, 9.037272802,
      9.180700586, 9.22755702, 9.274413364, 9.321269503, 9.368125326,
      9.414980722, 9.461835581, 9.508689791, 9.555543242, 9.602395818,
      9.649247403, 9.696097877, 9.716454845, 9.734865976, 9.751335883,
      9.765869182, 9.776082915, 9.79059287, 9.795538992, 9.808448775,
      9.573664952, 9.587110561, 9.587161723, 9.599642122, 9.608359566,
      9.610924859, 9.622440763, 9.620539543, 9.631091749, 9.628218899,
      9.352503957, 9.339205066, 9.317414441, 9.3046319, 9.279704494, 9.261985422,
      9.240201795, 9.225951215, 9.199153995, 9.178610035, 9.17870364,
      9.154672225, 9.138810366, 9.117947398, 9.095480483, 9.079343741,
      9.054709669, 9.034279088, 9.016202633, 8.990665306, 8.977073179,
      8.954744909, 8.937423735, 8.911404157, 8.889716785, 8.870359435,
      8.843461297, 8.816075099, 8.78989477, 8.769865955, 8.799362063,
      8.780647483, 8.755144881, 8.741492206, 8.719796708, 8.70197141,
      8.675878553, 8.661616611, 8.637078733, 8.618859242, 8.588331025,
      8.566575578, 8.538964072, 8.52316139, 8.495319518, 8.477836234,
      8.451124205, 8.425046129, 8.405986813, 8.37725238, 8.435308197,
      8.421305538, 8.409071701, 8.389259958, 8.37249581, 8.358161227,
      8.335581995, 8.322834906, 8.298672563, 8.285058817, 8.27217056,
      8.250121818, 8.234272656, 8.217353072, 8.196057701, 8.182706142,
      8.15744283, 8.14377134, 8.130305304, 8.104804413, 8.199505125, 8.192255158,
      8.185115173, 8.178083516, 8.171158558, 8.164338694, 8.145553595,
      8.138195011, 8.130948031, 8.123810977, 8.068569759, 8.058676126,
      8.048932005, 8.039335163, 8.017851409, 8.007800758, 7.997901942,
      7.988152695, 7.970720152, 7.956601586, 7.991646487, 7.975451904,
      7.968587622, 7.960490927, 7.953158241, 7.945936743, 7.934664783,
      7.929180162, 7.912549658, 7.906204524, 7.825915327, 7.808063373,
      7.790235033, 7.777912783, 7.756934086, 7.747601638, 7.72662859,
      7.717288247, 7.696320878, 7.681228781, 7.784669531, 7.780951423,
      7.777346235, 7.77385057, 7.77046113, 7.767174713, 7.755576474, 7.753199131,
      7.750929756, 7.748763505, 7.651743889, 7.634835121, 7.617776595,
      7.612427784, 7.595470946, 7.586326596, 7.571751971, 7.557141343,
      7.542496883, 7.533679346, 7.611144812, 7.606497443, 7.605277715,
      7.603813356, 7.603658978, 7.59318008, 7.593970743, 7.594686939,
      7.587601183, 7.589117806, 7.590470218, 7.586175471, 7.588079791,
      7.585515652, 7.584097493, 7.586793422, 7.586459002, 7.586849731,
      7.586026337, 7.587989523, 7.619910672, 7.620847618, 7.621784564,
      7.622721509, 7.623658455, 7.624595401, 7.625532347, 7.626469292,
      7.627406238, 7.628343184, 7.794045444, 7.807227753, 7.820410142,
      7.83501487, 7.846880692, 7.860063312, 7.873246008, 7.912079531,
      7.902989187, 7.914804379, 8.386100349, 8.433834215, 8.481571018,
      8.529310562, 8.577052648, 8.624797076, 8.672543644, 8.720292149,
      8.768042383, 8.815794141, 8.863547215, 8.911301393, 8.959020563,
      9.005875752, 9.05273145, 9.099587518, 9.146443827, 9.193300252,
      9.240156673, 9.287012973, 9.333869039, 9.380724758, 9.42758002,
      9.474434715, 9.521288732, 9.568141959, 9.61499428, 9.661845579,
      9.708695733, 9.755544617, 9.802392097, 9.835950241, 9.841922474,
      9.832945922, 9.833644106, 9.831344045, 9.820394125, 9.803986009,
      9.791777319, 9.776614327, 9.637695174, 9.634819824, 9.630977952,
      9.626170655, 9.620399022, 9.613664143, 9.605967104, 9.597308989,
      9.587690879, 9.577113855, 9.53952964, 9.538574664, 9.537619688,
      9.536664712, 9.535709736, 9.53475476, 9.533799784, 9.520244801,
      9.518335539, 9.516426277, 9.514517016, 9.512607756, 9.510698496,
      9.508789237, 9.506879978, 9.504970719, 9.503061461, 9.501152204,
      9.499242946, 9.49733369, 9.495424434, 9.493515178, 9.491605923,
      9.489696668, 9.487787414, 9.48587816, 9.483968907, 9.482059654,
      9.480150401, 9.478241149, 9.476331898, 9.474422647, 9.472513396,
      9.470604146, 9.468694897, 9.466785647, 9.464876399, 9.46296715,
      9.461057903, 9.459148655, 9.457239408, 9.455330162, 9.453420916,
      9.451511671, 9.449602425, 9.447693181, 9.445783937, 9.443874693,
      9.44196545, 9.440056207, 9.438146965, 9.436237723, 9.434328481, 9.43241924,
      9.43051, 9.42860076, 9.42669152, 9.424782281, 9.422873042, 9.420963804,
      9.419054566, 9.417145329, 9.415236092, 9.413326855, 9.411417619,
      9.409508384, 9.407599149, 9.405689914, 9.40378068, 9.401871446,
      9.399962212, 9.398052979, 9.396143747, 9.394234515, 9.392325283,
      9.390416052, 9.388506821, 9.386597591, 9.384688361, 9.382779132,
      9.380869903, 9.378960674, 9.377051446, 9.375142218, 9.373232991,
      9.371323764, 9.369414538, 9.367505312, 9.365596086, 9.363686861,
      9.361777636, 9.359868412, 9.357959188, 9.356049965, 9.354140742,
      9.352231519, 9.350322297, 9.348413075, 9.346503854, 9.344594633,
      9.330150509, 9.327287745, 9.324424982, 9.321562221, 9.318699461,
      9.315836702, 9.300445442, 9.29662986, 9.292814281, 9.288998706,
      9.285183133, 9.281367564, 9.277551999, 9.273736437, 9.269920878,
      9.266105322, 9.26228977, 9.258474221, 9.254658675, 9.250843132,
      9.184485195, 9.175916409, 9.16734766, 9.151174012, 9.143932827,
      9.137082619, 9.12002985, 9.1106276, 9.101712214, 9.092562743, 9.033590804,
      9.008351551, 8.993212544, 8.969852648, 8.945946692, 8.926299488,
      8.898368611, 8.881953652, 8.85313089, 8.832306472, 8.805999984,
      8.787630059, 8.75702871, 8.737251795, 8.709704407, 8.681679846,
      8.653185929, 8.624230341, 8.594820636, 8.564964243, 8.578764319,
      8.555727055, 8.52737968, 8.498568577, 8.481576797, 8.452572985,
      8.423116278, 8.394397553, 8.371675909, 8.344913677, 8.289983221,
      8.263917841, 8.237467111, 8.205037819, 8.172211605, 8.138994946,
      8.105394207, 8.07141565, 8.037065431, 8.002349605, 7.967274126,
      7.931476145, 7.895101605, 7.858375691, 7.82130397, 7.783891895,
      7.746144805, 7.708067929, 7.669666384, 7.630945177, 7.591909205,
      7.552563257, 7.512912016, 7.468416959, 7.420523446, 7.379265552,
      7.337731185, 7.295924291, 7.25384872, 7.211508226, 7.180227103,
      7.133691665, 7.084065833, 7.040684256, 6.997055391, 6.953182436,
      6.907687047, 6.859484014, 6.810935395, 6.762051427, 6.833265866,
      6.796991918, 6.764636228, 6.720747608, 6.687961139, 6.655250078,
      6.611057789, 6.577935461, 6.535647653, 6.499973873, 6.585858983,
      6.554049167, 6.528973367, 6.506208882, 6.472098656, 6.449165356,
      6.426352788, 6.396847726, 6.369410573, 6.338283607, 6.411492135,
      6.395444364, 6.371838301, 6.359284716, 6.346147413, 6.325639268,
      6.31131567, 6.292278871, 6.276986617, 6.264287037, 6.299930152, 6.28731645,
      6.290801194, 6.289512306, 6.295119352, 6.297651536, 6.315377994,
      6.333077783, 6.335842751, 6.34266623, 6.373120394, 6.373120394,
      6.373120394, 6.373120394, 6.373120394, 6.373120394, 6.373120394,
      6.373120394, 6.373120394, 6.373120394, 6.985928722, 7.034372606,
      7.082612466, 7.130145676, 7.177691919, 7.225250701, 7.272821534,
      7.320403935, 7.367997431, 7.415601554, 7.463215843, 7.510839844,
      7.558473106, 7.606115185, 7.653765638, 7.701424029, 7.749089923,
      7.796762888, 7.844442494, 7.892128314, 7.939819918, 7.987516882,
      8.035218776, 8.082925212, 8.130635963, 8.17835085, 8.22606969, 8.273792299,
      8.321518489, 8.36924807, 8.416980852, 8.464716641, 8.512455239,
      8.560196451, 8.607940075, 8.655685911, 8.703433755, 8.751183402,
      8.798934646, 8.846687279, 8.894441091, 8.942195872, 8.989332897,
      9.036188431, 9.083044384, 9.129900623, 9.176757021, 9.223613457,
      9.270469812, 9.317325973, 9.364181828, 9.411037264, 9.457892172,
      9.504746441, 9.55159996, 9.598452614, 9.645304287, 9.69215486, 9.739004207,
      9.785852198, 9.674596761, 9.695552128, 9.716002696, 9.729920582,
      9.744590119, 9.763147501, 9.767337115, 9.782936112, 9.797110163,
      9.804957078, 9.783081926, 9.791819213, 9.799576763, 9.806355716,
      9.809661105, 9.810427425, 9.810203718, 9.822360883, 9.821074825,
      9.818728759, 9.716618723, 9.721404232, 9.726189737, 9.717486605,
      9.72131358, 9.725140554, 9.727832868, 9.730769563, 9.722907479,
      9.725776637, 9.728645795, 9.731514952, 9.734384108, 9.723752272,
      9.725664332, 9.727576392, 9.729488451, 9.717896682, 9.718852357,
      9.719808032, 9.720763707, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.708214135, 9.708214135,
      9.708214135, 9.708214135, 9.708214135, 9.695556304, 9.681943821,
      9.660151509, 9.638658611, 9.621236407, 9.602864584, 9.580503188,
      9.550400391, 9.51559387, 9.478899701, 9.452956749, 9.421872173,
      9.385311323, 9.355608089, 9.318468528, 9.280302318, 9.246855237,
      9.199888152, 9.302023899, 9.276472167, 9.260098129, 9.232338883,
      9.214324202, 9.187367663, 9.162623868, 9.136004144, 9.109223086,
      9.081203438, 9.083127483, 9.05259507, 9.033632344, 9.008575511, 8.98367773,
      8.953760749, 8.932174112, 8.899694864, 8.878760911, 8.845397468,
      8.871748574, 8.844828846, 8.823544157, 8.802288118, 8.772744281,
      8.752715876, 8.720313873, 8.699384702, 8.672669812, 8.644753896,
      8.650800258, 8.627813703, 8.606917851, 8.57868001, 8.554703638, 8.5333885,
      8.504484211, 8.479005069, 8.457181092, 8.428240985, 8.449758627,
      8.430639655, 8.404666612, 8.379666956, 8.360957074, 8.339725696,
      8.317020132, 8.288762918, 8.266487507, 8.24341779, 8.165840769,
      8.138423634, 8.11301552, 8.081091626, 8.048384101, 8.015284543,
      7.984213585, 7.95647907, 7.925359793, 7.890902796, 7.96871184, 7.948219851,
      7.919827417, 7.902983215, 7.874371793, 7.852828732, 7.828193999,
      7.809923175, 7.781808314, 7.75477655, 7.77036014, 7.754838447, 7.730042859,
      7.711959426, 7.691176977, 7.668821495, 7.651978397, 7.625428494,
      7.60933029, 7.581588489, 7.636483782, 7.617230622, 7.600969582,
      7.588908826, 7.572600426, 7.553206286, 7.540943912, 7.527480548,
      7.505058851, 7.492600598, 7.399215429, 7.380491305, 7.351689275,
      7.334194955, 7.30518857, 7.287474324, 7.258269917, 7.240341842,
      7.210945522, 7.192809514, 7.409272986, 7.406606348, 7.403980422,
      7.40139459, 7.398848241, 7.396340774, 7.393871598, 7.39144013, 7.389045797,
      7.386688033, 7.337551859, 7.332251946, 7.327032647, 7.321892746,
      7.316831043, 7.305978739, 7.294870893, 7.289290289, 7.283794538,
      7.278382362, 7.261375966, 7.245688047, 7.240703341, 7.230835635,
      7.224369933, 7.218002426, 7.209625866, 7.20480766, 7.188484525,
      7.183380698, 7.23270668, 7.229936002, 7.227207623, 7.224520901,
      7.216733375, 7.214486823, 7.212308781, 7.210197171, 7.208149977,
      7.206165241, 7.204241069, 7.191462704, 7.188409872, 7.187520533,
      7.186685028, 7.18590014, 7.185162836, 7.184470263, 7.183819733,
      7.183208719, 7.210636391, 7.210636391, 7.210636391, 7.210636391,
      7.210636391, 7.210636391, 7.210636391, 7.210636391, 7.210636391,
      7.210636391, 7.175634454, 7.175497648, 7.175370859, 7.175253389,
      7.175144581, 7.170346444, 7.170666675, 7.170957113, 7.171220559,
      7.168266539, 7.180263515, 7.179966946, 7.179683993, 7.176939143,
      7.176747472, 7.176567519, 7.176398568, 7.176239949, 7.176091032,
      7.175951223, 7.177409247, 7.178759954, 7.178608215, 7.178461125,
      7.178318541, 7.178180326, 7.178046345, 7.177916469, 7.177790571,
      7.177668532, 7.169530351, 7.169132824, 7.169849397, 7.169747961,
      7.169254854, 7.169690444, 7.16983314, 7.169969072, 7.170492276,
      7.170953243, 7.799682745, 7.847362744, 7.89504893, 7.942740875,
      7.990438152, 8.038140335, 8.08584704, 8.13355805, 8.181273184, 8.22899226,
      8.213294359, 8.243466965, 8.28537369, 8.403674696, 8.44538882, 8.485928514,
      8.532696302, 8.570083979, 8.612717642, 8.655850613, 8.692037016,
      8.736158716, 8.776075775, 8.812556769, 8.85642253, 8.893746232,
      8.930036034, 8.972122641, 9.006656878, 9.042752237, 9.161988241,
      9.208844678, 9.255701072, 9.302557306, 9.349413269, 9.396268849,
      9.443123936, 9.489978418, 9.536832185, 9.583685125, 9.63053712,
      9.677388053, 9.7242378, 9.771086232, 9.817933217, 9.864778612, 9.912011031,
      9.960689946, 9.989926099, 9.998331955, 9.430998098, 9.430998098,
      9.430998098, 9.430998098, 9.430998098, 9.430998098, 9.430998098,
      9.430998098, 9.430998098, 9.430998098, 9.330531717, 9.322911668,
      9.316229367, 9.307742808, 9.300122843, 9.292502906, 9.284882996,
      9.277263114, 9.269643259, 9.261166734, 9.192381117, 9.182558877,
      9.167264373, 9.154905636, 9.142547012, 9.130188501, 9.117830101,
      9.098534834, 9.088655886, 9.068321728, 9.043068291, 9.029371293,
      9.01567446, 8.999005347, 8.987997478, 8.964718971, 8.947526782,
      8.932923581, 8.918320572, 8.903717753, 8.839484844, 8.821261451,
      8.803038422, 8.784815755, 8.762544301, 8.73570322, 8.716578428,
      8.697454042, 8.677708899, 8.650181154, 8.738017783, 8.723729212,
      8.714084342, 8.692425789, 8.68242921, 8.664889796, 8.652104612,
      8.639987253, 8.626584185, 8.613799344, 8.490510461, 8.469586964,
      8.448663965, 8.424731573, 8.395706442, 8.37263209, 8.350810842,
      8.328990146, 8.302041766, 8.272772859, 8.457211438, 8.443305555,
      8.437083204, 8.430955358, 8.424920595, 8.40715839, 8.400250891,
      8.393772192, 8.387391853, 8.381108393, 8.342818836, 8.332762618,
      8.322706451, 8.312650336, 8.302594271, 8.304668324, 8.291128777,
      8.283577885, 8.276141449, 8.267524682, 8.24941748, 8.241590468,
      8.233882046, 8.226290435, 8.2078907, 8.19855549, 8.190393515, 8.182355205,
      8.167592607, 8.157339128, 8.207463201, 8.201858269, 8.19730957,
      8.192879528, 8.188516949, 8.184220811, 8.179990107, 8.169470963,
      8.163866073, 8.15826119, 8.222587659, 8.222439269, 8.222293152,
      8.222149273, 8.222007598, 8.221868094, 8.221730727, 8.221595465,
      8.221462275, 8.221331125, 8.172998336, 8.169870401, 8.155252746,
      8.150992835, 8.147268427, 8.143600789, 8.13998906, 8.136432394,
      8.132929953, 8.129480917, 8.107518761, 8.101913928, 8.096309099,
      8.088525969, 8.083891038, 8.079326665, 8.074831781, 8.070405336,
      8.062705396, 8.057100594, 8.12354047, 8.12354047, 8.12354047, 8.12354047,
      8.12354047, 8.12354047, 8.12354047, 8.12354047, 8.12354047, 8.12354047,
      8.051495794, 8.045890997, 8.040286204, 8.031535119, 8.026837309,
      8.022211004, 8.017655125, 8.013168604, 8.008750394, 8.00439946,
      7.995568495, 7.989963721, 7.979127831, 7.97429738, 7.969540439,
      7.964855895, 7.960242656, 7.955699642, 7.951225791, 7.946820058,
      7.930523428, 7.925502494, 7.920557946, 7.915688631, 7.910893411,
      7.906171166, 7.901520794, 7.896941208, 7.892431338, 7.878193202,
      7.811407557, 7.802629673, 7.793984595, 7.773552501, 7.764422569,
      7.755430693, 7.746574812, 7.732397093, 7.717025714, 7.707826093,
      7.759340415, 7.753067407, 7.747956374, 7.742923086, 7.737966368,
      7.728442438, 7.724575572, 7.720826107, 7.706382152, 7.701286384,
      7.709172192, 7.705890727, 7.702709035, 7.699624107, 7.69663302,
      7.693732943, 7.679078014, 7.675782291, 7.672586773, 7.669488438,
      7.583645157, 7.56657591, 7.55777216, 7.545083252, 7.540251413, 7.5238269,
      7.508197027, 7.50229975, 7.491220435, 7.476890336, 7.611519945,
      7.611519945, 7.611519945, 7.611519945, 7.611519945, 7.611519945,
      7.611519945, 7.611519945, 7.611519945, 7.611519945, 7.474293782,
      7.460069531, 7.448143975, 7.436013481, 7.423881226, 7.411747315,
      7.399611841, 7.399779405, 7.399334232, 7.405187414, 7.471080696,
      7.467824674, 7.46924932, 7.467301549, 7.468975341, 7.468042015,
      7.467775828, 7.468067873, 7.468792074, 7.468724827, 7.479601188,
      7.47958765, 7.479575142, 7.479563586, 7.47955291, 7.479543049, 7.479533939,
      7.479525524, 7.479517751, 7.479510571, 8.112550131, 8.160263471,
      8.207980835, 8.255702037, 8.303426891, 8.35115521, 8.398886802,
      8.446621473, 8.49435903, 8.542099274, 8.589842008, 8.637587029,
      8.685334136, 8.733083124, 8.780833787, 8.828585918, 8.876339308,
      8.924093746, 8.97157188, 9.01842722, 9.06528303, 9.112139175, 9.158995527,
      9.205851963, 9.252708363, 9.299564611, 9.346420594, 9.393276202,
      9.440131323, 9.486985848, 9.533839664, 9.58069266, 9.627544719,
      9.674395723, 9.721245549, 9.76809407, 9.814941151, 9.861786652,
      9.908901848, 9.957580889, 9.845867662, 9.842555882, 9.836259558,
      9.826988864, 9.814753917, 9.799564777, 9.781431441, 9.760363849,
      9.736371879, 9.70946536, 9.612382034, 9.615251222, 9.604663851,
      9.606575926, 9.595030008, 9.582527336, 9.582527336, 9.574947556,
      9.569340116, 9.568385138, 9.56743016, 9.566475182, 9.565520204,
      9.564565226, 9.563610249, 9.562655271, 9.561700293, 9.560745316,
      9.559790339, 9.558835361, 9.545271361, 9.543362093, 9.537083542,
      9.535297013, 9.524400894, 9.521538026, 9.51867516, 9.514082037,
      9.500216543, 9.496400773, 9.517783244, 9.515873983, 9.513964722,
      9.512055462, 9.510146202, 9.495641275, 9.492778424, 9.489915574,
      9.487052726, 9.484189879, 9.506507992, 9.505553018, 9.504598044,
      9.50364307, 9.502688096, 9.501733123, 9.500778149, 9.499823175,
      9.498868201, 9.497913228, 9.590130678, 9.582442504, 9.587228107,
      9.578577044, 9.582404083, 9.572791579, 9.575660777, 9.565088276,
      9.553557938, 9.554513617, 9.542026161, 9.542026161, 9.542026161,
      9.542026161, 9.530040813, 9.528518909, 9.527563934, 9.526608958,
      9.525653983, 9.524699008, 9.523744032, 9.522789057, 9.521834082,
      9.520879107, 9.519924132, 9.518969157, 9.518014183, 9.517059208,
      9.516104233, 9.515149258, 9.514194284, 9.513239309, 9.512284335,
      9.51132936, 9.510374386, 9.509419412, 9.508464438, 9.507509463,
      9.506554489, 9.505599515, 9.504644541, 9.503689567, 9.502734593,
      9.50177962, 9.500824646, 9.499869672, 9.498914698, 9.497959725,
      9.497004751, 9.496049778, 9.495094804, 9.494139831, 9.493184858,
      9.492229884, 9.491274911, 9.490319938, 9.489364965, 9.488409992,
      9.487455019, 9.486500046, 9.485545073, 9.484590101, 9.483635128,
      9.482680155, 9.481725183, 9.48077021, 9.479815238, 9.478860265,
      9.477905293, 9.47695032, 9.475995348, 9.475040376, 9.474085404,
      9.473130432, 9.47217546, 9.471220488, 9.470265516, 9.469310544,
      9.468355572, 9.4674006, 9.466445629, 9.465490657, 9.464535686, 9.463580714,
      9.462625743, 9.461670771, 9.4607158, 9.459760829, 9.458805857, 9.457850886,
      9.456895915, 9.455940944, 9.454985973, 9.454031002, 9.453076031,
      9.45212106, 9.451166089, 9.450211119, 9.449256148, 9.448301177,
      9.447346207, 9.446391236, 9.445436266, 9.444481296, 9.443526325,
      9.442571355, 9.441616385, 9.440661415, 9.439706445, 9.438751474,
      9.437796504, 9.436841535, 9.435886565, 9.434931595, 9.433976625,
      9.433021655, 9.432066686, 9.431111716, 9.430156747, 9.429201777,
      9.428246808, 9.427291838, 9.426336869, 9.4253819, 9.42442693, 9.423471961,
      9.422516992, 9.421562023, 9.420607054, 9.419652085, 9.418697116,
      9.417742148, 9.416787179, 9.41583221, 9.414877241, 9.413922273,
      9.412967304, 9.412012336, 9.411057367, 9.410102399, 9.409147431,
      9.408192462, 9.407237494, 9.406282526, 9.405327558, 9.40437259,
      9.403417622, 9.402462654, 9.401507686, 9.400552718, 9.39959775,
      9.398642783, 9.397687815, 9.396732847, 9.39577788, 9.394822912,
      9.393867945, 9.392912977, 9.39195801, 9.391003043, 9.390048076,
      9.389093108, 9.388138141, 9.387183174, 9.386228207, 9.38527324,
      9.384318273, 9.383363306, 9.38240834, 9.381453373, 9.380498406, 9.37954344,
      9.378588473, 9.377633506, 9.37667854, 9.375723574, 9.374768607,
      9.373813641, 9.372858675, 9.371903708, 9.370948742, 9.369993776,
      9.36903881, 9.368083844, 9.367128878, 9.366173912, 9.365218946,
      9.364263981, 9.363309015, 9.362354049, 9.361399084, 9.360444118,
      9.359489153, 9.358534187, 9.357579222, 9.356624256, 9.355669291,
      9.354714326, 9.353759361, 9.352804395, 9.35184943, 9.350894465, 9.3499395,
      9.348984535, 9.348029571, 9.347074606, 9.346119641, 9.345164676,
      9.344209712, 9.343254747, 9.342299782, 9.341344818, 9.340389853,
      9.339434889, 9.338479925, 9.33752496, 9.336569996, 9.335615032,
      9.334660068, 9.333705104, 9.33275014, 9.331795176, 9.330840212,
      9.329885248, 9.328930284, 9.32797532, 9.327020357, 9.326065393,
      9.325110429, 9.324155466, 9.323200502, 9.322245539, 9.321290575,
      9.320335612, 9.319380649, 9.318425685, 9.317470722, 9.316515759,
      9.315560796, 9.314605833, 9.31365087, 9.312695907, 9.311740944,
      9.310785981, 9.309831019, 9.308876056, 9.307921093, 9.306966131,
      9.306011168, 9.305056205, 9.304101243, 9.303146281, 9.302191318,
      9.301236356, 9.300281394, 9.299326431, 9.298371469, 9.297416507,
      9.296461545, 9.295506583, 9.294551621, 9.293596659, 9.292641697,
      9.291686735, 9.290731774, 9.289776812, 9.28882185, 9.287866889,
      9.286911927, 9.285956966, 9.285002004, 9.284047043, 9.283107931,
      9.282345589, 9.281594918, 9.28085574, 9.280127877, 9.279411158,
      9.278705412, 9.278010471, 9.277326169, 9.276652344, 9.275988836,
      9.275335487, 9.274692141, 9.274058646, 9.27343485, 9.272820605,
      9.272215765, 9.271620187, 9.271033728, 9.270456249, 9.269887613,
      9.269327684, 9.268776329, 9.268233416, 9.267698817, 9.267172405,
      9.266654054, 9.26614364, 9.265641043, 9.265146142, 9.26465882, 9.264178961,
      9.263706451, 9.263241176, 9.262783027, 9.262331895, 9.261887671,
      9.26145025, 9.255463264, 9.254508304, 9.253553344, 9.252598384,
      9.245468878, 9.244328399, 9.236316634, 9.234438921, 9.23260321, 9.2307675,
      9.203984295, 9.187843466, 9.18325962, 9.166207095, 9.160708668,
      9.143647083, 9.136399877, 9.121088128, 9.110464606, 9.097242542,
      9.070479436, 9.058959898, 9.039563531, 9.01873455, 9.006216889,
      8.982816431, 8.97093701, 8.946636906, 8.933849069, 8.908650902,
      8.944575103, 8.922114752, 8.911145252, 8.900175831, 8.880255667,
      8.865194004, 8.853315578, 8.839838324, 8.817072855, 8.804286272,
      8.79149981, 8.766361157, 8.75266729, 8.738973568, 8.717941083, 8.69871402,
      8.684113929, 8.658851512, 8.641813539, 8.626307997, 8.709185485,
      8.700949298, 8.692713141, 8.684477014, 8.676240917, 8.66800485,
      8.656591458, 8.64986082, 8.630962305, 8.623711119, 8.649357319, 8.64294622,
      8.636535135, 8.630124064, 8.623713006, 8.617301963, 8.610890933,
      8.604479917, 8.598068915, 8.591657927, 8.639067333, 8.637168193,
      8.635298076, 8.633456538, 8.631643144, 8.629857466, 8.62809908,
      8.626367571, 8.624662528, 8.622983549, 8.550775369, 8.543451735,
      8.536325505, 8.53051116, 8.521622524, 8.514298972, 8.50697544, 8.499651928,
      8.492328436, 8.485004965, 8.588280175, 8.589199123, 8.590118071,
      8.591037019, 8.591955968, 8.592874916, 8.593793864, 8.594712813,
      8.595631761, 8.596550709, 8.523431146, 8.518848087, 8.514265033,
      8.509681984, 8.50509894, 8.5005159, 8.495932866, 8.491349836, 8.486766812,
      8.482183792, 8.41670708, 8.407560823, 8.398414604, 8.389268425,
      8.380122284, 8.370976182, 8.361830118, 8.352684093, 8.341512085,
      8.334105962, 8.312944659, 8.302888593, 8.292832577, 8.278508934,
      8.270241313, 8.250063595, 8.241244079, 8.232633373, 8.217657595,
      8.206692629, 8.195727728, 8.184585918, 8.17340501, 8.162224164,
      8.151043377, 8.139862648, 8.128681974, 8.117501354, 8.098786863,
      8.089360192, 8.188551381, 8.186118955, 8.183723674, 8.181364972,
      8.179042293, 8.176753095, 8.173946997, 8.171140899, 8.168334802,
      8.165528705, 8.090480825, 8.082084567, 8.073688325, 8.065292098,
      8.056895885, 8.048499686, 8.0401035, 8.031707327, 8.023311164, 8.014915013,
      8.073847515, 8.071299941, 8.068791262, 8.066320888, 8.05414358,
      8.050403778, 8.046663978, 8.042924178, 8.039872109, 8.036910186,
      7.92397355, 7.911867164, 7.899760795, 7.887654439, 7.875237499,
      7.863417587, 7.843812723, 7.833621267, 7.823583691, 7.80188067,
      7.839022515, 7.831677964, 7.824444769, 7.809599561, 7.800274656,
      7.790949741, 7.782903486, 7.775482975, 7.763316508, 7.753991545,
      7.732772862, 7.722519865, 7.712882147, 7.704670148, 7.692013613,
      7.681760516, 7.671507389, 7.661254231, 7.651001041, 7.640747817,
      7.670734001, 7.66501594, 7.651956009, 7.644489286, 7.637022547,
      7.629555793, 7.623480396, 7.617551447, 7.611712579, 7.600354403,
      7.592887563, 7.585420705, 7.577953827, 7.570486929, 7.56405117,
      7.558096311, 7.54836235, 7.540895371, 7.53342837, 7.525961346, 7.5184943,
      7.511027231, 7.504307959, 7.498331931, 7.488857912, 7.481390747,
      7.473923557, 7.466456341, 7.458989098, 7.450555049, 7.409207081,
      7.400964016, 7.392845765, 7.384850463, 7.368784462, 7.358529679,
      7.348686389, 7.340433705, 7.332305985, 7.318075408, 7.386281541,
      7.38303292, 7.379833856, 7.366210999, 7.361537792, 7.357424967,
      7.353684208, 7.350000474, 7.346372903, 7.342800641, 7.257435595,
      7.248712586, 7.231147066, 7.219402985, 7.210330002, 7.201394265,
      7.186791456, 7.17189085, 7.162611347, 7.153472189, 7.109530745,
      7.098421366, 7.075843806, 7.064319799, 7.052969525, 7.041790417,
      7.019166711, 7.007574714, 6.996157494, 6.973316201, 6.996264352,
      6.986865837, 6.966028235, 6.956162006, 6.946444955, 6.936874864,
      6.924034631, 6.906386012, 6.896496772, 6.886757077, 6.871285544,
      6.855793854, 6.84574479, 6.835847676, 6.82610025, 6.810595216, 6.795142869,
      6.785086091, 6.775181401, 6.757256655, 6.71499089, 6.697216088,
      6.684825926, 6.664069703, 6.654497644, 6.633745585, 6.624165951,
      6.603418134, 6.58826337, 6.572805494, 6.586096321, 6.577949923,
      6.558620367, 6.550380716, 6.530970495, 6.522642845, 6.506293455,
      6.494906466, 6.483402911, 6.467263127, 6.551682568, 6.549383935,
      6.539264741, 6.533426083, 6.531030957, 6.523816195, 6.522456206,
      6.521178295, 6.517868558, 6.517555215, 6.565033646, 6.565033646,
      6.565033646, 6.565033646, 6.565033646, 6.565033646, 6.565033646,
      6.565033646, 6.565033646, 6.565033646, 6.4717821, 6.462813433, 6.457688876,
      6.458980862, 6.45606773, 6.450368543, 6.453269683, 6.454679901,
      6.459156749, 6.463477339, 7.117710609, 7.16525349, 7.21280904, 7.260376768,
      7.307956189, 7.355546828, 7.403148216, 7.45075989, 7.498381394,
      7.546012277, 6.971778036, 6.971778036, 6.971778036, 6.975575035,
      6.975802812, 6.976027098, 6.985060519, 6.985997433, 6.986934348,
      6.987871263, 6.757372472, 6.739707952, 6.722043129, 6.707953385,
      6.695969668, 6.67006099, 6.652395035, 6.654930393, 6.654189281,
      6.638736666, 6.819210327, 6.820147228, 6.82108413, 6.822021031,
      6.822957933, 6.823894835, 6.824831737, 6.825768639, 6.826705541,
      6.827642443, 7.024879611, 7.03755198, 7.050027854, 7.062310293,
      7.076370091, 7.091437254, 7.106504719, 7.121572482, 7.136640538,
      7.151708883, 7.58960483, 7.637252431, 7.68490812, 7.732571463, 7.780242027,
      7.82791938, 7.875603095, 7.923292743, 7.970987898, 8.018688132,
      8.062723296, 8.101201048, 8.13778443, 8.174401585, 8.213849919,
      8.246101927, 8.28982215, 8.320943331, 8.362689342, 8.393861172, 7.57629444,
      7.553135331, 7.518098249, 7.494022761, 7.475241796, 7.452245024,
      7.422673199, 7.422790024, 7.40757391, 7.347058892, 7.814318954,
      7.827501385, 7.840683893, 7.853866478, 7.867049138, 7.880231873,
      7.893414681, 7.90659756, 7.91978051, 7.93296353, 7.660794493, 7.66384832,
      7.66656856, 7.66899222, 7.671152091, 7.663140956, 7.664058701, 7.664726844,
      7.664587822, 7.664458108, 7.989876814, 8.010656179, 8.031435817,
      8.052215721, 8.071404481, 8.08090849, 8.100736944, 8.120565604,
      8.140394465, 8.16022352, 8.550906197, 8.598649368, 8.646394789,
      8.694142258, 8.741891571, 8.78964252, 8.837394899, 8.885148498,
      8.932903107, 8.980215245, 9.027070682, 9.073926564, 9.120782757,
      9.167639134, 9.214495571, 9.261351952, 9.30820816, 9.355064082,
      9.377536304, 9.407643393, 9.451634371, 9.481964504, 9.499099353,
      9.521541893, 9.540399856, 9.565452746, 9.576298733, 9.598478648,
      9.606427552, 9.625743685, 9.484551358, 9.490699255, 9.507292594,
      9.514710885, 9.519650257, 9.536964234, 9.540921453, 9.557267168,
      9.560243755, 9.562247116, 9.683701156, 9.692476894, 9.700272785,
      9.693685729, 9.698556277, 9.702451488, 9.691948734, 9.692930502,
      9.679507184, 9.677584332, 9.647808943, 9.642029155, 9.635286133,
      9.627580962, 9.618914723, 9.609288497, 9.598703363, 9.587160397,
      9.588116076, 9.589071755, 9.590027434, 9.590983113, 9.591938792,
      9.585474576, 9.579865864, 9.579865864, 9.579865864, 9.579865864,
      9.579865864, 9.593323217, 9.594278896, 9.595234574, 9.596190253,
      9.597145932, 9.59810161, 9.599057289, 9.600012968, 9.600968646,
      9.601924325, 9.602880003, 9.603835682, 9.60479136, 9.605747039,
      9.606702717, 9.607658396, 9.608614074, 9.609569752, 9.610525431,
      9.611481109, 9.612436787, 9.613392466, 9.614348144, 9.615303822, 9.6162595,
      9.617215178, 9.618170856, 9.619126534, 9.620082212, 9.62103789,
      9.621993568, 9.622949246, 9.623904924, 9.624860602, 9.62581628,
      9.626771958, 9.627727636, 9.628683314, 9.629638991, 9.630594669,
      9.631550347, 9.632506025, 9.633461702, 9.63441738, 9.635373057,
      9.636328735, 9.637284413, 9.63824009, 9.639195768, 9.640151445,
      9.641107122, 9.6420628, 9.643018477, 9.643974155, 9.644929832, 9.645885509,
      9.646841186, 9.647796864, 9.648752541, 9.649708218, 9.650663895,
      9.651619572, 9.652575249, 9.653530926, 9.654486603, 9.65544228,
      9.656397957, 9.657353634, 9.658309311, 9.659264988, 9.660220665,
      9.661176342, 9.662132019, 9.663087695, 9.664043372, 9.664999049,
      9.665954725, 9.666910402, 9.667866079, 9.668821755, 9.669777432,
      9.670733108, 9.671688785, 9.672644461, 9.673600138, 9.674555814,
      9.67551149, 9.676467167, 9.677422843, 9.678378519, 9.679334196,
      9.680289872, 9.681245548, 9.682201224, 9.6831569, 9.683924699, 9.684663209,
      9.685390392, 9.686106423, 9.686811472, 9.687505708, 9.688189298,
      9.688862404, 9.689525187, 9.690177806, 9.690820417, 9.691453173,
      9.692076226, 9.692689725, 9.693293816, 9.693888643, 9.69447435,
      9.695051075, 9.695618956, 9.69617813, 9.696728729, 9.697270886, 9.69780473,
      9.698330389, 9.698847987, 9.69935765, 9.699859498, 9.700353651,
      9.700840228, 9.701319344, 9.701791115, 9.702255652, 9.702713068,
      9.70316347, 9.703606967, 9.704043665, 9.704473667, 9.704897077,
      9.705313996, 9.705724523, 9.706128756, 9.706526793, 9.706918727,
      9.707304652, 9.707684661, 9.708058845, 9.708427292, 9.708790092,
      9.709147329, 9.70949909, 9.709845459, 9.710186518, 9.710522349,
      9.710853031, 9.711178645, 9.711499267, 9.711814974, 9.712125842,
      9.712431945, 9.712733356, 9.713030146, 9.713322387, 9.713610148,
      9.713893498, 9.714172506, 9.714447236, 9.714717755, 9.714984128,
      9.715246418, 9.715504687, 9.715758998, 9.716009411, 9.716255985,
      9.71649878, 9.716737854, 9.716973263, 9.717205064, 9.717433312,
      9.717658061, 9.717879366, 9.718097279, 9.718311852, 9.718523136,
      9.718731182, 9.718936039, 9.719137756, 9.719336382, 9.719531963,
      9.719724547, 9.719914179, 9.720100905, 9.720284768, 9.720465814,
      9.720644085, 9.720819624, 9.720992472, 9.721162672, 9.721330263,
      9.721495285, 9.721657778, 9.721817781, 9.721975331, 9.722130467,
      9.722283226, 9.722433643, 9.722581755, 9.722727597, 9.722871204,
      9.72301261, 9.723151849, 9.723288954, 9.723423957, 9.723556892, 9.72368779,
      9.723816681, 9.723943597, 9.724068568, 9.724191624, 9.724312794,
      9.724432107, 9.724549591, 9.724665275, 9.724779187, 9.724891352,
      9.725001799, 9.725110552, 9.72521764, 9.725323086, 9.725426916,
      9.725529155, 9.725629827, 9.725728957, 9.725826567, 9.725922681,
      9.726017323, 9.726110514, 9.724570858, 9.724570858, 9.724570858,
      9.724570858, 9.724570858, 9.724570858, 9.724570858, 9.724570858,
      9.724570858, 9.724570858, 9.724570858, 9.724570858, 9.724570858,
      9.724570858, 9.724570858, 9.724570858, 9.724570858, 9.724570858,
      9.724570858, 9.724570858, 9.724570858, 9.724570858, 9.724570858,
      9.724570858, 9.724570858, 9.724570858, 9.724570858, 9.724570858,
      9.724570858, 9.724570858, 9.724570858, 9.724570858, 9.724570858,
      9.724570858, 9.724570858, 9.724570858, 9.724570858, 9.724570858,
      9.724570858, 9.724570858, 9.724570858, 9.724570858, 9.711907321,
      9.700012181, 9.696509717, 9.68193849, 9.666414608, 9.66259866, 9.646124466,
      9.628699631, 9.698907196, 9.692989659, 9.68580605, 9.684851064,
      9.671242328, 9.669333026, 9.654771314, 9.651908369, 9.645546583,
      9.633269238, 9.680045159, 9.680045159, 9.680045159, 9.680045159,
      9.680045159, 9.680045159, 9.680045159, 9.680045159, 9.667397201,
      9.666442216, 9.524666849, 9.502180584, 9.480348121, 9.464109662,
      9.438172179, 9.42391884, 9.397046494, 9.381848858, 9.354043208,
      9.325299681, 9.411028817, 9.399621138, 9.390102555, 9.367998144,
      9.357531656, 9.346518543, 9.323983168, 9.312569627, 9.294791577,
      9.276699497, 9.262887378, 9.240388541, 9.226093431, 9.206680617,
      9.186483022, 9.172233129, 9.147895852, 9.13044777, 9.115254189,
      9.087551155, 9.261315155, 9.257237895, 9.255328694, 9.253419493,
      9.251510292, 9.249601092, 9.239801414, 9.23779412, 9.230209333,
      9.227346618, 9.224483904, 9.221682288, 9.218929806, 9.212168186,
      9.200657518, 9.196988994, 9.193320473, 9.189651955, 9.185983441,
      9.182314929, 9.22850141, 9.22850141, 9.22850141, 9.22850141, 9.217249586,
      9.21659303, 9.214392502, 9.213474287, 9.212556073, 9.211637858, 9.22318129,
      9.22318129, 9.22318129, 9.22318129, 9.22318129, 9.22318129, 9.22318129,
      9.22318129, 9.22318129, 9.22318129, 9.048718247, 9.035929368, 9.018347116,
      8.997554128, 8.983857672, 8.970161378, 8.950560846, 8.929911486,
      8.915308516, 8.900705736, 8.824071402, 8.802705337, 8.775046674,
      8.753365829, 8.733337885, 8.702836885, 8.680154894, 8.659226745,
      8.638299124, 8.605040542, 8.657147496, 8.640736324, 8.624325399,
      8.604908203, 8.591281468, 8.566404595, 8.545552431, 8.528238401,
      8.510924652, 8.487123297, 8.46356454, 8.445348198, 8.427132178,
      8.405118242, 8.378205561, 8.35908122, 8.339964003, 8.32043172, 8.293025456,
      8.269757239, 8.504792695, 8.504030293, 8.503279559, 8.502477035,
      8.489640509, 8.48819281, 8.486767248, 8.485363485, 8.483981188, 8.48262003,
      8.503226602, 8.503226602, 8.503226602, 8.503226602, 8.503226602,
      8.503226602, 8.493443235, 8.492854569, 8.492274915, 8.491704136,
      8.476013922, 8.474178354, 8.463892912, 8.461922475, 8.459982145,
      8.458071463, 8.456189979, 8.454337246, 8.452512826, 8.443652055,
      8.477356998, 8.477356998, 8.477356998, 8.477356998, 8.477356998,
      8.477356998, 8.477356998, 8.477356998, 8.477356998, 8.477356998,
      8.477356998, 8.477356998, 8.477356998, 8.477356998, 8.477356998,
      8.477356998, 8.477356998, 8.477356998, 8.477356998, 8.477356998,
      8.477356998, 8.477356998, 8.477356998, 8.477356998, 8.477356998,
      8.477356998, 8.477356998, 8.477356998, 8.477356998, 8.477356998,
      8.594384666, 8.602681912, 8.610979159, 8.619276407, 8.627573655,
      8.635870904, 8.644168153, 8.652465402, 8.660762651, 8.6690599, 8.560028956,
      8.560028956, 8.560028956, 8.560028956, 8.560028956, 8.560028956,
      8.560028956, 8.560028956, 8.560028956, 8.560028956, 8.742539479,
      8.755472282, 8.768405083, 8.781337881, 8.794270677, 8.807203468,
      8.820136254, 8.833069036, 8.846001811, 8.858934579, 8.819513751,
      8.828078154, 8.83525786, 8.846948913, 8.856171754, 8.865394591,
      8.874617425, 8.883840254, 8.893063079, 8.9022859, 8.780255067, 8.780255067,
      8.780255067, 8.780255067, 8.780255067, 8.780255067, 8.780255067,
      8.780255067, 8.780255067, 8.780255067, 8.964010176, 8.976942852,
      8.989875514, 9.002808162, 9.015740795, 9.028673412, 9.041606013,
      9.054538597, 9.067471163, 9.080403711, 8.90885589, 8.90885589, 8.90885589,
      8.90885589, 8.90885589, 8.90885589, 8.90885589, 8.90885589, 8.90885589,
      8.90885589, 8.90885589, 8.90885589, 8.90885589, 8.90885589, 8.90885589,
      8.90885589, 8.90885589, 8.90885589, 8.90885589, 8.90885589, 8.90885589,
      8.90885589, 8.90885589, 8.90885589, 8.90885589, 8.90885589, 8.90885589,
      8.90885589, 8.90885589, 8.90885589, 8.840142878, 8.83609022, 8.824716849,
      8.819219034, 8.813721229, 8.808223432, 8.802725645, 8.797227867,
      8.791730098, 8.786232338, 8.842296062, 8.833369448, 8.832165763,
      8.83098049, 8.829813349, 8.828664063, 8.821720451, 8.819884822,
      8.818049193, 8.816213565, 8.814377938, 8.81254231, 8.810706683,
      8.808871056, 8.80703543, 8.805199804, 8.800641079, 8.799021147,
      8.797425981, 8.795855203, 8.807692421, 8.806774227, 8.805856032,
      8.804937837, 8.804019643, 8.803101448, 8.802183254, 8.80126506,
      8.800346865, 8.799428671, 8.773922324, 8.77117004, 8.768417757,
      8.765665475, 8.762913194, 8.760160915, 8.757408636, 8.754656359,
      8.744934467, 8.742333926, 8.739773089, 8.73725135, 8.734768116,
      8.732322801, 8.720727623, 8.717059473, 8.713391326, 8.709723181,
      8.706055039, 8.7023869, 8.747789573, 8.747789573, 8.747789573, 8.747789573,
      8.747789573, 8.747789573, 8.747789573, 8.747789573, 8.747789573,
      8.747789573, 8.747789573, 8.747789573, 8.747789573, 8.747789573,
      8.747789573, 8.747789573, 8.747789573, 8.747789573, 8.747789573,
      8.747789573, 8.687875102, 8.684315977, 8.680811117, 8.677359698,
      8.668951161, 8.664367943, 8.65978473, 8.655201522, 8.65061832, 8.646035122,
      8.702695482, 8.702695482, 8.702695482, 8.702695482, 8.702695482,
      8.702695482, 8.702695482, 8.702695482, 8.702695482, 8.702695482,
      8.64145193, 8.636868743, 8.63228556, 8.627702383, 8.623119211, 8.618536043,
      8.613952881, 8.609369724, 8.604786572, 8.600203425, 8.656766617,
      8.656766617, 8.656766617, 8.656766617, 8.656766617, 8.656766617,
      8.656766617, 8.656766617, 8.656766617, 8.656766617, 8.826748557,
      8.838752738, 8.850756914, 8.862761084, 8.874765246, 8.886769402,
      8.89877355, 8.910777691, 8.922781822, 8.934785944, 9.143645891, 9.16965642,
      9.195666836, 9.221677128, 9.247687286, 9.273697299, 9.299707155,
      9.320955203, 9.341032748, 9.363455451, 9.031412798, 9.031412798,
      9.031412798, 9.031412798, 9.031412798, 9.031412798, 9.031412798,
      9.031412798, 9.031412798, 9.031412798, 9.20335606, 9.21535982, 9.227363559,
      9.239367274, 9.251370967, 9.263374635, 9.275378279, 9.287381897,
      9.29938549, 9.311389056, 9.257021539, 9.264393641, 9.271765737,
      9.279137826, 9.286509908, 9.293881984, 9.301254052, 9.315736639,
      9.321864139, 9.337536356, 9.226095058, 9.226095058, 9.226095058,
      9.226095058, 9.226095058, 9.226095058, 9.226095058, 9.226095058,
      9.226095058, 9.226095058, 9.213632261, 9.212714047, 9.211795832,
      9.210877618, 9.209959404, 9.209041189, 9.208122975, 9.207204761,
      9.197065732, 9.192229557, 9.215310924, 9.215310924, 9.215310924,
      9.215310924, 9.215310924, 9.215310924, 9.215310924, 9.215310924,
      9.215310924, 9.215310924, 9.215310924, 9.215310924, 9.215310924,
      9.215310924, 9.215310924, 9.215310924, 9.215310924, 9.215310924,
      9.215310924, 9.215310924, 9.078267045, 9.068206694, 9.058146407,
      9.048086184, 9.037920004, 9.015519663, 9.004549481, 8.993579381,
      8.982609362, 8.971639424, 8.898587425, 8.870668162, 8.854253656,
      8.837839417, 8.821425442, 8.805011729, 8.788598277, 8.759815115,
      8.74249748, 8.725180147, 8.868394313, 8.862896425, 8.857398546,
      8.851900676, 8.846402815, 8.832614442, 8.82245667, 8.816045185,
      8.809633714, 8.803222258, 8.821458987, 8.816875596, 8.812292211,
      8.807708831, 8.803125457, 8.798542087, 8.793958723, 8.789375365,
      8.784792011, 8.774655992, 8.836736102, 8.836736102, 8.836736102,
      8.836736102, 8.836736102, 8.836736102, 8.836736102, 8.836736102,
      8.836736102, 8.836736102, 8.836736102, 8.836736102, 8.836736102,
      8.836736102, 8.836736102, 8.836736102, 8.836736102, 8.836736102,
      8.836736102, 8.836736102, 8.836736102, 8.836736102, 8.836736102,
      8.836736102, 8.836736102, 8.836736102, 8.836736102, 8.836736102,
      8.836736102, 8.836736102, 8.836736102, 8.836736102, 8.836736102,
      8.836736102, 8.836736102, 8.836736102, 8.836736102, 8.836736102,
      8.836736102, 8.836736102, 8.836736102, 8.836736102, 8.836736102,
      8.836736102, 8.836736102, 8.836736102, 8.836736102, 8.836736102,
      8.836736102, 8.836736102, 8.928773018, 8.935221192, 8.941669364,
      8.948117534, 8.954565703, 8.961013869, 8.967462032, 8.973910194,
      8.980358353, 8.98680651, 8.901036513, 8.901036513, 8.901036513,
      8.901036513, 8.901036513, 8.901036513, 8.901036513, 8.901036513,
      8.901036513, 8.901036513, 8.901036513, 8.901036513, 8.901036513,
      8.901036513, 8.901036513, 8.901036513, 8.901036513, 8.901036513,
      8.901036513, 8.901036513, 8.901036513, 8.901036513, 8.901036513,
      8.901036513, 8.901036513, 8.901036513, 8.901036513, 8.901036513,
      8.901036513, 8.901036513, 8.901036513, 8.901036513, 8.901036513,
      8.901036513, 8.901036513, 8.901036513, 8.901036513, 8.901036513,
      8.901036513, 8.901036513, 8.839379012, 8.8347956, 8.830212194, 8.825628794,
      8.821045398, 8.816462008, 8.811878624, 8.807295244, 8.80271187, 8.78888374,
      8.768232535, 8.754985085, 8.742594513, 8.735270332, 8.727946172,
      8.720622034, 8.713297917, 8.705973821, 8.698649747, 8.691325694,
      8.782258886, 8.782258886, 8.7766225, 8.776287403, 8.775957438, 8.775632527,
      8.768329612, 8.767411419, 8.766493226, 8.765575033, 8.605017807,
      8.592233157, 8.579448618, 8.566664193, 8.547603082, 8.528375395,
      8.51468398, 8.5009927, 8.487301557, 8.473610549, 8.533260888, 8.524994205,
      8.516787478, 8.499676873, 8.487442386, 8.478295825, 8.469149304,
      8.460002822, 8.450856379, 8.441709975, 8.432563611, 8.423417286, 8.414271,
      8.405124753, 8.395978545, 8.386832375, 8.377686245, 8.368540153,
      8.354138277, 8.337702812, 8.351937395, 8.343702468, 8.33546757, 8.3272327,
      8.318997857, 8.310763042, 8.302528255, 8.294293496, 8.286058765,
      8.277824061, 8.148495451, 8.131187605, 8.113880017, 8.096262003,
      8.071838496, 8.048363233, 8.029793635, 8.011224281, 7.992655156,
      7.974086241, 8.19630133, 8.19630133, 8.19630133, 8.19630133, 8.19630133,
      8.19630133, 8.19630133, 8.19630133, 8.19630133, 8.19630133, 8.051831045,
      8.040650732, 8.025132077, 8.005929856, 7.994159234, 7.981742766,
      7.969636259, 7.957529782, 7.945423334, 7.933316911, 8.041081637,
      8.03827556, 8.035469483, 8.032663406, 8.029857329, 8.027051253,
      8.024245177, 8.021439101, 8.018633025, 8.015826949, 8.048945316,
      8.048945316, 8.048945316, 8.048945316, 8.048945316, 8.048945316,
      8.048945316, 8.048945316, 8.048945316, 8.048945316, 8.048945316,
      8.048945316, 8.048945316, 8.048945316, 8.048945316, 8.048945316,
      8.048945316, 8.048945316, 8.048945316, 8.048945316, 7.89327273,
      7.881166381, 7.86906004, 7.848343344, 7.83808349, 7.819648159, 7.806616308,
      7.793584448, 7.780552575, 7.767520684, 7.921354062, 7.921354062,
      7.921354062, 7.921354062, 7.921354062, 7.921354062, 7.921354062,
      7.921354062, 7.921354062, 7.921354062, 7.754488773, 7.741456836,
      7.728424869, 7.715392868, 7.702360829, 7.689328748, 7.67629662,
      7.663264442, 7.650232208, 7.637199916, 7.790231655, 7.790231655,
      7.790231655, 7.790231655, 7.790231655, 7.790231655, 7.790231655,
      7.790231655, 7.790231655, 7.790231655, 7.790231655, 7.790231655,
      7.790231655, 7.790231655, 7.790231655, 7.790231655, 7.790231655,
      7.790231655, 7.790231655, 7.790231655, 7.719061329, 7.713456461,
      7.707851588, 7.702246709, 7.696641824, 7.691036934, 7.679113854,
      7.674197914, 7.669356774, 7.655562615, 7.731881115, 7.731881115,
      7.731881115, 7.731881115, 7.731881115, 7.731881115, 7.731881115,
      7.731881115, 7.731881115, 7.731881115, 7.649026378, 7.64249013,
      7.636950264, 7.629496242, 7.62295996, 7.616423666, 7.609887361,
      7.603351043, 7.596814712, 7.590278369, 7.666398791, 7.666398791,
      7.666398791, 7.666398791, 7.666398791, 7.666398791, 7.666398791,
      7.666398791, 7.666398791, 7.666398791, 7.583742012, 7.577205643,
      7.570669259, 7.564132862, 7.55759645, 7.551060025, 7.544523584,
      7.537987129, 7.531450658, 7.524914172, 7.541937647, 7.537264706,
      7.53259176, 7.527918807, 7.523245849, 7.518572885, 7.513899914,
      7.509226937, 7.504553954, 7.499880965, 7.554008156, 7.554008156,
      7.554008156, 7.554008156, 7.554008156, 7.554008156, 7.554008156,
      7.554008156, 7.554008156, 7.554008156, 7.554008156, 7.554008156,
      7.554008156, 7.554008156, 7.554008156, 7.554008156, 7.554008156,
      7.554008156, 7.554008156, 7.554008156, 7.642561254, 7.649134787,
      7.655708331, 7.662281885, 7.668855451, 7.675429026, 7.682002612,
      7.688576209, 7.695149815, 7.712044546, 7.620332141, 7.620332141,
      7.620332141, 7.620332141, 7.620332141, 7.620332141, 7.620332141,
      7.620332141, 7.620332141, 7.620332141, 7.620332141, 7.620332141,
      7.620332141, 7.620332141, 7.620332141, 7.620332141, 7.620332141,
      7.620332141, 7.620332141, 7.620332141, 7.620332141, 7.620332141,
      7.620332141, 7.620332141, 7.620332141, 7.620332141, 7.620332141,
      7.620332141, 7.620332141, 7.620332141, 7.620332141, 7.620332141,
      7.620332141, 7.620332141, 7.620332141, 7.620332141, 7.620332141,
      7.620332141, 7.620332141, 7.620332141, 7.620332141, 7.620332141,
      7.620332141, 7.620332141, 7.620332141, 7.620332141, 7.620332141,
      7.620332141, 7.620332141, 7.620332141, 7.620332141, 7.620332141,
      7.620332141, 7.620332141, 7.620332141, 7.620332141, 7.620332141,
      7.620332141, 7.620332141, 7.620332141, 7.290258946, 7.264348481,
      7.233174908, 7.200355857, 7.173528041, 7.146698851, 7.119868212,
      7.093036049, 7.06620229, 7.027680451, 7.256776757, 7.249308625,
      7.241840461, 7.234372263, 7.226904033, 7.21625818, 7.210013888,
      7.203864462, 7.186158231, 7.179442485, 7.172828703, 7.160439944,
      7.152041291, 7.143642594, 7.135243854, 7.126845071, 7.118446245,
      7.110047377, 7.101648466, 7.093249515, 7.084850522, 7.076451487,
      7.068052413, 7.059653298, 7.051254142, 7.042854948, 7.034455714,
      7.02605644, 7.017657128, 7.009257778, 7.09346935, 7.092533131, 7.091596911,
      7.090660691, 7.089724471, 7.088788252, 7.087852032, 7.086915812,
      7.085979592, 7.085043372, 6.898944233, 6.883128598, 6.867312716,
      6.85149659, 6.835680225, 6.819863625, 6.802214361, 6.788081933,
      6.764942512, 6.751649911, 6.997498121, 7.002189148, 7.006880185,
      7.011571229, 7.016262283, 7.020953345, 7.025644416, 7.030335495,
      7.03860814, 7.05242742, 6.983409506, 6.983409506, 6.983409506, 6.983409506,
      6.983409506, 6.983409506, 6.983409506, 6.983409506, 6.983409506,
      6.983409506, 6.983409506, 6.983409506, 6.983409506, 6.983409506,
      6.983409506, 6.983409506, 6.983409506, 6.983409506, 6.983409506,
      6.983409506, 6.983409506, 6.983409506, 6.983409506, 6.983409506,
      6.983409506, 6.983409506, 6.983409506, 6.983409506, 6.983409506,
      6.983409506, 6.971880642, 6.970944416, 6.97000819, 6.969071964,
      6.968135738, 6.967199512, 6.966263286, 6.96532706, 6.964390833,
      6.963454607, 6.873407783, 6.86216684, 6.853766838, 6.845366804,
      6.836966738, 6.82856664, 6.820166511, 6.811766352, 6.803366161,
      6.794965941, 6.878508948, 6.877572718, 6.876636488, 6.875700258,
      6.874764027, 6.873827797, 6.872891566, 6.871955336, 6.871019105,
      6.870082875, 6.869146644, 6.868210414, 6.867274183, 6.866337952,
      6.865401722, 6.864465491, 6.86352926, 6.862593029, 6.861656798,
      6.860720567, 6.767898363, 6.759498018, 6.751097645, 6.742697244,
      6.734296814, 6.725896358, 6.717495873, 6.709095362, 6.700694824,
      6.69229426, 6.683893669, 6.675493053, 6.667092411, 6.658691744,
      6.650291053, 6.641890337, 6.633489596, 6.625088832, 6.610196273,
      6.602942165, 6.595798221, 6.588762785, 6.570419064, 6.56284065,
      6.555377283, 6.548027235, 6.533905397, 6.524574449, 6.515243472,
      6.50663486, 6.587740987, 6.585869204, 6.58399742, 6.582125636, 6.580253851,
      6.578382067, 6.576510282, 6.574638497, 6.572766712, 6.570894927,
      6.421075554, 6.404283632, 6.392739823, 6.370005538, 6.358055896,
      6.346286688, 6.324138496, 6.311230934, 6.294246547, 6.279049721,
      6.330828461, 6.32226299, 6.312744194, 6.303225374, 6.288300395,
      6.280145907, 6.272115215, 6.264206457, 6.245109581, 6.236664149,
      6.313328681, 6.310465796, 6.307602911, 6.304740025, 6.301877138,
      6.299014251, 6.296151363, 6.293288474, 6.290425584, 6.287562694,
      6.284699803, 6.281836911, 6.278974018, 6.276111124, 6.27324823,
      6.270385335, 6.267522439, 6.264659543, 6.261796645, 6.258933747,
      6.256070848, 6.253207948, 6.250345047, 6.247482146, 6.244619243,
      6.24175634, 6.238893436, 6.236030531, 6.233167626, 6.230304719,
      6.261252397, 6.261252397, 6.261252397, 6.261252397, 6.261252397,
      6.261252397, 6.261252397, 6.261252397, 6.261252397, 6.261252397,
      6.261252397, 6.261252397, 6.261252397, 6.261252397, 6.261252397,
      6.261252397, 6.261252397, 6.261252397, 6.261252397, 6.261252397,
      6.261252397, 6.261252397, 6.261252397, 6.261252397, 6.261252397,
      6.261252397, 6.261252397, 6.261252397, 6.261252397, 6.261252397,
      6.237124261, 6.235450281, 6.233801903, 6.232178738, 6.230580401,
      6.22880154, 6.226892254, 6.224982969, 6.223073683, 6.211486135,
      6.209250881, 6.207049794, 6.204882353, 6.202748045, 6.200646364,
      6.198576814, 6.196538904, 6.194532152, 6.192556081, 6.190610225,
      6.289124593, 6.294865661, 6.305536661, 6.31895187, 6.325651639,
      6.332351438, 6.339051266, 6.345751124, 6.352451012, 6.35915093,
      6.280237436, 6.280237436, 6.280237436, 6.280237436, 6.280237436,
      6.280237436, 6.280237436, 6.280237436, 6.280237436, 6.280237436,
      6.201298833, 6.194628239, 6.187957635, 6.18128702, 6.174616394,
      6.167945757, 6.161275109, 6.15460445, 6.14793378, 6.141263098, 6.213365008,
      6.213365008, 6.213365008, 6.213365008, 6.213365008, 6.213365008,
      6.213365008, 6.213365008, 6.213365008, 6.213365008, 6.19085855, 6.18894926,
      6.187039969, 6.185130678, 6.183221387, 6.181312095, 6.179402803,
      6.177493511, 6.175584219, 6.173674926, 6.171765633, 6.16985634,
      6.167947046, 6.166325742, 6.164781045, 6.163259978, 6.16176218,
      6.160287295, 6.158834974, 6.157404872, 6.175915136, 6.175915136,
      6.175915136, 6.175915136, 6.175915136, 6.175915136, 6.175915136,
      6.175915136, 6.175915136, 6.175915136, 6.175915136, 6.175915136,
      6.175915136, 6.175915136, 6.175915136, 6.175915136, 6.175915136,
      6.175915136, 6.175915136, 6.175915136, 6.155996649, 6.154609971,
      6.15324451, 6.151899941, 6.150575945, 6.149272207, 6.147988418,
      6.146724274, 6.145479474, 6.144253722, 6.143046727, 6.141858203,
      6.140687868, 6.139535443, 6.138400655, 6.137283233, 6.136182914,
      6.135099434, 6.134032538, 6.13298197, 6.053339541, 6.04686032, 6.040479668,
      6.03335989, 6.025738703, 6.010486983, 6.003711075, 5.997038216,
      5.990466853, 5.983995453, 5.910805516, 5.89950234, 5.88873263, 5.878125941,
      5.858678719, 5.845584952, 5.834687069, 5.818988831, 5.805678464,
      5.792367964, 5.83484035, 5.826268807, 5.817697228, 5.809125611,
      5.800553957, 5.789504347, 5.782295573, 5.77454973, 5.765977921,
      5.757406072, 5.742956556, 5.735507315, 5.728171301, 5.720946809, 5.7133597,
      5.7047876, 5.688642107, 5.681070442, 5.673613856, 5.666270616, 5.726755428,
      5.723892303, 5.721029177, 5.718566936, 5.716242096, 5.713952795,
      5.711698491, 5.709478651, 5.707292748, 5.705140266, 5.625399354,
      5.617840933, 5.6103974, 5.603067026, 5.585674859, 5.576946106, 5.569176133,
      5.561524242, 5.553988656, 5.546567624, 5.461846475, 5.448567096,
      5.425654548, 5.412613712, 5.399769842, 5.376059754, 5.36215539,
      5.348461156, 5.325862568, 5.309978714, 5.439467562, 5.436451978,
      5.433482479, 5.430558364, 5.427678942, 5.418046124, 5.410519962,
      5.406954331, 5.403443166, 5.399985638, 5.396580931, 5.39322824,
      5.389926773, 5.386675749, 5.383474401, 5.380321972, 5.377217716, 5.3741609,
      5.371150801, 5.368186706, 5.310234661, 5.303245162, 5.293898904,
      5.278399962, 5.2713999, 5.263563219, 5.256295154, 5.249137743, 5.237481893,
      5.231683762, 5.271665496, 5.268236684, 5.26486026, 5.26192341, 5.259339454,
      5.255145049, 5.251968674, 5.240839439, 5.237907686, 5.235065447,
      5.276858457, 5.276858457, 5.276858457, 5.276858457, 5.276858457,
      5.276858457, 5.276858457, 5.276858457, 5.276858457, 5.276858457,
      5.276858457, 5.276858457, 5.276858457, 5.276858457, 5.276858457,
      5.276858457, 5.276858457, 5.276858457, 5.276858457, 5.276858457,
      5.360948439, 5.367924517, 5.374900611, 5.381876722, 5.388852849,
      5.395828992, 5.402805151, 5.418423245, 5.429498574, 5.437473068,
      5.445447584, 5.453422121, 5.46139668, 5.469371258, 5.477345857,
      5.485320476, 5.500756834, 5.51392777, 5.522901204, 5.531874664,
      5.390005594, 5.387476913, 5.38502547, 5.382648911, 5.380344959,
      5.378111401, 5.375946093, 5.373846956, 5.371811974, 5.369839191,
      5.363405434, 5.36182691, 5.360320688, 5.358883468, 5.3575121, 5.356203575,
      5.354955024, 5.342764089, 5.341139452, 5.339589222, 5.195563134,
      5.179548836, 5.163525455, 5.147493521, 5.131706155, 5.121023652,
      5.110328506, 5.088656472, 5.066999943, 5.06454996, 5.207640329,
      5.207178102, 5.206722955, 5.206274779, 5.205833469, 5.205398918,
      5.204971024, 5.204549684, 5.204134798, 5.203726267, 5.13514955,
      5.136000707, 5.136849981, 5.142072126, 5.154008197, 5.161918562,
      5.167161426, 5.170636509, 5.172939955, 5.174466823, 5.64591172,
      5.685031409, 5.724154432, 5.763280534, 5.797579086, 5.829187489,
      5.87234528, 5.905784187, 5.943910116, 5.982037544, 5.669611252,
      5.678226787, 5.686842336, 5.695457903, 5.704073486, 5.712689087,
      5.724459259, 5.731613126, 5.75072668, 5.758436407, 5.22885062, 5.192991054,
      5.157127626, 5.115193604, 5.071031892, 5.032671261, 5.007987919,
      5.00901774, 5.009884269, 5.010615271, 5.425165146, 5.436136819,
      5.447108553, 5.458080349, 5.469052203, 5.480024114, 5.490996082,
      5.502466148, 5.512981464, 5.532423543, 5.415231426, 5.416226765,
      5.423165938, 5.43074918, 5.432740286, 5.434731391, 5.436722497,
      5.438713603, 5.440704709, 5.442695815, 5.56820679, 5.578173226,
      5.600034616, 5.610511938, 5.626954394, 5.639927491, 5.652900649,
      5.665873864, 5.678847134, 5.691820455, 6.130203656, 6.173274159,
      6.217473609, 6.254808719, 6.303653211, 6.344967511, 6.389406262,
      6.42601525, 6.46819612, 6.510070423, 6.605502227, 6.65386501, 6.702236232,
      6.750616445, 6.799006198, 6.847406039, 6.895816512, 6.94423816,
      6.992671525, 7.041117146, 7.089228444, 7.136763496, 7.184311514,
      7.231872003, 7.279444475, 7.327028448, 7.374623451, 7.422229017,
      7.469844686, 7.517470003, 7.565104519, 7.612747789, 7.660399374,
      7.708058835, 7.755725739, 7.803399654, 7.851080151, 7.898766801,
      7.946459178, 7.994156853, 8.0418594, 8.089566447, 8.137277785, 8.184993233,
      8.232712609, 8.280435727, 8.328162401, 8.37589244, 8.423625652,
      8.471361843, 8.519100817, 8.566842377, 8.614586321, 8.662332449,
      8.710080556, 8.757830438, 8.805581888, 8.853334697, 8.901088657,
      8.948843556, 8.995855308, 9.042710909, 9.089566909, 9.136423177,
      9.183279588, 9.230136019, 9.276992355, 9.32384848, 9.370704282,
      9.417559652, 9.464414478, 9.511268649, 9.558122054, 9.604974579,
      9.651826106, 9.698676516, 9.745525682, 9.792373474, 9.839219754,
      9.886064377, 9.93413075, 9.974549388, 9.999728906, 9.997182042,
      9.994716404, 9.992342809, 9.990068703, 9.990585291, 9.995152933,
      9.997292294, 9.765444674, 9.774071424, 9.782698153, 9.791291816,
      9.79805571, 9.804715079, 9.81127155, 9.817726727, 9.824082189, 9.841128344,
      9.322868245, 9.286993405, 9.249992919, 9.218238763, 9.187083369,
      9.150472489, 9.112773736, 9.074722456, 9.036324381, 9.001847264,
      8.933665195, 8.892782311, 8.851598219, 8.810117804, 8.768994249,
      8.728392216, 8.687522456, 8.646389322, 8.604997092, 8.563349976,
      8.484289069, 8.44005485, 8.395611106, 8.346781553, 8.293547766,
      8.247804839, 8.201876595, 8.155766053, 8.097875893, 8.050107499,
      8.124868464, 8.084351876, 8.043567861, 8.002520765, 7.962268683,
      7.931845083, 7.890733156, 7.849277663, 7.806909317, 7.764285012,
      7.769626298, 7.729377956, 7.688839575, 7.648015561, 7.618901041,
      7.578239175, 7.537292978, 7.496066662, 7.454564336, 7.424699433,
      7.419057492, 7.391506959, 7.352497688, 7.318381304, 7.285705574,
      7.246494114, 7.208724584, 7.175815857, 7.139438143, 7.099730588,
      7.141916144, 7.117812111, 7.088510312, 7.059181329, 7.029825811,
      7.000444444, 6.971037974, 6.941607128, 6.912152615, 6.882675125,
      7.219017394, 7.219017394, 7.219017394, 7.219017394, 7.219017394,
      7.219017394, 7.219017394, 7.219017394, 7.219017394, 7.219017394,
      6.986583931, 6.968002202, 6.949420018, 6.92875265, 6.906419613,
      6.883748648, 6.862143055, 6.842637198, 6.823130871, 6.803624084,
      7.238338302, 7.254355757, 7.270373521, 7.286391586, 7.302409947,
      7.30727126, 7.321115122, 7.336186628, 7.351258363, 7.366330321,
      7.134785553, 7.131045171, 7.127304785, 7.123564396, 7.119824004,
      7.116083607, 7.112343208, 7.108602804, 7.104862398, 7.101121988,
      6.923506619, 6.905845254, 6.887326103, 6.866213955, 6.844782139,
      6.823025866, 6.804061828, 6.78547598, 6.766889755, 6.748303161,
      6.960113315, 6.960113315, 6.960113315, 6.960113315, 6.960113315,
      6.960113315, 6.960113315, 6.960113315, 6.960113315, 6.960113315,
      6.660507825, 6.634057203, 6.607492992, 6.580818624, 6.554037424,
      6.538625109, 6.51125119, 6.485624731, 6.46725436, 6.444082837, 7.190234009,
      7.220412067, 7.256449276, 7.289502797, 7.318143872, 7.351170672,
      7.386264162, 7.414852932, 7.443519511, 7.477662764, 6.854830257,
      6.837048308, 6.817024155, 6.796696624, 6.776061165, 6.757703364,
      6.740038849, 6.722374031, 6.704708917, 6.687043513, 7.086262806,
      7.101330168, 7.116397829, 7.131465785, 7.146534032, 7.161602564,
      7.176671377, 7.191740466, 7.206809827, 7.221879456, 6.719466554,
      6.692147775, 6.664741768, 6.643033173, 6.620592461, 6.594335367,
      6.567145934, 6.541933797, 6.519492903, 6.496948435, 6.793105569,
      6.794042468, 6.794979367, 6.795916266, 6.796853166, 6.797790065,
      6.798726965, 6.799663865, 6.800600765, 6.801537664, 6.478902471,
      6.456567317, 6.433110107, 6.400707094, 6.378252, 6.3558967, 6.333636811,
      6.313471648, 6.291252588, 6.267040042, 6.312193055, 6.293599809,
      6.275006387, 6.256260271, 6.23729188, 6.218323322, 6.201820355, 6.1805921,
      6.161622993, 6.145677411, 6.064537775, 6.044818334, 6.020201878,
      6.002199027, 5.981413749, 5.953958578, 5.934622248, 5.921666069,
      5.892711141, 5.887426858, 6.130297417, 6.131252983, 6.132208549,
      6.133164116, 6.134119682, 6.135075249, 6.136030815, 6.136986382,
      6.137941948, 6.138897515, 5.937015199, 5.921827777, 5.912425684,
      5.913498062, 5.908585065, 5.911164583, 5.913793814, 5.930396817,
      5.953804531, 5.969670603, 6.023437192, 6.02439275, 6.025348309,
      6.026303867, 6.027259426, 6.028214985, 6.029170543, 6.030126102,
      6.031081661, 6.03203722, 6.628979282, 6.677346093, 6.725721611,
      6.774106387, 6.822500969, 6.870905904, 6.919321734, 6.95981476,
      7.003296324, 7.038487467, 7.108835279, 7.15637574, 7.203928962,
      7.251494453, 7.299071727, 7.346660307, 7.394259723, 7.441869512,
      7.489489215, 7.537118381, 7.478421382, 7.512221719, 7.551175493,
      7.577658503, 7.615657017, 7.645294201, 7.678513828, 7.715559186,
      7.740065537, 7.776153406, 7.963061663, 8.010761083, 8.058465229,
      8.10617379, 8.153886579, 8.201603415, 8.249324115, 8.297048493,
      8.344776359, 8.392507525, 8.440241796, 8.487978978, 8.535718875,
      8.583461287, 8.631206015, 8.678952854, 8.726701603, 8.774452054,
      8.822204001, 8.869957235, 8.749629469, 8.778041501, 8.8060454, 8.831403275,
      8.859580789, 8.882961384, 8.911128533, 8.932943324, 8.960720282,
      8.981376947, 9.148460462, 9.178797068, 9.204951245, 9.23014068,
      9.254366465, 9.277629701, 9.300129492, 9.327177914, 9.353796401,
      9.375518038, 9.342159441, 9.356845649, 9.382461449, 9.397424937,
      9.410198884, 9.43526879, 9.447083612, 9.457950607, 9.481144515,
      9.491055453, 9.526603996, 9.536496571, 9.545443642, 9.567234528,
      9.576055367, 9.595576185, 9.604961016, 9.611814956, 9.629880367,
      9.636850332, 9.494455759, 9.501160772, 9.507865778, 9.501173441,
      9.506918404, 9.512663363, 9.518408316, 9.524153266, 9.52989821, 9.53564315,
      9.662100882, 9.663094015, 9.675268728, 9.676465483, 9.675512833,
      9.687028515, 9.685102817, 9.695654829, 9.692757565, 9.697436275,
      9.630847998, 9.634675014, 9.625042876, 9.627912061, 9.630781246,
      9.63365043, 9.636519613, 9.639388795, 9.642257976, 9.631660487,
      9.594015826, 9.593060846, 9.592105867, 9.591150887, 9.590195908,
      9.589240929, 9.588285949, 9.58733097, 9.586375991, 9.585421012,
      9.637476007, 9.640345189, 9.64321437, 9.632616523, 9.634528594,
      9.636440665, 9.638352736, 9.626794919, 9.627750596, 9.628706274,
      9.616190992, 9.616190992, 9.616190992, 9.603565626, 9.602610645,
      9.601655665, 9.600700685, 9.599745705, 9.598790725, 9.597835745,
      9.596880765, 9.583303142, 9.581393864, 9.579484587, 9.57757531,
      9.575666034, 9.573756758, 9.571847482, 9.569938207, 9.568028932,
      9.566119658, 9.564210385, 9.562301112, 9.560391839, 9.558482567,
      9.556573296, 9.554664025, 9.552754754, 9.550845484, 9.548936215,
      9.547026945, 9.545117677, 9.543208409, 9.541299141, 9.539389874,
      9.537480607, 9.535571341, 9.533662075, 9.53175281, 9.529843545,
      9.527934281, 9.526025017, 9.511514349, 9.508651489, 9.50578863,
      9.502925773, 9.500062917, 9.497200063, 9.494337211, 9.49147436,
      9.476018389, 9.472202643, 9.468386901, 9.451982196, 9.447214262,
      9.442446335, 9.437678416, 9.432910503, 9.428142598, 9.410796157,
      9.392940192, 9.387645245, 9.369859316, 9.363966748, 9.358163868,
      9.347395764, 9.333955073, 9.327660384, 9.3210752, 9.303945571, 9.270984906,
      9.255189339, 9.241748371, 9.220529875, 9.210320598, 9.190905504,
      9.171140134, 9.157112009, 9.143392011, 9.123194071, 9.125857719,
      9.107882744, 9.087995937, 9.068134985, 9.060441681, 9.040518449,
      9.020298395, 9.00791917, 8.991796937, 8.971256495, 9.012607445,
      9.006587547, 8.997007165, 8.982505344, 8.976489446, 8.960798142,
      8.95216369, 8.940608508, 8.936703083, 8.920576355, 9.002607471,
      8.989685632, 8.988079193, 8.986545922, 8.985082516, 8.978862178,
      8.976593328, 8.974393624, 8.972260969, 8.97019333, 9.078999105,
      9.083601206, 9.088203307, 9.092805406, 9.097407505, 9.102009601,
      9.106611697, 9.111213792, 9.115815885, 9.120417977, 9.257394053,
      9.271255526, 9.278066362, 9.285232817, 9.298164943, 9.311097038,
      9.31075991, 9.322763451, 9.334766964, 9.346770448, 9.131403592,
      9.129053232, 9.126774493, 9.124565205, 9.122423262, 9.120346621,
      9.118333303, 9.116381384, 9.114489003, 9.104470796, 9.085657301,
      9.076439634, 9.074522727, 9.072692975, 9.070946457, 9.056856274,
      9.054921229, 9.053074153, 9.05131109, 9.049628257, 9.062810776,
      9.062304234, 9.061828309, 9.061381176, 9.060961114, 9.053252638,
      9.053350189, 9.053439829, 9.05352223, 9.053598, 9.058575617, 9.0583259,
      9.058091386, 9.057871154, 9.053854163, 9.053903469, 9.053948878,
      9.053990708, 9.054029246, 9.054064757, 9.727915379, 9.748246461,
      9.753355486, 9.763775524, 9.768281033, 9.767303086, 9.763084887,
      9.755885185, 9.745714131, 9.737414618, 9.636459053, 9.638433253,
      9.626026359, 9.625092864, 9.623190638, 9.606898728, 9.60210053,
      9.582909797, 9.575224346, 9.566577806, 9.530104086, 9.517625818,
      9.517625818, 9.517625818, 9.510576218, 9.510149425, 9.503974612,
      9.503019638, 9.502064664, 9.501109691, 9.500154717, 9.499199743,
      9.49824477, 9.497289796, 9.496334823, 9.495379849, 9.494424876,
      9.493469902, 9.492514929, 9.491559956, 9.490604983, 9.48965001,
      9.488695037, 9.487740064, 9.486785091, 9.485830118, 9.484875145,
      9.483920172, 9.4829652, 9.482010227, 9.481055255, 9.480100282, 9.47914531,
      9.478190337, 9.477235365, 9.476280393, 9.47532542, 9.474370448,
      9.473415476, 9.472460504, 9.471505532, 9.47055056, 9.469595588,
      9.468640616, 9.467685645, 9.466730673, 9.465775701, 9.46482073,
      9.463865758, 9.462910787, 9.461955815, 9.461000844, 9.460045873,
      9.459090901, 9.45813593, 9.457180959, 9.456225988, 9.455271017,
      9.454316046, 9.453361075, 9.452406104, 9.451451133, 9.450496163,
      9.449541192, 9.448586221, 9.447631251, 9.44667628, 9.44572131, 9.444766339,
      9.443811369, 9.442856399, 9.441901429, 9.440946458, 9.439991488,
      9.439036518, 9.438081548, 9.437126578, 9.436171608, 9.435216639,
      9.434261669, 9.433306699, 9.432351729, 9.43139676, 9.43044179, 9.429486821,
      9.428531851, 9.427576882, 9.426621912, 9.425666943, 9.424711974,
      9.423757005, 9.422802036, 9.421847067, 9.420892098, 9.419937129,
      9.41898216, 9.418027191, 9.417072222, 9.416117253, 9.415162285,
      9.414207316, 9.413252348, 9.412297379, 9.411342411, 9.410387442,
      9.409432474, 9.408477506, 9.407522537, 9.406567569, 9.405612601,
      9.404657633, 9.403702665, 9.402747697, 9.401792729, 9.400837761,
      9.399882793, 9.398927826, 9.397972858, 9.39701789, 9.396062923,
      9.395107955, 9.394152988, 9.39319802, 9.392243053, 9.391288086,
      9.390333118, 9.389378151, 9.388423184, 9.387468217, 9.38651325,
      9.385558283, 9.384603316, 9.383648349, 9.382693382, 9.381738416,
      9.380783449, 9.379828482, 9.378873516, 9.377918549, 9.376963583,
      9.376008616, 9.37505365, 9.374098683, 9.373143717, 9.372188751,
      9.371233785, 9.370278819, 9.369323853, 9.368368887, 9.367413921,
      9.366458955, 9.365503989, 9.364549023, 9.363594057, 9.362639092,
      9.361684126, 9.36072916, 9.359774195, 9.358819229, 9.357864264,
      9.356909299, 9.355954333, 9.354999368, 9.354044403, 9.353089438,
      9.352134473, 9.351179508, 9.350224543, 9.349269578, 9.348314613,
      9.347359648, 9.346404683, 9.345458503, 9.344696084, 9.343945336,
      9.343206082, 9.342478146, 9.341761354, 9.341055536, 9.340360524,
      9.339676153, 9.33900226, 9.338338685, 9.337685269, 9.337041858,
      9.336408299, 9.33578444, 9.335170134, 9.334565233, 9.333969595,
      9.333383078, 9.332805541, 9.332236847, 9.331676862, 9.331125452,
      9.330582485, 9.330047833, 9.329521368, 9.329002965, 9.328492501,
      9.327989853, 9.327494903, 9.327007533, 9.326527626, 9.326055069,
      9.325589749, 9.325131554, 9.324680377, 9.324236109, 9.323798646,
      9.323367882, 9.322943715, 9.322526044, 9.32211477, 9.321709795,
      9.321311023, 9.320918357, 9.320531706, 9.320150977, 9.319776079,
      9.319406923, 9.319043421, 9.318685486, 9.318333034, 9.31798598,
      9.317644242, 9.317307738, 9.316976388, 9.316650114, 9.316328837,
      9.316012481, 9.31570097, 9.315394232, 9.315092191, 9.314794777,
      9.314501919, 9.314213547, 9.313929592, 9.313649986, 9.313374663,
      9.313103558, 9.312836605, 9.312573742, 9.312314905, 9.312060033,
      9.311809066, 9.311561943, 9.311318605, 9.311078995, 9.310843055,
      9.31061073, 9.310381963, 9.310156701, 9.30993489, 9.309716476, 9.309501409,
      9.309289636, 9.309081107, 9.308875773, 9.308673584, 9.308474493,
      9.308278452, 9.308085413, 9.307895332, 9.307708163, 9.307523862,
      9.307342384, 9.307163686, 9.306987725, 9.30681446, 9.296884043,
      9.295929081, 9.294974119, 9.294019157, 9.293064195, 9.290314876,
      9.289442212, 9.288582905, 9.287736752, 9.286903552, 9.273573776,
      9.272003351, 9.25794908, 9.255664428, 9.253414687, 9.251199327,
      9.246722346, 9.243859622, 9.231939846, 9.229100155, 9.213804997,
      9.197793324, 9.193576959, 9.189619118, 9.173248718, 9.168687292,
      9.152954681, 9.146652021, 9.141582922, 9.124130175, 9.056201887,
      9.034593863, 9.012410922, 8.989662546, 8.966358052, 8.942506599,
      8.918117188, 8.893198664, 8.867759726, 8.841808919, 8.84245748,
      8.827157113, 8.801838322, 8.776005863, 8.749668173, 8.722833543,
      8.695510124, 8.667705931, 8.639428841, 8.623017417, 8.668463641, 8.6438004,
      8.630922193, 8.605935582, 8.592725694, 8.567426176, 8.541613225,
      8.527569082, 8.501469648, 8.487128749, 8.494686588, 8.472615369,
      8.459608998, 8.43456783, 8.41959333, 8.39578475, 8.37523053, 8.356073825,
      8.342117761, 8.316185144, 8.431210707, 8.426458032, 8.411135788,
      8.404734458, 8.399875974, 8.391633928, 8.378280565, 8.373315628,
      8.368500927, 8.351684914, 8.285901155, 8.266162111, 8.258253569,
      8.238456273, 8.22874773, 8.210550812, 8.194104598, 8.182236342,
      8.171311274, 8.153884001, 8.099880564, 8.080943971, 8.061951207,
      8.042904841, 8.023807317, 8.000428243, 7.984688635, 7.959839984,
      7.941130164, 7.923479122, 7.983401316, 7.967727617, 7.960545737,
      7.95033242, 7.933302904, 7.94023075, 7.943678397, 7.946930578, 7.954157589,
      7.958925652, 8.049678098, 8.050615054, 8.05155201, 8.052488966,
      8.053425922, 8.054362878, 8.055299834, 8.05623679, 8.057173746,
      8.058110702, 8.688243651, 8.735992747, 8.783743506, 8.831495719,
      8.879249179, 8.927003674, 8.974426977, 9.021282349, 9.068138184,
      9.114994345, 9.161850706, 9.208707143, 9.255563536, 9.302419772,
      9.349275736, 9.396131317, 9.442986405, 9.489840889, 9.536694659,
      9.583547601, 9.630399599, 9.677250535, 9.724100286, 9.770948722,
      9.817795711, 9.864641111, 9.911868143, 9.960547064, 9.982490002,
      9.99114738, 9.3902844, 9.387882887, 9.385518069, 9.383189386, 9.380439086,
      9.377576296, 9.374713508, 9.371850721, 9.368987936, 9.366125152,
      9.200148828, 9.184954255, 9.167284924, 9.142484213, 9.125758885,
      9.109621669, 9.091375876, 9.065864397, 9.047692778, 9.031089766,
      8.977268768, 8.958138553, 8.939008791, 8.907434459, 8.887402747,
      8.867371539, 8.846063729, 8.814804344, 8.793872701, 8.772206768,
      8.739570078, 8.717739054, 8.695908644, 8.666629486, 8.639350612,
      8.616621952, 8.588226696, 8.558426552, 8.534800749, 8.507821419,
      8.513485632, 8.49018184, 8.466681389, 8.437006071, 8.411634221,
      8.388912098, 8.366190606, 8.340559974, 8.310133873, 8.284833945,
      8.297803899, 8.276884896, 8.25596637, 8.235048318, 8.206262956,
      8.189165974, 8.160183991, 8.137558392, 8.115742954, 8.09392804,
      8.023704088, 7.997765969, 7.964934821, 7.933642922, 7.906823109,
      7.876719066, 7.843011305, 7.820938857, 7.787176688, 7.758526536,
      7.850741063, 7.832161006, 7.813593214, 7.79407354, 7.776383914,
      7.752253757, 7.73700329, 7.710045993, 7.694511918, 7.679210475,
      7.616497812, 7.59870569, 7.5713417, 7.549098965, 7.526855961, 7.503789056,
      7.474001236, 7.455596714, 7.425634746, 7.407038754, 7.518647008,
      7.508614436, 7.496506852, 7.47743744, 7.467238453, 7.45719342, 7.447005399,
      7.434897326, 7.416003096, 7.405808172, 7.338899285, 7.323486724,
      7.305543293, 7.284845679, 7.271099084, 7.254983392, 7.232341167,
      7.218463755, 7.204794585, 7.179636054, 7.380453222, 7.380453222,
      7.380453222, 7.380453222, 7.380453222, 7.380453222, 7.380453222,
      7.380453222, 7.380453222, 7.380453222, 7.263579912, 7.25159381,
      7.243885475, 7.236293981, 7.22881758, 7.221454548, 7.214203188,
      7.195401027, 7.187617485, 7.179951927, 7.488018832, 7.503092614,
      7.518166575, 7.53324071, 7.548315014, 7.563389483, 7.578464113,
      7.593538899, 7.608613837, 7.623688922, 7.328070758, 7.321057327,
      7.302726644, 7.294912534, 7.287474565, 7.280149374, 7.272935272,
      7.265830594, 7.258833701, 7.240265297, 7.232728684, 7.225306343,
      7.217996562, 7.210797656, 7.203707962, 7.196725843, 7.178512162,
      7.170695211, 7.163286244, 7.155989653, 7.102254449, 7.092178342,
      7.082254472, 7.063525123, 7.050656219, 7.040435474, 7.030369143,
      7.020454936, 7.001984875, 6.994203983, 6.979047049, 6.96737665,
      6.958968427, 6.940678266, 6.932902119, 6.917618778, 6.906100478,
      6.897557436, 6.879426952, 6.871653929, 6.760262698, 6.736281972,
      6.719613747, 6.699649457, 6.675675376, 6.651512019, 6.635103668,
      6.614522635, 6.590382173, 6.566057464, 6.656734891, 6.648691451,
      6.634999385, 6.622601242, 6.61323519, 6.596711629, 6.591452384,
      6.575000927, 6.56980158, 6.553416185, 6.582332512, 6.56879956, 6.566574643,
      6.557697599, 6.550972911, 6.545228554, 6.533311546, 6.532166168,
      6.524265275, 6.529569379, 6.526305271, 6.525246931, 6.526039256,
      6.523772607, 6.528573202, 6.528235216, 6.531803515, 6.53770215,
      6.546851149, 6.552634547, 7.179547, 7.227106262, 7.274677555, 7.322260398,
      7.369854317, 7.417458845, 7.465073522, 7.512697892, 7.560331507,
      7.60797392, 7.655624691, 7.703283383, 7.750949561, 7.798622793, 7.84630265,
      7.893988703, 7.941680525, 7.989377688, 8.037079767, 8.084786374,
      8.132497289, 8.180212334, 8.227931325, 8.275654077, 8.323380403,
      8.371110113, 8.418843016, 8.466578917, 8.514317622, 8.562058931,
      8.609802646, 8.657548564, 8.705296482, 8.753046195, 8.800797497,
      8.84855018, 8.896304034, 8.944058848, 8.991160767, 9.03801632, 9.084872286,
      9.131728533, 9.178584935, 9.22544137, 9.27229772, 9.319153871, 9.366009711,
      9.412865129, 9.459720014, 9.506574256, 9.553427743, 9.600280361,
      9.647131994, 9.693982521, 9.740831818, 9.77219014, 9.78142027, 9.801840962,
      9.821468967, 9.827493813, 9.938312732, 9.946389882, 9.951256598,
      9.949819242, 9.944037275, 9.951320217, 9.941918037, 9.929552234,
      9.914232851, 9.905323841, 9.646243328, 9.646243328, 9.646243328,
      9.646243328, 9.646243328, 9.646243328, 9.646243328, 9.646243328,
      9.646243328, 9.646243328, 9.562555973, 9.551479768, 9.532177703,
      9.520874501, 9.504032379, 9.482839233, 9.47332012, 9.451185067,
      9.428105708, 9.416691239, 9.380068873, 9.354162711, 9.32731659,
      9.305897215, 9.283871591, 9.255154928, 9.229206451, 9.207756634,
      9.177175014, 9.145659246, 9.201010436, 9.183382206, 9.159722389,
      9.144528396, 9.116813916, 9.10067684, 9.084237876, 9.05587811, 9.038957987,
      9.01006958, 9.030139843, 9.007121603, 8.987862688, 8.972352244,
      8.945660229, 8.928078656, 8.911663204, 8.882827927, 8.865508095,
      8.848188579, 8.942460609, 8.933311956, 8.924163349, 8.915014787,
      8.90586627, 8.89135187, 8.874796335, 8.864737231, 8.854678186, 8.844619199,
      8.908720503, 8.90413701, 8.899553522, 8.89497004, 8.890386564, 8.885803092,
      8.881219627, 8.875857873, 8.871994927, 8.867411478, 8.924533927,
      8.924533927, 8.924533927, 8.924533927, 8.924533927, 8.924533927,
      8.924533927, 8.924533927, 8.924533927, 8.924533927, 8.924533927,
      8.924533927, 8.924533927, 8.924533927, 8.924533927, 8.924533927,
      8.924533927, 8.924533927, 8.924533927, 8.924533927, 8.924533927,
      8.924533927, 8.924533927, 8.924533927, 8.924533927, 8.924533927,
      8.924533927, 8.924533927, 8.924533927, 8.924533927, 8.86489857,
      8.861382277, 8.857919604, 8.849741708, 8.845158285, 8.840574867,
      8.835991454, 8.831408047, 8.826824645, 8.822241248, 8.879270407,
      8.879270407, 8.879270407, 8.879270407, 8.879270407, 8.879270407,
      8.879270407, 8.879270407, 8.879270407, 8.879270407, 8.879270407,
      8.879270407, 8.879270407, 8.879270407, 8.879270407, 8.879270407,
      8.879270407, 8.879270407, 8.879270407, 8.879270407, 8.892435668,
      8.893354615, 8.894273562, 8.895192509, 8.896111456, 8.897030403,
      8.89794935, 8.898868298, 8.899787245, 8.900706192, 8.901625139,
      8.902544086, 8.903463033, 8.90438198, 8.905300927, 8.906219874,
      8.907138821, 8.908057768, 8.908976715, 8.909895662, 8.835991454,
      8.831408047, 8.826824645, 8.820345866, 8.81659492, 8.812864909,
      8.808281528, 8.793304952, 8.789052642, 8.784865109, 8.75094208,
      8.737997152, 8.731850675, 8.725797587, 8.708447562, 8.700998442,
      8.692033809, 8.683797684, 8.67556159, 8.667325526, 8.646812647,
      8.637665384, 8.628518162, 8.619370981, 8.610223841, 8.601076741,
      8.58790986, 8.580402675, 8.560934582, 8.552769633, 8.655021809,
      8.653795263, 8.652587479, 8.65139817, 8.650227054, 8.649073853,
      8.642196353, 8.640360756, 8.63852516, 8.636689564, 8.62262362, 8.619871396,
      8.617119174, 8.614366953, 8.611614732, 8.608862513, 8.606110295,
      8.603358078, 8.600605862, 8.597853647, 8.546226884, 8.539816007,
      8.533405144, 8.526994294, 8.520583457, 8.514172635, 8.504042603,
      8.498719021, 8.4934764, 8.476119816, 8.529457372, 8.526705185, 8.514689964,
      8.511943814, 8.509239579, 8.50657662, 8.503954311, 8.501372032,
      8.498829176, 8.496325142, 8.49385934, 8.491431188, 8.479568519,
      8.475900538, 8.472232559, 8.468564582, 8.465178467, 8.462273084,
      8.459412036, 8.456594647, 8.41415602, 8.40774542, 8.401334833, 8.394924259,
      8.388513699, 8.382103152, 8.375692618, 8.369282097, 8.362871589,
      8.356461094, 8.28129911, 8.27208248, 8.254286158, 8.24241234, 8.230538606,
      8.218664955, 8.206791386, 8.1949179, 8.182008796, 8.170875777, 8.207132701,
      8.198736154, 8.190339632, 8.181943135, 8.171924648, 8.165024907,
      8.15662848, 8.139562612, 8.132294889, 8.125137404, 8.226572882,
      8.226363442, 8.226157209, 8.225954136, 8.225754174, 8.225557275,
      8.225363392, 8.22517248, 8.224984491, 8.224799383, 8.227494485,
      8.227494485, 8.227494485, 8.227494485, 8.227494485, 8.227494485,
      8.227494485, 8.227494485, 8.227494485, 8.240406594, 8.228431073,
      8.228431073, 8.228431073, 8.228431073, 8.228431073, 8.228431073,
      8.228431073, 8.228431073, 8.228431073, 8.228431073, 8.409205785,
      8.422390515, 8.435575268, 8.448760041, 8.461944833, 8.475129644,
      8.488314471, 8.501499313, 8.514558174, 8.527490885, 8.372004559,
      8.372923507, 8.373842455, 8.374761403, 8.375680351, 8.376599299,
      8.377518247, 8.378437195, 8.379356143, 8.380275091, 8.381194039,
      8.382112987, 8.383031935, 8.383950883, 8.384869831, 8.385788779,
      8.386707727, 8.387626675, 8.388545623, 8.389464571, 8.507048045,
      8.516270892, 8.525493742, 8.534716596, 8.543939452, 8.553162311,
      8.562385173, 8.571608037, 8.580830903, 8.590053771, 9.015270613,
      9.054505303, 9.080709066, 9.118994424, 9.157279721, 9.182488298,
      9.219824706, 9.248829078, 9.280782658, 9.317170509, 9.156312026,
      9.168019976, 9.186919019, 9.20824186, 9.229564614, 9.250887275,
      9.272209839, 9.2935323, 9.311261078, 9.322698331, 8.989957698, 8.985374106,
      8.980790521, 8.976206941, 8.971623366, 8.967039797, 8.962456234,
      8.957872676, 8.953289124, 8.948705578, 8.808002403, 8.793400984,
      8.778799744, 8.764198685, 8.749597804, 8.734997101, 8.711511908,
      8.699418522, 8.677789836, 8.662283813, 8.646777998, 8.631272389,
      8.615766987, 8.60026179, 8.584756797, 8.564485096, 8.541119709,
      8.524710253, 8.508301034, 8.491892054, 8.463237466, 8.445924762,
      8.423277034, 8.398679243, 8.382517137, 8.36240223, 8.344187662,
      8.325973409, 8.30775947, 8.285866028, 8.331899206, 8.318209707, 8.30452034,
      8.290831102, 8.276270731, 8.263387546, 8.242286277, 8.230944516,
      8.209304448, 8.196029775, 8.119677977, 8.096623906, 8.068913923,
      8.04849309, 8.028083969, 8.007675201, 7.987266761, 7.963079762,
      7.946159981, 7.918115566, 8.02157147, 8.012388319, 8.002310004,
      7.991129835, 7.973391075, 7.964012304, 7.954775338, 7.933685571,
      7.923983133, 7.914427317, 7.833155301, 7.808777267, 7.79330926,
      7.773652239, 7.756005127, 7.738358001, 7.720710846, 7.703063647,
      7.684537135, 7.667700522, 7.769044896, 7.760648739, 7.749700837,
      7.74278381, 7.735191551, 7.726795343, 7.718399122, 7.703821243,
      7.696672868, 7.689632902, 7.636315773, 7.624208947, 7.612102063,
      7.59999512, 7.587888114, 7.575781041, 7.563673898, 7.551566683,
      7.539459393, 7.527352024, 7.502282077, 7.490311273, 7.469407267,
      7.458406814, 7.447572203, 7.425157951, 7.413868008, 7.402782658,
      7.383913468, 7.369954126, 7.46334572, 7.458922564, 7.454566765,
      7.450277305, 7.446053179, 7.441893399, 7.43779699, 7.433762992,
      7.429790462, 7.425878467, 7.305030639, 7.293468518, 7.277299998,
      7.263339163, 7.249378109, 7.235416831, 7.221455325, 7.20749359, 7.19353163,
      7.179569446, 7.27064584, 7.265040112, 7.25943437, 7.253828614, 7.248222845,
      7.242617062, 7.237011265, 7.231405455, 7.225864215, 7.221333662,
      7.121499213, 7.10846134, 7.095423301, 7.082385097, 7.06934673, 7.056308203,
      7.043269517, 7.026625298, 7.015843683, 7.003778357, 7.083501952,
      7.077895797, 7.07228963, 7.066683451, 7.05768199, 7.052919701, 7.048229931,
      7.043611586, 7.038092258, 7.03248601, 6.914249353, 6.902394269,
      6.890717925, 6.867893607, 6.855601857, 6.843708569, 6.823861743, 6.8089694,
      6.796326664, 6.779365823, 6.925689369, 6.923817636, 6.921945902,
      6.920074168, 6.918202434, 6.9163307, 6.914458965, 6.91258723, 6.910715494,
      6.908843758, 6.906972022, 6.90532613, 6.903821923, 6.902340722,
      6.900882177, 6.89944594, 6.898031672, 6.896639037, 6.895267705,
      6.893917351, 6.835080183, 6.829984009, 6.824965426, 6.820023261,
      6.815156356, 6.810363575, 6.805643795, 6.800995911, 6.784935615,
      6.779672176, 6.831880368, 6.83056464, 6.829269042, 6.827993265,
      6.826737006, 6.825499967, 6.824281855, 6.823082381, 6.821901259,
      6.82073821, 6.808120418, 6.799869553, 6.797062991, 6.790203939,
      6.787656528, 6.785148029, 6.782677851, 6.78024541, 6.77785013, 6.775491447,
      7.030532106, 7.04749231, 7.064452976, 7.081414096, 7.098375662,
      7.115337667, 7.132300103, 7.149262964, 7.16622624, 7.183189926, 6.96472523,
      6.963789004, 6.962852778, 6.961916551, 6.960980325, 6.960044098,
      6.951318162, 6.95004542, 6.94879215, 6.947558054, 6.854170455, 6.835407155,
      6.827518891, 6.819750277, 6.812099517, 6.804564845, 6.797144519,
      6.778340423, 6.770390301, 6.762560767, 6.858217552, 6.857434171,
      6.856662783, 6.855903203, 6.855155251, 6.85441875, 6.853693525,
      6.852979402, 6.852276212, 6.851583788, 6.793492749, 6.789029996,
      6.784635248, 6.780307474, 6.776045661, 6.771848808, 6.767715931,
      6.763646061, 6.757352439, 6.754203132, 6.751149727, 6.736728956,
      6.733277088, 6.729930272, 6.726685334, 6.723539193, 6.720488862,
      6.711288377, 6.707146842, 6.699763056, 6.650734412, 6.634490916,
      6.627953622, 6.622236572, 6.609731912, 6.59953584, 6.593753721,
      6.586328877, 6.571201188, 6.565351489, 6.605313678, 6.602140732,
      6.599064417, 6.590726304, 6.588505418, 6.586385744, 6.584362708,
      6.580605218, 6.569128853, 6.566963668, 6.619509423, 6.619509423,
      6.619509423, 6.619509423, 6.619509423, 6.619509423, 6.619509423,
      6.619509423, 6.619509423, 6.619509423, 6.566458664, 6.56616815,
      6.565898863, 6.565649328, 6.557708548, 6.558161237, 6.558571391,
      6.553172332, 6.554184851, 6.555087972, 6.818505392, 6.836406182,
      6.854307637, 6.869323358, 6.883458172, 6.897373836, 6.912106358,
      6.929063123, 6.946020404, 6.962978192, 6.742398692, 6.742779642,
      6.743119622, 6.743423048, 6.743693859, 6.743935567, 6.744151305,
      6.744343868, 6.744515748, 6.744669169, 6.748931367, 6.748885613,
      6.74884056, 6.748796197, 6.748752513, 6.7487095, 6.748667145, 6.748625439,
      6.748584372, 6.748543935, 6.748504117, 6.748464909, 6.748426302,
      6.748388286, 6.748350853, 6.748313994, 6.748277699, 6.74824196,
      6.748206769, 6.748172117, 6.748137997, 6.748104399, 6.748071315,
      6.748038739, 6.748006662, 6.747975076, 6.747943974, 6.747913349,
      6.747883193, 6.747853499, 6.747824261, 6.74779547, 6.74776712, 6.747739205,
      6.747711717, 6.747684651, 6.747657999, 6.747631756, 6.747605914,
      6.747580469, 7.366010872, 7.413614561, 7.461228435, 7.50885204,
      7.556484924, 7.604126644, 7.651776756, 7.699434824, 7.747100414,
      7.794773092, 7.558219659, 7.580212383, 7.605750477, 7.63128948,
      7.656829354, 7.682370064, 7.705635765, 7.725831378, 7.745710694,
      7.770258353, 7.656054937, 7.67018307, 7.684311317, 7.698439676,
      7.712568145, 7.726696724, 7.74082541, 7.754954203, 7.7690831, 7.783212101,
      8.24081567, 8.288539406, 8.336266664, 8.383997255, 8.431730987,
      8.479467665, 8.527207092, 8.57494907, 8.6226934, 8.670439878, 8.718188301,
      8.765938464, 8.813690159, 8.861443179, 8.909197313, 8.95695235,
      9.003811291, 9.050666969, 9.097523024, 9.144379325, 9.191235747,
      9.238092171, 9.284948478, 9.331804557, 9.378660293, 9.425515578,
      9.472370301, 9.51922435, 9.566077614, 9.612929978, 9.659781324,
      9.706631531, 9.753480473, 9.800328018, 9.847174027, 9.894018355,
      9.942396351, 9.979336651, 9.999298397, 9.995595437, 9.443775191,
      9.44282022, 9.44186525, 9.44091028, 9.43995531, 9.43900034, 9.43804537,
      9.4370904, 9.43613543, 9.43518046, 9.540639905, 9.547344868, 9.554049824,
      9.560754773, 9.567459714, 9.574164648, 9.580869573, 9.587574491,
      9.594279401, 9.600984303, 9.406705513, 9.400252314, 9.393897281,
      9.38763893, 9.368898837, 9.362072714, 9.355350383, 9.348730276,
      9.342210848, 9.335790579, 9.156058358, 9.135211721, 9.107868648,
      9.08049411, 9.058709906, 9.031066618, 9.002189611, 8.979468893,
      8.944817745, 8.922079411, 8.854412657, 8.823539553, 8.788203493,
      8.757796062, 8.730570358, 8.690943253, 8.662824116, 8.622326733,
      8.593315275, 8.551949656, 8.547808156, 8.518699907, 8.490588773,
      8.45645761, 8.421548283, 8.386281266, 8.350883634, 8.314710305,
      8.278404582, 8.247609636, 8.290142283, 8.258284787, 8.22664091,
      8.200333309, 8.174026662, 8.147720964, 8.117609577, 8.084338617,
      8.055614418, 8.028417574, 8.122253299, 8.101857547, 8.085371778,
      8.059972167, 8.0446889, 8.01756361, 8.002000334, 7.978265891, 7.959005958,
      7.943404774, 7.95209531, 7.938431823, 7.922392069, 7.899551001,
      7.885758815, 7.871531259, 7.846768784, 7.832851392, 7.819143013,
      7.793678918, 7.869737035, 7.855081972, 7.846568209, 7.838183311,
      7.828180108, 7.817927249, 7.801512214, 7.792884045, 7.784386444,
      7.776017461, 7.720142501, 7.709049892, 7.69070078, 7.675006738,
      7.663672856, 7.652509774, 7.635109852, 7.618416232, 7.607013641,
      7.595782857, 7.579285413, 7.56164156, 7.550172942, 7.538877101,
      7.523237611, 7.504690534, 7.493158451, 7.481800079, 7.466976111,
      7.447570587, 7.483122389, 7.474686131, 7.454600262, 7.445670318,
      7.436875439, 7.428213612, 7.419682852, 7.411281203, 7.391256758,
      7.382359867, 7.350116184, 7.328257086, 7.317540106, 7.306984776,
      7.296588701, 7.281531351, 7.264247492, 7.25357314, 7.243059817,
      7.232705138, 7.159995321, 7.138360973, 7.124056254, 7.104334417,
      7.084067302, 7.069658499, 7.055465868, 7.037723266, 7.015844523,
      7.001540673, 7.028582885, 7.011064352, 6.999632094, 6.988300084,
      6.970905077, 6.962219577, 6.942213707, 6.933471519, 6.913421685,
      6.90462584, 6.930772536, 6.912734022, 6.905734336, 6.899012087,
      6.887188774, 6.874366241, 6.866423737, 6.861109796, 6.845962142,
      6.841408619, 6.790988004, 6.773728472, 6.756334318, 6.750314028,
      6.733066308, 6.723562019, 6.708832496, 6.69407543, 6.690768968,
      6.676185056, 6.833732962, 6.834669865, 6.835606768, 6.83654367,
      6.837480573, 6.838417476, 6.83935438, 6.840291283, 6.841228186,
      6.842165089, 6.716765148, 6.70475667, 6.703297466, 6.692977788,
      6.685120858, 6.687927157, 6.678976622, 6.672814415, 6.675372136,
      6.678420277, 6.958168917, 6.974180032, 6.990191559, 7.006203492,
      7.009832989, 7.024898758, 7.039964851, 7.055031262, 7.070097988,
      7.085165023, 6.811615217, 6.809049344, 6.808969537, 6.811005459,
      6.813378716, 6.818961681, 6.810641944, 6.810375841, 6.810128991,
      6.809900087, 6.862328556, 6.863265462, 6.864202367, 6.865139272,
      6.866076177, 6.867013083, 6.867949988, 6.868886894, 6.869823799,
      6.870760705, 7.245467195, 7.27314118, 7.302483619, 7.331828203,
      7.361174868, 7.378074602, 7.406468532, 7.434864172, 7.463261466,
      7.490779261, 7.76997102, 7.817646947, 7.865329328, 7.913017734,
      7.960711738, 8.008410914, 8.056114837, 8.103823185, 8.15153577,
      8.199252411, 8.246972925, 8.294697125, 8.342424824, 8.390155832,
      8.437889954, 8.485626998, 8.533366766, 8.581109059, 8.628853677,
      8.676600417, 8.724349076, 8.772099449, 8.819851327, 8.867604502,
      8.915358764, 8.963001486, 9.009856724, 9.056712459, 9.103568553,
      9.150424876, 8.858483183, 8.88074275, 8.899751895, 8.9119735, 8.933297014,
      8.954620505, 8.967174222, 8.983554752, 9.003942887, 9.024330985,
      8.874215552, 8.882512759, 8.890809962, 8.899107162, 8.907404359,
      8.915701553, 8.912817241, 8.918686562, 8.925766837, 8.933139145, 8.7615052,
      8.75600749, 8.750509789, 8.745012097, 8.739514414, 8.73401674, 8.728519075,
      8.72302142, 8.717523772, 8.712026134, 8.793341645, 8.794260592, 8.79517954,
      8.796098488, 8.797017436, 8.797936383, 8.798855331, 8.799774279,
      8.800693226, 8.801612174, 8.715691225, 8.71019359, 8.704695964,
      8.699198347, 8.693700738, 8.688203139, 8.682705548, 8.677207966,
      8.671710393, 8.666212829, 9.075064836, 9.098449602, 9.110152737,
      9.133348631, 9.143399861, 9.165658878, 9.175331226, 9.196118909,
      9.208719825, 9.224963289, 9.509265549, 9.535285489, 9.547114129,
      9.567469831, 9.578989517, 9.599266629, 9.606931184, 9.622838354,
      9.63930316, 9.641874604, 9.723265354, 9.728474299, 9.731702826,
      9.732955476, 9.732236776, 9.729551232, 9.724903329, 9.718297533,
      9.709980179, 9.699247336, 9.646498746, 9.642652461, 9.637840756,
      9.632064724, 9.625325452, 9.617624025, 9.608961527, 9.599339039,
      9.588757639, 9.577218406, 9.552115467, 9.55116049, 9.550205513,
      9.549250536, 9.535689983, 9.533780717, 9.531871452, 9.529962187,
      9.528052923, 9.526143659, 9.524234396, 9.522325133, 9.520415871,
      9.518506609, 9.516597347, 9.514688086, 9.512778826, 9.510869566,
      9.508960306, 9.507051047, 9.505141789, 9.503232531, 9.501323273,
      9.499414016, 9.497504759, 9.495595503, 9.493686247, 9.491776992,
      9.489867737, 9.487958483, 9.486049229, 9.484139976, 9.482230723,
      9.48032147, 9.478412218, 9.476502967, 9.474593716, 9.472684465,
      9.470775215, 9.468865965, 9.466956716, 9.465047468, 9.463138219,
      9.461228971, 9.459319724, 9.457410477, 9.455501231, 9.453591985,
      9.451682739, 9.449773494, 9.447864249, 9.445955005, 9.444045761,
      9.442136518, 9.440227275, 9.438318033, 9.436408791, 9.43449955,
      9.432590309, 9.430681068, 9.428771828, 9.426862588, 9.424953349,
      9.42304411, 9.421134872, 9.419225634, 9.417316397, 9.41540716, 9.413497923,
      9.411588687, 9.409679451, 9.407770216, 9.405860981, 9.403951747,
      9.402042513, 9.40013328, 9.398224047, 9.396314814, 9.394405582, 9.39249635,
      9.390587119, 9.388677888, 9.386768658, 9.384859428, 9.382950199,
      9.38104097, 9.379131741, 9.377222513, 9.375313285, 9.373404058,
      9.371494831, 9.369585604, 9.367676378, 9.365767153, 9.363857928,
      9.361948703, 9.360039479, 9.358130255, 9.356221031, 9.354311808,
      9.352402586, 9.350493364, 9.348584142, 9.346674921, 9.3447657, 9.342856479,
      9.340947259, 9.33903804, 9.33712882, 9.335219602, 9.333310383, 9.331401165,
      9.329491948, 9.327582731, 9.325673514, 9.323764298, 9.321855082,
      9.319945867, 9.318036652, 9.316127437, 9.314218223, 9.31230901,
      9.310399796, 9.308490583, 9.306581371, 9.304672159, 9.302762947,
      9.300853736, 9.298944525, 9.297035315, 9.295126105, 9.293216895,
      9.291307686, 9.289398478, 9.287489269, 9.285580061, 9.283670854,
      9.281761647, 9.27985244, 9.277943234, 9.276034028, 9.274124823,
      9.272215618, 9.270306413, 9.268397209, 9.266488005, 9.264578801,
      9.262669598, 9.260760396, 9.258851194, 9.256941992, 9.255032791,
      9.25312359, 9.251214389, 9.249305189, 9.247395989, 9.24548679, 9.243577591,
      9.241668392, 9.239759194, 9.237849996, 9.235940799, 9.234077552,
      9.232241841, 9.230406131, 9.228570422, 9.226734712, 9.224899004,
      9.223063295, 9.221227587, 9.21939188, 9.217556173, 9.215720466,
      9.213884759, 9.212049053, 9.210213348, 9.208377643, 9.206541938,
      9.204706233, 9.202870529, 9.201034826, 9.199199122, 9.197363419,
      9.195527717, 9.193692015, 9.191856313, 9.190020612, 9.188184911,
      9.186349211, 9.18451351, 9.182677811, 9.180842111, 9.179006412,
      9.177170714, 9.175335016, 9.173499318, 9.17166362, 9.169827923,
      9.167992227, 9.16615653, 9.164320835, 9.162485139, 9.160649444,
      9.158813749, 9.156978055, 9.155142361, 9.153306667, 9.151470974,
      9.149635281, 9.147799589, 9.145963897, 9.144128205, 9.142292514,
      9.140456823, 9.138621133, 9.136785443, 9.134949753, 9.133114063,
      9.131278374, 9.129442686, 9.127606998, 9.12577131, 9.123935622,
      9.122099935, 9.120264248, 9.118428562, 9.116592876, 9.11475719,
      9.112921505, 9.11108582, 9.109250136, 9.107414452, 9.105578768,
      9.103743085, 9.101907402, 9.100071719, 9.098236037, 9.096400355,
      9.094564674, 9.092728992, 9.090893312, 9.089057631, 9.087221951,
      9.085386272, 9.083550592, 9.081714914, 9.079879235, 9.078043557,
      9.076207879, 9.074372202, 9.072536525, 9.070700848, 9.068865172,
      9.067029496, 9.06519382, 9.063358145, 9.06152247, 9.059686796, 9.057851122,
      9.056015448, 9.054179774, 9.052344101, 9.050508429, 9.048672757,
      9.046837085, 9.045001413, 9.043165742, 9.041330071, 9.039494401,
      9.03765873, 9.035823061, 9.033987391, 9.032151722, 9.030316054,
      9.028480385, 9.026644718, 9.02480905, 9.022973383, 9.021137716,
      9.019302049, 9.017466383, 9.015630718, 9.013795052, 9.011959387,
      9.010123722, 9.008288058, 9.006452394, 9.004616731, 9.002781067,
      9.000945404, 8.999109742, 8.99727408, 8.995438418, 8.993602757,
      8.991767095, 8.989931435, 8.988095774, 8.986260114, 8.984424455,
      8.982588795, 8.968378825, 8.965626459, 8.961749137, 8.95949937, 8.9449142,
      8.942006188, 8.93914256, 8.934047357, 8.930379049, 8.926710744,
      8.890507226, 8.879885242, 8.861117906, 8.850079509, 8.833844012,
      8.813261168, 8.80411314, 8.78262652, 8.772567947, 8.750179125, 8.739210816,
      8.715921383, 8.704044154, 8.679855716, 8.662008703, 8.641609112,
      8.616105607, 8.601058627, 8.57417723, 8.556089359, 8.60432263, 8.593355278,
      8.575289889, 8.558636506, 8.546760481, 8.534884545, 8.523008698,
      8.503921371, 8.486489159, 8.47370554, 8.412047094, 8.395639487,
      8.367027477, 8.349716292, 8.332405378, 8.302912528, 8.284698985,
      8.255363287, 8.235282237, 8.212863279, 8.209602256, 8.190783822,
      8.172572178, 8.154028252, 8.127399259, 8.105157033, 8.08500223,
      8.057250498, 8.034142141, 8.013733271, 8.053656464, 8.031940903,
      8.009539475, 7.993459167, 7.976136225, 7.959409865, 7.941244187,
      7.925846232, 7.902320394, 7.879867445, 7.862332424, 7.844581573,
      7.826934379, 7.807882361, 7.781669501, 7.76689446, 7.743042064,
      7.725487894, 7.70598541, 7.683799889, 7.919606024, 7.920542977,
      7.921479931, 7.922416885, 7.923353838, 7.924290792, 7.925227745,
      7.926164699, 7.927101653, 7.928038607, 7.842950531, 7.838332052,
      7.833291944, 7.827687156, 7.822082366, 7.816477573, 7.810872778,
      7.805267979, 7.799663178, 7.794058373, 8.140700341, 8.161481524,
      8.170790473, 8.189405165, 8.209234672, 8.229064353, 8.248894199,
      8.268724205, 8.288554365, 8.295546847, 8.352961161, 8.374697291,
      8.383571486, 8.40435477, 8.425138185, 8.445921723, 8.466705377,
      8.476543808, 8.494561083, 8.514392539, 8.624706387, 8.638284673,
      8.663842547, 8.689037296, 8.707809526, 8.725762203, 8.749895877,
      8.774029599, 8.785167189, 8.808363483, 8.410651903, 8.404925632,
      8.39928639, 8.393732865, 8.388263763, 8.382877809, 8.377573751, 8.37235035,
      8.355065238, 8.349272823, 8.449989022, 8.450907971, 8.451826919,
      8.452745867, 8.453664815, 8.454583764, 8.455502712, 8.45642166,
      8.457340608, 8.458259556, 8.324799473, 8.315653603, 8.306507772,
      8.297361979, 8.288216224, 8.279070507, 8.269924828, 8.260779187,
      8.251633583, 8.242488017, 8.265760551, 8.260414463, 8.255149661,
      8.237825084, 8.231849029, 8.225963791, 8.220168001, 8.214460309,
      8.208839385, 8.20330392, 8.197852624, 8.181143388, 8.174422864, 8.16848155,
      8.162630524, 8.156868422, 8.151193904, 8.145605648, 8.140102353,
      8.134682736, 8.093394273, 8.084069141, 8.074744033, 8.065418946,
      8.056093881, 8.046768835, 8.037443809, 8.0281188, 8.018793808, 8.009468832,
      7.886286133, 7.861995595, 7.844885535, 7.824972745, 7.806404973,
      7.787837242, 7.7614444, 7.74605625, 7.719272553, 7.703310485, 7.735569876,
      7.723324025, 7.709939525, 7.687396173, 7.67495516, 7.652447546,
      7.638103977, 7.625484589, 7.605504485, 7.589700287, 7.611324613,
      7.600950968, 7.590733874, 7.580671004, 7.559089127, 7.548431298, 7.5380839,
      7.52789266, 7.508105576, 7.495544416, 7.446676618, 7.425143911,
      7.412047626, 7.387368975, 7.373920975, 7.360674914, 7.33752914,
      7.322381924, 7.304194092, 7.287463488, 7.375830206, 7.369019909,
      7.359558374, 7.351160835, 7.34276325, 7.334365619, 7.323469471,
      7.316525847, 7.309687579, 7.30057045, 7.257089547, 7.240359064,
      7.230969213, 7.22172132, 7.21156058, 7.200376813, 7.182868804, 7.173423314,
      7.164120637, 7.15495865, 7.308368545, 7.3102431, 7.312117657, 7.313992213,
      7.31586677, 7.317741328, 7.319615886, 7.321490444, 7.323365002,
      7.325239561, 7.161005489, 7.151890622, 7.131267587, 7.121677448,
      7.112232299, 7.102929987, 7.093768386, 7.075637978, 7.063649944,
      7.054157328, 7.211555992, 7.213430528, 7.215305064, 7.217179601,
      7.219054138, 7.220928676, 7.222803214, 7.224677752, 7.226552291,
      7.22842683, 6.966959501, 6.951552349, 6.926043137, 6.909164687, 6.89072804,
      6.867371176, 6.851010832, 6.831960037, 6.808447908, 6.78493607,
      6.730453204, 6.712170918, 6.682639527, 6.661566498, 6.63599807,
      6.610289186, 6.58444411, 6.558466975, 6.532361786, 6.506132426,
      6.479782661, 6.45331614, 6.429888115, 6.407936206, 6.385209538,
      6.358862435, 6.33091791, 6.305745976, 6.275417609, 6.252084095,
      6.213836423, 6.185512923, 6.162427121, 6.127904698, 6.104419968,
      6.069743726, 6.046092466, 6.017474875, 5.987479013, 5.951280084,
      6.095344011, 6.082809267, 6.066588037, 6.059095382, 6.048931644,
      6.032341256, 6.027321261, 6.031212902, 6.036766767, 6.042127923,
      6.365074107, 6.379676149, 6.394052292, 6.40820605, 6.42511953, 6.442397475,
      6.459675909, 6.476954841, 6.49423428, 6.511514235, 6.920417538,
      6.968845072, 7.017284596, 7.065736653, 7.11337878, 7.160920483,
      7.208474899, 7.256041536, 7.303619912, 7.351209548, 7.398809976,
      7.446420732, 7.494041359, 7.541671405, 7.589310425, 7.636957974,
      7.684613615, 7.732276912, 7.779947433, 7.827624745, 7.637116344,
      7.666480828, 7.693689143, 7.716954596, 7.741230073, 7.769641671,
      7.797692582, 7.820287296, 7.84177208, 7.869230039, 7.54273016, 7.543667103,
      7.544604046, 7.54554099, 7.546477933, 7.547414876, 7.548351819,
      7.549288763, 7.550225706, 7.551162649, 6.975269244, 6.931224501,
      6.875457264, 6.83050015, 6.773967787, 6.727994415, 6.682115122,
      6.656366914, 6.596211791, 6.546363485, 7.253409669, 7.266587296,
      7.279765084, 7.292943031, 7.306121135, 7.319299392, 7.332477801,
      7.345656359, 7.356819037, 7.367191088, 7.221902002, 7.222838932,
      7.223775861, 7.224712791, 7.225649721, 7.22658665, 7.22752358, 7.22846051,
      7.22939744, 7.23033437, 7.845023751, 7.892709644, 7.940401316, 7.988098342,
      8.035800294, 8.083506783, 8.131217586, 8.178932522, 8.226651409,
      8.274374063, 8.131582223, 8.164803677, 8.192053859, 8.218065493,
      8.250328531, 8.269828874, 8.301132677, 8.331776361, 8.350893776,
      8.381239313, 8.373116094, 8.400585799, 8.422584849, 8.442267922,
      8.468781107, 8.486000077, 8.508239126, 8.533796185, 8.55935344,
      8.571995331, 8.806250486, 8.843599117, 8.870146628, 8.899381409,
      8.928989847, 8.957136528, 8.980518618, 9.014610662, 9.0382705, 9.059717225,
      9.0018334, 9.015711422, 9.041722345, 9.054639772, 9.079711602, 9.092551069,
      9.115865743, 9.139999127, 9.150990055, 9.174185802, 9.526403159,
      9.573256292, 9.601269022, 9.623705179, 9.643335314, 9.658917429,
      9.672565104, 9.697563339, 9.708302695, 9.717119123, 9.538347031,
      9.544251623, 9.549179618, 9.566493428, 9.570439296, 9.586784853,
      9.589750118, 9.598058483, 9.606606954, 9.607621255, 9.621066725,
      9.621104942, 9.633585215, 9.632648846, 9.630743753, 9.641295929,
      9.638419215, 9.648008445, 9.644161589, 9.652788615, 9.528769966,
      9.516580745, 9.515544042, 9.514539043, 9.513564781, 9.512620316,
      9.51170474, 9.510817171, 9.509956753, 9.509122657, 9.508314079,
      9.507530241, 9.506770385, 9.50603378, 9.505319715, 9.504627502,
      9.503956472, 9.503305978, 9.502675393, 9.502064108, 9.51417629, 9.51417629,
      9.51417629, 9.507823912, 9.507439272, 9.507060523, 9.506687575, 9.50632034,
      9.505958729, 9.505602657, 9.474375968, 9.467583616, 9.46637204,
      9.465215852, 9.464112531, 9.463059674, 9.449473577, 9.448139916,
      9.446867189, 9.445310135, 9.508284281, 9.510196365, 9.512108449,
      9.514020533, 9.515932617, 9.517844701, 9.519756784, 9.521668868,
      9.523580951, 9.522063763, 9.540588355, 9.54345756, 9.546326765,
      9.535765309, 9.53767739, 9.539589472, 9.541501553, 9.543413635,
      9.545325716, 9.547237796, 9.549149877, 9.551061957, 9.552974037,
      9.554886118, 9.543359618, 9.544315298, 9.545270978, 9.546226658,
      9.547182338, 9.548138018, 9.524957459, 9.52431044, 9.523673329,
      9.523045973, 9.522428222, 9.521819931, 9.521220954, 9.520631149,
      9.520050375, 9.519478494, 9.51891537, 9.51836087, 9.517814861, 9.517277212,
      9.516747797, 9.51622649, 9.515713165, 9.515207701, 9.514709978,
      9.514219878, 9.5058867, 9.505177136, 9.504489286, 9.503822486, 9.496245431,
      9.495624402, 9.495031841, 9.494466445, 9.493926972, 9.493412238,
      9.457298786, 9.457340807, 9.44479488, 9.441991973, 9.430295216, 9.43024888,
      9.419315863, 9.419871775, 9.409059409, 9.400249858, 9.557908089,
      9.564613033, 9.559046266, 9.563725972, 9.569470884, 9.575215791,
      9.580960693, 9.573275977, 9.578061585, 9.582847191, 9.601067809,
      9.606812688, 9.612557561, 9.604860939, 9.609646527, 9.600987028,
      9.604814057, 9.608641085, 9.599018717, 9.601887908, 9.564402456,
      9.564402456, 9.564402456, 9.564402456, 9.564402456, 9.564402456,
      9.564402456, 9.564402456, 9.564402456, 9.564402456, 9.560491594,
      9.560255195, 9.560022418, 9.559793206, 9.559567506, 9.559345263,
      9.559126425, 9.55891094, 9.558698755, 9.558489821, 9.554933072, 9.55463065,
      9.55433749, 9.554053309, 9.553777832, 9.553510792, 9.553251932, 9.553001,
      9.552757755, 9.55252196, 9.549838986, 9.549619493, 9.549410079,
      9.549210283, 9.549019663, 9.548837798, 9.546813808, 9.546706531,
      9.546605817, 9.546511263, 9.565616442, 9.566572122, 9.567527801,
      9.568483481, 9.56943916, 9.57039484, 9.557901414, 9.557901414, 9.557901414,
      9.557901414, 9.552709786, 9.552475461, 9.552248314, 9.552028124,
      9.551814679, 9.551607773, 9.551407205, 9.549125315, 9.548938597,
      9.548760456, 9.548590496, 9.548428344, 9.54827364, 9.548126043,
      9.547985226, 9.547850878, 9.547722702, 9.546296657, 9.546221022,
      9.546150015, 9.563843188, 9.564798867, 9.565754547, 9.566710226,
      9.567665906, 9.568621585, 9.556128826, 9.556128826, 9.556128826,
      9.556128826, 9.551654157, 9.551452168, 9.551256367, 9.551066563,
      9.550882574, 9.550704222, 9.550531333, 9.550363741, 9.550201283,
      9.550043803, 9.549891146, 9.549743167, 9.549599721, 9.54946067,
      9.549325879, 9.549195218, 9.54906856, 9.548945782, 9.548826767,
      9.548711397, 9.543798072, 9.543914352, 9.544019924, 9.543217013,
      9.543414955, 9.542875371, 9.543143445, 9.542827222, 9.54266005, 9.5430281,
      9.542998897, 9.543346618, 9.543635722, 9.543680183, 9.543934225,
      9.544141552, 9.544310754, 9.544361933, 9.544501333, 9.544612964,
      9.693170541, 9.690274216, 9.699863312, 9.695996894, 9.704623809,
      9.699788768, 9.707454239, 9.701652034, 9.69488663, 9.700631416,
      9.706376197, 9.712120971, 9.704387004, 9.695692004, 9.686037045, 9.6754232,
      9.68152779, 9.673490618, 9.664242072, 9.661256653, 9.655237661,
      9.655237661, 9.655237661, 9.655237661, 9.655237661, 9.655237661,
      9.655237661, 9.655237661, 9.655237661, 9.655237661, 9.661517114,
      9.661769588, 9.66201432, 9.662251547, 9.662481501, 9.662704404,
      9.662920472, 9.663129915, 9.663332937, 9.663529734, 9.704181466,
      9.707606044, 9.709651672, 9.71007575, 9.698562499, 9.700474562,
      9.714657443, 9.740178658, 9.749672258, 9.749289297, 9.762433596,
      9.769692439, 9.789027089, 9.79120085, 9.802843012, 9.806421789,
      9.809889984, 9.813147839, 9.811439803, 9.809886775, 9.808474861,
      9.816367469, 9.814023097, 9.811928739, 9.816588819, 9.813878893,
      9.816528959, 9.813486755, 9.814601299, 9.81468047, 9.79811086, 9.795383992,
      9.793105116, 9.791115445, 9.789291865, 9.785617562, 9.785617562,
      9.785617562, 9.785617562, 9.785617562, 9.785617562, 9.785617562,
      9.785617562, 9.785617562, 9.785617562, 9.760248255, 9.732970934,
      9.703789542, 9.672708037, 9.632732596, 9.75643065, 9.75643065, 9.731081463,
      9.716498212, 9.700962285, 9.68447468, 9.66480962, 9.635813032, 9.615526462,
      9.594293258, 9.572114451, 9.548991083, 9.512272965, 9.486317723,
      9.459422158, 9.431587367, 9.402814462, 9.360480349, 9.328892933,
      9.296371923, 9.475603508, 9.458725521, 9.439457043, 9.431836576,
      9.411623536, 9.396260149, 9.381383896, 9.359282719, 9.347914851,
      9.325706743, 9.326864014, 9.303830845, 9.279854703, 9.267494894,
      9.242581574, 9.229276213, 9.203427255, 9.176638715, 9.161444481,
      9.133723406, 9.167670034, 9.142794948, 9.129490677, 9.103680242,
      9.089431367, 9.062852029, 9.045447421, 9.020972306, 9.005461352,
      8.977497511, 8.824169002, 8.785401803, 8.754757387, 8.718285697,
      8.677762909, 8.638268852, 8.602351281, 8.564009208, 8.520858951,
      8.476831081, 8.579840418, 8.544796895, 8.521171519, 8.485250112,
      8.460727957, 8.423930577, 8.398512689, 8.360841281, 8.323351631,
      8.295157345, 8.255793967, 8.227636354, 8.187342308, 8.15835121,
      8.117191127, 8.087309794, 8.045285789, 8.014515399, 7.971629624,
      7.934226328, 8.065625581, 8.044446663, 8.024037615, 7.992513473,
      7.970304768, 7.948978424, 7.917238026, 7.893491734, 7.871248856,
      7.839832781, 7.910079495, 7.882279462, 7.86555361, 7.848827811,
      7.832102055, 7.803409469, 7.785762351, 7.768115241, 7.750468127,
      7.732820993, 7.834452811, 7.826056718, 7.817660618, 7.807465065,
      7.788814447, 7.779489519, 7.770164579, 7.760839625, 7.751514658,
      7.742189675, 7.577227161, 7.545024558, 7.522781501, 7.500538132,
      7.470777875, 7.443622655, 7.420461396, 7.397299618, 7.362327889,
      7.33824889, 7.467419312, 7.45531141, 7.443203408, 7.431095303, 7.412938038,
      7.394637697, 7.381603404, 7.368568967, 7.35553438, 7.342499641,
      7.326714664, 7.30448253, 7.290522105, 7.276561472, 7.262600625, 7.24863956,
      7.23467827, 7.21326571, 7.194474171, 7.179587557, 7.234753195, 7.225425714,
      7.216098169, 7.201550407, 7.185365501, 7.175109181, 7.164852777,
      7.154596291, 7.144339723, 7.134083075, 7.147096071, 7.137089443,
      7.118562341, 7.111016615, 7.10003125, 7.090702886, 7.081374465,
      7.072045988, 7.062717454, 7.053388864, 7.020863961, 7.00282771,
      6.993329916, 6.974800937, 6.962687783, 6.950574515, 6.938461133,
      6.926347639, 6.914234035, 6.901972316, 6.90370074, 6.894777533,
      6.879689102, 6.868502476, 6.85731577, 6.846128984, 6.834942119,
      6.823755177, 6.812568159, 6.799458282, 6.755738942, 6.744429319,
      6.727829602, 6.71386145, 6.699893162, 6.68592474, 6.671956187, 6.657987505,
      6.642345451, 6.619441549, 6.699049026, 6.688107605, 6.680637541,
      6.67316746, 6.665697362, 6.658227246, 6.650757112, 6.643286962,
      6.635816796, 6.628346612, 6.643727554, 6.638120676, 6.632513791,
      6.624926513, 6.620237928, 6.615457367, 6.599650263, 6.594415622,
      6.589260684, 6.579413002, 6.652696883, 6.652696883, 6.652696883,
      6.652696883, 6.652696883, 6.652696883, 6.652696883, 6.652696883,
      6.652696883, 6.652696883, 6.652696883, 6.652696883, 6.652696883,
      6.652696883, 6.652696883, 6.652696883, 6.652696883, 6.652696883,
      6.652696883, 6.652696883, 6.652696883, 6.652696883, 6.652696883,
      6.652696883, 6.652696883, 6.652696883, 6.652696883, 6.652696883,
      6.652696883, 6.652696883, 6.550067488, 6.541666503, 6.533265497,
      6.524864471, 6.516463425, 6.508062359, 6.499661274, 6.49126017,
      6.478635861, 6.471522828, 6.464517855, 6.44625077, 6.438701124,
      6.427226495, 6.417895255, 6.408563992, 6.399232707, 6.389901401,
      6.380570074, 6.3712084, 6.475158286, 6.475158286, 6.475158286, 6.475158286,
      6.475158286, 6.475158286, 6.475158286, 6.475158286, 6.475158286,
      6.475158286, 6.475158286, 6.475158286, 6.475158286, 6.475158286,
      6.475158286, 6.475158286, 6.475158286, 6.475158286, 6.475158286,
      6.475158286, 6.475158286, 6.475158286, 6.475158286, 6.475158286,
      6.475158286, 6.475158286, 6.475158286, 6.475158286, 6.475158286,
      6.475158286, 6.548870908, 6.554568305, 6.560197936, 6.56582759,
      6.571457267, 6.57669958, 6.582687101, 6.588316847, 6.593946615,
      6.599576405, 6.531448053, 6.531448053, 6.531448053, 6.531448053,
      6.531448053, 6.531448053, 6.531448053, 6.531448053, 6.531448053,
      6.531448053, 6.52008983, 6.519153588, 6.518217346, 6.517281103,
      6.516344861, 6.515408619, 6.514472376, 6.513536134, 6.512599891,
      6.511663649, 6.522082167, 6.522082167, 6.522082167, 6.522082167,
      6.522082167, 6.522082167, 6.522082167, 6.522082167, 6.522082167,
      6.522082167, 6.510727406, 6.509791164, 6.508854921, 6.507918679,
      6.506982436, 6.506046194, 6.505109951, 6.504173708, 6.503237466,
      6.502301223, 6.331095482, 6.316198573, 6.301177002, 6.285980215,
      6.270783342, 6.255586381, 6.240389329, 6.21989222, 6.20710858, 6.183207086,
      6.237865857, 6.224368329, 6.213901161, 6.203433957, 6.192966716,
      6.182499437, 6.172032119, 6.161564762, 6.151097364, 6.138434053,
      6.220117794, 6.217254884, 6.214391972, 6.21152906, 6.208666147,
      6.205803233, 6.202940318, 6.200077403, 6.197214486, 6.187488862,
      6.022048494, 6.004962148, 5.9878756, 5.970788847, 5.953701881, 5.934647906,
      5.919360987, 5.895310334, 5.8733874, 5.855356245, 6.050049829, 6.050049829,
      6.050049829, 6.050049829, 6.050049829, 6.050049829, 6.050049829,
      6.050049829, 6.050049829, 6.050049829, 5.904501126, 5.892137855,
      5.879774487, 5.867411021, 5.855047455, 5.842683788, 5.830320019,
      5.813948792, 5.803529834, 5.792740099, 5.925368028, 5.925368028,
      5.925368028, 5.925368028, 5.925368028, 5.925368028, 5.925368028,
      5.925368028, 5.925368028, 5.925368028, 5.869601824, 5.864833341,
      5.860064852, 5.855296357, 5.850527855, 5.845759347, 5.837717547,
      5.833573164, 5.829492007, 5.825473115, 5.821255583, 5.816487034,
      5.802550747, 5.797991722, 5.793502218, 5.789081181, 5.784727571,
      5.780440366, 5.76852301, 5.762802597, 5.86014121, 5.863009216, 5.865877223,
      5.868745231, 5.871613241, 5.874481252, 5.877349264, 5.886931201,
      5.889669201, 5.892365163, 5.853888107, 5.853888107, 5.853888107,
      5.853888107, 5.853888107, 5.853888107, 5.853888107, 5.853888107,
      5.853888107, 5.853888107, 5.853888107, 5.853888107, 5.853888107,
      5.853888107, 5.853888107, 5.853888107, 5.853888107, 5.853888107,
      5.853888107, 5.853888107, 5.853888107, 5.853888107, 5.853888107,
      5.853888107, 5.853888107, 5.853888107, 5.853888107, 5.853888107,
      5.853888107, 5.853888107, 5.853888107, 5.853888107, 5.853888107,
      5.853888107, 5.853888107, 5.853888107, 5.853888107, 5.853888107,
      5.853888107, 5.853888107, 5.735842907, 5.727554228, 5.711431714,
      5.700961847, 5.691078296, 5.680072099, 5.669602003, 5.659131829,
      5.648661576, 5.637022743, 5.749658982, 5.749658982, 5.749658982,
      5.749658982, 5.749658982, 5.749658982, 5.749658982, 5.749658982,
      5.749658982, 5.749658982, 5.749658982, 5.749658982, 5.749658982,
      5.749658982, 5.749658982, 5.749658982, 5.749658982, 5.749658982,
      5.749658982, 5.749658982, 5.749658982, 5.749658982, 5.749658982,
      5.749658982, 5.749658982, 5.749658982, 5.749658982, 5.749658982,
      5.749658982, 5.749658982, 5.749658982, 5.749658982, 5.749658982,
      5.749658982, 5.749658982, 5.749658982, 5.749658982, 5.749658982,
      5.749658982, 5.749658982, 5.786736421, 5.800979801, 5.804279818,
      5.807329579, 5.810332505, 5.813289318, 5.816200728, 5.819067432,
      5.821890118, 5.824669465, 5.785073972, 5.785073972, 5.785073972,
      5.785073972, 5.785073972, 5.785073972, 5.785073972, 5.785073972,
      5.785073972, 5.785073972, 5.785073972, 5.785073972, 5.785073972,
      5.785073972, 5.785073972, 5.785073972, 5.785073972, 5.785073972,
      5.785073972, 5.785073972, 5.785073972, 5.785073972, 5.785073972,
      5.785073972, 5.785073972, 5.785073972, 5.785073972, 5.785073972,
      5.785073972, 5.785073972, 5.785073972, 5.785073972, 5.785073972,
      5.785073972, 5.785073972, 5.785073972, 5.785073972, 5.785073972,
      5.785073972, 5.785073972, 5.785073972, 5.785073972, 5.785073972,
      5.785073972, 5.785073972, 5.785073972, 5.785073972, 5.785073972,
      5.785073972, 5.785073972, 5.662906842, 5.648721524, 5.639861595,
      5.631024237, 5.620553768, 5.602844453, 5.593734084, 5.584761945,
      5.566236271, 5.555465759, 5.676298818, 5.676298818, 5.676298818,
      5.676298818, 5.676298818, 5.676298818, 5.676298818, 5.676298818,
      5.676298818, 5.676298818, 5.632017125, 5.628200797, 5.624384465,
      5.620568128, 5.611072001, 5.607531806, 5.604045664, 5.600612752,
      5.59723226, 5.593903391, 5.63611486, 5.63611486, 5.63611486, 5.63611486,
      5.63611486, 5.63611486, 5.63611486, 5.63611486, 5.63611486, 5.63611486,
      5.63611486, 5.63611486, 5.63611486, 5.63611486, 5.63611486, 5.63611486,
      5.63611486, 5.63611486, 5.63611486, 5.63611486, 5.513223178, 5.493472118,
      5.48412809, 5.474925822, 5.465863188, 5.448417893, 5.436997589,
      5.426980897, 5.417228523, 5.402099164, 5.475047123, 5.471487943,
      5.467983128, 5.464531851, 5.461133296, 5.446751052, 5.442632145,
      5.438576121, 5.434582025, 5.430648914, 5.477772161, 5.477772161,
      5.477772161, 5.477772161, 5.477772161, 5.477772161, 5.477772161,
      5.477772161, 5.477772161, 5.477772161, 5.477772161, 5.477772161,
      5.477772161, 5.477772161, 5.477772161, 5.477772161, 5.477772161,
      5.477772161, 5.477772161, 5.477772161, 5.988644016, 6.0266664, 6.06876293,
      6.108350573, 6.148860926, 6.189373415, 6.223933586, 6.26837585,
      6.301001688, 6.337989173, 5.880272255, 5.880272255, 5.880272255,
      5.880272255, 5.880272255, 5.880272255, 5.880272255, 5.880272255,
      5.880272255, 5.880272255, 5.880272255, 5.880272255, 5.880272255,
      5.880272255, 5.880272255, 5.880272255, 5.880272255, 5.880272255,
      5.880272255, 5.880272255, 5.813444488, 5.80841269, 5.803764284,
      5.799186755, 5.790998898, 5.785278532, 5.779558155, 5.773837765,
      5.764762639, 5.759829081, 5.689481292, 5.678884786, 5.669567263,
      5.660391063, 5.644538897, 5.63087451, 5.621339002, 5.611948095,
      5.598818317, 5.582232975, 5.550327234, 5.539176254, 5.528194061,
      5.50631033, 5.494881047, 5.483624717, 5.472170112, 5.450544339, 5.43901449,
      5.427659111, 5.493734548, 5.488179759, 5.473091757, 5.465271058,
      5.458888587, 5.452603341, 5.44641385, 5.440318664, 5.434316357,
      5.427693434, 5.49982132, 5.499857558, 5.49989324, 5.499928376, 5.499962973,
      5.49999704, 5.500030585, 5.500063616, 5.500096141, 5.500128167,
      5.499697537, 5.499697537, 5.499697537, 5.499697537, 5.499697537,
      5.499697537, 5.499697537, 5.499697537, 5.499697537, 5.499697537,
      5.499697537, 5.499697537, 5.499697537, 5.499697537, 5.499697537,
      5.499697537, 5.499697537, 5.499697537, 5.499697537, 5.499697537,
      5.455980569, 5.442771498, 5.43962331, 5.436571195, 5.433612233,
      5.430743593, 5.427962529, 5.425266379, 5.411627832, 5.408439059,
      5.455700308, 5.455700308, 5.455700308, 5.455700308, 5.455700308,
      5.455700308, 5.455700308, 5.455700308, 5.455700308, 5.455700308,
      5.455700308, 5.455700308, 5.455700308, 5.455700308, 5.455700308,
      5.455700308, 5.455700308, 5.455700308, 5.455700308, 5.455700308,
      5.455700308, 5.455700308, 5.455700308, 5.455700308, 5.455700308,
      5.455700308, 5.455700308, 5.455700308, 5.455700308, 5.455700308,
      5.455700308, 5.455700308, 5.455700308, 5.455700308, 5.455700308,
      5.455700308, 5.455700308, 5.455700308, 5.455700308, 5.455700308,
      5.405347596, 5.402350485, 5.399444858, 5.396627936, 5.39389702,
      5.391249495, 5.388682823, 5.376976166, 5.37477658, 5.372677593,
      5.271588002, 5.254311466, 5.245235681, 5.230553183, 5.214970705,
      5.199739033, 5.195437679, 5.177873345, 5.164917822, 5.151963259,
      5.143106016, 5.132352774, 5.118982726, 5.10986987, 5.101839194, 5.11073864,
      5.109106534, 5.111576463, 5.133801569, 5.148527546, 5.159480268,
      5.164460002, 5.168845927, 5.171753066, 5.173680075, 5.174957428,
      5.175804155, 5.176365437, 5.176737503, 5.176984142, 5.70525225,
      5.749432302, 5.789410462, 5.837224976, 5.873292248, 5.913090768,
      5.956276634, 5.999465064, 6.038634635, 6.084228327, 5.474360355,
      5.462940333, 5.451520188, 5.440099918, 5.428670974, 5.416772789,
      5.410869046, 5.404556959, 5.393646667, 5.382736276, 6.09614179,
      6.145949479, 6.194260396, 6.242574285, 6.290891742, 6.339213359,
      6.387539722, 6.435871413, 6.484209007, 6.532553073, 6.580904177,
      6.629262881, 6.677629741, 5.756072267, 5.525513342, 5.478576195,
      5.658907254, 5.403781472, 5.356829372, 5.309870872, 5.262905612,
      5.215933223, 5.16895333, 5.40401559, 5.098918255, 5.051917996, 5.183906795,
      5.739551685, 5.01083875, 5.005876425, 6.051647448, 6.101942951, 6.15152143,
      6.199832662, 6.248146932, 6.296464838, 6.344786973, 6.393113921,
      6.441446264, 6.489784575, 6.489566037, 6.527322876, 6.565758936,
      6.609234312, 6.652715974, 6.692362262, 6.72719175, 6.769713611,
      6.807987739, 6.842208044, 6.969538247, 7.017977947, 7.066430186, 7.1140591,
      7.161600987, 7.209155582, 7.256722391, 7.304300931, 7.351890725,
      7.399491303, 7.447102204, 7.494722969, 7.542353147, 7.589992292,
      7.63763996, 7.685295714, 7.732959117, 7.780629738, 7.828307145, 7.87599091,
      7.923680604, 7.971375802, 8.019076076, 8.066781008, 8.114490319,
      8.162203826, 8.20992135, 8.257642704, 8.305367703, 8.353096158,
      8.201456629, 8.229717622, 8.261980989, 8.294245237, 8.326510326,
      8.355315938, 8.380704365, 8.409488948, 8.440795776, 8.472103177,
      7.479835176, 7.434030716, 7.388226699, 7.342422449, 7.296617287,
      7.250810533, 7.205001505, 7.159189523, 7.113373906, 7.067553975,
      8.244549327, 8.292273345, 8.340000871, 8.387731715, 8.435465684,
      8.483202584, 8.530942218, 8.578684388, 8.626428893, 8.67417553,
      8.721924097, 8.769674387, 8.817426194, 8.865179308, 8.91293352,
      8.960621939, 9.007477148, 9.05433286, 9.101188939, 9.148045254,
      7.934371238, 7.889431687, 7.844496971, 7.799567046, 7.754641868,
      7.708887497, 7.663070828, 7.617257916, 7.57144811, 7.525640751,
      8.721924097, 8.769674387, 8.817426194, 8.865179308, 8.91293352,
      8.960621939, 9.007477148, 9.05433286, 9.101188939, 9.148045254,
      8.921276828, 8.948227604, 8.975178365, 8.991577736, 9.015256596,
      9.04126752, 9.065997045, 9.080094672, 9.105166429, 9.130238104,
      9.457382692, 9.504236969, 9.551090496, 9.584754074, 9.619875773,
      9.655228391, 9.690012638, 9.72419874, 9.753953793, 9.78273918, 9.530191701,
      9.538424985, 9.558647757, 9.578870379, 9.599092847, 8.712424434,
      8.733206434, 9.291788526, 9.248727704, 9.25167105, 9.851119247,
      9.881498865, 9.910873214, 9.935117336, 9.953623032, 9.970826178,
      9.825069037, 9.984311145, 9.920815616, 9.99326045, 9.928845174,
      9.951526919, 9.961176062, 9.931775212, 9.654295113, 9.692621982,
      9.964028679, 9.975215006, 9.984985213, 9.803056147, 9.645875166,
      9.730149841, 9.739524506, 9.740567578, 9.729762237, 9.738490255,
      9.739595115, 9.73973498, 9.739752686, 9.739754927, 9.882038677, 9.73309787,
      9.739924723, 9.738670859, 9.747316516, 9.737612246, 9.892074058,
      9.871162556, 9.848305579, 9.832446002, 9.85483926, 9.837264803,
      9.820584206, 9.810657121, 9.804528733, 9.800596106, 9.797159517,
      9.795422944, 9.794058249, 9.792286974, 9.77904413, 9.778089137,
      9.777134145, 9.776179152, 9.773894519, 9.761483991, 9.759574662,
      9.757665335, 9.755756008, 9.753846681, 9.751937356, 9.75002803,
      9.748118706, 9.746209381, 9.744300058, 9.742390735, 9.740481412,
      9.738572091, 9.736662769, 9.734753449, 9.732844128, 9.730934809,
      9.72902549, 9.727116171, 9.725206853, 9.723297536, 9.721388219,
      9.719478903, 9.717569587, 9.715660272, 9.701082373, 9.698219398,
      9.695356424, 9.692493452, 9.676965882, 9.673149922, 9.669333966,
      9.665518015, 9.661702068, 9.650015776, 9.640820633, 9.636052389,
      9.626251744, 9.622151322, 9.608418551, 9.602698715, 9.596978893,
      9.591259085, 9.585539291, 9.570038119, 9.564894063, 9.554368651,
      9.547697999, 9.541027368, 9.53435676, 9.525933287, 9.508260413,
      9.500639664, 9.493018946, 9.485398261, 9.427329766, 9.415915305,
      9.391897228, 9.37953627, 9.3574401, 9.341489805, 9.315598158, 9.301346573,
      9.275932436, 9.259431446, 9.251785411, 9.229611439, 9.214416433,
      9.19078005, 9.170847206, 9.152743298, 9.127222619, 9.108914265,
      9.087529508, 9.061918877, 9.043897515, 9.013592915, 8.995365883,
      8.966325553, 8.945666959, 8.923722657, 8.895995525, 8.874821402,
      8.851955464, 8.822136714, 8.850833434, 8.833514185, 8.816195247,
      8.798876619, 8.776970443, 8.751530828, 8.733309167, 8.715087857,
      8.694959866, 8.668069604, 8.677692467, 8.664304061, 8.638797493,
      8.621057341, 8.603742068, 8.585320956, 8.569030417, 8.54549703,
      8.521664666, 8.503447286, 8.448449013, 8.427526515, 8.406604509,
      8.379111132, 8.352048879, 8.330228151, 8.308407972, 8.285694555,
      8.256118152, 8.23006669, 8.170848135, 8.139193809, 8.107419725,
      8.081116408, 8.05253395, 8.019370377, 7.989271706, 7.961636911,
      7.921820564, 7.893175896, 7.859519431, 7.82425108, 7.793967865,
      7.764415394, 7.72928869, 7.693287897, 7.662460462, 7.631999608,
      7.589587254, 7.55821737, 7.653137665, 7.624390604, 7.605933478,
      7.580200619, 7.557957981, 7.535715089, 7.510910138, 7.49102829,
      7.463132941, 7.444890303, 7.403267723, 7.376276464, 7.352905916,
      7.328174115, 7.302395437, 7.279879719, 7.251738007, 7.23139574,
      7.200935297, 7.170992554, 7.204598299, 7.184182835, 7.163200058,
      7.143304896, 7.11852263, 7.101764662, 7.073586945, 7.056584937,
      7.039836848, 7.011694544, 6.9016145, 6.867340999, 6.837104256, 6.808428917,
      6.774755417, 6.739681101, 6.715796121, 6.680709458, 6.650877509,
      6.621279191, 6.620396146, 6.598278093, 6.564989669, 6.533089739,
      6.508797498, 6.477817584, 6.452539953, 6.418738147, 6.394381183,
      6.362018749, 6.395516132, 6.366023315, 6.346781613, 6.316440144,
      6.297024651, 6.266529779, 6.246945465, 6.218581381, 6.196621404,
      6.169960049, 6.190593713, 6.169832701, 6.145198226, 6.127903995,
      6.099565504, 6.08201947, 6.064736735, 6.036432405, 6.018897075,
      6.001624885, 5.973353623, 5.955828074, 5.927322305, 5.909550687,
      5.892045674, 5.863582849, 5.845830691, 5.817139475, 5.799147258,
      5.781424889, 5.708054762, 5.687020113, 5.655134575, 5.63395669,
      5.607753413, 5.581034448, 5.552779684, 5.52771108, 5.497503724,
      5.474004135, 5.57508043, 5.562333241, 5.544655398, 5.534898679,
      5.514360648, 5.501918636, 5.483875585, 5.474070447, 5.453505045,
      5.443675085, 5.423095291, 5.413241671, 5.392648562, 5.382447845,
      5.365881758, 5.350954668, 5.339674982, 5.321251708, 5.302687146,
      5.288173213, 5.276362514, 5.257882726, 5.242992834, 5.23168269,
      5.213277998, 5.195847594, 5.190299744, 5.169322148, 5.156039699,
      5.142782377, 5.131955416, 5.115147316, 5.106940202, 5.09623853,
      5.088536262, 5.09392386, 5.098979055, 5.115316998, 5.136279786,
      5.150169745, 5.460007417, 5.483002988, 5.505999257, 5.528996192,
      5.551993763, 5.574991938, 5.597990688, 5.620989982, 5.643989789,
      5.663682871, 5.280645698, 5.268745922, 5.256846019, 5.244945988,
      5.233045831, 5.221145546, 5.209245134, 5.197344595, 5.185443929,
      5.173543137, 5.569717547, 5.592716168, 5.615715339, 5.638715032,
      5.659381098, 5.677979207, 5.696289416, 5.717043367, 5.739040368,
      5.761037672, 5.484498133, 5.481515438, 5.478532741, 5.475550042,
      5.472567341, 5.469584638, 5.466601933, 5.463619226, 5.460636517,
      5.457653806, 5.753038619, 5.775036104, 5.797033854, 5.818678467,
      5.838277349, 5.855235394, 5.871930703, 5.88977424, 5.909933008,
      5.930092056, 5.42335931, 5.408035352, 5.38415478, 5.375221758, 5.355865881,
      5.337672343, 5.327767887, 5.315175773, 5.30520734, 5.326400528,
      5.947124282, 5.982483055, 6.01960575, 6.050189556, 6.080289069,
      6.115937384, 6.149064769, 6.177694979, 6.209843866, 6.244527748,
      6.448887835, 6.497227115, 6.545573021, 6.593926117, 6.642286962,
      6.690656113, 6.739034124, 6.787421544, 6.83581892, 6.884226798,
      6.932645722, 6.981076233, 7.029518871, 7.077851261, 7.125383142,
      7.172928102, 7.22048565, 7.268055298, 7.315636561, 7.363228967,
      7.410832046, 7.458445338, 7.506068386, 7.553700741, 7.601341956,
      7.64899159, 7.696649205, 7.744314367, 7.791986643, 7.839665603,
      7.611454128, 7.637948425, 7.664443703, 7.682111086, 7.704193076,
      7.729735239, 7.755278133, 7.780821731, 7.806366015, 7.819284359,
      7.886992253, 7.909631603, 7.937091511, 7.964552172, 7.992013565,
      8.009124988, 8.033468175, 8.059974524, 8.086481457, 8.112988954,
      8.089005108, 8.111265587, 8.133952725, 8.156640173, 8.179327921,
      8.202015959, 8.211913798, 8.233648617, 8.255383662, 8.277118926,
      8.157788757, 8.169080654, 8.168202169, 8.216446146, 8.229630409,
      8.242814712, 8.255999055, 8.269183436, 8.279919782, 8.282505217,
      8.544457997, 8.570050279, 8.600399199, 8.629738476, 8.64810373,
      8.677493613, 8.706883696, 8.723121518, 8.750921214, 8.778812176,
      8.308201302, 8.299966524, 8.291731773, 8.28349705, 8.275262355,
      8.267027687, 8.246688395, 8.23754285, 8.228397342, 8.219251872,
      8.486319725, 8.49739601, 8.508472303, 8.519548603, 8.53062491, 8.541701224,
      8.552777543, 8.563853867, 8.574930197, 8.586006531, 8.331990818,
      8.323755959, 8.315521129, 8.307286326, 8.29905155, 8.290816803,
      8.285365977, 8.281527816, 8.27850684, 8.275622311, 8.640754232,
      8.653452226, 8.67290586, 8.692359521, 8.711813207, 8.73053985, 8.745768266,
      8.756762593, 8.775282546, 8.793802503, 9.203315039, 9.250171444,
      9.297027703, 9.343883704, 9.390739335, 9.437594485, 9.484449045,
      9.531302902, 9.578155945, 9.625008058, 9.671859122, 9.718709016,
      9.76555761, 9.812404773, 9.832666943, 9.83768073, 9.841377655, 9.84206609,
      9.839756318, 9.847845251, 9.773553249, 9.771819424, 9.768121108,
      9.762462776, 9.754848881, 9.74528385, 9.733772091, 9.72031799, 9.704925914,
      9.687600209, 9.614504222, 9.616416295, 9.618328368, 9.606778046,
      9.607733724, 9.608689403, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.596181612, 9.596181612,
      9.596181612, 9.596181612, 9.596181612, 9.585835388, 9.585210841,
      9.584595857, 9.583990289, 9.583393995, 9.582806831, 9.582228658,
      9.581659338, 9.568482633, 9.563362486, 9.561453213, 9.55954394,
      9.549987192, 9.548003369, 9.54008498, 9.537222103, 9.534359228,
      9.526589996, 9.498796078, 9.485352089, 9.477572158, 9.46115576,
      9.454485405, 9.435218476, 9.427598025, 9.407386543, 9.398816724,
      9.377662127, 9.378456576, 9.359405505, 9.349887167, 9.331152032,
      9.317585396, 9.302091872, 9.283712933, 9.27177746, 9.250089712, 9.23607234,
      9.261338832, 9.247963646, 9.229475782, 9.219010269, 9.208544826,
      9.198079453, 9.181661403, 9.164181565, 9.152769328, 9.141357178,
      9.095589126, 9.078450486, 9.064753057, 9.050278364, 9.026938852,
      9.01038921, 8.991504655, 8.968423001, 8.952912852, 8.937402936,
      8.971596592, 8.959717268, 8.947838046, 8.927093406, 8.91717243,
      8.898686223, 8.885898858, 8.873111618, 8.8603245, 8.84210061, 8.831653026,
      8.808993936, 8.79529961, 8.781605432, 8.764075763, 8.752996881,
      8.729743772, 8.718278885, 8.699133451, 8.684533356, 8.657615998,
      8.642110245, 8.622276998, 8.609722945, 8.585066718, 8.566654202,
      8.550244372, 8.533834783, 8.517425433, 8.495529459, 8.520948016,
      8.507256674, 8.493565469, 8.479874399, 8.463180563, 8.452121802,
      8.429015519, 8.417568387, 8.397777149, 8.383180507, 8.368584026,
      8.353987706, 8.335478398, 8.32363504, 8.299806081, 8.287597604, 8.27557301,
      8.252354837, 8.239246775, 8.221533543, 8.238951056, 8.217245421,
      8.205541135, 8.194753546, 8.176686977, 8.162998939, 8.150026563,
      8.135234607, 8.12127677, 8.104457166, 8.129360101, 8.120356869,
      8.111528342, 8.102833439, 8.085645852, 8.074465416, 8.064287404,
      8.055382575, 8.041249565, 8.030069287, 8.028669724, 8.02030401,
      8.010219649, 7.999966669, 7.983598488, 7.974989847, 7.966511511,
      7.958161529, 7.947779372, 7.92972043, 7.861107331, 7.848812249,
      7.836702253, 7.812815587, 7.800327338, 7.788027007, 7.76397307,
      7.751299916, 7.73881739, 7.71460448, 7.76131001, 7.752365206, 7.743555695,
      7.722982751, 7.71369308, 7.704543843, 7.695532943, 7.678877039,
      7.665554691, 7.656208909, 7.730036899, 7.726207147, 7.722435759,
      7.71872185, 7.715064551, 7.711463001, 7.700365179, 7.697351548,
      7.694429606, 7.691596586, 7.586165202, 7.576171307, 7.566328319,
      7.548058487, 7.534721721, 7.524581229, 7.513319218, 7.493988514,
      7.486123884, 7.472465434, 7.459017618, 7.451285167, 7.432008249,
      7.424168632, 7.404798525, 7.396857761, 7.377400403, 7.369364144,
      7.354367842, 7.341919684, 7.427898073, 7.424805234, 7.421486117,
      7.419476197, 7.417557793, 7.415726779, 7.405344236, 7.404274187,
      7.403268648, 7.402323793, 7.296003547, 7.281547659, 7.267048186,
      7.254141549, 7.241975435, 7.236203602, 7.22633228, 7.204755731,
      7.204746973, 7.204033699, 7.326430076, 7.326430076, 7.326430076,
      7.326430076, 7.326430076, 7.326430076, 7.326430076, 7.326430076,
      7.326430076, 7.326430076, 7.274255951, 7.277268675, 7.275556951,
      7.27505532, 7.275566689, 7.276862797, 7.276725889, 7.2781191, 7.281664305,
      7.285634074, 7.500037656, 7.515111581, 7.530185681, 7.545259951,
      7.55993907, 7.571905048, 7.583685159, 7.595282318, 7.606699393,
      7.620686149, 7.634813992, 7.648941951, 7.665405502, 7.677372521,
      7.691500825, 7.720798642, 7.740094159, 7.736448119, 7.801362566,
      7.859314444, 8.232742164, 8.280465285, 8.328191961, 8.375922001,
      8.423655215, 8.471391408, 8.519130384, 8.566871945, 8.614615891,
      8.66236202, 8.710110128, 8.757860011, 8.805611462, 8.853364272,
      8.901118233, 8.948873132, 8.995884327, 9.042739928, 9.089595928,
      9.136452197, 9.183308607, 9.230165039, 9.277021374, 9.323877499,
      9.370733302, 9.417588671, 9.464443496, 9.511297667, 9.558151072,
      9.605003596, 9.651855123, 9.698705531, 9.745554697, 9.792402487,
      9.839248766, 9.872791188, 9.872788266, 9.867612258, 9.857682633,
      9.84097315, 9.753305468, 9.737198345, 9.731563535, 9.710552425,
      9.700043539, 9.687590034, 9.659759418, 9.642467653, 9.609803184,
      9.587698482, 9.525025547, 9.523116283, 9.521207021, 9.519297759,
      9.517388497, 9.515479236, 9.513569975, 9.511660715, 9.509751456,
      9.507842196, 9.405174269, 9.387808803, 9.372956212, 9.358816944,
      9.339165586, 9.327751914, 9.31633834, 9.297796523, 9.280409028,
      9.268049213, 9.218326214, 9.193677444, 9.174424213, 9.145749955,
      9.128669346, 9.099065597, 9.076389639, 9.050159391, 9.021588257,
      8.999313972, 9.040926326, 9.016822181, 9.004641139, 8.984774626,
      8.96792646, 8.953655992, 8.930874768, 8.90967686, 8.892769881, 8.876810723,
      8.835584146, 8.81511781, 8.788172013, 8.767572951, 8.745600126,
      8.717923085, 8.696804961, 8.673912638, 8.645539234, 8.623369946,
      8.624774502, 8.607799874, 8.58200958, 8.556761762, 8.536738311,
      8.516715303, 8.49423363, 8.465936756, 8.443425535, 8.42057467, 8.376957317,
      8.349105145, 8.318913635, 8.299793221, 8.269097601, 8.237976932,
      8.218617748, 8.187378272, 8.163098503, 8.136243167, 8.116616193,
      8.097281866, 8.066120311, 8.034541753, 8.01458621, 7.982411, 7.953276818,
      7.927370254, 7.896299773, 7.863204329, 7.817670403, 7.784011801,
      7.760109977, 7.725458161, 7.690427029, 7.657107583, 7.631337347,
      7.595928638, 7.560152306, 7.526443443, 7.523384612, 7.488720397,
      7.462577358, 7.43068045, 7.395614312, 7.360174164, 7.336193734,
      7.300751881, 7.264941418, 7.232622636, 7.227806779, 7.204874417,
      7.170529363, 7.135797471, 7.112411335, 7.077655523, 7.042518679,
      7.018696457, 6.983547531, 6.94802327, 6.970394896, 6.942661268,
      6.916755411, 6.887327341, 6.862807432, 6.831767705, 6.80856476,
      6.775992268, 6.754040596, 6.72111168, 6.691819739, 6.66582661, 6.635264675,
      6.610307182, 6.578537458, 6.550003025, 6.521417949, 6.492783745,
      6.464101889, 6.435373812, 6.486684829, 6.461840184, 6.436832808,
      6.41166767, 6.397756935, 6.372861098, 6.347804049, 6.327499515,
      6.306512796, 6.283783288, 6.219146167, 6.185323772, 6.162238262,
      6.139062944, 6.107186274, 6.081398491, 6.058148232, 6.029450836,
      5.999772377, 5.974190266, 6.264904909, 6.264904909, 6.264904909,
      6.264904909, 6.264904909, 6.264904909, 6.264904909, 6.264904909,
      6.264904909, 6.264904909, 6.039505221, 6.026530814, 6.006898783,
      5.982754926, 5.976818807, 5.954600975, 5.945899354, 5.93677984,
      5.937352559, 5.947701127, 6.085364735, 6.089361924, 6.089361924,
      6.089361924, 6.089361924, 6.089361924, 6.089361924, 6.089361924,
      6.089361924, 6.089361924, 6.320787304, 6.339026563, 6.357266324,
      6.375506599, 6.3937474, 6.411988737, 6.430230622, 6.448473067, 6.466716082,
      6.484910162, 6.882266434, 6.9306849, 6.979114931, 7.027557067, 7.075926859,
      7.123458203, 7.171002642, 7.218559691, 7.266128857, 7.31370966,
      7.361301623, 7.408904279, 7.456517166, 7.504139828, 7.551771815,
      7.59941268, 7.647061981, 7.694719282, 7.742384147, 7.790056143,
      7.837734841, 7.885419812, 7.933110629, 7.980806864, 8.028508091,
      8.076213905, 8.123924059, 8.171638375, 8.219356671, 8.267078761,
      8.314804458, 8.362533574, 8.410265918, 8.458001295, 8.50573951,
      8.553480366, 8.601223663, 8.6489692, 8.696716774, 8.74446618, 8.792217212,
      8.839969662, 8.887723321, 8.935477978, 8.982741596, 9.02959706,
      9.076452962, 9.123309169, 9.170165552, 9.217021989, 9.015794168,
      9.043613219, 9.060306719, 9.088053087, 9.102976187, 9.129926614,
      9.143753176, 9.169763704, 9.182629619, 9.207700982, 9.126866236,
      9.131829849, 9.148483997, 9.165138103, 9.17964568, 9.185097603,
      9.200820077, 9.216542508, 9.229390114, 9.234563049, 9.527161993,
      9.544613109, 9.55737794, 9.573720347, 9.591152698, 9.607630454,
      9.623154773, 9.637953591, 9.652621684, 9.664144574, 9.751367372,
      9.762662286, 9.764877445, 9.778514909, 9.777761313, 9.77852925,
      9.784031871, 9.778361448, 9.78417368, 9.775564542, 9.734182372,
      9.730305021, 9.720977721, 9.717103357, 9.712263627, 9.706459619,
      9.699692414, 9.691963093, 9.683272734, 9.673622411, 9.598159152,
      9.595296241, 9.592433331, 9.589570424, 9.577560086, 9.57052627,
      9.566710427, 9.562894589, 9.559078754, 9.555262924, 9.551447097,
      9.547631275, 9.543815456, 9.539999642, 9.536183831, 9.532368025,
      9.528552222, 9.524736423, 9.520920628, 9.517104837, 9.488075873,
      9.482356324, 9.476636788, 9.470917265, 9.465197755, 9.459478258,
      9.453758774, 9.435447195, 9.428776918, 9.422106661, 9.327342629,
      9.312535125, 9.289261681, 9.27797256, 9.254289579, 9.242587116,
      9.218507733, 9.193856135, 9.181184062, 9.15616691, 9.093001733, 9.0646322,
      9.035760449, 9.006394673, 8.964043995, 8.933857073, 8.903261422,
      8.872237404, 8.840792014, 8.808932131, 8.84856858, 8.822640896,
      8.793768317, 8.76443983, 8.74705193, 8.717544399, 8.687591439, 8.661340138,
      8.635550055, 8.60823195, 8.626597375, 8.598054174, 8.581365612,
      8.552620482, 8.534717638, 8.506716826, 8.485149302, 8.460223646,
      8.435157954, 8.409956574, 8.384623721, 8.359163472, 8.333579781,
      8.307876474, 8.282057261, 8.256125733, 8.23008537, 8.203939544,
      8.177691519, 8.15134446, 8.149966704, 8.123734195, 8.096058959,
      8.074977532, 8.053954032, 8.020702694, 7.998977951, 7.974769433,
      7.94581491, 7.923870474, 7.94788541, 7.923692456, 7.89950353, 7.875495373,
      7.859923083, 7.840510946, 7.817266875, 7.802416589, 7.78891919,
      7.774553414, 7.925107311, 7.932421636, 7.938498293, 7.943547381,
      7.947743128, 7.951230079, 7.954128195, 7.956537064, 7.958539386,
      7.960203848, 8.294660753, 8.318304517, 8.341948541, 8.365592812,
      8.389237318, 8.400023553, 8.422713847, 8.445404316, 8.468094946,
      8.490785729, 8.848948454, 8.896702316, 8.944457137, 8.99155155,
      9.038407108, 9.085263077, 9.132119326, 9.178975728, 9.225832163,
      9.272688512, 9.319544661, 9.366400498, 9.413255912, 9.460110792,
      9.506965028, 9.553818509, 9.600671119, 9.647522743, 9.69437326,
      9.741222546, 9.732704406, 9.75132206, 9.779152154, 9.792960841,
      9.819397043, 9.838811752, 9.855457795, 9.877913926, 9.885973291,
      9.905459087, 9.561473085, 9.566258701, 9.571044314, 9.575829924,
      9.580615531, 9.585401135, 9.590186736, 9.594972334, 9.586318356,
      9.590145391, 9.378390871, 9.367674632, 9.351353124, 9.335542328,
      9.323855543, 9.303788624, 9.295962425, 9.275806326, 9.267884193,
      9.247644678, 9.239632041, 9.223645436, 9.211411887, 9.200692124,
      9.183037119, 9.165247003, 9.147328068, 9.141802602, 9.124013357,
      9.106095305, 9.11688634, 9.10828351, 9.091553879, 9.085799605, 9.071468881,
      9.05710466, 9.048610481, 9.03666415, 9.024719492, 9.012776376, 9.087888836,
      9.088096678, 9.08107826, 9.082317847, 9.078226173, 9.076006175,
      9.078887045, 9.078837885, 9.080075407, 9.081153881, 9.382447744,
      9.400966215, 9.419484588, 9.424720055, 9.442305351, 9.459890553,
      9.477475658, 9.481750031, 9.498710875, 9.516024965, 9.626780037,
      9.637533053, 9.660670481, 9.670432356, 9.692596892, 9.704295941,
      9.722772143, 9.737809885, 9.751298381, 9.771519297, 9.509689918,
      9.509689918, 9.509689918, 9.509689918, 9.509689918, 9.509689918,
      9.509689918, 9.509689918, 9.509689918, 9.509689918, 9.509689918,
      9.509689918, 9.509689918, 9.509689918, 9.509689918, 9.509689918,
      9.509689918, 9.509689918, 9.509689918, 9.509689918, 9.466482925,
      9.456067139, 9.452251412, 9.44843569, 9.444619971, 9.439107367, 9.424281,
      9.419513107, 9.414745222, 9.409977345, 9.354921882, 9.34635232,
      9.337782799, 9.316650875, 9.307132789, 9.297614759, 9.275544893,
      9.265079065, 9.254613309, 9.239307097, 9.218126761, 9.196632862,
      9.184273853, 9.16407558, 9.146443322, 9.133139012, 9.119834842,
      9.094028162, 9.079779402, 9.062134298, 9.077002515, 9.065122257,
      9.053242107, 9.035362787, 9.016593058, 9.003804513, 8.991016098,
      8.970375072, 8.952434629, 8.938738699, 8.838123342, 8.818093356,
      8.785663045, 8.764732175, 8.731418141, 8.709587347, 8.677454961,
      8.652813384, 8.629225808, 8.594955169, 8.706933001, 8.693239762,
      8.679546667, 8.658498595, 8.639310865, 8.624711478, 8.610112261,
      8.595513214, 8.580914336, 8.554041667, 8.489467656, 8.470347903,
      8.451228528, 8.432109527, 8.400756053, 8.380735988, 8.360716348,
      8.33369289, 8.307956106, 8.287036871, 8.302664404, 8.284450866,
      8.266237639, 8.235866373, 8.216751488, 8.197636959, 8.178522786,
      8.155572252, 8.12801472, 8.107886021, 8.208858538, 8.197893624,
      8.186794496, 8.175613575, 8.164432716, 8.153251918, 8.142071178,
      8.130544946, 8.119683197, 8.100535218, 8.072589144, 8.059556647,
      8.046524221, 8.033491862, 8.020459565, 8.007427328, 7.994395144,
      7.981363012, 7.968330926, 7.948866023, 7.833755261, 7.812430399,
      7.791105658, 7.766719148, 7.736255699, 7.71401383, 7.69177196, 7.669530053,
      7.642180008, 7.612734742, 7.649095992, 7.630527911, 7.611959706,
      7.59339136, 7.569538341, 7.543977911, 7.526740433, 7.505176361,
      7.485687075, 7.4661975, 7.487773285, 7.474655304, 7.44992805, 7.436459552,
      7.416657033, 7.399928417, 7.383199537, 7.366470383, 7.349740943,
      7.333011205, 7.210540956, 7.181114862, 7.148961241, 7.122586364,
      7.096668032, 7.070748244, 7.041998507, 7.00923282, 6.980344674,
      6.953504199, 6.98486158, 6.962601075, 6.940339753, 6.913712366,
      6.883862362, 6.86509409, 6.837850444, 6.814666738, 6.791482224,
      6.768296922, 6.791304666, 6.767319343, 6.75123366, 6.723863674,
      6.700652873, 6.702466246, 6.684591295, 6.660790964, 6.645384768,
      6.618729188, 6.67775174, 6.661295265, 6.650488255, 6.638273467,
      6.617804882, 6.606730915, 6.586702995, 6.57304188, 6.561720246,
      6.545058286, 6.519666671, 6.50477111, 6.489875424, 6.474979617,
      6.460083692, 6.444481046, 6.430233761, 6.415337499, 6.396737149,
      6.384384051, 6.360851491, 6.348117172, 6.327823282, 6.312001244,
      6.298482538, 6.280223008, 6.264082224, 6.247941335, 6.231800338,
      6.215659227, 6.312686677, 6.306016242, 6.299345799, 6.292675347,
      6.286004886, 6.279334417, 6.272663938, 6.26599345, 6.259322953,
      6.252652446, 6.302446496, 6.30053722, 6.298627944, 6.296718668,
      6.294809391, 6.292900115, 6.290990838, 6.28908156, 6.287172283,
      6.285263005, 6.283353727, 6.281444449, 6.279535171, 6.277625892,
      6.275716613, 6.273807334, 6.271898055, 6.269988775, 6.268079495,
      6.266170215, 6.519232874, 6.537478211, 6.555724174, 6.573970774,
      6.592218024, 6.610465933, 6.628714513, 6.646963776, 6.665213733,
      6.683464394, 6.434297209, 6.431434351, 6.428571494, 6.425708635,
      6.422845777, 6.419982917, 6.417120057, 6.414257197, 6.411394336,
      6.408531474, 6.417002665, 6.415410801, 6.413870691, 6.412354139,
      6.410860787, 6.409390279, 6.407942267, 6.406516408, 6.405112362,
      6.403729797, 6.297204226, 6.286737293, 6.276270329, 6.263421579,
      6.254698309, 6.244632145, 6.234165047, 6.223697913, 6.209119738,
      6.200274196, 6.236928144, 6.23126171, 6.225870771, 6.220561941,
      6.215333976, 6.210185654, 6.205115767, 6.200123129, 6.195206568,
      6.190364933, 6.174491236, 6.168867385, 6.163477078, 6.158168872,
      6.152941526, 6.147793814, 6.142724531, 6.137732489, 6.132816518,
      6.127975465, 6.078227137, 6.068819658, 6.059300081, 6.049780467,
      6.040260816, 6.027994958, 6.020005319, 6.011385421, 6.001865615,
      5.992345771, 5.966307368, 5.95736086, 5.948550068, 5.93935727, 5.920094848,
      5.91090325, 5.90185105, 5.892936159, 5.884156518, 5.874500951, 5.911621572,
      5.906350513, 5.901159762, 5.896048104, 5.883615847, 5.876944608,
      5.870273353, 5.863602081, 5.857953336, 5.852549925, 5.84722883,
      5.841988805, 5.836828622, 5.831747072, 5.818909545, 5.812238138,
      5.805566713, 5.799170743, 5.793712881, 5.788338164, 5.783045332,
      5.777833146, 5.772700384, 5.767645844, 5.76266834, 5.748478185,
      5.741168115, 5.735643907, 5.730203853, 5.724846678, 5.719571126,
      5.714375964, 5.709259972, 5.704221951, 5.699260721, 5.683276472,
      5.677684215, 5.672177145, 5.666753973, 5.661413429, 5.656154262,
      5.650975241, 5.64587515, 5.640852794, 5.63352381, 5.629576754, 5.614907355,
      5.610364811, 5.606173693, 5.598871911, 5.593615531, 5.588439258,
      5.583341879, 5.574940754, 5.570878935, 5.566940791, 5.56312258,
      5.548367124, 5.544165185, 5.540091162, 5.5803311, 5.578958486, 5.577627848,
      5.576337904, 5.575087414, 5.573875172, 5.572700011, 5.571560799,
      5.570456437, 5.569385863, 5.42131852, 5.404612696, 5.395108592,
      5.378566652, 5.360332479, 5.343802832, 5.334536816, 5.316348414,
      5.298007905, 5.28791771, 5.316350128, 5.312755505, 5.298458064, 5.29505426,
      5.280850882, 5.275300258, 5.262803842, 5.257386175, 5.257677086,
      5.260176695, 5.312205846, 5.306917142, 5.30695935, 5.30699735, 5.307031586,
      5.303718919, 5.304110182, 5.301794781, 5.302477428, 5.30102511,
      5.301898867, 5.301127709, 5.302082524, 5.302890903, 5.30357532,
      5.304154797, 5.304645433, 5.305060854, 5.305412596, 5.305710423,
      5.48966862, 5.504642726, 5.519616982, 5.534591382, 5.549565922,
      5.564540594, 5.579515396, 5.59449032, 5.614169428, 5.624830406, 6.03751011,
      6.084917307, 6.123348589, 6.166573207, 6.208954593, 6.2467077, 6.289571479,
      6.329427382, 6.365934665, 6.423596966, 6.514649596, 6.562998028,
      6.611353852, 6.659717627, 6.708089907, 6.756471246, 6.804862191,
      6.853263289, 6.901675086, 6.950098123, 6.998532942, 7.046980083,
      7.094979636, 7.142516283, 7.190065836, 7.237627801, 7.28520169,
      7.332787023, 7.380383329, 7.427990141, 7.475607002, 7.523233455,
      7.570869054, 7.618513354, 7.666165915, 7.7138263, 7.761494075, 7.80916881,
      7.856850074, 7.90453744, 7.95223048, 7.999928767, 8.047631876, 8.095339451,
      8.143051296, 8.190767229, 8.238487068, 8.286210627, 8.333937717,
      8.381668151, 8.429401733, 8.477138272, 8.52487757, 8.572619428,
      8.620363648, 8.668110026, 8.715858359, 8.763608441, 8.811360067,
      8.859113027, 8.906867111, 8.954622109, 9.001524964, 9.04838062, 9.09523666,
      9.142092952, 9.188949371, 9.235805797, 9.282662114, 9.329518206,
      9.166748669, 9.18578058, 9.216045532, 9.233623213, 9.257279683,
      9.279575075, 9.295232687, 9.311479655, 9.336995885, 9.350738861,
      9.50891302, 9.531120607, 9.552367843, 9.572655876, 9.586149858,
      9.597277814, 9.6131854, 9.628707452, 9.643723491, 9.658389324, 9.708754379,
      9.718035187, 9.728083469, 9.740755177, 9.739654599, 9.74882166,
      9.757572198, 9.765174102, 9.758694332, 9.763539956, 9.794294231,
      9.796540607, 9.789342985, 9.777798033, 9.777776756, 9.763315217,
      9.746917973, 9.736265303, 9.72235917, 9.70113883, 9.65102992, 9.65102992,
      9.65102992, 9.65102992, 9.638392192, 9.637437209, 9.636482227, 9.635527244,
      9.621935886, 9.620026597, 9.61811731, 9.616208022, 9.614298736,
      9.612389449, 9.610480164, 9.608570879, 9.606661594, 9.60475231,
      9.602843026, 9.600933743, 9.59902446, 9.597115178, 9.595205896,
      9.593296615, 9.591387335, 9.589478055, 9.587568775, 9.585659496,
      9.583750217, 9.581840939, 9.579931661, 9.578022384, 9.576113108,
      9.574203832, 9.572294556, 9.570385281, 9.568476006, 9.566566732,
      9.564657458, 9.562748185, 9.560838913, 9.55892964, 9.557020369,
      9.555111098, 9.553201827, 9.551292557, 9.549383287, 9.547474018,
      9.545564749, 9.543655481, 9.541746213, 9.539836946, 9.537927679,
      9.536018413, 9.534109147, 9.532199882, 9.530290617, 9.528381352,
      9.526472089, 9.524562825, 9.522653562, 9.5207443, 9.518835038, 9.516925776,
      9.515016515, 9.513107255, 9.511197995, 9.509288735, 9.507379476,
      9.505470217, 9.415403136, 9.381651556, 9.346010869, 9.318140014,
      9.307356746, 9.284164063, 9.260384565, 9.236027868, 9.211103425,
      9.195941688, 9.135121913, 9.107041522, 9.077467549, 9.036786897,
      9.006464268, 8.975671109, 8.932274056, 8.900801264, 8.86891425,
      8.824172072, 8.902703172, 8.87530248, 8.847421807, 8.831482362,
      8.803376931, 8.787200106, 8.758877299, 8.730089772, 8.71321663,
      8.684233576, 8.679504579, 8.66338993, 8.635179821, 8.614840417,
      8.590175917, 8.565914882, 8.544530163, 8.516536361, 8.498272078,
      8.469009437, 8.500627937, 8.480025948, 8.459565936, 8.444954883,
      8.423338313, 8.403733422, 8.389061473, 8.366495287, 8.347690776,
      8.332459388, 8.663212226, 8.67058459, 8.677956954, 8.672284393,
      8.678732614, 8.685180834, 8.691629054, 8.698077274, 8.704525493,
      8.710973711, 8.743548134, 8.751845376, 8.760142617, 8.768439856,
      8.776737094, 8.785034329, 8.793331563, 8.801628795, 8.809926025,
      8.817003568, 8.813338154, 8.820710498, 8.82808284, 8.83545518, 8.842827518,
      8.850199854, 8.857572189, 8.864944521, 8.872316851, 8.879689178,
      8.616791795, 8.60703276, 8.597421272, 8.577572948, 8.570212768,
      8.556126753, 8.546378966, 8.536778544, 8.517223574, 8.509875752,
      8.466057529, 8.457546463, 8.437072342, 8.428531818, 8.40804133,
      8.399472722, 8.379254495, 8.370384572, 8.356011882, 8.341515898,
      8.430993101, 8.424582465, 8.418171844, 8.411761235, 8.40535064,
      8.398940058, 8.392529489, 8.386118934, 8.379708392, 8.373297862,
      8.464869397, 8.465788345, 8.466707293, 8.467626242, 8.46854519,
      8.469464138, 8.470383086, 8.471302035, 8.472220983, 8.473139931,
      8.203558311, 8.192147843, 8.168948256, 8.143851845, 8.124173443,
      8.104490277, 8.095020488, 8.075212079, 8.051050626, 8.035012817,
      8.279649921, 8.28058688, 8.281523839, 8.282460797, 8.283397756,
      8.284334715, 8.285271674, 8.286208632, 8.287145591, 8.28808255,
      8.191571294, 8.185035052, 8.178498821, 8.171962601, 8.16542639,
      8.158890189, 8.152353997, 8.145817815, 8.139281641, 8.132745476,
      8.417013592, 8.432093651, 8.447173745, 8.462253871, 8.465157336,
      8.478591892, 8.492724034, 8.506856197, 8.520980501, 8.534842529,
      8.639378629, 8.651226735, 8.666574776, 8.686028428, 8.705482107,
      8.711942938, 8.730462868, 8.74898281, 8.76750276, 8.773000168, 9.103297423,
      9.128778813, 9.146451488, 9.16790695, 9.191205024, 9.213541711,
      9.233186727, 9.246262102, 9.260892705, 9.278452267, 9.242383926,
      9.254276698, 9.265221566, 9.275219659, 9.284272107, 9.292380041,
      9.312767166, 9.319923506, 9.326137599, 9.331410571, 9.441765653,
      9.439372479, 9.44835873, 9.443120978, 9.435998254, 9.440289257,
      9.430340628, 9.418985604, 9.418170565, 9.403654769, 9.360851687,
      9.354215315, 9.346616681, 9.338056885, 9.328537023, 9.318058191,
      9.319970291, 9.308532856, 9.296138642, 9.283630509, 9.270167774,
      9.268258569, 9.266349366, 9.264440162, 9.262530959, 9.260621757,
      9.258712555, 9.256803353, 9.254894151, 9.252984951, 9.25107575, 9.24916655,
      9.24725735, 9.245348151, 9.243438952, 9.241529753, 9.239620555,
      9.237711357, 9.23580216, 9.233944249, 9.232108539, 9.230272829,
      9.228437119, 9.22660141, 9.224765701, 9.222929993, 9.221094285,
      9.219258578, 9.21742287, 9.215587164, 9.213751457, 9.211915751,
      9.210080046, 9.20824434, 9.206408636, 9.204572931, 9.202737227,
      9.200901524, 9.19906582, 9.197230118, 9.195394415, 9.193558713,
      9.191723011, 9.18988731, 9.188051609, 9.186215909, 9.184380209,
      9.182544509, 9.18070881, 9.178873111, 9.127224445, 9.121726093,
      9.103778882, 9.0849204, 9.077022343, 9.058748423, 9.049620485, 9.041382966,
      9.026803295, 9.019911582, 8.963429902, 8.941446832, 8.916457211,
      8.895642448, 8.871983872, 8.847784345, 8.820860138, 8.792063243,
      8.762368945, 8.732401567, 8.725060386, 8.694485998, 8.663016756,
      8.642990913, 8.61063685, 8.577714116, 8.555587814, 8.521460169,
      8.488218349, 8.457308418, 8.450520369, 8.416147735, 8.380274064,
      8.355755359, 8.319006179, 8.293406716, 8.25595547, 8.217448803,
      8.190245755, 8.150869423, 8.125849528, 8.091555806, 8.056895427,
      8.021874361, 7.986498482, 7.950773565, 7.911797869, 7.877036249,
      7.836721284, 7.792386573, 7.847468719, 7.814211678, 7.7805531, 7.758501105,
      7.724786751, 7.690678048, 7.65618124, 7.626993818, 7.598339849,
      7.563437334, 7.599642672, 7.580278869, 7.549310446, 7.529785157,
      7.498678783, 7.467135548, 7.447012075, 7.415348621, 7.395084801,
      7.363304828, 7.40193402, 7.385517664, 7.3657067, 7.341406668, 7.324979817,
      7.297036054, 7.28035721, 7.256519817, 7.235535167, 7.218859948,
      7.202433749, 7.182967117, 7.158984621, 7.142000988, 7.122495744,
      7.098516566, 7.074348917, 7.053223657, 7.037280069, 7.013138671,
      6.980203729, 6.96388745, 6.939224572, 6.914393925, 6.88940061, 6.875840512,
      6.851100698, 6.82619534, 6.801129473, 6.78694714, 6.727987711, 6.701323578,
      6.675948703, 6.653843566, 6.631822631, 6.59838208, 6.576129134, 6.55396694,
      6.526905842, 6.497977646, 6.503331239, 6.486351194, 6.458040107,
      6.435405818, 6.411268045, 6.398534593, 6.370119742, 6.35015641,
      6.330309023, 6.315526051, 6.557542364, 6.557542364, 6.557542364,
      6.557542364, 6.557542364, 6.557542364, 6.557542364, 6.557542364,
      6.557542364, 6.557542364, 6.439048411, 6.433415846, 6.431181611,
      6.420579986, 6.421226375, 6.425248851, 6.437408668, 6.444584697,
      6.434113849, 6.434694319, 6.706456256, 6.723237605, 6.736788132,
      6.750128851, 6.76326301, 6.777314112, 6.793320133, 6.809326638,
      6.833185833, 6.841941263, 7.264822266, 7.312402755, 7.359994418,
      7.407596787, 7.455209399, 7.502831799, 7.550463535, 7.598104162,
      7.645753238, 7.693410325, 7.741074987, 7.788746794, 7.836425313,
      7.884110118, 7.93180078, 7.979496872, 8.027197967, 8.074903659,
      8.122613697, 8.170327901, 8.21804609, 8.265768078, 8.313493679,
      8.361222704, 8.408954961, 8.456690258, 8.504428398, 8.552169184,
      8.599912416, 8.647657894, 8.695405415, 8.743154774, 8.790905764,
      8.838658178, 8.886411806, 8.934166439, 8.98145477, 9.028310221,
      9.062183758, 9.095084125, 9.166067307, 9.212923744, 9.259780129,
      9.306636344, 9.353492278, 9.400347819, 9.447202858, 9.494057282,
      9.540910982, 9.587763844, 9.493803995, 9.512857164, 9.537051813,
      9.556448799, 9.576735159, 9.596063473, 9.614064653, 9.63182466, 9.6479739,
      9.657876697, 9.613601182, 9.631864996, 9.645585749, 9.654376243,
      9.662186853, 9.673131506, 9.688512064, 9.694408659, 9.69927893,
      9.703173864, 9.706094585, 9.716328191, 9.723045798, 9.72401574,
      9.724014827, 9.723044165, 9.734559668, 9.732616011, 9.729704813,
      9.725827167, 9.692787487, 9.686227938, 9.69101347, 9.682323466,
      9.686150459, 9.689977449, 9.680324623, 9.683193794, 9.672581009,
      9.674493076, 9.662921763, 9.663877439, 9.664833116, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.652304344, 9.652304344, 9.652304344,
      9.652304344, 9.652304344, 9.639666165, 9.613435501, 9.585298926,
      9.555260505, 9.523324316, 9.485237554, 9.451392295, 9.415694866,
      9.366976853, 9.454452723, 9.426032439, 9.40296235, 9.378949082,
      9.353993719, 9.328097358, 9.301261107, 9.272555592, 9.244703214,
      9.208311613, 9.435157361, 9.435157361, 9.435157361, 9.435157361,
      9.435157361, 9.435157361, 9.435157361, 9.435157361, 9.432178453,
      9.431997537, 9.434707672, 9.434707672, 9.434707672, 9.434707672,
      9.434707672, 9.434707672, 9.434707672, 9.434707672, 9.434707672,
      9.434707672, 9.434707672, 9.434707672, 9.434707672, 9.434707672,
      9.434707672, 9.434707672, 9.434707672, 9.434707672, 9.434707672,
      9.434707672, 9.283991724, 9.272578521, 9.250343586, 9.236385692,
      9.218182603, 9.198686773, 9.184817086, 9.161638454, 9.145419084,
      9.126503799, 9.104055207, 9.077706511, 9.06032258, 9.039952407,
      9.016282116, 8.999865157, 8.970992981, 8.95038806, 8.924059232,
      8.905471861, 8.932528933, 8.909605721, 8.894096448, 8.871334237,
      8.850143498, 8.833242452, 8.807828905, 8.787788883, 8.768191091,
      8.741974958, 8.722496386, 8.700828665, 8.673847183, 8.654361184,
      8.631228626, 8.603517805, 8.583475631, 8.559461911, 8.531056581,
      8.509929342, 8.66089182, 8.652655809, 8.644397821, 8.636182236,
      8.619043433, 8.61197306, 8.605009967, 8.589400226, 8.580253219,
      8.571106252, 8.684368967, 8.684368967, 8.684368967, 8.684368967,
      8.684368967, 8.684368967, 8.684368967, 8.684368967, 8.684368967,
      8.684368967, 8.684368967, 8.684368967, 8.684368967, 8.684368967,
      8.684368967, 8.684368967, 8.684368967, 8.684368967, 8.684368967,
      8.684368967, 8.662017108, 8.660683569, 8.659370426, 8.658077366,
      8.653335982, 8.651500384, 8.649664785, 8.647829187, 8.64599359,
      8.644157992, 8.51998721, 8.509020397, 8.496036789, 8.486936194,
      8.466262423, 8.456967349, 8.447812861, 8.429226267, 8.41715218,
      8.405461308, 8.373875818, 8.355876415, 8.342186687, 8.32849709,
      8.314807624, 8.295353061, 8.284114555, 8.260947908, 8.249283083,
      8.231978009, 8.302249109, 8.292390149, 8.285729113, 8.279169169,
      8.269324615, 8.25403693, 8.247048438, 8.240165957, 8.233387893, 8.21468169,
      8.12068734, 8.097690211, 8.084593548, 8.060342074, 8.046221075,
      8.027088711, 8.007520914, 7.993416257, 7.968498229, 7.95458828,
      8.025046768, 8.016735913, 8.020564674, 8.013247871, 8.006042026,
      7.986943529, 7.979209871, 7.971593418, 7.964092412, 7.948158162,
      8.063355559, 8.063355559, 8.063355559, 8.05672576, 8.056309207,
      8.055899033, 8.05549514, 8.055097433, 8.054705817, 8.054320197,
      8.053940484, 8.053566585, 8.053198413, 8.052835879, 8.052478898,
      8.052127384, 8.051781253, 8.051440424, 8.051104815, 8.050774345,
      8.055546601, 8.055546601, 8.055546601, 8.055546601, 8.055546601,
      8.055546601, 8.055546601, 8.055546601, 8.055546601, 8.055546601,
      8.055546601, 8.055546601, 8.055546601, 8.055546601, 8.055546601,
      8.055546601, 8.055546601, 8.055546601, 8.055546601, 8.055546601,
      8.055546601, 8.055546601, 8.055546601, 8.055546601, 8.055546601,
      8.055546601, 8.055546601, 8.055546601, 8.055546601, 8.055546601,
      7.985462752, 7.974191644, 7.969436312, 7.964753354, 7.959553794,
      7.955563317, 7.951091542, 7.937423892, 7.933707588, 7.930104144,
      7.866847836, 7.852453265, 7.842292381, 7.83590549, 7.817777058,
      7.811207763, 7.792911704, 7.78617062, 7.76771747, 7.760814561, 7.873173787,
      7.872346853, 7.871545211, 7.870768089, 7.870014738, 7.869284433,
      7.868576469, 7.867890165, 7.867224859, 7.866579909, 7.633539582,
      7.613792118, 7.594024995, 7.57423907, 7.542568693, 7.523208556,
      7.506983129, 7.478978512, 7.451664981, 7.434430031, 7.571639272,
      7.568535224, 7.557736788, 7.563822169, 7.560524586, 7.559620155,
      7.560715499, 7.558454651, 7.560036958, 7.561536663, 7.597936281,
      7.596499179, 7.597133621, 7.596275161, 7.597019589, 7.596609686,
      7.596494984, 7.596627219, 7.596950537, 7.596923235, 7.60025003,
      7.600445923, 7.600614793, 7.60076037, 7.600885866, 7.600994053,
      7.601087318, 7.601167719, 7.601237032, 7.601296785, 8.235545034,
      8.283268369, 8.330995248, 8.37872548, 8.426458875, 8.474195237, 8.52193437,
      8.569676076, 8.61567296, 8.653482252, 8.711924528, 8.759674475,
      8.807425981, 8.855178839, 8.902932838, 8.950687769, 8.997664767,
      9.044520386, 9.091376399, 9.138232675, 9.185089089, 9.231945519,
      9.278801848, 9.325657963, 9.372513751, 9.419369101, 9.466223904,
      9.513078048, 9.559931421, 9.606783909, 9.653635396, 9.70048576,
      9.747334875, 9.794182611, 9.84102883, 9.887873387, 9.936010633,
      9.975638321, 9.999631331, 9.997087293, 9.400984306, 9.397168633,
      9.388671143, 9.385342195, 9.38206406, 9.378835965, 9.375657148,
      9.372526861, 9.369265405, 9.353845429, 9.136731138, 9.114132935,
      9.09328746, 9.072442551, 9.051598201, 9.02868014, 8.999424146, 8.97591044,
      8.954974328, 8.934038819, 8.962913006, 8.945591677, 8.928270676,
      8.910950001, 8.89362965, 8.876309619, 8.858989906, 8.836943114,
      8.822960743, 8.796799628, 8.726659612, 8.703335367, 8.673602508,
      8.648022035, 8.625293117, 8.602564874, 8.579837301, 8.557110392,
      8.528766156, 8.498946244, 8.475322294, 8.451699072, 8.428076572,
      8.404454791, 8.379922157, 8.348887, 8.320686269, 8.296169483, 8.271653479,
      8.247138253, 8.295730027, 8.276614017, 8.257498367, 8.238383077,
      8.219268145, 8.200124866, 8.181037197, 8.157572977, 8.130365865,
      8.114052039, 8.013636525, 7.9807622, 7.953129502, 7.926309129, 7.899489516,
      7.870850771, 7.845712621, 7.81576825, 7.782085702, 7.752267145,
      7.880411565, 7.864608001, 7.848804475, 7.833000977, 7.8171975, 7.801394033,
      7.781621433, 7.768682897, 7.744004582, 7.730712523, 7.789139274,
      7.78069835, 7.771445258, 7.752232552, 7.743425047, 7.734750785,
      7.726207775, 7.706484225, 7.696911584, 7.688016107, 7.625873466,
      7.60792236, 7.595756975, 7.57192147, 7.559377601, 7.547022391, 7.523083755,
      7.510295694, 7.497758689, 7.476381368, 7.649470428, 7.648534242,
      7.647598056, 7.646661871, 7.645725685, 7.644789499, 7.643853313,
      7.642917127, 7.641980941, 7.641044755, 7.583200515, 7.578814017,
      7.574494316, 7.565031751, 7.559426682, 7.553821604, 7.548216517,
      7.54261142, 7.537006313, 7.531401197, 7.526799144, 7.522340635,
      7.517950015, 7.513626258, 7.509368351, 7.499001897, 7.49339671,
      7.487791511, 7.482186302, 7.476581082, 7.54150424, 7.54150424, 7.54150424,
      7.54150424, 7.54150424, 7.54150424, 7.54150424, 7.54150424, 7.54150424,
      7.54150424, 7.47097585, 7.466267056, 7.461799417, 7.457399808, 7.4530672,
      7.44880058, 7.444598948, 7.440461321, 7.43638673, 7.43237422, 7.428422852,
      7.413694255, 7.408274278, 7.403758829, 7.399312136, 7.394933159,
      7.390620873, 7.386374271, 7.382192357, 7.378074153, 7.245204878,
      7.232973653, 7.218510025, 7.197213855, 7.184783797, 7.172540749,
      7.148809256, 7.136186603, 7.123753839, 7.100305268, 7.07284588,
      7.056110137, 7.03673823, 7.022426933, 6.997887665, 6.98385338, 6.970029879,
      6.944814703, 6.930658133, 6.916714196, 6.960873562, 6.951085267,
      6.941444992, 6.924858058, 6.912744441, 6.900765758, 6.890961503,
      6.88130553, 6.864875098, 6.852760955, 6.840624111, 6.830804439,
      6.816599927, 6.804485386, 6.789974244, 6.779995626, 6.770167934,
      6.756007252, 6.739167541, 6.729032376, 6.856866246, 6.856103552,
      6.855352533, 6.854613012, 6.853884812, 6.85316776, 6.852461687,
      6.851766423, 6.851081804, 6.850407666, 6.780856056, 6.775654718,
      6.770532565, 6.75401433, 6.748291146, 6.742655035, 6.737104682,
      6.731638792, 6.726256091, 6.72095532, 6.991385979, 7.006451346,
      7.021517042, 7.036583062, 7.051649402, 7.066716058, 7.081783024,
      7.096850295, 7.111917868, 7.126985737, 7.067488454, 7.076886753,
      7.086285121, 7.095683558, 7.105082063, 7.114480635, 7.123879273,
      7.133277978, 7.142676747, 7.152075581, 6.912601237, 6.904469666,
      6.896461372, 6.885429244, 6.869066911, 6.860668346, 6.852397071,
      6.84425118, 6.831097377, 6.816476539, 6.795220087, 6.787206799,
      6.769729746, 6.757266859, 6.747783073, 6.736565309, 6.729120415,
      6.710981644, 6.703678581, 6.68984394, 6.542857651, 6.51489332, 6.494592123,
      6.475068681, 6.449659924, 6.424105696, 6.398410428, 6.372578417,
      6.346613827, 6.331908944, 6.506112908, 6.495436129, 6.490957286,
      6.485535331, 6.482538245, 6.46831039, 6.465170215, 6.462172651,
      6.453155638, 6.451449597, 6.37409953, 6.367295159, 6.353685869,
      6.341508285, 6.329123709, 6.316737219, 6.304348948, 6.294980868,
      6.289131769, 6.291529294, 6.374814181, 6.37503188, 6.371304719,
      6.371934618, 6.372496588, 6.370206267, 6.371059914, 6.369659657,
      6.368842401, 6.370117758, 6.59288856, 6.609207233, 6.625526397,
      6.641846059, 6.658166227, 6.674486907, 6.690640251, 6.706643535,
      6.72264734, 6.738651658, 6.991721361, 7.022661377, 7.056758085,
      7.090859276, 7.12496482, 7.159074589, 7.192739612, 7.220004304,
      7.248452862, 7.281619216, 7.500880098, 7.548511461, 7.596151732,
      7.64380047, 7.691457237, 7.739121598, 7.78679312, 7.834471373, 7.882155928,
      7.929846359, 7.977542237, 8.025243135, 8.072948645, 8.120658508,
      8.168372545, 8.216090574, 8.26381241, 8.311537867, 8.359266755,
      8.406998884, 7.950728156, 7.958531013, 7.976983118, 7.987167927,
      7.995353026, 8.003411418, 8.01134508, 8.027727548, 8.038074141,
      8.048319959, 7.858475773, 7.853803072, 7.849130371, 7.844457668,
      7.839784964, 7.835112259, 7.830439552, 7.825766843, 7.821094132,
      7.81642142, 7.811748706, 7.80707599, 7.802403272, 7.797730552, 7.79305783,
      7.788385106, 7.78371238, 7.779039651, 7.77436692, 7.769694187, 7.765021451,
      7.760348712, 7.755675971, 7.751003227, 7.74633048, 7.74165773, 7.736984978,
      7.732312222, 7.727639464, 7.722966702, 7.917671788, 7.928018067,
      7.938364378, 7.948710721, 7.959057094, 7.969403497, 7.97974993,
      7.990096393, 8.000442884, 8.010789404, 7.832995261, 7.829255454,
      7.825515647, 7.821775838, 7.818036029, 7.814296218, 7.810556407,
      7.806816594, 7.803076781, 7.799336966, 7.79559715, 7.791857333,
      7.788117514, 7.784377695, 7.780637874, 7.776898052, 7.773158228,
      7.769418404, 7.765678578, 7.773808822, 8.010566062, 8.025644358,
      8.040722747, 8.055801227, 8.070879796, 8.085958451, 8.101037191,
      8.116116013, 8.131194916, 8.146273897, 7.927657957, 7.926723777,
      7.925832336, 7.924981687, 7.924169971, 7.923395415, 7.922656323,
      7.921951079, 7.921278138, 7.920636025, 7.920023333, 7.919438718,
      7.918880898, 7.918348646, 7.917840796, 7.917356231, 7.916893886,
      7.920762829, 7.920350038, 7.919949885, 8.068149883, 8.078496578,
      8.088843297, 8.099190041, 8.109536809, 8.1198836, 8.130230415, 8.140577252,
      8.150924111, 8.161270991, 8.672165308, 8.719913797, 8.767664019,
      8.815415766, 8.86316883, 8.910923, 8.9586493, 9.005504484, 9.052360178,
      9.099216244, 9.146072552, 9.192928977, 9.239785398, 9.286641699,
      9.333497767, 9.38035349, 9.427208756, 9.474063456, 9.520917479,
      9.567770712, 9.614623041, 9.661474349, 9.708324512, 9.755173406,
      9.802020898, 9.848866849, 9.895711113, 9.944155428, 9.980355261,
      9.999206282, 9.416475614, 9.416475614, 9.429871313, 9.430826995,
      9.431782678, 9.432738361, 9.433694044, 9.434649726, 9.435605409,
      9.436561092, 9.437516774, 9.438472457, 9.439428139, 9.440383822,
      9.441339505, 9.442295187, 9.44325087, 9.444206552, 9.445162234,
      9.446117917, 9.260520879, 9.244764915, 9.23410077, 9.223646621,
      9.205429437, 9.192124489, 9.179580731, 9.169008698, 9.158596721,
      9.139685126, 9.461746528, 9.473262862, 9.484779167, 9.496295442,
      9.507811687, 9.519327899, 9.53084408, 9.542360229, 9.553876344,
      9.565392426, 9.252974713, 9.240615167, 9.22825574, 9.215896431, 9.20353724,
      9.191178165, 9.178819206, 9.166460362, 9.154101633, 9.141743016,
      9.055833231, 9.040796758, 9.022574849, 9.00018499, 8.990036602,
      8.967737541, 8.957663505, 8.936359147, 8.925484541, 8.91131583,
      8.781968267, 8.755209044, 8.728365595, 8.703599383, 8.681897869,
      8.660129435, 8.626382316, 8.604594275, 8.582895016, 8.548952304,
      8.639371976, 8.624151436, 8.608950684, 8.593768585, 8.578604069,
      8.563456125, 8.545759365, 8.534002141, 8.522229288, 8.505582466,
      8.507711045, 8.500454619, 8.483496812, 8.472426485, 8.466985318,
      8.466598332, 8.461327168, 8.45849929, 8.468401796, 8.479474047,
      8.891026807, 8.90102505, 8.922348574, 8.943672077, 8.964995556,
      8.986319004, 9.007642417, 9.028965791, 9.050289119, 9.068312308,
      9.447201251, 9.494055676, 9.540909375, 9.587762237, 9.634614145,
      9.681464979, 9.728314617, 9.775162929, 9.822009781, 9.868855031,
      9.596276058, 9.621361317, 9.646446297, 9.671530983, 9.696615363,
      9.708319921, 9.732429821, 9.756539412, 9.780648683, 9.80475762,
      9.468085224, 9.466175975, 9.464266727, 9.462357478, 9.460448231,
      9.458538984, 9.456629737, 9.454720491, 9.452811245, 9.450901999,
      9.487558525, 9.488514206, 9.489469888, 9.490425569, 9.491381251,
      9.492336932, 9.493292613, 9.494248295, 9.495203976, 9.496159657,
      9.345340539, 9.334874216, 9.324407969, 9.313941797, 9.3034757, 9.293009677,
      9.282543727, 9.272077851, 9.261612047, 9.251146315, 9.086073528,
      9.068116224, 9.046332384, 9.021197618, 9.002512958, 8.973836461,
      8.95689808, 8.92775154, 8.910606812, 8.882734366, 8.851577112, 8.833780297,
      8.803831858, 8.785853922, 8.758680812, 8.737761753, 8.713350002,
      8.690619113, 8.667888916, 8.645159404, 8.573789221, 8.546788411,
      8.520468713, 8.494150049, 8.467832411, 8.441515791, 8.411820791,
      8.388635819, 8.357637108, 8.324250718, 8.314946501, 8.282672597,
      8.256362945, 8.230054258, 8.203746533, 8.177439762, 8.151133941,
      8.120321331, 8.098188683, 8.066105953, 8.069385946, 8.049584772,
      8.020721749, 7.998302682, 7.970960398, 7.946385238, 7.921008136,
      7.896016857, 7.871026071, 7.846035722, 7.953233197, 7.938352493,
      7.923471849, 7.908591259, 7.893710716, 7.878830212, 7.86394974,
      7.849069294, 7.833423442, 7.815540513, 7.720420857, 7.699096293,
      7.680932565, 7.656692619, 7.634959141, 7.614011138, 7.592686075,
      7.571640182, 7.550057138, 7.52873141, 7.508359067, 7.486153651,
      7.462270454, 7.443299702, 7.421972252, 7.398809532, 7.379171954,
      7.35255887, 7.335051584, 7.31468584, 7.206504448, 7.182911849, 7.149800884,
      7.115385775, 7.09230068, 7.058416246, 7.034745441, 7.000263505,
      6.977064262, 6.942550815, 6.872717353, 6.835239802, 6.797422828,
      6.770876822, 6.733128837, 6.695045441, 6.668197507, 6.63019171,
      6.591854357, 6.564716986, 6.561006041, 6.52463233, 6.499391009,
      6.463045211, 6.426341872, 6.40073999, 6.364075112, 6.33848712, 6.301860004,
      6.269637993, 6.284833417, 6.25085492, 6.227854315, 6.193833498, 6.16851994,
      6.139380764, 6.109844491, 6.080269341, 6.050656419, 6.021006797,
      6.052200765, 6.032558413, 6.006256075, 5.979811392, 5.95323373,
      5.931549003, 5.91121017, 5.884842583, 5.858339456, 5.831704863, 6.00667947,
      5.999058211, 5.991436932, 5.983815631, 5.976194309, 5.968572965,
      5.960951599, 5.953330211, 5.945708801, 5.938087368, 5.734258427,
      5.718821971, 5.692676205, 5.666387642, 5.642971235, 5.620872708,
      5.598399618, 5.572162415, 5.545784853, 5.521447415, 5.679623813,
      5.671051545, 5.662479234, 5.653906878, 5.645334477, 5.636762032,
      5.628189541, 5.619617005, 5.611044422, 5.602471793, 5.415496431,
      5.393412702, 5.371393239, 5.349435126, 5.327535573, 5.304205326,
      5.283195113, 5.256224052, 5.237427616, 5.211929608, 5.219475214,
      5.194349298, 5.180183423, 5.151929466, 5.141413943, 5.119873508,
      5.102320639, 5.087607102, 5.068552153, 5.051843674, 5.052073839,
      5.051805145, 5.077986217, 5.111550618, 5.133784446, 5.1485162, 5.158278762,
      5.16474898, 5.169037469, 5.171880029, 5.382459654, 5.396293371,
      5.409913632, 5.423323734, 5.436983971, 5.452958907, 5.468934054,
      5.484909403, 5.500884949, 5.516860683, 5.318440007, 5.316450895,
      5.314461783, 5.31247267, 5.310483557, 5.308494443, 5.306505328,
      5.304516213, 5.302527098, 5.300537981, 5.847047614, 5.882962003,
      5.92475326, 5.955890198, 5.998065783, 6.034444076, 6.068280841,
      6.107816407, 6.142846917, 6.174500538, 6.152557902, 6.186268049,
      6.211729789, 6.240921131, 6.273665796, 6.306412436, 6.33916117,
      6.359764471, 6.391546617, 6.423331005, 6.662027835, 6.710400536,
      6.758782321, 6.807173738, 6.855575335, 6.903987656, 6.952411244,
      7.000846639, 7.049294382, 7.097249829, 7.00956814, 7.04570607, 7.075265309,
      7.107459962, 7.143482033, 7.174375164, 7.202889415, 7.237870567,
      7.271395393, 7.299355991, 7.478828147, 7.524523781, 7.561296219,
      7.602800975, 7.635081936, 7.678870592, 7.715509515, 7.753404268,
      7.796241217, 7.826536629, 7.943781777, 7.991479166, 8.039181451,
      8.086888251, 8.134599353, 8.182314575, 8.230033736, 8.277756649,
      8.325483128, 8.373212983, 7.936880767, 7.948171987, 7.959463247,
      7.970754548, 7.982045888, 7.993337267, 8.004628684, 8.015920138,
      8.027211629, 8.038503156, 7.751393034, 7.737826871, 7.718748533,
      7.706642012, 7.694535456, 7.68242886, 7.670322223, 7.65821554, 7.646108809,
      7.634002027, 7.890636426, 7.899095042, 7.907553676, 7.916012326,
      7.924470994, 7.932929679, 7.94138838, 7.949847098, 7.958305832,
      7.966764581, 8.444688881, 8.478492718, 8.51341276, 8.54698155, 8.580015786,
      8.612524095, 8.648122357, 8.688109424, 8.715201414, 8.751695137,
      8.689649095, 8.708021274, 8.738263389, 8.764056264, 8.784560559,
      8.813392786, 8.832575244, 8.857367379, 8.88525859, 8.911509186,
      8.784535184, 8.801189788, 8.816078238, 8.829033731, 8.837590866,
      8.853313886, 8.869036897, 8.884759897, 8.900482886, 8.916205861,
      9.062896159, 9.087967967, 9.099922952, 9.124056389, 9.148189744,
      9.159177374, 9.182373088, 9.205568708, 9.223317567, 9.238393555,
      9.23426952, 9.254656911, 9.264053411, 9.281444894, 9.300897581, 9.32035018,
      9.326564101, 9.345082846, 9.363601504, 9.381573234, 9.480208255,
      9.494441491, 9.514491625, 9.537685038, 9.547573136, 9.569912024,
      9.584590769, 9.602227156, 9.619789898, 9.632859149, 9.600170338,
      9.604460648, 9.620806013, 9.637151281, 9.652348861, 9.656353848,
      9.671731561, 9.687109183, 9.689064048, 9.70347499, 9.76436549, 9.775941062,
      9.791926231, 9.797017405, 9.813361455, 9.817667867, 9.83171874,
      9.841894224, 9.848618595, 9.863028551, 9.675044597, 9.675044597,
      9.675044597, 9.675044597, 9.675044597, 9.675044597, 9.675044597,
      9.675044597, 9.675044597, 9.675044597, 9.809973802, 9.819562545,
      9.823868251, 9.831092206, 9.833930149, 9.842556718, 9.851183264,
      9.835776291, 9.830725848, 9.826290777, 9.805904094, 9.797366023,
      9.797144682, 9.796939931, 9.796750553, 9.796575417, 9.79641347,
      9.796263737, 9.79612531, 9.795997347, 9.792222558, 9.792359128,
      9.792487281, 9.792607539, 9.79272039, 9.790160824, 9.790357855,
      9.790545817, 9.79072513, 9.790896191, 9.788952613, 9.789120948,
      9.787304472, 9.787413885, 9.787521621, 9.787627706, 9.787732165,
      9.787835024, 9.787936306, 9.788036036, 9.788134238, 9.788230935,
      9.78832615, 9.788419906, 9.788512225, 9.788603129, 9.787097779,
      9.787097779, 9.787097779, 9.787097779, 9.78869264, 9.78878078, 9.788867568,
      9.787430349, 9.787430349, 9.787430349, 9.787430349, 9.787430349,
      9.787430349, 9.787430349, 9.774745073, 9.773790081, 9.772835088,
      9.771880096, 9.770925104, 9.769970112, 9.76901512, 9.768060128,
      9.767105136, 9.766150145, 9.777877145, 9.777877145, 9.777877145,
      9.777877145, 9.774507122, 9.76494138, 9.763986389, 9.763031397,
      9.762076406, 9.761121414, 9.760166423, 9.759211432, 9.758256441,
      9.75730145, 9.756346459, 9.755391468, 9.754436477, 9.753481486,
      9.752526495, 9.751571505, 9.750616514, 9.749661523, 9.748706533,
      9.747751543, 9.739686264, 9.73263074, 9.73072142, 9.728812101, 9.726902783,
      9.724993465, 9.710412324, 9.707549342, 9.704686363, 9.701823385,
      9.686292562, 9.682476591, 9.678660624, 9.674844662, 9.671028705,
      9.654551554, 9.586485631, 9.570109546, 9.554277678, 9.541132577,
      9.520495228, 9.510900486, 9.497801639, 9.48019081, 9.461876094,
      9.448253888, 9.425711007, 9.402570377, 9.391452006, 9.367896724,
      9.356360328, 9.332403686, 9.307872547, 9.295359947, 9.27045852,
      9.244998117, 9.294382712, 9.276194779, 9.262484829, 9.252544512,
      9.239102317, 9.220349543, 9.210103638, 9.20001292, 9.177546139,
      9.167004907, 9.131585113, 9.110323346, 9.095215139, 9.083092258,
      9.058741286, 9.046831482, 9.022695541, 9.010370033, 8.991907077,
      8.973567446, 8.986018285, 8.97189897, 8.951935619, 8.940733894,
      8.929701333, 8.906421827, 8.895002833, 8.883756219, 8.860283116,
      8.848656373, 8.874358346, 8.865235243, 8.853593826, 8.834875318,
      8.825442926, 8.816153256, 8.807004169, 8.785642244, 8.776048188,
      8.766599256, 9.018715016, 9.026087283, 9.021728699, 9.026824412,
      9.03327255, 9.039720686, 9.04616882, 9.05261695, 9.059065078, 9.065513203,
      8.917703702, 8.913120198, 8.9085367, 8.903953207, 8.89936972, 8.894786238,
      8.890202761, 8.88561929, 8.881035825, 8.876452365, 9.025903249,
      9.032351388, 9.038799524, 9.045247658, 9.051695789, 9.058143917,
      9.064592042, 9.071040164, 9.077488284, 9.0839364, 8.936037771, 8.931454246,
      8.926870725, 8.922287211, 8.917703702, 8.913120198, 8.9085367, 8.903953207,
      8.89936972, 8.894786238, 8.965159474, 8.952883547, 8.952883547,
      8.952883547, 8.952883547, 8.952883547, 8.952883547, 8.952883547,
      8.952883547, 8.952883547, 8.891119456, 8.886535984, 8.881952517,
      8.877369056, 8.8727856, 8.86820215, 8.863618705, 8.859035265, 8.854451831,
      8.849868402, 8.845284979, 8.84070156, 8.836118148, 8.83153474, 8.826951338,
      8.822367941, 8.817784549, 8.813201163, 8.808617782, 8.804034407,
      8.644951672, 8.629465031, 8.613902363, 8.592258366, 8.578890603,
      8.560903837, 8.539072973, 8.517005962, 8.501835902, 8.484757007,
      8.47478955, 8.452881278, 8.430739414, 8.4186063, 8.398450022, 8.37616585,
      8.362225393, 8.343406916, 8.321095448, 8.305540929, 8.286601209,
      8.267623162, 8.248608547, 8.229559042, 8.210476248, 8.191361692,
      8.172216833, 8.152878553, 8.133836898, 8.121894069, 8.255143566,
      8.250183268, 8.247551611, 8.24503926, 8.230549872, 8.227884632,
      8.225340199, 8.222911171, 8.220592382, 8.218378891, 8.422719, 8.433066274,
      8.437689643, 8.445524952, 8.450174913, 8.459550904, 8.468773731,
      8.477996561, 8.487219396, 8.496442235, 8.389005554, 8.389924502,
      8.39084345, 8.391762398, 8.392681347, 8.393600295, 8.394519243,
      8.395438191, 8.396357139, 8.397276087, 8.373116856, 8.37219868,
      8.371280504, 8.370362328, 8.369444152, 8.368525977, 8.367607801,
      8.366689625, 8.36577145, 8.364853274, 8.389005554, 8.389924502, 8.39084345,
      8.391762398, 8.392681347, 8.393600295, 8.394519243, 8.395438191,
      8.396357139, 8.397276087, 8.60564906, 8.62137203, 8.632462192, 8.639503207,
      8.654295398, 8.669087597, 8.683879802, 8.698672014, 8.702560571,
      8.714461913, 9.106064272, 9.134158133, 9.153018356, 9.173782009,
      9.198030475, 9.221316434, 9.243640986, 9.26500524, 9.285410313,
      9.304857326, 9.231163819, 9.242118009, 9.252125418, 9.269305536,
      9.283079997, 9.291188411, 9.305807917, 9.318328295, 9.324543029,
      9.343061783, 9.335075456, 9.338772858, 9.354212957, 9.356663276,
      9.371454458, 9.372962238, 9.373534526, 9.386466416, 9.386099164,
      9.398102519, 9.370179992, 9.366090054, 9.374386853, 9.369653952,
      9.377319889, 9.384985817, 9.379305753, 9.386010872, 9.379364895,
      9.385109943, 9.324077662, 9.325033347, 9.325989031, 9.326944716,
      9.327900401, 9.328856086, 9.316454119, 9.316454119, 9.316454119,
      9.316454119, 9.291422605, 9.289513397, 9.287604188, 9.28569498,
      9.283785773, 9.281876566, 9.279967359, 9.278058153, 9.276148947,
      9.274239742, 9.363742191, 9.355507442, 9.359334557, 9.34980658,
      9.352675821, 9.342187784, 9.344099882, 9.332653246, 9.33360893,
      9.334564615, 9.322160472, 9.309642578, 9.308687615, 9.307732653,
      9.30677769, 9.305822727, 9.300510442, 9.29948173, 9.289797504, 9.300402726,
      9.299447764, 9.298492802, 9.29753784, 9.296582878, 9.295627916,
      9.294672954, 9.293717992, 9.29276303, 9.291808068, 9.290853106,
      9.289898145, 9.288943183, 9.287988221, 9.28703326, 9.286078298,
      9.285123337, 9.284168376, 9.283213414, 9.282258453, 9.281303492,
      9.28034853, 9.279393569, 9.278438608, 9.277483647, 9.276528686,
      9.275573725, 9.274618764, 9.273663803, 9.272708843, 9.271753882,
      9.270798921, 9.269843961, 9.268889, 9.267934039, 9.266979079, 9.266024119,
      9.265069158, 9.264114198, 9.263159238, 9.262204277, 9.261249317,
      9.260294357, 9.259339397, 9.258384437, 9.257429477, 9.256474517,
      9.255519557, 9.254564597, 9.253609637, 9.252654678, 9.251699718,
      9.250744758, 9.249789799, 9.248834839, 9.24787988, 9.24693714, 9.246018923,
      9.245100707, 9.244182491, 9.243264275, 9.242346059, 9.241427843,
      9.240509627, 9.239591411, 9.238673195, 9.237754979, 9.236836763,
      9.235918548, 9.235000332, 9.234082116, 9.233163901, 9.232245685,
      9.23132747, 9.230409254, 9.229491039, 9.228572823, 9.227654608,
      9.226736393, 9.225818178, 9.224899962, 9.223981747, 9.223063532,
      9.222145317, 9.221227102, 9.220308887, 9.219390673, 9.218472458,
      9.217554243, 9.216636028, 9.215717814, 9.214799599, 9.213881384,
      9.21296317, 9.212044955, 9.211126741, 9.210208527, 9.209290312,
      9.208372098, 9.207453884, 9.20653567, 9.205617456, 9.204699242,
      9.203781028, 9.202862814, 9.2019446, 9.201026386, 9.200108172, 9.199189958,
      9.198271744, 9.197353531, 9.196435317, 9.195517104, 9.19459889,
      9.193680676, 9.192762463, 9.19184425, 9.190926036, 9.190007823, 9.18908961,
      9.188171397, 9.187253183, 9.18633497, 9.185416757, 9.184498544,
      9.183580331, 9.182662118, 9.181743906, 9.180825693, 9.17990748,
      9.178989267, 9.178071055, 9.177152842, 9.176234629, 9.172537907,
      9.171648135, 9.170771981, 9.169909236, 9.169059696, 9.168223158,
      9.167399425, 9.166588299, 9.165789589, 9.165003104, 9.164228658,
      9.163466066, 9.162715147, 9.161975723, 9.16106608, 9.160147868,
      9.159229657, 9.158311445, 9.157393234, 9.156475022, 9.155556811,
      9.154638599, 9.153720388, 9.152802176, 9.151883965, 9.150965754,
      9.150047543, 9.149129331, 9.14821112, 9.147292909, 9.146374698,
      9.145456487, 9.144538276, 9.143620065, 9.142701855, 9.141783644,
      9.140865433, 9.139947222, 9.139029012, 9.138110801, 9.137192591,
      9.13627438, 9.13535617, 9.134437959, 9.133519749, 9.132601539, 9.131683328,
      9.124801875, 9.123725237, 9.122665073, 9.12162113, 9.120593161,
      9.119580922, 9.118584172, 9.117602675, 9.116636197, 9.115684509,
      9.114747386, 9.113824603, 9.112915943, 9.112021189, 9.111140128,
      9.110272552, 9.109418255, 9.108577032, 9.107748685, 9.106933017,
      9.106129833, 9.105338943, 9.104560158, 9.103793295, 9.103038169,
      9.102294603, 9.101443693, 9.100525485, 9.099607276, 9.098689067,
      9.097770859, 9.09685265, 9.095934442, 9.095016234, 9.094098025,
      9.093179817, 9.092261609, 9.0913434, 9.090425192, 9.089506984, 9.088588776,
      9.087670568, 9.08675236, 9.085834152, 9.084915944, 9.083997736,
      9.083079529, 9.073863044, 9.072648585, 9.071452704, 9.070275117,
      9.069115547, 9.067973716, 9.066849354, 9.065742195, 9.064651975,
      9.063578435, 9.062521322, 9.061480383, 9.060455372, 9.059446046,
      9.058452164, 9.057473491, 9.056509794, 9.055560844, 9.054626416,
      9.053706289, 9.052800242, 9.051908062, 9.051029537, 9.050164456,
      9.049312616, 9.048473813, 9.047647849, 9.046834526, 9.046033652,
      9.045245037, 9.044468492, 9.043703834, 9.042950881, 9.042209453,
      9.041319368, 9.040401162, 9.039482956, 9.038564751, 9.037646545,
      9.03672834, 9.035810134, 9.034891929, 9.033973723, 9.033055518,
      9.032137313, 9.031219108, 9.030300902, 9.019621478, 9.018319741,
      9.017037915, 9.015775695, 9.014532784, 9.013308885, 9.012103709,
      9.010916969, 9.009748385, 9.008597678, 9.007464575, 9.006348808,
      9.005250112, 9.004168225, 9.003102892, 9.00205386, 9.001020878,
      9.000003702, 8.999002091, 8.998015807, 8.997044615, 8.996088284,
      8.995146589, 8.994219304, 8.99330621, 8.992407089, 8.991521729,
      8.990649919, 8.989791452, 8.988946123, 8.988113732, 8.987294082,
      8.986486977, 8.985692225, 8.984909638, 8.984139029, 8.983380217,
      8.982633019, 8.981826426, 8.980908223, 8.97999002, 8.979071818,
      8.978153615, 8.977235412, 8.97631721, 8.975399007, 8.974480805,
      8.973562602, 8.962244084, 8.960903041, 8.959582509, 8.958282174,
      8.95700173, 8.95574087, 8.954499298, 8.953276717, 8.952072839, 8.950887377,
      8.94972005, 8.948570582, 8.947438699, 8.946324133, 8.945226619,
      8.944145896, 8.943081709, 8.942033805, 8.941001934, 8.939985853,
      8.938985319, 8.938000094, 8.937029946, 8.936074644, 8.93513396,
      8.934207672, 8.933295559, 8.932397405, 8.931512996, 8.930642122,
      8.929784577, 8.928940156, 8.92810866, 8.927289889, 8.92648365, 8.925689752,
      8.924908005, 8.924138224, 8.923380226, 8.92263383, 8.9218087, 8.920890501,
      8.919972301, 8.919054101, 8.918135901, 8.917217701, 8.916299502,
      8.915381302, 8.914463102, 8.913544903, 8.902266538, 8.900925959,
      8.899605883, 8.898305998, 8.897025995, 8.895765571, 8.894524426,
      8.893302267, 8.892098804, 8.89091375, 8.889746825, 8.888597752,
      8.887466258, 8.886352075, 8.885254938, 8.884174587, 8.883110765,
      8.88206322, 8.873548359, 8.871712721, 8.869877083, 8.868041445,
      8.866205808, 8.864370171, 8.862534534, 8.860698898, 8.857040166,
      8.855474478, 8.830305369, 8.826374519, 8.811126297, 8.806083337,
      8.791560072, 8.783863169, 8.778365422, 8.766291874, 8.754573922,
      8.744141168, 8.729150861, 8.720695429, 8.702516961, 8.693916608,
      8.685680476, 8.665159819, 8.656012473, 8.643816727, 8.625217852,
      8.615160152, 8.657175227, 8.65225765, 8.641883122, 8.635472039, 8.62906097,
      8.622649915, 8.614772452, 8.609588047, 8.60329745, 8.587143936, 8.55699387,
      8.549955593, 8.535468775, 8.526322005, 8.516249408, 8.507959295,
      8.489430618, 8.481599282, 8.467059564, 8.457002705, 8.471339943,
      8.463104606, 8.454869298, 8.446634018, 8.431674666, 8.42471907,
      8.417869009, 8.400406134, 8.391669943, 8.384412051, 8.413743911,
      8.408882111, 8.404094292, 8.399379335, 8.394736138, 8.380058771,
      8.373648241, 8.367801061, 8.362726295, 8.357728725, 8.537240367,
      8.544612723, 8.551985081, 8.55935744, 8.566729799, 8.57410216, 8.581474521,
      8.588846883, 8.5881602, 8.590008929, 8.470811245, 8.468735109, 8.46669069,
      8.464677506, 8.462695081, 8.460742945, 8.458820639, 8.456927706,
      8.455063699, 8.453228178, 8.572029255, 8.578477475, 8.584925695,
      8.591373916, 8.597822137, 8.604270358, 8.610718579, 8.617166801,
      8.623615022, 8.630063244, 8.51476918, 8.512937348, 8.511133512,
      8.509357245, 8.507608126, 8.505885741, 8.504189684, 8.502519551,
      8.500874949, 8.499255488, 8.53682326, 8.537742208, 8.538661157,
      8.526557159, 8.526557159, 8.526557159, 8.526557159, 8.526557159,
      8.526557159, 8.526557159, 8.49985436, 8.4982505, 8.49667116, 8.495115965,
      8.493584547, 8.492076543, 8.490584341, 8.488748771, 8.4869132, 8.48507763,
      8.483242061, 8.481406491, 8.479570922, 8.477735353, 8.475899785,
      8.474064217, 8.472228649, 8.470393081, 8.4608772, 8.458952842, 8.347644861,
      8.33923786, 8.330958148, 8.31100892, 8.301927001, 8.293304885, 8.27268401,
      8.263597663, 8.254648748, 8.233720723, 8.233054181, 8.215581553,
      8.206452491, 8.187257799, 8.175770493, 8.166103738, 8.151301902,
      8.134797845, 8.124826817, 8.102934656, 8.092521908, 8.082266421,
      8.060110778, 8.049422025, 8.038894622, 8.016488338, 8.005535718,
      7.994748353, 7.972103663, 7.960898744, 8.093957993, 8.092036853,
      8.090145071, 8.088282199, 8.086447796, 8.084641429, 8.082862671,
      8.081111099, 8.079386301, 8.077687867, 8.243787184, 8.254134237,
      8.264481307, 8.274828393, 8.285175494, 8.295094773, 8.292951411,
      8.302354215, 8.31175703, 8.321159854, 8.214445882, 8.21538284, 8.216319799,
      8.217256757, 8.218193715, 8.219130673, 8.220067631, 8.22100459,
      8.221941548, 8.222878506, 8.199257022, 8.198529898, 8.197813903,
      8.197108869, 8.196414627, 8.195731012, 8.195057863, 8.194395018,
      8.193742321, 8.193099615, 8.215351456, 8.216288415, 8.217225373,
      8.218162331, 8.219099289, 8.220036247, 8.220973206, 8.221910164,
      8.222847122, 8.22378408, 8.431215765, 8.447244617, 8.463273511,
      8.479302443, 8.482400337, 8.497480532, 8.512560753, 8.527640997,
      8.542536566, 8.557328668, 8.941475786, 8.963567464, 8.990761961,
      9.016990929, 9.042255401, 9.066556428, 9.085740822, 9.10027376,
      9.119480586, 9.138994518, 9.065829611, 9.078100953, 9.100134869,
      9.110199467, 9.119318381, 9.140641464, 9.148807237, 9.156029578,
      9.170164311, 9.181381111, 9.173524147, 9.190178185, 9.193630744,
      9.198286386, 9.211087003, 9.21265906, 9.226520642, 9.227151573,
      9.226848058, 9.238851774, 9.211119434, 9.20709297, 9.215389953,
      9.223686928, 9.218724945, 9.22609708, 9.220204381, 9.226652418, 9.23310045,
      9.22627594, 9.165426914, 9.166345859, 9.167264803, 9.168183747,
      9.169102691, 9.170021636, 9.157663638, 9.157663638, 9.157663638,
      9.157663638, 9.123824955, 9.121846589, 9.119898458, 9.117980099,
      9.11609106, 9.114230894, 9.112399159, 9.110595423, 9.108819258,
      9.107070245, 9.200661203, 9.191993817, 9.195674001, 9.186081795,
      9.18884083, 9.178325275, 9.180163897, 9.168726462, 9.169645406, 9.17056435,
      9.158206135, 9.145770283, 9.144852072, 9.143933861, 9.14301565,
      9.129663053, 9.127827365, 9.125991677, 9.124155989, 9.122320302,
      9.120484615, 9.118648929, 9.116813243, 9.114977557, 9.113141872,
      9.111306187, 9.109470503, 9.107634818, 9.105799135, 9.103963451,
      9.102127768, 9.100292086, 9.098456403, 9.096620721, 9.09478504,
      9.092949359, 9.091113678, 9.089277998, 9.087442317, 9.085606638,
      9.083770958, 9.08193528, 9.080099601, 9.078263923, 9.076428245,
      9.074592568, 9.07275689, 9.070921214, 9.069085537, 9.067249861,
      9.065414186, 9.063578511, 9.061742836, 9.059907161, 9.058071487,
      9.056235813, 9.05440014, 9.052564467, 9.050728794, 9.048893122, 9.04705745,
      9.045221778, 9.043386107, 9.041550436, 9.039714766, 9.037879095,
      9.036043426, 9.034207756, 9.032372087, 9.030536419, 9.02870075,
      9.026865082, 9.025029415, 9.023193747, 9.021358081, 9.019522414,
      9.017686748, 9.015851082, 9.014015417, 9.012179752, 9.010344087,
      9.008508422, 9.006672758, 9.004837095, 9.003001432, 9.001165769,
      8.999330106, 8.997494444, 8.995658782, 8.99382312, 8.991987459,
      8.990151798, 8.988316138, 8.986480478, 8.984644818, 8.982809159, 8.9809735,
      8.979137841, 8.977302183, 8.975466525, 8.973630867, 8.97179521,
      8.969959553, 8.968123897, 8.966288241, 8.964452585, 8.962616929,
      8.960781274, 8.958945619, 8.957109965, 8.955274311, 8.953438657,
      8.951603004, 8.949767351, 8.947931698, 8.946096046, 8.944260394,
      8.942424742, 8.940589091, 8.93875344, 8.936917789, 8.935082139,
      8.933246489, 8.93141084, 8.929575191, 8.927739542, 8.925903893,
      8.924068245, 8.922232597, 8.92039695, 8.916775871, 8.915213414,
      8.913674847, 8.900399798, 8.897647462, 8.895443659, 8.893291037,
      8.891171302, 8.889083953, 8.887028497, 8.872665642, 8.865981561,
      8.854696888, 8.851336172, 8.848026715, 8.832437025, 8.828501792,
      8.824626532, 8.81050163, 8.804121158, 8.750423847, 8.73086252, 8.723005274,
      8.702959056, 8.682312837, 8.661076562, 8.63926, 8.616872751, 8.593924245,
      8.570423751, 8.583192619, 8.563342162, 8.550199374, 8.5273818, 8.504010224,
      8.492335663, 8.46860143, 8.444328364, 8.430550099, 8.407069931,
      8.418565992, 8.407276443, 8.383960558, 8.372289442, 8.348610219,
      8.332375182, 8.31228839, 8.289834395, 8.27492502, 8.258698511, 8.237074867,
      8.21520907, 8.193108722, 8.170781179, 8.148233559, 8.132369313,
      8.114910276, 8.092085867, 8.068868131, 8.045439976, 8.082177483,
      8.063642066, 8.05193485, 8.030866753, 8.021104876, 8.002996293,
      7.984793602, 7.966501132, 7.94812301, 7.929663167, 7.905112243, 7.88962463,
      7.874155661, 7.850580099, 7.831160044, 7.814227654, 7.792141072,
      7.771460674, 7.750827825, 7.73358676, 7.885086507, 7.881047207, 7.8788394,
      7.87826606, 7.879057407, 7.880902245, 7.880795219, 7.882754649,
      7.886091465, 7.890097623, 8.191599461, 8.208020977, 8.220713657,
      8.240543434, 8.260373373, 8.280203469, 8.300033715, 8.315526872,
      8.330967542, 8.345731082, 8.737687714, 8.771583023, 8.807600082,
      8.843319664, 8.8809973, 8.911588761, 8.946029824, 8.97872481, 9.010123899,
      9.037300096, 9.180727967, 9.2275844, 9.274440744, 9.321296883, 9.368152706,
      9.415008102, 9.46186296, 9.50871717, 9.55557062, 9.602423196, 9.649274781,
      9.696125254, 9.716482199, 9.734893308, 9.751363193, 9.765896469,
      9.776105284, 9.790620753, 9.800731561, 9.808850732, 9.574063884,
      9.587509493, 9.587560502, 9.600040899, 9.608672985, 9.611317375,
      9.622833278, 9.620931909, 9.631484114, 9.628611116, 9.352892994,
      9.33951523, 9.317719761, 9.2953146, 9.279348536, 9.261701608, 9.239851429,
      9.225600854, 9.198803769, 9.178330738, 9.178428435, 9.154401309,
      9.138476012, 9.117680645, 9.095151386, 9.07901465, 9.054447075,
      9.033967716, 9.015956509, 8.990423014, 8.971369251, 8.950685554, 8.9243521,
      8.90583652, 8.883109745, 8.856637748, 8.837510315, 8.81333856, 8.786490213,
      8.76646148, 8.790944764, 8.777654694, 8.752198689, 8.733103201,
      8.712514241, 8.698227741, 8.672539614, 8.650646539, 8.631557345,
      8.614143113, 8.577998045, 8.56250804, 8.534959712, 8.512706649,
      8.491053776, 8.462806251, 8.446350158, 8.417892742, 8.398110555,
      8.372369219, 8.429235107, 8.416478592, 8.398434751, 8.379789108,
      8.367278325, 8.351699406, 8.330444499, 8.317774735, 8.293128614,
      8.280118949, 8.259956743, 8.242099377, 8.228956237, 8.210776085,
      8.190822636, 8.177549783, 8.152366823, 8.138771609, 8.115300878,
      8.099217432, 8.193975195, 8.186809116, 8.179751757, 8.172801483,
      8.165956685, 8.159215774, 8.140511179, 8.133229069, 8.126057413,
      8.118994552, 8.063836735, 8.054014624, 8.044340957, 8.034813516,
      8.01340056, 8.003417145, 7.993584561, 7.983900557, 7.967564769,
      7.952543394, 7.988624551, 7.97157052, 7.965702789, 7.956784918,
      7.949508426, 7.942342279, 7.931992313, 7.926588488, 7.909382122,
      7.903737912, 7.814558955, 7.805331592, 7.7867268, 7.774631177, 7.754372978,
      7.738535958, 7.723908692, 7.702738437, 7.693198223, 7.672045782,
      7.791206737, 7.778266964, 7.774743326, 7.771326754, 7.768014023,
      7.764802004, 7.754011067, 7.751704811, 7.749503333, 7.747401929,
      7.642227111, 7.633337821, 7.61634776, 7.611062794, 7.594168402,
      7.577123548, 7.570982605, 7.556418201, 7.54181716, 7.532479648,
      7.609990434, 7.605905242, 7.604721061, 7.603738973, 7.603589578,
      7.593498663, 7.5942593, 7.594948362, 7.595572717, 7.589376235, 7.590700683,
      7.586493834, 7.588358928, 7.585847227, 7.588032801, 7.586834566,
      7.586501059, 7.586890699, 7.586069573, 7.588027328, 7.619895282,
      7.620832227, 7.621769173, 7.622706119, 7.623643064, 7.62458001,
      7.625516956, 7.626453902, 7.627390847, 7.628327793, 7.794029977,
      7.807212286, 7.820394674, 7.835002596, 7.846865461, 7.860048082,
      7.879164365, 7.911801957, 7.902051385, 7.915079859, 8.386379635,
      8.434113518, 8.481850338, 8.529589897, 8.577331998, 8.625076439,
      8.672823019, 8.720571534, 8.768321778, 8.816073545, 8.863826625,
      8.911580809, 8.959294714, 9.006149907, 9.053005607, 9.099861677,
      9.146717988, 9.193574413, 9.240430833, 9.287287132, 9.334143196,
      9.380998913, 9.427854172, 9.474708864, 9.521562877, 9.568416098,
      9.615268414, 9.662119706, 9.708969853, 9.755818729, 9.802666201,
      9.836224228, 9.84219613, 9.83322989, 9.833927746, 9.831627358, 9.820617071,
      9.804264236, 9.792055229, 9.776891921, 9.637971517, 9.635096062,
      9.631254086, 9.626446684, 9.620674948, 9.613939965, 9.606242822,
      9.597584603, 9.587966389, 9.577389262, 9.539804741, 9.538849764,
      9.537894788, 9.536939812, 9.535984836, 9.535029861, 9.534074885,
      9.520519802, 9.51861054, 9.516701279, 9.514792018, 9.512882757,
      9.510973497, 9.509064238, 9.507154979, 9.50524572, 9.503336462,
      9.501427204, 9.499517947, 9.49760869, 9.495699434, 9.493790178,
      9.491880923, 9.489971668, 9.488062414, 9.48615316, 9.484243907,
      9.482334654, 9.480425401, 9.478516149, 9.476606898, 9.474697647,
      9.472788396, 9.470879146, 9.468969896, 9.467060647, 9.465151398,
      9.46324215, 9.461332902, 9.459423655, 9.457514408, 9.455605161,
      9.453695915, 9.45178667, 9.449877424, 9.44796818, 9.446058936, 9.444149692,
      9.442240448, 9.440331206, 9.438421963, 9.436512721, 9.43460348,
      9.432694239, 9.430784998, 9.428875758, 9.426966518, 9.425057279,
      9.42314804, 9.421238802, 9.419329564, 9.417420327, 9.41551109, 9.413601853,
      9.411692617, 9.409783381, 9.407874146, 9.405964911, 9.404055677,
      9.402146443, 9.40023721, 9.398327977, 9.396418744, 9.394509512, 9.39260028,
      9.390691049, 9.388781818, 9.386872588, 9.384963358, 9.383054128,
      9.381144899, 9.37923567, 9.377326442, 9.375417215, 9.373507987, 9.37159876,
      9.369689534, 9.367780308, 9.365871082, 9.363961857, 9.362052632,
      9.360143408, 9.358234184, 9.356324961, 9.354415738, 9.352506515,
      9.350597293, 9.348688071, 9.34677885, 9.344869629, 9.330425402,
      9.327562637, 9.324699875, 9.321837113, 9.318974353, 9.316111595,
      9.300720232, 9.296904649, 9.29308907, 9.289273494, 9.285457922,
      9.281642353, 9.277826787, 9.274011225, 9.270195665, 9.26638011,
      9.262564557, 9.258749008, 9.254933462, 9.251117919, 9.184759464,
      9.177582745, 9.170822428, 9.159394854, 9.150836569, 9.138325549, 9.1315605,
      9.113159328, 9.105191279, 9.094947042, 9.0359713, 9.018380283, 8.995538691,
      8.972142495, 8.948200827, 8.929104448, 8.911451746, 8.885512002,
      8.861234908, 8.835385633, 8.809670647, 8.791447848, 8.767794502,
      8.740678152, 8.713077549, 8.685000629, 8.656455193, 8.627448912,
      8.597989328, 8.56846521, 8.582674181, 8.558826589, 8.530431118,
      8.509152645, 8.484981059, 8.455924463, 8.426415819, 8.398491665,
      8.378431149, 8.348319641, 8.305553136, 8.273868856, 8.24177547,
      8.209279656, 8.176387982, 8.143106903, 8.109442769, 8.075401825,
      8.04099021, 8.006213962, 7.971079019, 7.935315512, 7.898881962, 7.86209799,
      7.824969148, 7.787500874, 7.749698493, 7.71156722, 7.673112157,
      7.634338298, 7.595250527, 7.548605448, 7.503764711, 7.463048121,
      7.422047248, 7.380766236, 7.339209124, 7.297379856, 7.255282274,
      7.204533668, 7.169773184, 7.126900658, 7.083774112, 7.039108944,
      6.991439993, 6.943411236, 6.896110689, 6.851054733, 6.805774616,
      6.760214097, 6.827414154, 6.795053249, 6.753240298, 6.718458574,
      6.685740102, 6.641528371, 6.608399483, 6.571758934, 6.530693022,
      6.495637733, 6.578820442, 6.551187583, 6.527046967, 6.504368287,
      6.470341665, 6.447486591, 6.424748825, 6.390695653, 6.366657446,
      6.337383924, 6.410633842, 6.39463687, 6.37165055, 6.359109111, 6.346469729,
      6.325930584, 6.305422804, 6.293493496, 6.277648818, 6.265198365,
      6.301354168, 6.288787221, 6.29224356, 6.291049164, 6.296608769,
      6.299202677, 6.316601284, 6.333937403, 6.34726408, 6.354265774,
      6.374836216, 6.374836216, 6.374836216, 6.374836216, 6.374836216,
      6.374836216, 6.374836216, 6.374836216, 6.374836216, 6.374836216,
      6.987668681, 7.036113011, 7.084319695, 7.131853381, 7.179400083,
      7.226959306, 7.274530563, 7.322113371, 7.369707256, 7.417311752,
      7.464926399, 7.51255074, 7.560184327, 7.607826713, 7.655477459,
      7.703136127, 7.750802283, 7.798475494, 7.846155331, 7.893841365,
      7.94153317, 7.989230318, 8.036932382, 8.084638975, 8.132349878, 8.18006491,
      8.227783889, 8.275506629, 8.323232945, 8.370962645, 8.418695538,
      8.466431431, 8.514170127, 8.561911428, 8.609655136, 8.657401047,
      8.705148959, 8.752898668, 8.800649965, 8.848402644, 8.896156494,
      8.943911306, 8.991016005, 9.037871557, 9.084727522, 9.131583768,
      9.17844017, 9.225296605, 9.272152955, 9.319009107, 9.365864948,
      9.412720368, 9.459575255, 9.506429499, 9.553282988, 9.600135609,
      9.646987245, 9.693837776, 9.740687077, 9.787535016, 9.675906148,
      9.69720064, 9.717289812, 9.731250101, 9.746248899, 9.764805624, 9.76899396,
      9.784592306, 9.798413634, 9.806239414, 9.784684066, 9.793420733,
      9.801177666, 9.807956003, 9.810918032, 9.811664152, 9.811420594,
      9.823672474, 9.822259927, 9.81989489, 9.71807704, 9.722862548, 9.727648052,
      9.718944377, 9.722771351, 9.726598324, 9.728975556, 9.731894677,
      9.724320389, 9.727189547, 9.730058705, 9.732927861, 9.735797017,
      9.725164656, 9.727076716, 9.728988776, 9.730900835, 9.719308542,
      9.720264217, 9.721219892, 9.722175567, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.709625472,
      9.709625472, 9.709625472, 9.709625472, 9.709625472, 9.696967147,
      9.68335417, 9.661274556, 9.640045891, 9.622623197, 9.604250883,
      9.581606902, 9.551763994, 9.516956499, 9.48026135, 9.454317895,
      9.414804105, 9.38603753, 9.346008459, 9.312307164, 9.277361911,
      9.235420835, 9.198389199, 9.300519491, 9.275273365, 9.25861736,
      9.230858683, 9.213144114, 9.185910735, 9.156284513, 9.134548561,
      9.107426228, 9.079770774, 9.081357571, 9.050825861, 9.031863173,
      9.000654455, 8.979640136, 8.949793811, 8.923660457, 8.896836943,
      8.866042618, 8.841819588, 8.868913616, 8.838973284, 8.814495953,
      8.787930113, 8.767901345, 8.742565461, 8.715083042, 8.694154004,
      8.660870839, 8.638888538, 8.646261332, 8.622173799, 8.602148885,
      8.574261955, 8.549216171, 8.528291263, 8.500156892, 8.470865034,
      8.441124902, 8.41674655, 8.441908563, 8.423813858, 8.399247754,
      8.372948897, 8.352929422, 8.327508513, 8.300292136, 8.282465702,
      8.258685275, 8.23721605, 8.156005118, 8.127399633, 8.094874496,
      8.066662891, 8.040361015, 8.00801374, 7.974460844, 7.940160562,
      7.906905805, 7.878261617, 7.956046872, 7.927533018, 7.910573538,
      7.883461246, 7.862135985, 7.835653557, 7.818240765, 7.789102686,
      7.763732124, 7.741658585, 7.759692203, 7.735996322, 7.716739541,
      7.697039239, 7.673529139, 7.657626323, 7.630057028, 7.613889602,
      7.586421151, 7.569674255, 7.617106475, 7.600869703, 7.58881045,
      7.572480052, 7.553109417, 7.540848501, 7.527363831, 7.5049649, 7.49250806,
      7.480238585, 7.385529382, 7.356649497, 7.339081219, 7.309999374,
      7.292213431, 7.262935885, 7.244938302, 7.215471089, 7.197267694,
      7.167616636, 7.395105039, 7.392654735, 7.390241851, 7.387865819,
      7.385526078, 7.383222075, 7.380953266, 7.378719115, 7.376519095,
      7.374352685, 7.325429928, 7.32031441, 7.315276722, 7.310315691,
      7.301086082, 7.297202543, 7.283719993, 7.27830895, 7.273561529,
      7.267770109, 7.242298412, 7.237416408, 7.23268237, 7.220647516,
      7.214336548, 7.206870143, 7.202135471, 7.185895077, 7.180869694,
      7.171297135, 7.223004614, 7.220382068, 7.217799569, 7.215256507,
      7.209760874, 7.20772699, 7.205755161, 7.203843503, 7.201990186,
      7.200193438, 7.198942295, 7.187166494, 7.186352433, 7.185587704,
      7.184869351, 7.184194591, 7.183560804, 7.182965525, 7.182406433,
      7.175481431, 7.204901144, 7.204901144, 7.204901144, 7.204901144,
      7.204901144, 7.204901144, 7.204901144, 7.204901144, 7.204901144,
      7.204901144, 7.175355832, 7.175239468, 7.175131689, 7.175031885,
      7.174939488, 7.170888627, 7.171158435, 7.171403187, 7.17162523,
      7.169131167, 7.179258758, 7.179008321, 7.178769384, 7.17854142,
      7.176330671, 7.176176204, 7.176031186, 7.175895039, 7.175767221,
      7.175647224, 7.1768982, 7.178057113, 7.177926907, 7.17780069, 7.17767834,
      7.177559739, 7.177444771, 7.177333326, 7.177225295, 7.177120574,
      7.17013778, 7.169796635, 7.170411432, 7.170324363, 7.170406418, 7.17020735,
      7.170332115, 7.170695411, 7.17084581, 7.171257619, 7.799638711,
      7.847318704, 7.895004885, 7.942696825, 7.990394098, 8.038096276,
      8.085802977, 8.133513982, 8.181229113, 8.228948186, 8.213250364,
      8.243422984, 8.285329706, 8.40363061, 8.445353761, 8.485885115,
      8.532652901, 8.570049509, 8.612674918, 8.655816699, 8.692003645,
      8.736117304, 8.776042943, 8.812516004, 8.856381765, 8.893713952,
      8.929996666, 8.972083273, 9.006625893, 9.042713488, 9.161949399,
      9.208805836, 9.25566223, 9.302518464, 9.349374428, 9.396230008,
      9.443085095, 9.489939578, 9.536793346, 9.583646286, 9.630498282,
      9.677349216, 9.724198964, 9.771047397, 9.817894383, 9.864739779,
      9.911970677, 9.960649594, 9.98990275, 9.998334108, 9.430962655,
      9.430962655, 9.430962655, 9.430962655, 9.430962655, 9.430962655,
      9.430962655, 9.430962655, 9.430962655, 9.430962655, 9.330496379,
      9.32287633, 9.31525631, 9.307636317, 9.300016352, 9.292396415, 9.284776506,
      9.277156624, 9.269536769, 9.261081718, 9.19229759, 9.179279049,
      9.166920201, 9.154561467, 9.142202846, 9.129844338, 9.108125397,
      9.097691842, 9.079515611, 9.066726407, 9.041473619, 9.027776641,
      9.00857725, 8.997424804, 8.973999176, 8.959075923, 8.94447257, 8.929869409,
      8.915266439, 8.90066366, 8.836435744, 8.815791762, 8.799811561,
      8.774414665, 8.750462599, 8.731337492, 8.712212793, 8.689399524,
      8.661690217, 8.64134745, 8.728594202, 8.718956711, 8.697147011,
      8.687079075, 8.670659286, 8.657874051, 8.64508893, 8.632303924,
      8.619519032, 8.606734253, 8.483472233, 8.462548904, 8.435747951,
      8.408019098, 8.38619695, 8.364375358, 8.342352397, 8.312799754,
      8.286107954, 8.263389275, 8.441611003, 8.435414387, 8.42931189,
      8.423302093, 8.417326093, 8.399386271, 8.392920698, 8.386553287,
      8.380282561, 8.366102102, 8.333571193, 8.323515022, 8.313458903,
      8.303402834, 8.293346816, 8.291044593, 8.283494978, 8.276059798,
      8.267423799, 8.249337098, 8.241511304, 8.233804082, 8.226213652,
      8.207795903, 8.198478045, 8.190317244, 8.18228009, 8.16750032, 8.157246841,
      8.146993406, 8.197984618, 8.193544297, 8.189171594, 8.184865485,
      8.180624962, 8.176449032, 8.172336715, 8.160079212, 8.154474332,
      8.148869458, 8.215028156, 8.214995585, 8.214963513, 8.214931932,
      8.214900835, 8.214870214, 8.214840063, 8.214810373, 8.214781139,
      8.214752352, 8.166534394, 8.163207023, 8.159467189, 8.145459043,
      8.141818987, 8.138234422, 8.134704507, 8.131228412, 8.127805321,
      8.12443443, 8.101332792, 8.095727964, 8.09012314, 8.083560371, 8.079001032,
      8.074511106, 8.070089544, 8.06573531, 8.056979092, 8.051374292,
      8.117799118, 8.117799118, 8.117799118, 8.117799118, 8.117799118,
      8.117799118, 8.117799118, 8.117799118, 8.117799118, 8.117799118,
      8.045769496, 8.040164702, 8.034559911, 8.028955123, 8.02243486,
      8.017875573, 8.013385696, 8.00896418, 8.004609991, 8.000322109,
      7.990572168, 7.984967395, 7.975113967, 7.970344598, 7.965647815,
      7.961022521, 7.956467635, 7.951982092, 7.947564843, 7.943214854,
      7.934343578, 7.922470802, 7.917572381, 7.912748496, 7.907998019,
      7.903319841, 7.89871287, 7.894176029, 7.889708256, 7.885308508,
      7.809390205, 7.80064284, 7.788180854, 7.771384698, 7.762287543,
      7.753327956, 7.744503881, 7.723916082, 7.714612304, 7.705449169,
      7.75756149, 7.750791724, 7.745715306, 7.740716109, 7.735792969,
      7.726820099, 7.723002484, 7.719300788, 7.704433046, 7.699830646,
      7.717666052, 7.704998338, 7.701843783, 7.698785173, 7.695819611,
      7.692944287, 7.690156475, 7.67561288, 7.672422514, 7.669329174,
      7.583491506, 7.566474423, 7.55763001, 7.544989269, 7.531716321,
      7.523463329, 7.508011459, 7.501973704, 7.485453137, 7.476634287,
      7.610443047, 7.610443047, 7.610443047, 7.610443047, 7.610443047,
      7.610443047, 7.610443047, 7.610443047, 7.610443047, 7.610443047,
      7.463959946, 7.459663301, 7.448090005, 7.435963078, 7.423834155,
      7.411703353, 7.399134184, 7.401549958, 7.401113212, 7.406835341,
      7.471266208, 7.468082289, 7.469475235, 7.467570571, 7.469207174,
      7.468294483, 7.468034147, 7.468319676, 7.469027789, 7.468962007,
      7.479597273, 7.479584032, 7.4795718, 7.479560498, 7.479550058, 7.479540414,
      7.479531505, 7.479523275, 7.479515674, 7.479508653, 8.112505507,
      8.160218844, 8.207936203, 8.255657402, 8.303382253, 8.351110569,
      8.398842157, 8.446576826, 8.49431438, 8.542054622, 8.589797353,
      8.637542373, 8.685289478, 8.733038464, 8.780789126, 8.828541255,
      8.876294644, 8.924049082, 8.971528057, 9.018383396, 9.065239206,
      9.112095351, 9.158951703, 9.205808139, 9.252664539, 9.299520787,
      9.346376771, 9.393232379, 9.440087501, 9.486942026, 9.533795843,
      9.580648839, 9.627500899, 9.674351904, 9.721201732, 9.768050254,
      9.814897336, 9.861742839, 9.908856318, 9.957535361, 9.845822341,
      9.842510613, 9.836214341, 9.826943698, 9.814708803, 9.799519714,
      9.78138643, 9.760318888, 9.736326969, 9.709420501, 9.612337309,
      9.615206497, 9.604619143, 9.606531217, 9.594985316, 9.582482661,
      9.582482661, 9.574911929, 9.574454657, 9.56873173, 9.567776752,
      9.566821774, 9.565866797, 9.564911819, 9.563956841, 9.563001863,
      9.562046886, 9.561091908, 9.560136931, 9.559181953, 9.545617828,
      9.54370856, 9.541799292, 9.535837183, 9.525067579, 9.52220471, 9.519341844,
      9.514613771, 9.500872774, 9.497057003, 9.518439948, 9.516530687,
      9.514621426, 9.512712165, 9.510802905, 9.496297741, 9.493434889,
      9.490572039, 9.48770919, 9.484846343, 9.507164932, 9.506209958,
      9.505254984, 9.50430001, 9.503345036, 9.502390062, 9.501435089,
      9.500480115, 9.499525141, 9.498570168, 9.590789343, 9.583100921,
      9.587886523, 9.579235213, 9.583062251, 9.5734495, 9.576318697, 9.565745949,
      9.554215363, 9.555171043, 9.54268334, 9.54268334, 9.54268334, 9.54268334,
      9.530564961, 9.529165784, 9.528210808, 9.527255833, 9.526300858,
      9.525345882, 9.524390907, 9.523435932, 9.522480957, 9.521525982,
      9.520571007, 9.519616032, 9.518661057, 9.517706082, 9.516751107,
      9.515796133, 9.514841158, 9.513886183, 9.512931209, 9.511976235,
      9.51102126, 9.510066286, 9.509111312, 9.508156337, 9.507201363,
      9.506246389, 9.505291415, 9.504336441, 9.503381467, 9.502426493,
      9.501471519, 9.500516546, 9.499561572, 9.498606598, 9.497651625,
      9.496696651, 9.495741678, 9.494786704, 9.493831731, 9.492876758,
      9.491921785, 9.490966811, 9.490011838, 9.489056865, 9.488101892,
      9.487146919, 9.486191946, 9.485236974, 9.484282001, 9.483327028,
      9.482372055, 9.481417083, 9.48046211, 9.479507138, 9.478552165,
      9.477597193, 9.476642221, 9.475687249, 9.474732276, 9.473777304,
      9.472822332, 9.47186736, 9.470912388, 9.469957416, 9.469002444,
      9.468047473, 9.467092501, 9.466137529, 9.465182558, 9.464227586,
      9.463272615, 9.462317643, 9.461362672, 9.4604077, 9.459452729, 9.458497758,
      9.457542787, 9.456587816, 9.455632845, 9.454677874, 9.453722903,
      9.452767932, 9.451812961, 9.45085799, 9.44990302, 9.448948049, 9.447993078,
      9.447038108, 9.446083137, 9.445128167, 9.444173197, 9.443218226,
      9.442263256, 9.441308286, 9.440353316, 9.439398346, 9.438443376,
      9.437488406, 9.436533436, 9.435578466, 9.434623496, 9.433668526,
      9.432713557, 9.431758587, 9.430803617, 9.429848648, 9.428893678,
      9.427938709, 9.42698374, 9.42602877, 9.425073801, 9.424118832, 9.423163863,
      9.422208894, 9.421253925, 9.420298956, 9.419343987, 9.418389018,
      9.417434049, 9.41647908, 9.415524112, 9.414569143, 9.413614174,
      9.412659206, 9.411704237, 9.410749269, 9.409794301, 9.408839332,
      9.407884364, 9.406929396, 9.405974428, 9.40501946, 9.404064492,
      9.403109524, 9.402154556, 9.401199588, 9.40024462, 9.399289652,
      9.398334684, 9.397379717, 9.396424749, 9.395469782, 9.394514814,
      9.393559847, 9.392604879, 9.391649912, 9.390694945, 9.389739978,
      9.38878501, 9.387830043, 9.386875076, 9.385920109, 9.384965142,
      9.384010175, 9.383055209, 9.382100242, 9.381145275, 9.380190308,
      9.379235342, 9.378280375, 9.377325409, 9.376370442, 9.375415476,
      9.374460509, 9.373505543, 9.372550577, 9.371595611, 9.370640645,
      9.369685678, 9.368730712, 9.367775746, 9.366820781, 9.365865815,
      9.364910849, 9.363955883, 9.363000917, 9.362045952, 9.361090986,
      9.360136021, 9.359181055, 9.35822609, 9.357271124, 9.356316159,
      9.355361194, 9.354406228, 9.353451263, 9.352496298, 9.351541333,
      9.350586368, 9.349631403, 9.348676438, 9.347721473, 9.346766508,
      9.345811544, 9.344856579, 9.343901614, 9.34294665, 9.341991685,
      9.341036721, 9.340081756, 9.339126792, 9.338171828, 9.337216863,
      9.336261899, 9.335306935, 9.334351971, 9.333397007, 9.332442043,
      9.331487079, 9.330532115, 9.329577151, 9.328622187, 9.327667223,
      9.32671226, 9.325757296, 9.324802332, 9.323847369, 9.322892405,
      9.321937442, 9.320982479, 9.320027515, 9.319072552, 9.318117589,
      9.317162626, 9.316207662, 9.315252699, 9.314297736, 9.313342773,
      9.31238781, 9.311432848, 9.310477885, 9.309522922, 9.308567959,
      9.307612997, 9.306658034, 9.305703071, 9.304748109, 9.303793146,
      9.302838184, 9.301883222, 9.300928259, 9.299973297, 9.299018335,
      9.298063373, 9.297108411, 9.296153449, 9.295198487, 9.294243525,
      9.293288563, 9.292333601, 9.291378639, 9.290423677, 9.289468716,
      9.288513754, 9.287558793, 9.286603831, 9.28564887, 9.284693908,
      9.283738947, 9.282861668, 9.282103097, 9.281356138, 9.280620615,
      9.279896352, 9.279183178, 9.278480922, 9.277789418, 9.2771085, 9.276438008,
      9.275777782, 9.275127664, 9.2744875, 9.273857138, 9.273236427, 9.272625221,
      9.272023373, 9.27143074, 9.270847182, 9.27027256, 9.269706736, 9.269149577,
      9.268600949, 9.268060722, 9.267528768, 9.267004959, 9.266489172,
      9.265981284, 9.265481172, 9.26498872, 9.264503809, 9.264026324,
      9.263556151, 9.263093178, 9.262637296, 9.262188395, 9.261746369,
      9.255827909, 9.25487295, 9.25391799, 9.25296303, 9.25200807, 9.251053111,
      9.244233718, 9.236200043, 9.234326817, 9.232491106, 9.205706544,
      9.198376201, 9.185628811, 9.168575348, 9.163076916, 9.145520846,
      9.138730903, 9.122932638, 9.11275899, 9.099058302, 9.07273685, 9.060746525,
      9.041785443, 9.020492576, 9.00840385, 8.985002498, 8.968929219, 8.94851378,
      8.924320214, 8.909688264, 8.9399057, 8.922732712, 8.911763208, 8.900793782,
      8.877436728, 8.8655582, 8.85367977, 8.829428287, 8.816641587, 8.803855009,
      8.784991552, 8.765481128, 8.75178727, 8.728097346, 8.711325869,
      8.696725628, 8.681171388, 8.655138608, 8.639632888, 8.620312095,
      8.706713791, 8.698477613, 8.690241465, 8.682005347, 8.673769259,
      8.661169988, 8.654369852, 8.636269633, 8.628133494, 8.618050626,
      8.645686067, 8.639274975, 8.632863898, 8.626452835, 8.620041786,
      8.61363075, 8.607219728, 8.600808721, 8.594397727, 8.587986746, 8.63614071,
      8.634286295, 8.63246022, 8.630662054, 8.62889137, 8.627147751, 8.625430783,
      8.62374006, 8.622075182, 8.620435754, 8.547630847, 8.540307222,
      8.533824063, 8.528047733, 8.518573664, 8.51125012, 8.503926597,
      8.496603093, 8.48927961, 8.481956147, 8.585219646, 8.586138594,
      8.587057543, 8.587976491, 8.588895439, 8.589814388, 8.590733336,
      8.591652284, 8.592571233, 8.593490181, 8.520378399, 8.515795343,
      8.511212292, 8.506629247, 8.502046205, 8.497463169, 8.492880138,
      8.488297112, 8.48371409, 8.479131074, 8.413660944, 8.404514699,
      8.395368494, 8.386222327, 8.377076199, 8.36793011, 8.358784059,
      8.346369922, 8.338890156, 8.330998021, 8.309714556, 8.299658507,
      8.283946099, 8.275596158, 8.267372642, 8.24715844, 8.238458235,
      8.224853368, 8.213888359, 8.202923416, 8.191923403, 8.180742453,
      8.169561566, 8.15838074, 8.147199973, 8.134655083, 8.124733355, 8.10458175,
      8.095067458, 8.085697031, 8.184925925, 8.182548863, 8.180208103,
      8.177903093, 8.175355506, 8.172549408, 8.16974331, 8.166937213,
      8.164131117, 8.161325021, 8.08628814, 8.07789189, 8.069495655, 8.061099436,
      8.05270323, 8.044307037, 8.035910858, 8.02751469, 8.019118533, 8.010722387,
      8.070471055, 8.067975032, 8.065517121, 8.063096741, 8.060713322,
      8.058366301, 8.056055124, 8.053559796, 8.050753717, 8.047947639,
      7.925252647, 7.913146259, 7.901039888, 7.885985814, 7.87608058,
      7.864451317, 7.844642794, 7.834438805, 7.81518156, 7.802149706,
      7.839239197, 7.83189136, 7.82465493, 7.809856871, 7.800531966, 7.791207052,
      7.783110452, 7.775686803, 7.763565995, 7.754241032, 7.73302224,
      7.722769244, 7.713082808, 7.702307617, 7.692054547, 7.68180145,
      7.671548323, 7.661295166, 7.651041976, 7.640788752, 7.670767023,
      7.66504846, 7.659416806, 7.645113887, 7.637647149, 7.630180396,
      7.623983723, 7.618047128, 7.612200728, 7.606443165, 7.593917579,
      7.586450723, 7.578983848, 7.571516953, 7.56488162, 7.558914145,
      7.553037332, 7.542184913, 7.534717915, 7.527250896, 7.519783854,
      7.512316788, 7.505348188, 7.499356358, 7.493455558, 7.482906489,
      7.475439303, 7.467972093, 7.460504856, 7.451778208, 7.410409756,
      7.402148483, 7.394012296, 7.385999325, 7.370185855, 7.359931082,
      7.349817675, 7.341547863, 7.333403271, 7.319413414, 7.387365768,
      7.384100608, 7.380885257, 7.377718958, 7.374600966, 7.371530548,
      7.367799566, 7.353783951, 7.350098697, 7.346469628, 7.261035667,
      7.252258186, 7.235467752, 7.222893836, 7.213768057, 7.20478031,
      7.190916717, 7.175224627, 7.165894712, 7.156705892, 7.112710711,
      7.101553376, 7.078927019, 7.067356541, 7.05596048, 7.033116076,
      7.021313836, 7.009689472, 6.998240362, 6.975366639, 6.998286871,
      6.988857761, 6.967989059, 6.958093187, 6.948346933, 6.938748073,
      6.917731071, 6.907670314, 6.897761655, 6.888002831, 6.872224744,
      6.856982831, 6.846915791, 6.837000968, 6.818818732, 6.811029499,
      6.795692211, 6.785627126, 6.775714253, 6.757658896, 6.709804658,
      6.697342483, 6.684921393, 6.664162245, 6.649009848, 6.63355099,
      6.612603519, 6.602659938, 6.581645986, 6.571794585, 6.585114582,
      6.576997765, 6.557697474, 6.549485627, 6.530102911, 6.521801396,
      6.50572274, 6.494127948, 6.482874383, 6.465842029, 6.551164488,
      6.548889455, 6.538993176, 6.537639494, 6.530776599, 6.528502147,
      6.522425462, 6.521149407, 6.517861314, 6.517548499, 6.564942503,
      6.564942503, 6.564942503, 6.564942503, 6.564942503, 6.564942503,
      6.564942503, 6.564942503, 6.564942503, 6.564942503, 6.47177601,
      6.461867712, 6.455345596, 6.459145203, 6.456266503, 6.450634122,
      6.453529544, 6.454955843, 6.459423637, 6.463754562, 7.117638723,
      7.165181585, 7.212737116, 7.260304825, 7.307884229, 7.355474851,
      7.403076223, 7.450687883, 7.498309372, 7.545940241, 6.971707219,
      6.971707219, 6.971707219, 6.975518621, 6.975747263, 6.9759724, 6.984992884,
      6.985929799, 6.986866713, 6.987803628, 6.757305358, 6.739640837,
      6.721976012, 6.707924439, 6.695929885, 6.669998918, 6.652332963,
      6.654950473, 6.654196662, 6.638724322, 6.81916273, 6.820099631,
      6.821036533, 6.821973435, 6.822910336, 6.823847238, 6.82478414,
      6.825721042, 6.826657944, 6.827594846, 7.024841402, 7.037514363,
      7.04999082, 7.062273834, 7.076325117, 7.091392278, 7.106459742,
      7.121527504, 7.13659556, 7.151663904, 7.589559321, 7.637206914,
      7.684862596, 7.732525932, 7.780196489, 7.827873836, 7.875557545,
      7.923247188, 7.970942337, 8.018642567, 8.062686957, 8.10115619, 8.13774869,
      8.174366414, 8.213806447, 8.246067336, 8.289779355, 8.32090055,
      8.362655326, 8.393819058, 7.576253485, 7.553094375, 7.518057311,
      7.493981823, 7.475232977, 7.452214117, 7.422635356, 7.422803979,
      7.407566505, 7.34715109, 7.81429659, 7.827479021, 7.840661529, 7.853844114,
      7.867026774, 7.880209509, 7.893392316, 7.906575195, 7.919758146,
      7.932941165, 7.660802529, 7.663855477, 7.666574936, 7.668997902,
      7.671157154, 7.673081759, 7.663931531, 7.664747893, 7.664607473,
      7.664476435, 7.990435517, 8.011214889, 8.031994534, 8.052774446,
      8.071847691, 8.081458456, 8.101286915, 8.121115581, 8.140944447,
      8.160773507, 8.551462356, 8.599205554, 8.646951, 8.694698492, 8.742447825,
      8.790198792, 8.837951186, 8.885704798, 8.933459418, 8.980761072,
      9.027616515, 9.074472402, 9.121328598, 9.168184976, 9.215041414,
      9.261897793, 9.308753998, 9.355609916, 9.377964707, 9.408180215,
      9.452171186, 9.482385398, 9.4996273, 9.521955328, 9.540919081, 9.565971757,
      9.576817325, 9.598997027, 9.606945514, 9.626261434, 9.485066451,
      9.491214141, 9.507694023, 9.515237795, 9.520176964, 9.537490938,
      9.541447954, 9.557793666, 9.560770051, 9.562773211, 9.68422884,
      9.693004373, 9.700800061, 9.694212603, 9.699082949, 9.702977958,
      9.692474806, 9.693456374, 9.680032659, 9.678109608, 9.648333626,
      9.642553641, 9.635810422, 9.628105054, 9.619438618, 9.609812195,
      9.599226865, 9.594844272, 9.589147972, 9.590103651, 9.59105933,
      9.592015009, 9.592970688, 9.593926366, 9.594882045, 9.595837724,
      9.596793403, 9.597749081, 9.59870476, 9.599660439, 9.600616117,
      9.601571796, 9.602527474, 9.603483153, 9.604438831, 9.60539451,
      9.606350188, 9.607305867, 9.608261545, 9.609217223, 9.610172902,
      9.61112858, 9.612084258, 9.613039937, 9.613995615, 9.614951293,
      9.615906971, 9.616862649, 9.617818328, 9.618774006, 9.619729684,
      9.620685362, 9.62164104, 9.622596718, 9.623552396, 9.624508074,
      9.625463751, 9.626419429, 9.627375107, 9.628330785, 9.629286463,
      9.63024214, 9.631197818, 9.632153496, 9.633109174, 9.634064851,
      9.635020529, 9.635976206, 9.636931884, 9.637887561, 9.638843239,
      9.639798916, 9.640754594, 9.641710271, 9.642665949, 9.643621626,
      9.644577303, 9.645532981, 9.646488658, 9.647444335, 9.648400012,
      9.64935569, 9.650311367, 9.651267044, 9.652222721, 9.653178398,
      9.654134075, 9.655089752, 9.656045429, 9.657001106, 9.657956783,
      9.65891246, 9.659868137, 9.660823813, 9.66177949, 9.662735167, 9.663690844,
      9.66464652, 9.665602197, 9.666557874, 9.66751355, 9.668469227, 9.669424904,
      9.67038058, 9.671336257, 9.672291933, 9.67324761, 9.674203286, 9.675158962,
      9.676114639, 9.677070315, 9.678025991, 9.678981668, 9.679937344,
      9.68089302, 9.681848696, 9.682804372, 9.683760048, 9.684715724,
      9.685671401, 9.686627077, 9.687582753, 9.688538428, 9.689494104,
      9.69044978, 9.691405456, 9.692361132, 9.693316808, 9.694272484,
      9.695228159, 9.696183835, 9.697139511, 9.698095186, 9.699050862,
      9.700006537, 9.700962213, 9.701917889, 9.702873564, 9.70382924,
      9.704784915, 9.70574059, 9.706696266, 9.707651941, 9.708607616,
      9.709563292, 9.710518967, 9.711474642, 9.712430317, 9.713385992,
      9.714341667, 9.715297342, 9.716253018, 9.717208693, 9.718164368,
      9.719120042, 9.720075717, 9.721031392, 9.721987067, 9.722942742,
      9.723898417, 9.724854091, 9.725809766, 9.726765441, 9.727721115,
      9.72867679, 9.729632465, 9.730588139, 9.731543814, 9.732499488,
      9.733455163, 9.734410837, 9.735366512, 9.736322186, 9.73727786,
      9.738233534, 9.739189209, 9.740144883, 9.741100557, 9.742056231,
      9.743011905, 9.743967579, 9.744923254, 9.745821276, 9.746566672,
      9.747300636, 9.748023343, 9.748734967, 9.749435676, 9.750125639,
      9.750805021, 9.751473984, 9.752132689, 9.752781291, 9.753419947,
      9.75404881, 9.754668028, 9.755277752, 9.755878125, 9.756469292,
      9.757051394, 9.75762457, 9.758188958, 9.758744691, 9.759291903,
      9.759830724, 9.760361283, 9.760883707, 9.761398121, 9.761904648,
      9.762403408, 9.762894522, 9.763378105, 9.763854274, 9.764323142,
      9.764784822, 9.765239423, 9.765687055, 9.766127824, 9.766561835,
      9.766989193, 9.767409998, 9.767824352, 9.768232354, 9.768634101,
      9.769029689, 9.769419212, 9.769802764, 9.770180436, 9.770552318, 9.7709185,
      9.771279067, 9.771634108, 9.771983705, 9.772327944, 9.772666905,
      9.773000671, 9.77332932, 9.773652931, 9.773971581, 9.774285347,
      9.774594303, 9.774898524, 9.775198081, 9.775493046, 9.77578349,
      9.776069481, 9.776351089, 9.776628381, 9.776901422, 9.777170278,
      9.777435012, 9.777695689, 9.777952371, 9.778205118, 9.778453991,
      9.778699049, 9.778940351, 9.779177955, 9.779411916, 9.779642292,
      9.779869137, 9.780092505, 9.780312449, 9.780529022, 9.780742275,
      9.780952261, 9.781159027, 9.781362625, 9.781563102, 9.781760506,
      9.778492814, 9.778492814, 9.778492814, 9.778492814, 9.778492814,
      9.778492814, 9.778492814, 9.778492814, 9.778492814, 9.778492814,
      9.778492814, 9.778492814, 9.778492814, 9.778492814, 9.778492814,
      9.778492814, 9.778492814, 9.778492814, 9.778492814, 9.778492814,
      9.778492814, 9.778492814, 9.778492814, 9.778492814, 9.778492814,
      9.778492814, 9.778492814, 9.778492814, 9.778492814, 9.76581061,
      9.777537494, 9.7682947, 9.764159603, 9.750523305, 9.735933331, 9.733070332,
      9.717528663, 9.701035301, 9.690666336, 9.678403329, 9.748714849,
      9.736042926, 9.735087937, 9.721461687, 9.71955237, 9.715431167,
      9.702897862, 9.698827759, 9.684413782, 9.680597813, 9.727439992,
      9.727439992, 9.727439992, 9.727439992, 9.727439992, 9.727439992,
      9.727439992, 9.715721812, 9.71389183, 9.712936842, 9.560019098,
      9.539032093, 9.521990996, 9.496032188, 9.481433394, 9.454858195,
      9.43268762, 9.411308194, 9.38254294, 9.365457695, 9.449259004, 9.435543744,
      9.417300649, 9.406758589, 9.383765127, 9.372351062, 9.355026155,
      9.336493027, 9.324132648, 9.300705491, 9.286005816, 9.272699959, 9.2468344,
      9.232583734, 9.218333254, 9.191538966, 9.176344517, 9.148617645,
      9.132480064, 9.116342741, 9.28792233, 9.286013122, 9.284103915,
      9.279878662, 9.278211815, 9.26554412, 9.262681388, 9.259818657,
      9.256955927, 9.254093199, 9.251230472, 9.237828683, 9.23489907, 9.22858842,
      9.2247729, 9.220957383, 9.217141869, 9.213326358, 9.204341716, 9.1930479,
      9.247394612, 9.247194458, 9.23785276, 9.236934545, 9.236016329,
      9.235098113, 9.234179897, 9.233261682, 9.232343466, 9.231425251,
      9.242976491, 9.242976491, 9.242976491, 9.242976491, 9.242976491,
      9.241178076, 9.241073158, 9.240969847, 9.230115801, 9.229197586,
      9.053719282, 9.040022156, 9.026325195, 9.007429368, 8.986103911,
      8.971500197, 8.956896678, 8.942293354, 8.925198058, 8.900486996,
      8.82292325, 8.802893636, 8.782645566, 8.754393436, 8.729794337,
      8.708864921, 8.680174696, 8.654084505, 8.63225586, 8.603886599,
      8.660160771, 8.63471872, 8.615992226, 8.598677037, 8.581303355, 8.55527442,
      8.533797607, 8.515580008, 8.497362737, 8.479145793, 8.458654778,
      8.431815168, 8.411295503, 8.389307977, 8.361736132, 8.345897434,
      8.321060646, 8.301042263, 8.274094274, 8.248314832, 8.495032676,
      8.48371059, 8.48235357, 8.481017303, 8.479701473, 8.478405766, 8.477129877,
      8.472116813, 8.470281246, 8.468445678, 8.49092658, 8.49092658, 8.49092658,
      8.4836421, 8.483203504, 8.482771625, 8.482346359, 8.481927605, 8.481515264,
      8.481109237, 8.456396141, 8.454540258, 8.452712736, 8.450913143,
      8.449141055, 8.43948761, 8.436735457, 8.433983305, 8.431231155,
      8.428479005, 8.462164212, 8.462164212, 8.462164212, 8.462164212,
      8.462164212, 8.462164212, 8.462164212, 8.462164212, 8.462164212,
      8.462164212, 8.462164212, 8.462164212, 8.462164212, 8.462164212,
      8.462164212, 8.462164212, 8.462164212, 8.462164212, 8.462164212,
      8.462164212, 8.462164212, 8.462164212, 8.462164212, 8.462164212,
      8.462164212, 8.462164212, 8.462164212, 8.462164212, 8.462164212,
      8.462164212, 8.579136659, 8.587433903, 8.595731149, 8.604028395,
      8.612325642, 8.62062289, 8.628920138, 8.637217387, 8.645514636,
      8.653811885, 8.54483617, 8.54483617, 8.54483617, 8.54483617, 8.54483617,
      8.54483617, 8.54483617, 8.54483617, 8.54483617, 8.54483617, 8.727260781,
      8.740193585, 8.753126388, 8.766059189, 8.778991988, 8.791924784,
      8.804857576, 8.817790364, 8.830723146, 8.843655922, 8.804259635,
      8.813482491, 8.822705343, 8.831928193, 8.841151039, 8.850373882,
      8.859596722, 8.868819557, 8.878042389, 8.887265217, 8.765294724,
      8.765294724, 8.765294724, 8.765294724, 8.765294724, 8.765294724,
      8.765294724, 8.765294724, 8.765294724, 8.765294724, 8.948965367,
      8.961898058, 8.974830736, 8.9877634, 9.000696051, 9.013628686, 9.026561306,
      9.03949391, 9.052426497, 9.065359066, 8.893895547, 8.893895547,
      8.893895547, 8.893895547, 8.893895547, 8.893895547, 8.893895547,
      8.893895547, 8.893895547, 8.893895547, 8.893895547, 8.893895547,
      8.893895547, 8.893895547, 8.893895547, 8.893895547, 8.893895547,
      8.889936346, 8.889702058, 8.88947136, 8.89302406, 8.89302406, 8.89302406,
      8.89302406, 8.89302406, 8.89302406, 8.89302406, 8.89302406, 8.89302406,
      8.89302406, 8.819054898, 8.813557093, 8.808059297, 8.80256151, 8.797063732,
      8.791565963, 8.786068204, 8.772406967, 8.767560162, 8.76278713,
      8.819610343, 8.818617162, 8.80927284, 8.807437213, 8.805601587,
      8.803765961, 8.801930336, 8.800094711, 8.798259086, 8.796423462,
      8.794587837, 8.792752214, 8.79091659, 8.789080967, 8.787245344,
      8.785409722, 8.7835741, 8.781738478, 8.769704907, 8.767641596, 8.787037721,
      8.786119528, 8.785201334, 8.78428314, 8.783364947, 8.782446753, 8.78152856,
      8.780610366, 8.779692173, 8.778773979, 8.753284887, 8.750532611,
      8.747780337, 8.745028063, 8.742275791, 8.735096065, 8.732645742,
      8.730232836, 8.727856778, 8.715197271, 8.711529125, 8.707860982,
      8.704494839, 8.700547274, 8.696879138, 8.693211006, 8.689542876,
      8.685874748, 8.682206623, 8.678538501, 8.723900996, 8.723900996,
      8.723900996, 8.723900996, 8.723900996, 8.723900996, 8.723900996,
      8.723900996, 8.723900996, 8.723900996, 8.723900996, 8.723900996,
      8.723900996, 8.723900996, 8.723900996, 8.723900996, 8.723900996,
      8.723900996, 8.723900996, 8.723900996, 8.662612728, 8.658029517,
      8.653446311, 8.648863111, 8.644279915, 8.639696725, 8.635113539,
      8.630530359, 8.625947183, 8.621364013, 8.67797213, 8.67797213, 8.67797213,
      8.67797213, 8.67797213, 8.67797213, 8.67797213, 8.67797213, 8.67797213,
      8.67797213, 8.616780848, 8.612197688, 8.607614532, 8.603031382,
      8.598448237, 8.593865097, 8.586108032, 8.58227269, 8.578495799,
      8.574776473, 8.631529104, 8.631529104, 8.631529104, 8.631529104,
      8.631529104, 8.631529104, 8.631529104, 8.631529104, 8.631529104,
      8.631529104, 8.801378565, 8.813382757, 8.825386944, 8.837391126,
      8.849395302, 8.861399473, 8.873403636, 8.885407793, 8.897411942,
      8.909416083, 9.118123364, 9.144133992, 9.170144519, 9.196154932,
      9.222165223, 9.248175378, 9.274185388, 9.300195241, 9.321336968,
      9.341408499, 9.007079184, 9.007079184, 9.007079184, 9.007079184,
      9.007079184, 9.007079184, 9.007079184, 9.007079184, 9.007079184,
      9.007079184, 9.17889552, 9.190899323, 9.202903106, 9.214906868,
      9.226910607, 9.238914323, 9.250918016, 9.262921686, 9.27492533, 9.28692895,
      9.232610117, 9.23998224, 9.247354357, 9.254726468, 9.262098572,
      9.271939511, 9.27781747, 9.296889745, 9.303308597, 9.314078352,
      9.202720915, 9.202720915, 9.202720915, 9.202720915, 9.202720915,
      9.202720915, 9.202720915, 9.202720915, 9.202720915, 9.202720915,
      9.190267365, 9.189349152, 9.188430939, 9.187512726, 9.181471435,
      9.172846946, 9.171011249, 9.169175552, 9.167339856, 9.16550416,
      9.188564332, 9.188564332, 9.188564332, 9.188564332, 9.188564332,
      9.188564332, 9.188564332, 9.188564332, 9.188564332, 9.188564332,
      9.188564332, 9.188564332, 9.188564332, 9.188564332, 9.188564332,
      9.188564332, 9.188564332, 9.188564332, 9.188564332, 9.188564332,
      9.048692299, 9.028916692, 9.01794641, 9.00697621, 8.996006092, 8.985036055,
      8.974066099, 8.963096224, 8.952126429, 8.933793675, 8.855221338,
      8.838807083, 8.822393092, 8.793595547, 8.77627732, 8.758959397,
      8.741641778, 8.724324459, 8.707007439, 8.679495063, 8.825514643,
      8.813649701, 8.807238236, 8.800826785, 8.794415349, 8.788003928,
      8.781592521, 8.775181129, 8.768769751, 8.762358387, 8.78056124,
      8.775977897, 8.771394559, 8.766811226, 8.762227898, 8.756734542,
      8.752993424, 8.737104371, 8.730692387, 8.725194728, 8.793417991,
      8.793417991, 8.793417991, 8.793417991, 8.793417991, 8.793417991,
      8.793417991, 8.793417991, 8.793417991, 8.793417991, 8.793417991,
      8.793417991, 8.793417991, 8.793417991, 8.793417991, 8.793417991,
      8.793417991, 8.793417991, 8.793417991, 8.793417991, 8.793417991,
      8.793417991, 8.793417991, 8.793417991, 8.793417991, 8.793417991,
      8.793417991, 8.793417991, 8.793417991, 8.793417991, 8.793417991,
      8.793417991, 8.793417991, 8.793417991, 8.793417991, 8.793417991,
      8.793417991, 8.793417991, 8.793417991, 8.793417991, 8.793417991,
      8.793417991, 8.793417991, 8.793417991, 8.793417991, 8.793417991,
      8.793417991, 8.793417991, 8.793417991, 8.793417991, 8.885332697,
      8.891780884, 8.898229069, 8.904677252, 8.911125434, 8.917573613,
      8.924021791, 8.930469967, 8.936918141, 8.943366313, 8.857718402,
      8.857718402, 8.857718402, 8.857718402, 8.857718402, 8.857718402,
      8.857718402, 8.857718402, 8.857718402, 8.857718402, 8.857718402,
      8.857718402, 8.857718402, 8.857718402, 8.857718402, 8.857718402,
      8.857718402, 8.857718402, 8.857718402, 8.857718402, 8.857718402,
      8.857718402, 8.857718402, 8.857718402, 8.857718402, 8.857718402,
      8.857718402, 8.857718402, 8.857718402, 8.857718402, 8.857718402,
      8.857718402, 8.857718402, 8.857718402, 8.857718402, 8.857718402,
      8.857718402, 8.857718402, 8.857718402, 8.857718402, 8.796150478,
      8.791567117, 8.786983761, 8.78240041, 8.777817065, 8.769116925,
      8.765233153, 8.751228574, 8.745730881, 8.740233197, 8.710149296,
      8.702825209, 8.695501144, 8.6881771, 8.680853077, 8.673529075, 8.666205094,
      8.658881135, 8.651557196, 8.644233278, 8.735008015, 8.735008015,
      8.735008015, 8.735008015, 8.726783573, 8.72629367, 8.725811268,
      8.725336254, 8.720338377, 8.719420186, 8.551759983, 8.533528006,
      8.519836539, 8.506145209, 8.492454014, 8.478762955, 8.465072032,
      8.451381243, 8.437690588, 8.417439176, 8.470829394, 8.461682905,
      8.452536455, 8.443390044, 8.434243673, 8.425097341, 8.415951047,
      8.406804793, 8.397658578, 8.388512401, 8.379366264, 8.370220165,
      8.361074104, 8.34819351, 8.3406861, 8.321149976, 8.311025343, 8.300969286,
      8.290913281, 8.280857326, 8.295042525, 8.286807791, 8.278573085,
      8.270338406, 8.262103754, 8.253869131, 8.245634534, 8.237399965,
      8.229165423, 8.220779062, 8.08211094, 8.060997109, 8.042427335,
      8.023857817, 8.005288538, 7.986719481, 7.968150631, 7.941993653,
      7.918400009, 7.898911849, 8.131654664, 8.131654664, 8.131654664,
      8.131654664, 8.131654664, 8.131654664, 8.131654664, 8.131654664,
      8.131654664, 8.131654664, 7.975511777, 7.963405286, 7.951298825,
      7.93919239, 7.927085979, 7.914979589, 7.902873216, 7.890766857,
      7.878660509, 7.86655417, 7.974024995, 7.971218921, 7.968412846,
      7.965606772, 7.962800698, 7.959994624, 7.957188549, 7.954382475,
      7.951576401, 7.948770326, 7.981800484, 7.981800484, 7.981800484,
      7.981800484, 7.981800484, 7.981800484, 7.981800484, 7.981800484,
      7.981800484, 7.981800484, 7.981800484, 7.981800484, 7.981800484,
      7.981800484, 7.981800484, 7.981800484, 7.981800484, 7.981800484,
      7.981800484, 7.981800484, 7.814564735, 7.801532881, 7.788501016,
      7.775469137, 7.762437239, 7.749405318, 7.73637337, 7.72334139, 7.710309375,
      7.69727732, 7.850678076, 7.850678076, 7.850678076, 7.850678076,
      7.850678076, 7.850678076, 7.850678076, 7.850678076, 7.850678076,
      7.850678076, 7.684245221, 7.671213074, 7.658180875, 7.645148619,
      7.632116303, 7.619083921, 7.606051471, 7.586239277, 7.575321621,
      7.554259806, 7.717756348, 7.717756348, 7.717756348, 7.717756348,
      7.717756348, 7.717756348, 7.717756348, 7.717756348, 7.717756348,
      7.717756348, 7.717756348, 7.717756348, 7.717756348, 7.717756348,
      7.717756348, 7.717756348, 7.717756348, 7.717756348, 7.717756348,
      7.717756348, 7.646774688, 7.641169739, 7.635564783, 7.62995982,
      7.618072661, 7.613155366, 7.608312892, 7.60354411, 7.588693983,
      7.582157623, 7.658253493, 7.658253493, 7.658253493, 7.658253493,
      7.658253493, 7.658253493, 7.658253493, 7.658253493, 7.658253493,
      7.658253493, 7.576498055, 7.56915422, 7.56261782, 7.556081405, 7.549544976,
      7.543008532, 7.536472073, 7.529935599, 7.523399109, 7.516862604,
      7.592761855, 7.592761855, 7.592761855, 7.592761855, 7.592761855,
      7.592761855, 7.592761855, 7.592761855, 7.592761855, 7.592761855,
      7.510326083, 7.503789545, 7.497252991, 7.49071642, 7.484179832,
      7.477643227, 7.471106604, 7.464569964, 7.458033305, 7.451496628,
      7.468457281, 7.463784241, 7.459111193, 7.454438138, 7.449765077,
      7.445092008, 7.440418932, 7.435745849, 7.431072758, 7.42639966, 7.48037122,
      7.48037122, 7.48037122, 7.48037122, 7.48037122, 7.48037122, 7.48037122,
      7.48037122, 7.48037122, 7.48037122, 7.48037122, 7.48037122, 7.48037122,
      7.48037122, 7.48037122, 7.48037122, 7.48037122, 7.48037122, 7.48037122,
      7.48037122, 7.568729496, 7.575302904, 7.581876324, 7.588449755,
      7.595023198, 7.601596652, 7.608170117, 7.61769724, 7.634179015,
      7.641694423, 7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446,
      7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446,
      7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446,
      7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446,
      7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446,
      7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446,
      7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446,
      7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446,
      7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446,
      7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446, 7.54802446,
      7.54802446, 7.20705704, 7.180229555, 7.153400715, 7.126570445, 7.088026894,
      7.060279913, 7.032531113, 7.004780508, 6.977028138, 6.948733011,
      7.177610632, 7.170142161, 7.162673659, 7.152665849, 7.146458777,
      7.139977982, 7.132509357, 7.116636438, 7.110047889, 7.103559405,
      7.089369938, 7.080970926, 7.072571873, 7.065163807, 7.055853366,
      7.047454192, 7.03905498, 7.030655728, 7.022256437, 7.013857108, 7.00545774,
      6.997058335, 6.988658892, 6.980259412, 6.971859895, 6.963460341,
      6.955060751, 6.946661125, 6.938261464, 6.929861767, 7.013823308,
      7.012887084, 7.01195086, 7.011014637, 7.010078413, 7.009142188,
      7.008205964, 7.00726974, 7.006333516, 7.005397292, 6.81979685, 6.802160275,
      6.788016179, 6.764889251, 6.751597453, 6.72812431, 6.71342704, 6.694805514,
      6.678063096, 6.661320442, 6.913163648, 6.91785451, 6.922545381,
      6.927236262, 6.931927152, 6.936618052, 6.941308961, 6.94599988,
      6.963099639, 6.968730684, 6.899885712, 6.899885712, 6.899885712,
      6.899885712, 6.899885712, 6.899885712, 6.899885712, 6.899885712,
      6.899885712, 6.899885712, 6.899885712, 6.899885712, 6.899885712,
      6.899885712, 6.899885712, 6.899885712, 6.899885712, 6.899885712,
      6.899885712, 6.899885712, 6.899885712, 6.899885712, 6.899885712,
      6.899885712, 6.899885712, 6.899885712, 6.899885712, 6.899885712,
      6.899885712, 6.899885712, 6.893924375, 6.89353017, 6.893142002,
      6.892759779, 6.89238341, 6.892012806, 6.891647878, 6.891288539,
      6.890934704, 6.890586288, 6.79828357, 6.784014584, 6.775614296,
      6.767213978, 6.759947836, 6.750505453, 6.74210505, 6.733704619, 6.72530416,
      6.716903674, 6.800207702, 6.799271469, 6.798335235, 6.797399002,
      6.796462768, 6.795526535, 6.794590301, 6.793654067, 6.792717834, 6.7917816,
      6.790845366, 6.789909132, 6.788972898, 6.788036665, 6.787100431,
      6.786164197, 6.785227963, 6.784291729, 6.783355495, 6.782419261,
      6.689835259, 6.681434661, 6.673034037, 6.664633388, 6.656232714,
      6.647832015, 6.639431291, 6.631030544, 6.622629773, 6.614228978,
      6.60582816, 6.597427319, 6.589026455, 6.580625569, 6.572224661,
      6.563823732, 6.555422781, 6.547021809, 6.535354826, 6.528308873,
      6.521369962, 6.513011817, 6.49631896, 6.488937359, 6.481667856,
      6.474508767, 6.457740513, 6.448496883, 6.440913136, 6.433444535,
      6.51173838, 6.509866588, 6.507994796, 6.506123004, 6.504251212, 6.50237942,
      6.500507627, 6.498635835, 6.496764042, 6.494892249, 6.342788214,
      6.33124961, 6.308514221, 6.29627613, 6.276178516, 6.260981587, 6.245784568,
      6.230587454, 6.215390244, 6.200192933, 6.252840778, 6.243321803,
      6.233802801, 6.224283773, 6.212429962, 6.204480597, 6.195481823,
      6.185962681, 6.169789683, 6.161540919, 6.235347563, 6.232484657,
      6.22962175, 6.226758843, 6.223895934, 6.221033025, 6.218170115,
      6.215307204, 6.212444292, 6.209581379, 6.206718466, 6.203855551,
      6.200992636, 6.19812972, 6.195266802, 6.192403884, 6.189540965,
      6.186678046, 6.183815125, 6.180952203, 6.17808928, 6.175226357,
      6.172363432, 6.169500507, 6.166637581, 6.163774653, 6.160911725,
      6.158048796, 6.15540298, 6.153071984, 6.183268271, 6.183268271,
      6.183268271, 6.183268271, 6.183268271, 6.183268271, 6.183268271,
      6.183268271, 6.183268271, 6.183268271, 6.183268271, 6.183268271,
      6.183268271, 6.183268271, 6.183268271, 6.183268271, 6.183268271,
      6.183268271, 6.183268271, 6.183268271, 6.183268271, 6.183268271,
      6.183268271, 6.183268271, 6.183268271, 6.183268271, 6.183268271,
      6.183268271, 6.183268271, 6.183268271, 6.160783051, 6.158873756,
      6.156964461, 6.155055165, 6.15314587, 6.151236574, 6.149327277,
      6.147417981, 6.145508684, 6.143599387, 6.141690089, 6.139780792,
      6.137871493, 6.135962195, 6.134052896, 6.132143597, 6.130234298,
      6.128324999, 6.126415699, 6.124506399, 6.218223094, 6.231658894,
      6.24250625, 6.2492057, 6.255905177, 6.262604681, 6.269304213, 6.276003772,
      6.282703358, 6.289402973, 6.210619987, 6.210619987, 6.210619987,
      6.210619987, 6.210619987, 6.210619987, 6.210619987, 6.210619987,
      6.210619987, 6.210619987, 6.131854173, 6.125183463, 6.118512741,
      6.111842007, 6.106298766, 6.098596072, 6.091925302, 6.085254519,
      6.078583723, 6.071912915, 6.143843365, 6.143843365, 6.143843365,
      6.143843365, 6.143843365, 6.143843365, 6.143843365, 6.143843365,
      6.143843365, 6.143843365, 6.129721123, 6.128736547, 6.127767041,
      6.126812375, 6.125872323, 6.124946661, 6.124035168, 6.123137629,
      6.122253829, 6.121383559, 6.120526612, 6.119682783, 6.118851873,
      6.118033684, 6.11722802, 6.116408345, 6.115453359, 6.114498372,
      6.113543386, 6.1125884, 6.122854816, 6.122854816, 6.122854816, 6.122854816,
      6.122854816, 6.122854816, 6.122854816, 6.122854816, 6.122854816,
      6.122854816, 6.122854816, 6.122854816, 6.122854816, 6.122854816,
      6.122854816, 6.122854816, 6.122854816, 6.122854816, 6.122854816,
      6.122854816, 6.112519482, 6.111798243, 6.111088047, 6.110388725,
      6.109700111, 6.10902204, 6.108354352, 6.107696888, 6.107049491,
      6.106412007, 6.105784285, 6.105166175, 6.10455753, 6.103958205,
      6.103368057, 6.102786947, 6.102214735, 6.101651286, 6.101096466,
      6.100550142, 6.017869296, 6.010248068, 6.002626819, 5.995005549,
      5.985300192, 5.978907396, 5.97190674, 5.964285384, 5.956664006,
      5.949042606, 5.880475575, 5.861500722, 5.848190763, 5.836985962,
      5.826218225, 5.808819536, 5.795509067, 5.782616304, 5.76892333,
      5.755612452, 5.798021742, 5.789450039, 5.780878297, 5.773355011,
      5.766391782, 5.75547217, 5.746900272, 5.738328334, 5.729756355,
      5.720257331, 5.713153165, 5.70401391, 5.695441765, 5.686869577,
      5.673928854, 5.666580825, 5.659344508, 5.65186539, 5.643292979,
      5.634720523, 5.697606935, 5.695602554, 5.693628823, 5.691685276,
      5.689771451, 5.687886895, 5.686031161, 5.68420381, 5.682404407,
      5.680632527, 5.60133369, 5.594141126, 5.586056083, 5.56894095, 5.561292633,
      5.553760568, 5.546343003, 5.539038215, 5.531844503, 5.513706878,
      5.428598012, 5.415512726, 5.402625066, 5.378896835, 5.365063914,
      5.35132572, 5.3292642, 5.312799552, 5.298868313, 5.2790927, 5.41444478,
      5.411811672, 5.40921882, 5.406665608, 5.404151434, 5.401675701,
      5.399237824, 5.396837223, 5.385447296, 5.38045697, 5.377350652,
      5.374291804, 5.371279704, 5.368313639, 5.365392907, 5.362516819,
      5.359684692, 5.356895857, 5.354149653, 5.351445432, 5.293778135,
      5.286483031, 5.270174014, 5.264369381, 5.258741277, 5.248139689,
      5.241106458, 5.231188686, 5.225581959, 5.209325906, 5.258134931,
      5.255666699, 5.253273873, 5.250954156, 5.248705322, 5.24652521,
      5.244411727, 5.242362843, 5.240376588, 5.233866728, 5.266318316,
      5.266318316, 5.266318316, 5.266318316, 5.266318316, 5.266318316,
      5.266318316, 5.266318316, 5.266318316, 5.266318316, 5.266318316,
      5.266318316, 5.266318316, 5.266318316, 5.266318316, 5.266318316,
      5.266318316, 5.266318316, 5.266318316, 5.266318316, 5.350392896,
      5.357368948, 5.364345017, 5.371321103, 5.378297205, 5.385273324,
      5.392249459, 5.409816887, 5.419102384, 5.427076849, 5.435051337,
      5.443025846, 5.451000377, 5.458974929, 5.466949501, 5.474924094,
      5.49228254, 5.50368845, 5.512661855, 5.521635286, 5.391727242, 5.389441494,
      5.387190702, 5.377892033, 5.375733429, 5.373640791, 5.37161211,
      5.369645437, 5.36773888, 5.365890607, 5.364098841, 5.362361858,
      5.360677988, 5.356804099, 5.355528023, 5.354310438, 5.353148669,
      5.352040166, 5.350982492, 5.349859296, 5.195497425, 5.179487098,
      5.163467448, 5.14743902, 5.131709175, 5.121026312, 5.099360936, 5.08867595,
      5.067017366, 5.066581928, 5.213109114, 5.213109114, 5.213109114,
      5.213109114, 5.213109114, 5.213109114, 5.213109114, 5.213109114,
      5.213109114, 5.213109114, 5.128960596, 5.129938894, 5.130914379,
      5.13690096, 5.150581374, 5.159647428, 5.165656118, 5.169638743,
      5.172278582, 5.174028421, 5.646019923, 5.685139621, 5.724262653,
      5.763388763, 5.797667437, 5.829274466, 5.872430926, 5.905887519,
      5.944013453, 5.982140885, 5.669709846, 5.67832538, 5.68694093, 5.695556497,
      5.70417208, 5.712787681, 5.724538817, 5.73169146, 5.75080383, 5.758512368,
      5.228941986, 5.193082429, 5.157219011, 5.115305231, 5.071128583,
      5.032767963, 5.007985133, 5.009015399, 5.009882297, 5.010613605,
      5.425231816, 5.436203489, 5.447175224, 5.45814702, 5.469118874,
      5.480090786, 5.491062754, 5.502520497, 5.513047115, 5.532477064,
      5.415295933, 5.416291272, 5.423218495, 5.430812713, 5.432803818,
      5.434794924, 5.436786029, 5.438777135, 5.440768241, 5.442759348,
      5.568258686, 5.578224322, 5.600084938, 5.610561483, 5.627014264,
      5.639987361, 5.652960519, 5.665933734, 5.678907004, 5.691880326,
      6.130250521, 6.173331214, 6.217519737, 6.254854126, 6.303697922,
      6.345021988, 6.389450274, 6.426058575, 6.468248944, 6.510113074,
      6.605554306, 6.653917098, 6.70228833, 6.750668553, 6.799058317,
      6.847458169, 6.895868653, 6.944290314, 6.992723691, 7.041169326,
      7.08927963, 7.136814696, 7.184362728, 7.23192323, 7.279495714, 7.3270797,
      7.374674714, 7.422280291, 7.46989597, 7.517521298, 7.565155823,
      7.612799103, 7.660450696, 7.708110166, 7.755777078, 7.803451, 7.851131504,
      7.89881816, 7.946510543, 7.994208223, 8.041910776, 8.089617827,
      8.137329169, 8.185044622, 8.232764002, 8.280487125, 8.328213802,
      8.375943844, 8.42367706, 8.471413254, 8.519152231, 8.566893793, 8.61463774,
      8.66238387, 8.710131979, 8.757881863, 8.805633314, 8.853386125,
      8.901140086, 8.948894985, 8.995905769, 9.04276137, 9.089617371,
      9.136473639, 9.18333005, 9.230186481, 9.277042816, 9.323898941,
      9.370754743, 9.417610112, 9.464464937, 9.511319108, 9.558172512,
      9.605025036, 9.651876562, 9.698726971, 9.745576135, 9.792423925,
      9.839270204, 9.886114826, 9.934183175, 9.974579756, 9.999726188,
      9.997179402, 9.994713856, 9.992340363, 9.990066364, 9.990590287,
      9.995157575, 9.997290235, 9.765472002, 9.774098752, 9.782725481,
      9.79131325, 9.798076813, 9.804735856, 9.811292006, 9.817746867,
      9.824102018, 9.841153253, 9.322892795, 9.287012911, 9.250012123,
      9.218262553, 9.187107157, 9.150491403, 9.112792359, 9.074740792,
      9.036342435, 9.001869603, 8.933682953, 8.892799797, 8.851615437,
      8.810134757, 8.769010131, 8.728407854, 8.687537855, 8.646404485,
      8.605012023, 8.563364678, 8.484303524, 8.440069084, 8.383271043,
      8.337926189, 8.292389552, 8.236974679, 8.187909816, 8.141131351,
      8.094027777, 8.037726053, 8.1148394, 8.078725089, 8.039637437, 7.998650407,
      7.957403631, 7.91590133, 7.874147655, 7.831923812, 7.788918012, 7.75541145,
      7.750968427, 7.716886465, 7.681386293, 7.640675918, 7.599682367,
      7.558409865, 7.522346076, 7.487320036, 7.445950539, 7.404306886,
      7.409945274, 7.376522398, 7.343281493, 7.304100338, 7.266974378,
      7.234129056, 7.19723451, 7.157555794, 7.123577479, 7.089423129,
      7.131726782, 7.10840067, 7.073706105, 7.05032981, 7.015609929, 6.992184295,
      6.957439952, 6.93396621, 6.904928375, 6.875667302, 7.207823097,
      7.207823097, 7.207823097, 7.207823097, 7.207823097, 7.207823097,
      7.207823097, 7.207823097, 7.207823097, 7.207823097, 6.975479357,
      6.956897355, 6.937660368, 6.915462132, 6.892927986, 6.870052901,
      6.85046826, 6.830962121, 6.811455517, 6.791948459, 7.226495816,
      7.242513041, 7.258530577, 7.27454842, 7.290566563, 7.297835159,
      7.310071062, 7.324574613, 7.339646172, 7.354717958, 7.12325828,
      7.119517887, 7.115777491, 7.112037091, 7.108296687, 7.10455628, 7.10081587,
      7.097075456, 7.093335039, 7.089594618, 6.912047816, 6.894386216,
      6.873681116, 6.852362358, 6.830720837, 6.810624038, 6.792038325,
      6.773452232, 6.754865767, 6.736278939, 6.947995367, 6.947995367,
      6.947995367, 6.947995367, 6.947995367, 6.947995367, 6.947995367,
      6.947995367, 6.947995367, 6.947995367, 6.65307733, 6.626851426,
      6.600505096, 6.574041981, 6.547465613, 6.532247963, 6.506022049,
      6.479675623, 6.463236747, 6.438573369, 7.183209941, 7.211771938,
      7.247808044, 7.282590081, 7.31133936, 7.342792077, 7.377884685,
      7.408156868, 7.435269645, 7.469412163, 6.846740277, 6.827418922,
      6.807248873, 6.786773257, 6.766841896, 6.74917754, 6.731512878,
      6.713847917, 6.696182662, 6.678517121, 7.077627048, 7.092694235,
      7.107761725, 7.122829513, 7.137897593, 7.152965962, 7.168034615,
      7.183103546, 7.198172752, 7.213242228, 6.714214874, 6.687054519,
      6.65980214, 6.639715045, 6.61690072, 6.589942127, 6.56288533, 6.539065243,
      6.516752331, 6.493181817, 6.787165258, 6.788102157, 6.789039055,
      6.789975954, 6.790912853, 6.791849752, 6.792786651, 6.79372355, 6.79466045,
      6.795597349, 6.476363148, 6.454141395, 6.429781754, 6.398459572,
      6.376104839, 6.353845476, 6.331677292, 6.312408073, 6.283665256,
      6.266204438, 6.308143927, 6.289550642, 6.271621493, 6.252184975,
      6.233216549, 6.214247953, 6.19849046, 6.1765791, 6.157609952, 6.143130093,
      6.06349576, 6.044503773, 6.019909184, 6.002493173, 5.982016329,
      5.954656291, 5.935654646, 5.922207948, 5.89383816, 5.88950623, 6.129062553,
      6.13001812, 6.130973686, 6.131929252, 6.132884818, 6.133840385,
      6.134795951, 6.135751518, 6.136707084, 6.137662651, 5.93734358,
      5.922318484, 5.913029231, 5.913867447, 5.909564877, 5.912264633,
      5.914861653, 5.93126566, 5.954393379, 5.97006978, 6.023339379, 6.024294937,
      6.025250496, 6.026206054, 6.027161613, 6.028117172, 6.02907273,
      6.030028289, 6.030983848, 6.031939407, 6.628880272, 6.677247066,
      6.725622565, 6.774007322, 6.822401884, 6.870806796, 6.919222604,
      6.959734839, 7.003198692, 7.038389838, 7.108739457, 7.156279891,
      7.203833088, 7.251398555, 7.298975806, 7.346564363, 7.394163758,
      7.441773527, 7.48939321, 7.537022357, 7.478344825, 7.512127428,
      7.551081192, 7.577564225, 7.61556273, 7.645218939, 7.678421002,
      7.715466352, 7.739972729, 7.776060592, 7.962968436, 8.010667846,
      8.058371984, 8.106080536, 8.153793317, 8.201510146, 8.249230838,
      8.296955209, 8.344683069, 8.392414228, 8.440148493, 8.48788567,
      8.535625562, 8.583367969, 8.631112692, 8.678859528, 8.726608273,
      8.774358721, 8.822110665, 8.869863897, 8.749536599, 8.777968031,
      8.80595572, 8.831332729, 8.859492518, 8.882891994, 8.911041649, 8.93287507,
      8.960634763, 8.981309808, 9.148394016, 9.178713853, 9.204868064,
      9.230057532, 9.25428335, 9.277546619, 9.300064378, 9.327113836, 9.35373334,
      9.375438815, 9.342080376, 9.356766616, 9.38239964, 9.397347147,
      9.410121125, 9.435191032, 9.447005886, 9.457872911, 9.48106682, 9.49097779,
      9.526526303, 9.536418909, 9.545366011, 9.567153821, 9.575974692,
      9.595512648, 9.604881608, 9.611735578, 9.629817894, 9.636772201,
      9.494377983, 9.501082996, 9.507788001, 9.501095695, 9.506840658,
      9.512585616, 9.51833057, 9.524075519, 9.529820464, 9.535565404,
      9.662022871, 9.663016034, 9.675207451, 9.676388726, 9.675436106,
      9.686951788, 9.685026119, 9.695578131, 9.692680897, 9.697376098,
      9.630772674, 9.63459969, 9.62496758, 9.627836765, 9.63070595, 9.633575134,
      9.636444317, 9.639313499, 9.642182681, 9.631585219, 9.593940642,
      9.592985662, 9.592030683, 9.591075703, 9.590120724, 9.589165744,
      9.588210765, 9.587255786, 9.586300807, 9.585345827, 9.637400711,
      9.640269893, 9.643139074, 9.632541255, 9.634453327, 9.636365398,
      9.638277469, 9.626719679, 9.627675357, 9.628631035, 9.61611578, 9.61611578,
      9.61611578, 9.603490441, 9.602535461, 9.601580481, 9.600625501,
      9.599670521, 9.598715541, 9.597760561, 9.596805581, 9.583227985,
      9.581318707, 9.579409429, 9.577500152, 9.575590876, 9.5736816, 9.571772324,
      9.569863049, 9.567953775, 9.566044501, 9.564135227, 9.562225954,
      9.560316682, 9.55840741, 9.556498138, 9.554588867, 9.552679597,
      9.550770327, 9.548861057, 9.546951788, 9.54504252, 9.543133251,
      9.541223984, 9.539314717, 9.53740545, 9.535496184, 9.533586918,
      9.531677653, 9.529768388, 9.527859124, 9.52594986, 9.511439219,
      9.508576359, 9.5057135, 9.502850643, 9.499987787, 9.497124933, 9.494262081,
      9.49139923, 9.475943287, 9.472127541, 9.468311799, 9.451907122,
      9.447139187, 9.442371261, 9.437603341, 9.432835429, 9.428067524,
      9.41072111, 9.392880343, 9.387586308, 9.372918547, 9.364098082,
      9.358293202, 9.352576683, 9.343287632, 9.328623466, 9.322409887,
      9.316290842, 9.272615207, 9.256387953, 9.243304233, 9.222061417,
      9.211447202, 9.191997393, 9.172198402, 9.15848529, 9.144402508, 9.12417348,
      9.116125082, 9.104183083, 9.088216253, 9.068348523, 9.060648796,
      9.040719195, 9.020492971, 8.999979496, 8.990239642, 8.97103789,
      9.012394818, 9.006381341, 8.996878545, 8.982314606, 8.976304467,
      8.958062581, 8.951879838, 8.940431229, 8.927433091, 8.920161975,
      9.00199086, 8.999930647, 8.988008612, 8.986478557, 8.985018221,
      8.983624454, 8.982294248, 8.974751249, 8.972607693, 8.970529483,
      9.079556762, 9.084158864, 9.088760964, 9.093363064, 9.097965162,
      9.102567259, 9.107169354, 9.111771448, 9.116373541, 9.120907288,
      9.257949168, 9.271810639, 9.278499407, 9.285779204, 9.298711329,
      9.311643422, 9.311306076, 9.323309615, 9.335313127, 9.347262191,
      9.131718162, 9.129358217, 9.127070183, 9.124851883, 9.1227012, 9.120616086,
      9.11859455, 9.116634664, 9.114734556, 9.104624176, 9.085884146,
      9.076581304, 9.074657957, 9.072822055, 9.071069664, 9.056973748,
      9.055033363, 9.053181188, 9.051413256, 9.049725773, 9.062852844,
      9.06234376, 9.061865445, 9.061416065, 9.06099389, 9.053246136, 9.053344215,
      9.053434339, 9.053517182, 9.053593358, 9.058596361, 9.058345382,
      9.058109681, 9.057888335, 9.057680474, 9.053890544, 9.053936974,
      9.053979741, 9.054019141, 9.054055446, 9.728168916, 9.748499792,
      9.753608512, 9.763973191, 9.768475342, 9.76755727, 9.763338778,
      9.756138784, 9.745967439, 9.737613846, 9.636707349, 9.638681455,
      9.626274372, 9.625340783, 9.623438462, 9.607146366, 9.602348073,
      9.583157154, 9.57547161, 9.566824977, 9.530350977, 9.517872617,
      9.517872617, 9.517872617, 9.517872617, 9.517872617, 9.505282582,
      9.504327608, 9.503372634, 9.50241766, 9.501462686, 9.500507712,
      9.499552739, 9.498597765, 9.497642791, 9.496687818, 9.495732845,
      9.494777871, 9.493822898, 9.492867924, 9.491912951, 9.490957978,
      9.490003005, 9.489048032, 9.488093059, 9.487138086, 9.486183113,
      9.48522814, 9.484273168, 9.483318195, 9.482363222, 9.48140825, 9.480453277,
      9.479498305, 9.478543332, 9.47758836, 9.476633388, 9.475678415,
      9.474723443, 9.473768471, 9.472813499, 9.471858527, 9.470903555,
      9.469948583, 9.468993611, 9.468038639, 9.467083668, 9.466128696,
      9.465173724, 9.464218753, 9.463263781, 9.46230881, 9.461353839,
      9.460398867, 9.459443896, 9.458488925, 9.457533954, 9.456578982,
      9.455624011, 9.45466904, 9.45371407, 9.452759099, 9.451804128, 9.450849157,
      9.449894186, 9.448939216, 9.447984245, 9.447029275, 9.446074304,
      9.445119334, 9.444164363, 9.443209393, 9.442254423, 9.441299453,
      9.440344482, 9.439389512, 9.438434542, 9.437479572, 9.436524602,
      9.435569633, 9.434614663, 9.433659693, 9.432704723, 9.431749754,
      9.430794784, 9.429839815, 9.428884845, 9.427929876, 9.426974906,
      9.426019937, 9.425064968, 9.424109999, 9.423155029, 9.42220006,
      9.421245091, 9.420290122, 9.419335153, 9.418380185, 9.417425216,
      9.416470247, 9.415515278, 9.41456031, 9.413605341, 9.412650373,
      9.411695404, 9.410740436, 9.409785467, 9.408830499, 9.407875531,
      9.407100934, 9.406349277, 9.405609128, 9.404880311, 9.404162651,
      9.403455979, 9.402760126, 9.402074927, 9.401400219, 9.400735841,
      9.400081635, 9.399437446, 9.39880312, 9.398178507, 9.397563457,
      9.396957826, 9.396361467, 9.39577424, 9.395196005, 9.394626624,
      9.394065962, 9.393513885, 9.392970262, 9.392434964, 9.391907863,
      9.391388834, 9.390877752, 9.390374498, 9.38987895, 9.38939099, 9.388910504,
      9.388437376, 9.387971493, 9.387512745, 9.387061023, 9.386616219,
      9.386178227, 9.385746943, 9.385322264, 9.384904089, 9.384492318,
      9.384086854, 9.3836876, 9.383294461, 9.382907343, 9.382526154, 9.382150804,
      9.381781202, 9.381417261, 9.381058895, 9.380706017, 9.380358544,
      9.380016394, 9.379679484, 9.379347734, 9.379021066, 9.378699401,
      9.378382664, 9.378070777, 9.377763669, 9.377461264, 9.377163491,
      9.37687028, 9.376581559, 9.376297262, 9.376017319, 9.375741664,
      9.375470232, 9.375202957, 9.374939777, 9.374680628, 9.374425449,
      9.374174178, 9.373926757, 9.373683126, 9.373443227, 9.373207003,
      9.372974397, 9.372745355, 9.372519821, 9.372297742, 9.372079066,
      9.371863739, 9.371651711, 9.371442931, 9.371237349, 9.371034916,
      9.370835585, 9.370639307, 9.370446036, 9.370255726, 9.370068332,
      9.369883808, 9.369702111, 9.369523198, 9.369347025, 9.369173551,
      9.369002735, 9.368834536, 9.368668914, 9.368505829, 9.368345242,
      9.368187116, 9.368031412, 9.367878093, 9.367727124, 9.367578467,
      9.367432088, 9.367287951, 9.367146023, 9.367006269, 9.366868656,
      9.366733151, 9.366599722, 9.366468338, 9.366338966, 9.366211577,
      9.366086139, 9.365962623, 9.365840999, 9.365721238, 9.365603313,
      9.365487194, 9.365372854, 9.365260266, 9.365149403, 9.365040239,
      9.364932747, 9.364826902, 9.364722678, 9.364620051, 9.364518997,
      9.364419491, 9.36432151, 9.364225029, 9.364130027, 9.364036481,
      9.363944367, 9.363853665, 9.363764353, 9.363676409, 9.363589812,
      9.363504543, 9.363420579, 9.363337902, 9.363256492, 9.363176329,
      9.363097395, 9.36301967, 9.362943135, 9.362867774, 9.362793567,
      9.362720496, 9.362648546, 9.362577698, 9.362507935, 9.362439241, 9.3623716,
      9.362304995, 9.362239411, 9.362174832, 9.35060626, 9.349651295, 9.34869633,
      9.347289334, 9.346498887, 9.345720541, 9.344818384, 9.34386342,
      9.342908455, 9.341953491, 9.328468917, 9.3265597, 9.313793744, 9.311608414,
      9.309456484, 9.304041074, 9.301178322, 9.290239691, 9.287461747,
      9.284726229, 9.263001906, 9.253186344, 9.249071144, 9.232505141,
      9.227754968, 9.211183732, 9.205240005, 9.199955612, 9.182250044,
      9.176366744, 9.101838347, 9.07748481, 9.052227642, 9.027910245,
      9.011598656, 8.984543629, 8.956588469, 8.92987617, 8.903866404,
      8.877353977, 8.886725069, 8.862194695, 8.836330483, 8.809961409,
      8.783095757, 8.75574167, 8.727907155, 8.69960008, 8.670828185, 8.641599077,
      8.698285874, 8.673157935, 8.659837774, 8.634400752, 8.608452387,
      8.594303778, 8.56807256, 8.553630769, 8.527125894, 8.50012734, 8.512597657,
      8.496061852, 8.47045286, 8.456578101, 8.435657492, 8.416794397,
      8.390605881, 8.376131059, 8.349669158, 8.333904883, 8.45438628,
      8.440209722, 8.43518473, 8.422505743, 8.413064623, 8.407954129,
      8.402158622, 8.385991571, 8.38079342, 8.375752469, 8.297950767,
      8.277841261, 8.26958228, 8.249436733, 8.235740099, 8.220711424,
      8.200576323, 8.191638625, 8.177308314, 8.159697304, 8.105594656,
      8.086399448, 8.06715986, 8.046274555, 8.018446844, 8.002540789,
      7.986677644, 7.959896639, 7.942860959, 7.923539106, 7.983482617,
      7.965132148, 7.958233907, 7.947208343, 7.930564381, 7.93292342,
      7.936659101, 7.940181829, 7.948002658, 7.956111804, 8.050505248,
      8.051442204, 8.05237916, 8.053316116, 8.054253072, 8.055190028,
      8.056126984, 8.05706394, 8.058000896, 8.058937852, 8.689086699,
      8.736835826, 8.784586612, 8.83233885, 8.880092329, 8.927846841,
      8.975254256, 9.022109638, 9.068965479, 9.115821645, 9.162678008,
      9.209534445, 9.256390837, 9.303247069, 9.350103027, 9.3969586, 9.443813678,
      9.490668151, 9.537521907, 9.584374833, 9.631226814, 9.67807773,
      9.724927459, 9.771775871, 9.818622833, 9.865468203, 9.91272764,
      9.961406526, 9.983348784, 9.991280982, 9.392989023, 9.390126227,
      9.387263432, 9.384400639, 9.381537847, 9.378675057, 9.375812268,
      9.372949481, 9.370086695, 9.367223911, 9.201242298, 9.186047708,
      9.168157102, 9.143342807, 9.126818641, 9.110681408, 9.092221487,
      9.066696847, 9.048719851, 9.032077048, 8.978254857, 8.959124619,
      8.934359775, 8.908008059, 8.887976331, 8.862357251, 8.835084177,
      8.814151991, 8.788249788, 8.759529408, 8.737697816, 8.712071254,
      8.682203067, 8.658719219, 8.633902096, 8.603440555, 8.577337427,
      8.553711027, 8.522803371, 8.493622675, 8.505970109, 8.479201225,
      8.449683879, 8.426960693, 8.404238143, 8.381516226, 8.352722898,
      8.323400508, 8.299781862, 8.272394529, 8.288841895, 8.267923097,
      8.244558798, 8.215620056, 8.198383104, 8.170718721, 8.148902479,
      8.127086767, 8.105065646, 8.075583961, 8.009365611, 7.976453077,
      7.947823459, 7.921003243, 7.88806371, 7.854847787, 7.827117071,
      7.797752317, 7.763433978, 7.731180698, 7.83438426, 7.815816461,
      7.795857492, 7.778573087, 7.754010591, 7.738733804, 7.711749636,
      7.696190051, 7.671842136, 7.653291228, 7.597233255, 7.574990787,
      7.552748093, 7.524598239, 7.506351806, 7.476524407, 7.458082308,
      7.428081976, 7.404917865, 7.378995967, 7.501813076, 7.48804183,
      7.475934091, 7.460859242, 7.450910522, 7.441112037, 7.42736328,
      7.415255035, 7.400165954, 7.390210114, 7.321652358, 7.303303152,
      7.283039238, 7.269319752, 7.25580619, 7.230780496, 7.216926499,
      7.203280402, 7.178145376, 7.164162402, 7.361433457, 7.361433457,
      7.361433457, 7.361433457, 7.361433457, 7.361433457, 7.361433457,
      7.361433457, 7.361433457, 7.361433457, 7.255504734, 7.237798176,
      7.229553873, 7.222179675, 7.214917317, 7.207765122, 7.20072144,
      7.182747127, 7.175756887, 7.170112987, 7.472567356, 7.487640951,
      7.502714728, 7.517788685, 7.532862815, 7.547937116, 7.563011581,
      7.578086207, 7.593160989, 7.608235923, 7.315710669, 7.308884771,
      7.302162464, 7.291399116, 7.277064694, 7.269897378, 7.262838786,
      7.255887287, 7.249041276, 7.242299171, 7.235659412, 7.217454393,
      7.210263711, 7.203182118, 7.196207979, 7.189339682, 7.18257564,
      7.175914285, 7.162870475, 7.150834637, 7.097187817, 7.087188255,
      7.077339795, 7.067640193, 7.05253565, 7.036707912, 7.026697908,
      7.016839191, 6.999264107, 6.991565152, 6.97570112, 6.965688673,
      6.955827577, 6.938312892, 6.930607995, 6.914712319, 6.903909818,
      6.894782061, 6.877335111, 6.869625114, 6.758306188, 6.734384962,
      6.710272904, 6.685975853, 6.673005496, 6.648923315, 6.624655155,
      6.600206706, 6.58705754, 6.562833899, 6.654540541, 6.64568974, 6.632967679,
      6.619824326, 6.611354071, 6.59491674, 6.589738229, 6.573365372,
      6.568239617, 6.551925862, 6.581091129, 6.568024498, 6.565845821,
      6.557523358, 6.550340061, 6.545076009, 6.533170435, 6.532411708,
      6.525514027, 6.530644586, 6.527485689, 6.52646098, 6.527226937,
      6.525033397, 6.529677675, 6.52935036, 6.532802578, 6.538509578,
      6.547361533, 6.552957192, 7.179487221, 7.227046467, 7.274617745,
      7.322200574, 7.369794479, 7.417398994, 7.465013659, 7.512638017,
      7.560271621, 7.607914023, 7.655564784, 7.703223466, 7.750889635,
      7.798562858, 7.846242707, 7.893928753, 7.941620567, 7.989317725,
      8.037019797, 8.084726399, 8.132437309, 8.180152349, 8.227871334,
      8.275594082, 8.323320403, 8.37105011, 8.418783008, 8.466518906,
      8.514257607, 8.561998914, 8.609742625, 8.65748854, 8.705236456,
      8.752986168, 8.800737468, 8.848490149, 8.896244001, 8.943998814,
      8.991101864, 9.037957417, 9.084813383, 9.13166963, 9.178526031,
      9.225382466, 9.272238817, 9.319094968, 9.365950809, 9.412806227,
      9.459661113, 9.506515356, 9.553368844, 9.600221463, 9.647073097,
      9.693923626, 9.740772924, 9.77214405, 9.781374967, 9.801796409,
      9.821422962, 9.827448586, 9.938268098, 9.946346005, 9.951201885,
      9.949764592, 9.943994294, 9.951266507, 9.94186439, 9.929498647,
      9.914179324, 9.905281832, 9.646191072, 9.646191072, 9.646191072,
      9.646191072, 9.646191072, 9.646191072, 9.646191072, 9.646191072,
      9.646191072, 9.646191072, 9.56251443, 9.55142844, 9.532126394, 9.511876853,
      9.503306494, 9.482113612, 9.461720354, 9.44963974, 9.426560949,
      9.410823918, 9.365596051, 9.351343769, 9.324498713, 9.296714821,
      9.267993222, 9.250910314, 9.221258768, 9.190671861, 9.159150764,
      9.139244537, 9.194581509, 9.167796386, 9.152602278, 9.124884648,
      9.108747445, 9.090678285, 9.06382179, 9.046742628, 9.017702352,
      9.000379963, 9.007978534, 8.992467781, 8.974010873, 8.948789392,
      8.932373592, 8.910726267, 8.886737252, 8.869417348, 8.852097761,
      8.822377872, 8.928086735, 8.918938154, 8.909789617, 8.894460848,
      8.886849091, 8.869203964, 8.859144892, 8.84908588, 8.839026926,
      8.828968031, 8.893030812, 8.888447337, 8.883863868, 8.879280405,
      8.874696947, 8.870113494, 8.865530047, 8.860946605, 8.856363168,
      8.851779737, 8.908869961, 8.908869961, 8.908869961, 8.908869961,
      8.908869961, 8.908869961, 8.908869961, 8.908869961, 8.908869961,
      8.908869961, 8.908869961, 8.908869961, 8.908869961, 8.908869961,
      8.908869961, 8.908869961, 8.908869961, 8.908869961, 8.908869961,
      8.908869961, 8.908869961, 8.908869961, 8.908869961, 8.908869961,
      8.908869961, 8.908869961, 8.908869961, 8.908869961, 8.908869961,
      8.908869961, 8.852488752, 8.849161715, 8.845885424, 8.84265911,
      8.830817243, 8.826233841, 8.821650445, 8.817067055, 8.812598427,
      8.807908827, 8.864908277, 8.864908277, 8.864908277, 8.864908277,
      8.864908277, 8.864908277, 8.864908277, 8.864908277, 8.864908277,
      8.864908277, 8.864908277, 8.864908277, 8.864908277, 8.864908277,
      8.864908277, 8.864908277, 8.864908277, 8.864908277, 8.864908277,
      8.864908277, 8.878067756, 8.878986703, 8.87990565, 8.880824597,
      8.881743544, 8.882662491, 8.883581439, 8.884500386, 8.885419333,
      8.88633828, 8.887257227, 8.888176174, 8.889095122, 8.890014069,
      8.890933016, 8.891851963, 8.89277091, 8.893689857, 8.894608804,
      8.895527751, 8.821658984, 8.817075593, 8.812492208, 8.807908827,
      8.803325453, 8.798742083, 8.794158719, 8.782093387, 8.778011879,
      8.773992559, 8.733120894, 8.727048504, 8.721068387, 8.702884057,
      8.696360546, 8.68628371, 8.678047606, 8.669811533, 8.66157549, 8.653339477,
      8.632832536, 8.623685336, 8.614538176, 8.605391058, 8.591337824,
      8.583778665, 8.565115863, 8.556093229, 8.548159884, 8.535251361,
      8.642423967, 8.641390146, 8.640372142, 8.639369715, 8.638382626,
      8.63741064, 8.636453528, 8.635511062, 8.634583018, 8.633669176,
      8.610916691, 8.608164473, 8.605412255, 8.602660038, 8.599907822,
      8.597155608, 8.594403394, 8.591651182, 8.58889897, 8.58614676, 8.534539971,
      8.528129118, 8.52171828, 8.515307454, 8.508896643, 8.499844246,
      8.494584511, 8.48936896, 8.472110146, 8.46636079, 8.517359111, 8.514606929,
      8.511854747, 8.509102567, 8.506350387, 8.498482595, 8.495983852,
      8.493523261, 8.491100241, 8.48871422, 8.486364634, 8.484050931,
      8.481772562, 8.479528991, 8.477030995, 8.462959981, 8.460088451,
      8.45726074, 8.454476182, 8.451734122, 8.408157849, 8.401747262,
      8.395336687, 8.388926126, 8.382515578, 8.376105043, 8.369694521,
      8.363284013, 8.356873517, 8.350463035, 8.271264329, 8.259390392,
      8.247516539, 8.235642768, 8.223769081, 8.211895477, 8.195539168,
      8.185807261, 8.163999692, 8.153587488, 8.198198899, 8.189802379,
      8.181405883, 8.17149399, 8.164495891, 8.156099465, 8.139138596,
      8.131877304, 8.124726154, 8.117683489, 8.220741502, 8.220741502,
      8.220741502, 8.220741502, 8.220741502, 8.220741502, 8.220741502,
      8.220741502, 8.220741502, 8.220741502, 8.220741502, 8.220741502,
      8.220741502, 8.220741502, 8.220741502, 8.220741502, 8.220741502,
      8.220741502, 8.220741502, 8.233650946, 8.22167809, 8.22167809, 8.22167809,
      8.22167809, 8.22167809, 8.22167809, 8.22167809, 8.22167809, 8.22167809,
      8.22167809, 8.402415478, 8.415600197, 8.428784938, 8.4419697, 8.455154483,
      8.468339284, 8.481524103, 8.494708938, 8.507893787, 8.520830361,
      8.365378769, 8.366297717, 8.367216665, 8.368135613, 8.369054561,
      8.369973509, 8.370892457, 8.371811404, 8.372730352, 8.3736493, 8.374568248,
      8.375487196, 8.376406144, 8.377325092, 8.37824404, 8.379162988,
      8.380081936, 8.381000884, 8.381919832, 8.38283878, 8.500398199,
      8.509621043, 8.518843891, 8.528066742, 8.537289596, 8.546512454,
      8.555735313, 8.564958176, 8.57418104, 8.583403907, 9.008535156,
      9.047769831, 9.073976264, 9.112261628, 9.15054694, 9.175758215,
      9.213094654, 9.243548468, 9.274158444, 9.310546347, 9.149727335,
      9.162868636, 9.18043786, 9.201760726, 9.223083507, 9.244406197,
      9.265728791, 9.287051284, 9.306196469, 9.316319227, 8.985484051,
      8.981957122, 8.974819984, 8.970236411, 8.965652844, 8.961069282,
      8.956485726, 8.951902176, 8.947318631, 8.942735091, 8.802058724,
      8.787457378, 8.772856212, 8.753859822, 8.742031154, 8.718039075,
      8.700913953, 8.685407618, 8.669901492, 8.654395575, 8.638889865,
      8.619722753, 8.607207176, 8.582590166, 8.563581063, 8.547171278,
      8.530761734, 8.514352428, 8.49794336, 8.480062312, 8.442461108,
      8.422461073, 8.404245456, 8.386030159, 8.367815181, 8.349600519,
      8.331310581, 8.304640175, 8.282137149, 8.263021395, 8.316877123,
      8.303187768, 8.28610614, 8.275007087, 8.251937594, 8.24045034, 8.22105613,
      8.206461406, 8.191866838, 8.177272424, 8.09008038, 8.069922126, 8.04951261,
      8.024975901, 8.008377769, 7.979980717, 7.954892119, 7.933566003,
      7.912240177, 7.890914612, 8.001779028, 7.981933813, 7.9724259, 7.963061722,
      7.943587421, 7.932125243, 7.922446382, 7.912913791, 7.89586334,
      7.883756988, 7.79985889, 7.782211774, 7.764564665, 7.745861683,
      7.729188287, 7.705520844, 7.690970839, 7.664728614, 7.649873389,
      7.626987302, 7.739165962, 7.730769761, 7.722373546, 7.713977316,
      7.705581072, 7.697184811, 7.686745633, 7.679856247, 7.671805757,
      7.663409424, 7.60761586, 7.595508893, 7.583401863, 7.571294764,
      7.559187596, 7.547080353, 7.534973034, 7.522865634, 7.510476496,
      7.498628367, 7.467349969, 7.456380529, 7.435916572, 7.422541119,
      7.411325063, 7.394345267, 7.380386055, 7.366426669, 7.352467104,
      7.338507355, 7.441921882, 7.437248801, 7.430306812, 7.426386949,
      7.422526823, 7.418236208, 7.413563089, 7.408889963, 7.404216829,
      7.399543687, 7.277693985, 7.263733156, 7.249772108, 7.235810837,
      7.221849337, 7.207887609, 7.191634273, 7.179780911, 7.165818511,
      7.145981281, 7.250916389, 7.237438754, 7.231832945, 7.226227122, 7.2216753,
      7.217208543, 7.21280982, 7.208478103, 7.204212376, 7.200011642,
      7.095635884, 7.080595849, 7.069399046, 7.056360519, 7.037212849,
      7.02627145, 7.015495176, 7.003354179, 6.982733811, 6.971691313,
      7.055902258, 7.050296046, 7.044689823, 7.039866728, 7.035375771,
      7.028082427, 7.02247616, 7.016869881, 7.011263592, 7.005657291,
      6.884427256, 6.86953571, 6.85693186, 6.84501852, 6.825453971, 6.810561648,
      6.797616886, 6.780933712, 6.766040835, 6.750018358, 6.898935167,
      6.897528712, 6.896143771, 6.894780015, 6.893437121, 6.89211477,
      6.890812649, 6.889530448, 6.888267864, 6.887024596, 6.88580035,
      6.884594835, 6.883407765, 6.882238858, 6.881087836, 6.879954426,
      6.87883836, 6.877739372, 6.876657201, 6.87559159, 6.817077434, 6.812255394,
      6.807506797, 6.802830534, 6.798225508, 6.793690642, 6.789224874,
      6.781475301, 6.768799256, 6.763781483, 6.816194858, 6.815119128,
      6.81405986, 6.813016803, 6.811989708, 6.810978332, 6.809982434,
      6.809001778, 6.808036131, 6.807085263, 6.794682701, 6.793001024,
      6.791345063, 6.789714426, 6.777561165, 6.774754596, 6.772362801,
      6.771151392, 6.769995403, 6.768892309, 7.018766624, 7.035726503,
      7.052686849, 7.069647655, 7.086608912, 7.103570613, 7.120532751,
      7.137495318, 7.154458307, 7.17142171, 6.957913192, 6.957475101,
      6.957043718, 6.956618943, 6.956200672, 6.955788808, 6.955383251,
      6.954983906, 6.954590677, 6.95420347, 6.838625954, 6.830688874,
      6.822872175, 6.815174052, 6.807592726, 6.800126447, 6.781275695,
      6.773281055, 6.765407671, 6.757653727, 6.853364432, 6.852655347,
      6.851957118, 6.85126958, 6.850592567, 6.84992592, 6.84926948, 6.84862309,
      6.847986597, 6.84735985, 6.791648586, 6.785096082, 6.780761285,
      6.776492555, 6.77228889, 6.768149304, 6.764072826, 6.760058499,
      6.754637493, 6.75157086, 6.748247285, 6.744474286, 6.731383422,
      6.728094247, 6.724905207, 6.721813274, 6.718815511, 6.709179255,
      6.705069874, 6.698190337, 6.649213263, 6.632339469, 6.6264896, 6.620816895,
      6.603887648, 6.597973751, 6.592238944, 6.575259832, 6.569287242,
      6.563495507, 6.603509608, 6.600391602, 6.597368565, 6.589573266,
      6.587404922, 6.585335416, 6.58336028, 6.580054902, 6.568231236,
      6.566641569, 6.61769159, 6.61769159, 6.61769159, 6.61769159, 6.61769159,
      6.61769159, 6.61769159, 6.61769159, 6.61769159, 6.61769159, 6.566337735,
      6.566056046, 6.565794973, 6.557469839, 6.557944993, 6.558375455,
      6.55876551, 6.553625496, 6.554589042, 6.555448516, 6.817440845,
      6.835341595, 6.853243011, 6.868472182, 6.882620192, 6.896548848,
      6.91109011, 6.928046844, 6.945004094, 6.961961852, 6.7427128, 6.743059967,
      6.743369807, 6.74364634, 6.743893154, 6.744113449, 6.744310078,
      6.744485587, 6.744642247, 6.744782086, 6.748667292, 6.748625584,
      6.748584515, 6.748544075, 6.748504255, 6.748465045, 6.748426436,
      6.748388418, 6.748350983, 6.748314122, 6.748277825, 6.748242084,
      6.748206891, 6.748172238, 6.748138115, 6.748104515, 6.74807143,
      6.748038852, 6.748006773, 6.747975186, 6.747944082, 6.747913455,
      6.747883298, 6.747853602, 6.747824362, 6.74779557, 6.747767218,
      6.747739301, 6.747711812, 6.747684744, 6.747658091, 6.747631847,
      6.747606004, 6.747580557, 6.747555501, 6.747530828, 6.747506533,
      6.747482611, 6.747459055, 6.74743586, 7.365832815, 7.413436465,
      7.461050302, 7.508673871, 7.556306722, 7.603948409, 7.651598491,
      7.699256531, 7.746922093, 7.794594745, 7.558078632, 7.580038184,
      7.605576272, 7.631115269, 7.656655137, 7.682195841, 7.705497052,
      7.725694838, 7.745576292, 7.77009206, 7.655889321, 7.670017453,
      7.684145698, 7.698274056, 7.712402524, 7.726531101, 7.740659787,
      7.754788578, 7.768917474, 7.783046473, 8.240647845, 8.288371567,
      8.336098814, 8.383829394, 8.431563115, 8.479299782, 8.5270392, 8.57478117,
      8.622525491, 8.670271962, 8.718020379, 8.765770536, 8.813522226,
      8.861275242, 8.909029372, 8.956784406, 9.003646512, 9.050502189,
      9.097358242, 9.144214543, 9.191070965, 9.237927389, 9.284783697,
      9.331639776, 9.378495515, 9.425350801, 9.472205526, 9.519059578,
      9.565912844, 9.612765212, 9.659616562, 9.706466773, 9.75331572, 9.80016327,
      9.847009285, 9.893853619, 9.94222516, 9.979237518, 9.999307352,
      9.995571825, 9.4436341, 9.44267913, 9.44172416, 9.44076919, 9.43981422,
      9.43885925, 9.43790428, 9.43694931, 9.43599434, 9.43503937, 9.540498389,
      9.547203353, 9.553908309, 9.560613258, 9.567318199, 9.574023133,
      9.580728058, 9.587432976, 9.594137887, 9.600842789, 9.412813226,
      9.405192864, 9.397572532, 9.389952229, 9.382284633, 9.374708127,
      9.367087912, 9.359467726, 9.351847568, 9.34422744, 9.160759795,
      9.139913026, 9.106521808, 9.084736831, 9.051812773, 9.027806522,
      9.003141544, 8.972399832, 8.946744019, 8.923727054, 8.851417686,
      8.822663528, 8.786141045, 8.755341435, 8.719013247, 8.686571426,
      8.650066596, 8.616377737, 8.579332948, 8.544784117, 8.543869648,
      8.510954445, 8.474974832, 8.440824019, 8.405260361, 8.374470895,
      8.333396389, 8.301604261, 8.270821005, 8.227810468, 8.271708468,
      8.243289986, 8.216981778, 8.184788298, 8.151760476, 8.124559971,
      8.095999237, 8.062165472, 8.040079075, 8.006211666, 8.105036543,
      8.089380288, 8.063179887, 8.047848494, 8.020719004, 8.005066942,
      7.982035785, 7.962546964, 7.946411652, 7.923828461, 7.939418337,
      7.923603687, 7.900522442, 7.886715663, 7.872706015, 7.847711019,
      7.833779478, 7.820057159, 7.794578836, 7.78052726, 7.853549987,
      7.843297141, 7.833835241, 7.825643114, 7.817575041, 7.802937046,
      7.792684163, 7.782431268, 7.772974774, 7.764778551, 7.709097943,
      7.690759617, 7.676802807, 7.663829529, 7.652664085, 7.641666944,
      7.621840767, 7.607739949, 7.59649822, 7.585425914, 7.566616678,
      7.551443644, 7.540128657, 7.528984172, 7.511141986, 7.494949452,
      7.483564098, 7.472350284, 7.455427596, 7.438265784, 7.473938144,
      7.465640904, 7.457469282, 7.437653102, 7.42897951, 7.420437159,
      7.412024093, 7.40373838, 7.395578117, 7.37579959, 7.343661943, 7.321903618,
      7.311282465, 7.300821543, 7.290518476, 7.276980774, 7.258453766,
      7.24786681, 7.237439589, 7.227169737, 7.146952534, 7.132518982,
      7.118301886, 7.100016767, 7.078574001, 7.064247601, 7.044318185,
      7.024227802, 7.009798154, 6.988328817, 7.023735536, 7.004912143,
      6.995002584, 6.982424927, 6.9664837, 6.948612805, 6.937593326, 6.925912203,
      6.908924379, 6.900263692, 6.926533515, 6.920106434, 6.902324919,
      6.895705644, 6.884962587, 6.871307679, 6.864362879, 6.858278729,
      6.844054463, 6.839586925, 6.789254731, 6.772074387, 6.754755758,
      6.748806157, 6.731627332, 6.722787866, 6.708104925, 6.693391623,
      6.685651471, 6.675491021, 6.831063204, 6.832000107, 6.832937009,
      6.833873912, 6.834810815, 6.835747718, 6.836684621, 6.837621524,
      6.838558427, 6.83949533, 6.716610314, 6.704613216, 6.703590463,
      6.693243276, 6.68571292, 6.688454432, 6.679446884, 6.673733724,
      6.676379255, 6.679637181, 6.957369098, 6.973380192, 6.989391699,
      7.005403612, 7.009033355, 7.024099107, 7.039165183, 7.054231577,
      7.069298286, 7.084365305, 6.811869479, 6.809409522, 6.809402339,
      6.811479192, 6.813950522, 6.819567566, 6.810624808, 6.810359942,
      6.810114245, 6.809886416, 6.862116529, 6.863053434, 6.863990339,
      6.864927244, 6.865864149, 6.866801055, 6.86773796, 6.868674866,
      6.869611771, 6.870548677, 7.245295998, 7.272930264, 7.302272687,
      7.331617256, 7.360963906, 7.377863699, 7.406257616, 7.434653244,
      7.463050526, 7.490610958, 7.76976181, 7.817437708, 7.865120061,
      7.912808441, 7.960502422, 8.008201576, 8.055905479, 8.103613808,
      8.151326374, 8.199042998, 8.246763495, 8.29448768, 8.342215365,
      8.389946358, 8.437680467, 8.485417498, 8.533157255, 8.580899537,
      8.628644145, 8.676390877, 8.724139528, 8.771889893, 8.819641765,
      8.867394935, 8.915149193, 8.962795864, 9.009651099, 9.056506832,
      9.103362924, 9.150219247, 8.858279671, 8.880539238, 8.899592275,
      8.911773186, 8.9330967, 8.954420192, 8.967017277, 8.983357588, 9.003745723,
      9.024133822, 8.874019414, 8.882316621, 8.890613824, 8.898911025,
      8.907208221, 8.915505415, 8.912663992, 8.918535681, 8.92557674,
      8.932949049, 8.761316187, 8.755818478, 8.750320777, 8.744823085,
      8.739325403, 8.733827729, 8.728330065, 8.722832409, 8.717334762,
      8.711837124, 8.793152083, 8.794071031, 8.794989978, 8.795908926,
      8.796827874, 8.797746821, 8.798665769, 8.799584717, 8.800503664,
      8.801422612, 8.715502215, 8.71000458, 8.704506955, 8.699009338,
      8.693511729, 8.68801413, 8.68251654, 8.677018958, 8.671521386, 8.666023822,
      9.074873363, 9.098299593, 9.109964274, 9.133160169, 9.143211475,
      9.165470492, 9.175183879, 9.195933486, 9.208574842, 9.224780781,
      9.509081587, 9.535101603, 9.546930392, 9.567326141, 9.578808815,
      9.599086001, 9.606790156, 9.62266071, 9.639125588, 9.641690158,
      9.723080632, 9.728289719, 9.731518388, 9.732771181, 9.732052622,
      9.729367218, 9.724719456, 9.7181138, 9.709835851, 9.699066692, 9.646318442,
      9.642472224, 9.637660588, 9.631884624, 9.625145419, 9.61744406, 9.60878163,
      9.599159209, 9.588577877, 9.577038711, 9.551935904, 9.550980927,
      9.55002595, 9.549070974, 9.535510485, 9.533601219, 9.531691954,
      9.529782689, 9.527873425, 9.525964161, 9.524054898, 9.522145635,
      9.520236373, 9.518327111, 9.51641785, 9.514508589, 9.512599328,
      9.510690069, 9.508780809, 9.50687155, 9.504962292, 9.503053034,
      9.501143776, 9.499234519, 9.497325262, 9.495416006, 9.49350675,
      9.491597495, 9.48968824, 9.487778986, 9.485869732, 9.483960479,
      9.482051226, 9.480141974, 9.478232722, 9.47632347, 9.474414219,
      9.472504969, 9.470595719, 9.468686469, 9.46677722, 9.464867971,
      9.462958723, 9.461049475, 9.459140228, 9.457230981, 9.455321735,
      9.453412489, 9.451503243, 9.449593998, 9.447684753, 9.445775509,
      9.443866266, 9.441957022, 9.44004778, 9.438138537, 9.436229295,
      9.434320054, 9.432410813, 9.430501573, 9.428592332, 9.426683093,
      9.424773854, 9.422864615, 9.420955377, 9.419046139, 9.417136901,
      9.415227664, 9.413318428, 9.411409192, 9.409499956, 9.407590721,
      9.405681486, 9.403772252, 9.401863018, 9.399953785, 9.398044552,
      9.396135319, 9.394226087, 9.392316856, 9.390407625, 9.388498394,
      9.386589163, 9.384679934, 9.382770704, 9.380861475, 9.378952247,
      9.377043018, 9.375133791, 9.373224563, 9.371315337, 9.36940611,
      9.367496884, 9.365587659, 9.363678434, 9.361769209, 9.359859985,
      9.357950761, 9.356041537, 9.354132314, 9.352223092, 9.35031387,
      9.348404648, 9.346495427, 9.344586206, 9.342676986, 9.340767766,
      9.338858546, 9.336949327, 9.335040108, 9.33313089, 9.331221672,
      9.329312455, 9.327403238, 9.325494021, 9.323584805, 9.321675589,
      9.319766374, 9.317857159, 9.315947944, 9.31403873, 9.312129517,
      9.310220303, 9.30831109, 9.306401878, 9.304492666, 9.302583454,
      9.300674243, 9.298765033, 9.296855822, 9.294946612, 9.293037403,
      9.291128194, 9.289218985, 9.287309777, 9.285400569, 9.283491361,
      9.281582154, 9.279672948, 9.277763742, 9.275854536, 9.27394533,
      9.272036125, 9.270126921, 9.268217717, 9.266308513, 9.264399309,
      9.262490106, 9.260580904, 9.258671702, 9.2567625, 9.254853299, 9.252944098,
      9.251034897, 9.249125697, 9.247216497, 9.245307298, 9.243398099,
      9.241488901, 9.239579702, 9.237670505, 9.235761307, 9.233904969,
      9.232069259, 9.230233549, 9.228397839, 9.22656213, 9.224726421,
      9.222890713, 9.221055005, 9.219219297, 9.21738359, 9.215547883,
      9.213712177, 9.211876471, 9.210040765, 9.20820506, 9.206369356,
      9.204533651, 9.202697947, 9.200862244, 9.19902654, 9.197190837,
      9.195355135, 9.193519433, 9.191683731, 9.18984803, 9.188012329,
      9.186176629, 9.184340929, 9.182505229, 9.18066953, 9.178833831,
      9.176998132, 9.175162434, 9.173326736, 9.171491039, 9.169655342,
      9.167819645, 9.165983949, 9.164148253, 9.162312558, 9.160476863,
      9.158641168, 9.156805474, 9.15496978, 9.153134086, 9.151298393, 9.1494627,
      9.147627008, 9.145791316, 9.143955624, 9.142119933, 9.140284242,
      9.138448552, 9.136612862, 9.134777172, 9.132941483, 9.131105794,
      9.129270105, 9.127434417, 9.125598729, 9.123763042, 9.121927355,
      9.120091668, 9.118255982, 9.116420296, 9.11458461, 9.112748925, 9.11091324,
      9.109077556, 9.107241872, 9.105406188, 9.103570505, 9.101734822,
      9.099899139, 9.098063457, 9.096227775, 9.094392094, 9.092556412,
      9.090720732, 9.088885051, 9.087049371, 9.085213692, 9.083378013,
      9.081542334, 9.079706655, 9.077870977, 9.076035299, 9.074199622,
      9.072363945, 9.070528268, 9.068692592, 9.066856916, 9.065021241,
      9.063185566, 9.061349891, 9.059514216, 9.057678542, 9.055842869,
      9.054007195, 9.052171522, 9.05033585, 9.048500177, 9.046664506,
      9.044828834, 9.042993163, 9.041157492, 9.039321822, 9.037486152,
      9.035650482, 9.033814813, 9.031979144, 9.030143475, 9.028307807,
      9.026472139, 9.024636471, 9.022800804, 9.020965137, 9.019129471,
      9.017293805, 9.015458139, 9.013622474, 9.011786809, 9.009951144,
      9.00811548, 9.006279816, 9.004444152, 9.002608489, 9.000772826,
      8.998937164, 8.997101502, 8.99526584, 8.993430178, 8.991594517,
      8.989758857, 8.987923196, 8.986087536, 8.984251877, 8.982416217,
      8.968206317, 8.965453952, 8.962701587, 8.959949224, 8.957196862,
      8.954444501, 8.951692141, 8.948939783, 8.936143961, 8.933369811,
      8.902158695, 8.884300587, 8.87174603, 8.858667318, 8.838991091,
      8.829251232, 8.810061496, 8.790686045, 8.778670396, 8.756279011,
      8.745310661, 8.722018651, 8.710141375, 8.685950347, 8.666843569,
      8.647607733, 8.621617879, 8.607018698, 8.580134723, 8.560817302,
      8.610201082, 8.599233692, 8.579958283, 8.564422318, 8.55254625, 8.54067027,
      8.52879438, 8.508517966, 8.49218367, 8.479400002, 8.417731758, 8.391896037,
      8.37200624, 8.352339066, 8.326247355, 8.306894302, 8.285178235,
      8.258037434, 8.238922133, 8.207655852, 8.211972148, 8.193716517,
      8.170857222, 8.144826006, 8.125712806, 8.10142822, 8.074958747,
      8.054549135, 8.034139905, 8.012671863, 8.044531814, 8.031315814,
      8.008771416, 7.992044797, 7.975318317, 7.953995915, 7.940303867,
      7.914802537, 7.89519313, 7.877545738, 7.859898429, 7.842251187,
      7.820172063, 7.794644865, 7.778866293, 7.757725953, 7.739158247,
      7.720590519, 7.695527922, 7.680211262, 7.915165707, 7.91610266,
      7.917039614, 7.917976567, 7.918913521, 7.919850474, 7.920787428,
      7.921724381, 7.922661335, 7.923598289, 7.840258619, 7.834653835,
      7.829049048, 7.823444258, 7.817839466, 7.812234672, 7.806629874,
      7.801025073, 7.795420269, 7.789815461, 8.136409926, 8.157191064,
      8.167391078, 8.185181995, 8.205011465, 8.224841109, 8.24467092,
      8.264500893, 8.284331021, 8.291325115, 8.348734469, 8.370470566,
      8.379346375, 8.400129632, 8.420913021, 8.441696535, 8.462480165,
      8.473204106, 8.490402203, 8.510233643, 8.620536068, 8.634115961,
      8.659673816, 8.68494787, 8.704595156, 8.721737022, 8.745870687,
      8.770004401, 8.781143594, 8.804339884, 8.417066659, 8.410656053,
      8.40424546, 8.39783488, 8.391424314, 8.385013761, 8.378603221, 8.372192694,
      8.36578218, 8.35937168, 8.45089514, 8.451814088, 8.452733037, 8.453651985,
      8.454570933, 8.455489881, 8.45640883, 8.457327778, 8.458246726,
      8.459165674, 8.327304204, 8.320113511, 8.313031873, 8.299038831,
      8.289893069, 8.280747345, 8.272067336, 8.264805408, 8.257653597,
      8.24468694, 8.271840646, 8.265430336, 8.259020039, 8.252609755,
      8.246087138, 8.2395508, 8.233014474, 8.226478161, 8.21994186, 8.213405571,
      8.206869293, 8.200333026, 8.193796771, 8.187260526, 8.180724291,
      8.174188067, 8.167651853, 8.161115649, 8.154579454, 8.148043268,
      8.105350924, 8.096025761, 8.08783613, 8.080426023, 8.068367791,
      8.059042719, 8.049717667, 8.040392634, 8.031169103, 8.023691516,
      7.896212862, 7.874183589, 7.855615626, 7.837047749, 7.818479942,
      7.797994597, 7.771012478, 7.755481014, 7.730830974, 7.711343478,
      7.751496619, 7.732700672, 7.720498, 7.696570693, 7.683991684, 7.671601886,
      7.648341779, 7.634802002, 7.616911008, 7.601106891, 7.632377538,
      7.620608193, 7.601012161, 7.590794143, 7.580730364, 7.57081853,
      7.549228319, 7.538868895, 7.528665806, 7.5090504, 7.46059945, 7.43635658,
      7.423091874, 7.400319627, 7.38476232, 7.371353457, 7.350572006,
      7.333842284, 7.317112253, 7.300381903, 7.389266535, 7.380869152,
      7.372740469, 7.365977057, 7.359316291, 7.352756629, 7.346296552,
      7.339934563, 7.32410088, 7.315703143, 7.273292577, 7.264329678,
      7.250180566, 7.238997191, 7.227813702, 7.216709654, 7.207677409,
      7.194446524, 7.178077011, 7.168703967, 7.324376871, 7.325817334,
      7.327235686, 7.328632268, 7.332292534, 7.334167094, 7.336041655,
      7.337916216, 7.339790778, 7.341665339, 7.174206644, 7.164892122,
      7.155718466, 7.14668358, 7.137785399, 7.117382806, 7.1080026, 7.098764264,
      7.089665686, 7.080704786, 7.230766804, 7.232641344, 7.234515884,
      7.236390425, 7.238264967, 7.240139508, 7.242014051, 7.243888593,
      7.245763136, 7.247637679, 6.984339688, 6.966838834, 6.949137308,
      6.924509579, 6.908820969, 6.88178201, 6.865816165, 6.843102502,
      6.822582354, 6.806586042, 6.744643042, 6.723213968, 6.696211089,
      6.671793108, 6.645914938, 6.61990577, 6.59376957, 6.567510188, 6.541131353,
      6.514636681, 6.48802968, 6.461313749, 6.434492185, 6.407568186,
      6.380544854, 6.356989717, 6.326392618, 6.300782953, 6.27827525,
      6.244619154, 6.210440577, 6.187452703, 6.153014086, 6.12639169,
      6.094341124, 6.066403949, 6.036361865, 6.006273843, 5.976142516,
      5.94597035, 6.095176598, 6.082653936, 6.067010033, 6.059471054,
      6.049491551, 6.032999806, 6.028598398, 6.03250791, 6.031345612,
      6.036848337, 6.363973036, 6.378592113, 6.392985026, 6.407155293,
      6.423834462, 6.441112372, 6.458390769, 6.475669664, 6.492949065,
      6.510228981, 6.919121011, 6.967548231, 7.015987427, 7.064439141,
      7.112105992, 7.159647347, 7.207201429, 7.254767745, 7.302345813,
      7.349935154, 7.397535298, 7.445145784, 7.492766153, 7.540395953,
      7.588034738, 7.635682065, 7.683337495, 7.731000592, 7.778670925,
      7.826348061, 7.635848217, 7.665212642, 7.692678583, 7.7159599, 7.740000748,
      7.768412302, 7.796713793, 7.819323877, 7.840580423, 7.868038346,
      7.541550923, 7.542487866, 7.543424809, 7.544361752, 7.545298695,
      7.546235638, 7.547172582, 7.548109525, 7.549046468, 7.549983411,
      6.974114432, 6.930069525, 6.874302603, 6.82934529, 6.773275495,
      6.726875958, 6.680996478, 6.656549646, 6.597753885, 6.545549661,
      7.252575306, 7.265752922, 7.2789307, 7.292108637, 7.305286731, 7.318464979,
      7.331643379, 7.344821927, 7.3561546, 7.366536949, 7.221096729, 7.222033658,
      7.222970588, 7.223907518, 7.224844447, 7.225781377, 7.226718307,
      7.227655236, 7.228592166, 7.229529096, 7.844204102, 7.891889891,
      7.939581468, 7.987278405, 8.034980276, 8.08268669, 8.13039742, 8.178112286,
      8.225831107, 8.273553698, 8.130766431, 8.163987857, 8.191405758,
      8.217262429, 8.249525444, 8.269026073, 8.300329856, 8.331139364,
      8.350103526, 8.380449047, 8.372326731, 8.399796424, 8.421959605,
      8.441490925, 8.468004102, 8.485385171, 8.50747431, 8.533031362,
      8.558588612, 8.571230797, 8.80564112, 8.842841574, 8.869403702, 8.89879671,
      8.928414462, 8.956416756, 8.97979913, 9.014045111, 9.037562318,
      9.059009325, 9.001127474, 9.015005778, 9.041016704, 9.053934414,
      9.079006246, 9.091998607, 9.115171477, 9.139304863, 9.15029607, 9.17349182,
      9.525702263, 9.572555409, 9.600719805, 9.623165069, 9.642657127,
      9.658239791, 9.671888014, 9.696886531, 9.707626434, 9.716443407,
      9.53764892, 9.543553781, 9.548482044, 9.565795859, 9.569741995,
      9.586087556, 9.589053088, 9.597510345, 9.605920871, 9.606935434,
      9.620380907, 9.620419385, 9.63289966, 9.631963552, 9.630119999,
      9.640615277, 9.637738821, 9.647328053, 9.643481453, 9.652108481,
      9.528229323, 9.527532209, 9.526845769, 9.526169838, 9.525504257,
      9.524848867, 9.513699266, 9.512750688, 9.511831124, 9.510939689,
      9.510075523, 9.509237793, 9.508425693, 9.507638439, 9.506875273,
      9.506135459, 9.505418282, 9.504723052, 9.504049098, 9.50339577, 9.51634306,
      9.51634306, 9.51634306, 9.509552748, 9.50914163, 9.508736808, 9.508338186,
      9.50794567, 9.507559165, 9.50717858, 9.475533352, 9.473845793, 9.467244086,
      9.46604803, 9.464906656, 9.463817477, 9.450196042, 9.44882938, 9.447525149,
      9.445616175, 9.50978282, 9.511694904, 9.513606988, 9.515519072,
      9.517431156, 9.519343239, 9.521255323, 9.523167406, 9.525079489,
      9.52323966, 9.542064487, 9.544933692, 9.547802896, 9.537240884,
      9.539152965, 9.541065047, 9.542977128, 9.544889209, 9.54680129, 9.54871337,
      9.550625451, 9.552537531, 9.554449611, 9.556361691, 9.544834636,
      9.545790316, 9.546745996, 9.547701676, 9.548657356, 9.549613036,
      9.526133553, 9.525468527, 9.524813683, 9.524168866, 9.523533923,
      9.522908701, 9.522293053, 9.521686831, 9.521089892, 9.520502094,
      9.529342011, 9.529342011, 9.529342011, 9.529342011, 9.529342011,
      9.529342011, 9.529342011, 9.529342011, 9.529342011, 9.529342011,
      9.510504581, 9.509653725, 9.5088289, 9.50802931, 9.507254184, 9.498443055,
      9.49772132, 9.497032653, 9.496375545, 9.495748552, 9.457236121,
      9.457284188, 9.444741908, 9.441044266, 9.4294344, 9.42872679, 9.417295113,
      9.419842001, 9.408495649, 9.399251321, 9.560068617, 9.566773559,
      9.56074223, 9.565852586, 9.571597496, 9.577342401, 9.583087301,
      9.575401783, 9.58018739, 9.584972995, 9.603194411, 9.608939287,
      9.614684159, 9.606986736, 9.611772323, 9.603112025, 9.606939053,
      9.61076608, 9.601142913, 9.604012105, 9.566524261, 9.566524261,
      9.566524261, 9.566524261, 9.566524261, 9.566524261, 9.566524261,
      9.566524261, 9.566524261, 9.566524261, 9.562184089, 9.561921764,
      9.561663457, 9.561409107, 9.561158653, 9.560912036, 9.560669197,
      9.560430077, 9.560194621, 9.559962772, 9.556015638, 9.555680061,
      9.555354761, 9.555039424, 9.554733745, 9.554437427, 9.554150185,
      9.553871741, 9.553601825, 9.553340176, 9.550362772, 9.550119226,
      9.549886864, 9.549665172, 9.549453661, 9.549251864, 9.547005787,
      9.546886769, 9.54677503, 9.546670125, 9.566396504, 9.567352183,
      9.568307863, 9.569263542, 9.570219222, 9.571174901, 9.558681182,
      9.558681182, 9.558681182, 9.558681182, 9.553174139, 9.55292559,
      9.552684655, 9.552451099, 9.552224698, 9.552005232, 9.551792488,
      9.551586262, 9.549239952, 9.549047969, 9.548864804, 9.548690052,
      9.548523327, 9.54836426, 9.548212499, 9.548067711, 9.547929573,
      9.547797782, 9.546331484, 9.546253717, 9.564352145, 9.565307825,
      9.566263504, 9.567219184, 9.568174863, 9.569130543, 9.556637592,
      9.556637592, 9.556637592, 9.556637592, 9.55195715, 9.551745879, 9.55154108,
      9.551342555, 9.551150112, 9.550963563, 9.55078273, 9.550607436,
      9.550437513, 9.550272795, 9.550113123, 9.549958343, 9.549808305,
      9.549662864, 9.549521878, 9.549385212, 9.549252733, 9.549124313,
      9.548999827, 9.548879155, 9.543739922, 9.543861558, 9.543971991,
      9.543132171, 9.543339221, 9.542774834, 9.543055238, 9.542724481,
      9.542549627, 9.5429346, 9.542904058, 9.543267766, 9.543570162, 9.543616669,
      9.543882391, 9.544099249, 9.54427623, 9.544329762, 9.544475571,
      9.544592334, 9.693180736, 9.690284406, 9.699873502, 9.696007081,
      9.704633996, 9.69979895, 9.707464422, 9.701662213, 9.694896805,
      9.700641591, 9.706386372, 9.712131146, 9.704397175, 9.695702171,
      9.686047209, 9.67543336, 9.681535755, 9.673496297, 9.664245477,
      9.664498849, 9.65856414, 9.6556947, 9.6556947, 9.6556947, 9.6556947,
      9.6556947, 9.6556947, 9.6556947, 9.6556947, 9.6556947, 9.661776512,
      9.662021032, 9.662258054, 9.662487808, 9.662710517, 9.662926398,
      9.66313566, 9.663338505, 9.663535131, 9.663725729, 9.704371827,
      9.707720349, 9.709693704, 9.710115162, 9.698835527, 9.70074759, 9.72708338,
      9.740577981, 9.74958521, 9.758687291, 9.770706592, 9.769078311, 9.78968837,
      9.800513119, 9.807599039, 9.809875747, 9.812046401, 9.81239237, 9.81075287,
      9.819935764, 9.817211173, 9.814776866, 9.812602105, 9.81744233,
      9.814628142, 9.817380732, 9.814221331, 9.815379068, 9.815461445,
      9.814654828, 9.802015395, 9.799130071, 9.796879971, 9.795069068,
      9.792090126, 9.790800148, 9.78955645, 9.788296721, 9.788296721,
      9.788296721, 9.788296721, 9.788296721, 9.788296721, 9.788296721,
      9.788296721, 9.775611148, 9.736600419, 9.707416523, 9.667038653,
      9.629975574, 9.758937012, 9.758937012, 9.746261552, 9.719956303,
      9.704419176, 9.687930368, 9.667560337, 9.639212204, 9.618924433,
      9.597690022, 9.575510001, 9.539728961, 9.514714237, 9.488758098,
      9.46186163, 9.42138897, 9.391672023, 9.361019161, 9.329431536, 9.284299911,
      9.475275187, 9.458320227, 9.439051898, 9.431431432, 9.411218541,
      9.390059364, 9.38054084, 9.358439977, 9.33539499, 9.32398135, 9.312567809,
      9.301154365, 9.277179232, 9.252262232, 9.238956762, 9.213104094,
      9.193028038, 9.171625978, 9.14390094, 9.127763435, 9.149182434,
      9.135878095, 9.110065178, 9.095816226, 9.069069518, 9.054382571,
      9.027309932, 9.011798879, 8.983832413, 8.963861383, 8.801430405,
      8.761771232, 8.721228598, 8.69221209, 8.650800713, 8.608508728,
      8.565337526, 8.527133573, 8.489135869, 8.444225905, 8.546247823,
      8.510315086, 8.485792094, 8.448983273, 8.420996412, 8.385691711,
      8.355302816, 8.320521552, 8.281083704, 8.252982928, 8.212676837,
      8.183684614, 8.142512359, 8.112629844, 8.07059354, 8.028160541,
      7.996054908, 7.952281732, 7.919733838, 7.874552211, 8.021633188,
      7.989154723, 7.96782808, 7.946501775, 7.913134046, 7.890890918,
      7.867585943, 7.834311308, 7.811152389, 7.787993666, 7.848706077,
      7.831980321, 7.815034476, 7.789634334, 7.769144624, 7.75149751,
      7.733850377, 7.709264455, 7.686095387, 7.6675275, 7.779902891, 7.771506748,
      7.758436173, 7.742455134, 7.733130136, 7.72380512, 7.714480086,
      7.705155032, 7.695829957, 7.682592898, 7.510776111, 7.479006665,
      7.453699686, 7.430538639, 7.399604394, 7.371792436, 7.34771371,
      7.323634276, 7.287771936, 7.262775525, 7.402426442, 7.389819579,
      7.368269733, 7.35353162, 7.340496857, 7.327461937, 7.314426855,
      7.301391607, 7.281819952, 7.263089672, 7.249128614, 7.235167332,
      7.221205822, 7.207244083, 7.191114552, 7.168021169, 7.152627428,
      7.137740064, 7.122852439, 7.107964557, 7.16295255, 7.146936014,
      7.138960157, 7.122413512, 7.112156693, 7.101899795, 7.09164282,
      7.081385768, 7.07112864, 7.058066451, 7.072794543, 7.054341363,
      7.046842219, 7.035148207, 7.025819456, 7.016490651, 7.007161793,
      6.997832882, 6.988503919, 6.979174905, 6.94027874, 6.923440161,
      6.911326531, 6.899212792, 6.887098946, 6.874984994, 6.862870937,
      6.848816461, 6.827342105, 6.816798631, 6.824175928, 6.812988912,
      6.801801821, 6.790614655, 6.779427416, 6.768240104, 6.75705272,
      6.742940201, 6.733673287, 6.713064874, 6.676749044, 6.662780406,
      6.64881164, 6.634842749, 6.620873736, 6.600775366, 6.580991775,
      6.566096758, 6.551201604, 6.536306316, 6.620597714, 6.605959069,
      6.598488821, 6.591018558, 6.583548279, 6.576077985, 6.568607676,
      6.561137353, 6.553667014, 6.546196661, 6.561515809, 6.555908838,
      6.550301861, 6.544694878, 6.539087889, 6.533480894, 6.521618566,
      6.516641314, 6.511739876, 6.498416571, 6.57148883, 6.57148883, 6.57148883,
      6.57148883, 6.57148883, 6.57148883, 6.57148883, 6.57148883, 6.57148883,
      6.57148883, 6.57148883, 6.57148883, 6.57148883, 6.57148883, 6.57148883,
      6.57148883, 6.57148883, 6.57148883, 6.57148883, 6.57148883, 6.57148883,
      6.57148883, 6.57148883, 6.57148883, 6.57148883, 6.57148883, 6.57148883,
      6.57148883, 6.57148883, 6.57148883, 6.469131374, 6.460730203, 6.452329015,
      6.443927809, 6.435526587, 6.427125348, 6.418724092, 6.408274191,
      6.401301358, 6.393314602, 6.37625516, 6.368677305, 6.355143461, 6.34562474,
      6.336105998, 6.326587234, 6.317068448, 6.307549639, 6.298030807,
      6.288511951, 6.392162674, 6.392162674, 6.392162674, 6.392162674,
      6.392162674, 6.392162674, 6.392162674, 6.392162674, 6.392162674,
      6.392162674, 6.392162674, 6.392162674, 6.392162674, 6.392162674,
      6.392162674, 6.392162674, 6.392162674, 6.392162674, 6.392162674,
      6.392162674, 6.392162674, 6.392162674, 6.392162674, 6.392162674,
      6.392162674, 6.392162674, 6.392162674, 6.392162674, 6.392162674,
      6.392162674, 6.477993465, 6.484693986, 6.491394541, 6.49809513,
      6.508848602, 6.514487801, 6.520040188, 6.525525542, 6.53222631,
      6.548553541, 6.460410491, 6.460410491, 6.460410491, 6.460410491,
      6.460410491, 6.460410491, 6.460410491, 6.460410491, 6.460410491,
      6.460410491, 6.460410491, 6.460410491, 6.460410491, 6.460410491,
      6.45660771, 6.456345702, 6.456087707, 6.455833665, 6.455583514,
      6.455337195, 6.458560731, 6.458560731, 6.458560731, 6.458560731,
      6.458560731, 6.458560731, 6.458560731, 6.458560731, 6.458560731,
      6.458560731, 6.45509465, 6.446927999, 6.445973023, 6.445018048,
      6.444063072, 6.443108096, 6.44215312, 6.441198144, 6.440243169,
      6.439288193, 6.268268344, 6.253071368, 6.2378743, 6.217836942, 6.205084326,
      6.181214276, 6.164326367, 6.148184739, 6.132042977, 6.115901076,
      6.167444823, 6.156977448, 6.146510032, 6.136042575, 6.125575076,
      6.115107534, 6.104639949, 6.094172319, 6.080574716, 6.071787038,
      6.152352967, 6.149490035, 6.146627102, 6.143764168, 6.140901233,
      6.138038298, 6.135175361, 6.132312423, 6.129449484, 6.126586544,
      5.955220815, 5.935891489, 5.920856686, 5.89653496, 5.874859705,
      5.856828574, 5.838797154, 5.820765438, 5.802733419, 5.78470109,
      5.978927589, 5.978927589, 5.978927589, 5.978927589, 5.978927589,
      5.978927589, 5.978927589, 5.978927589, 5.978927589, 5.978927589,
      5.833697647, 5.821333801, 5.80896985, 5.796439454, 5.784227447,
      5.771863169, 5.754849926, 5.744381169, 5.723034281, 5.71201038,
      5.852406852, 5.852406852, 5.852406852, 5.852406852, 5.852406852,
      5.852406852, 5.852406852, 5.852406852, 5.852406852, 5.852406852,
      5.796763959, 5.791995375, 5.787226784, 5.782458187, 5.777689583,
      5.772920971, 5.768152353, 5.763383727, 5.758615094, 5.753846455,
      5.749077808, 5.744309153, 5.739540492, 5.734771823, 5.730003147,
      5.720415731, 5.7161584, 5.711966014, 5.707837589, 5.703772152, 5.815714857,
      5.819546715, 5.823319697, 5.830122663, 5.834904882, 5.839687107,
      5.844469338, 5.849251573, 5.854033814, 5.858816061, 5.803047794,
      5.803047794, 5.803047794, 5.803047794, 5.803047794, 5.803047794,
      5.803047794, 5.803047794, 5.803047794, 5.803047794, 5.803047794,
      5.803047794, 5.803047794, 5.803047794, 5.803047794, 5.803047794,
      5.803047794, 5.803047794, 5.803047794, 5.803047794, 5.803047794,
      5.803047794, 5.803047794, 5.803047794, 5.803047794, 5.803047794,
      5.803047794, 5.803047794, 5.803047794, 5.803047794, 5.803047794,
      5.803047794, 5.803047794, 5.803047794, 5.803047794, 5.803047794,
      5.803047794, 5.803047794, 5.803047794, 5.803047794, 5.683132289,
      5.674696873, 5.6604291, 5.649958857, 5.639488534, 5.62901813, 5.618547645,
      5.608077077, 5.597606426, 5.58399519, 5.698248216, 5.698248216,
      5.698248216, 5.698248216, 5.698248216, 5.698248216, 5.698248216,
      5.698248216, 5.698248216, 5.698248216, 5.698248216, 5.698248216,
      5.698248216, 5.698248216, 5.698248216, 5.698248216, 5.698248216,
      5.698248216, 5.698248216, 5.698248216, 5.698248216, 5.698248216,
      5.698248216, 5.698248216, 5.698248216, 5.698248216, 5.698248216,
      5.698248216, 5.698248216, 5.698248216, 5.698248216, 5.698248216,
      5.698248216, 5.698248216, 5.698248216, 5.698248216, 5.698248216,
      5.698248216, 5.698248216, 5.698248216, 5.758675952, 5.7634581, 5.768240253,
      5.773022411, 5.777804572, 5.782586739, 5.78736891, 5.792151085,
      5.796933266, 5.804133969, 5.746205253, 5.746205253, 5.746205253,
      5.746205253, 5.746205253, 5.746205253, 5.746205253, 5.746205253,
      5.746205253, 5.746205253, 5.746205253, 5.746205253, 5.746205253,
      5.746205253, 5.746205253, 5.746205253, 5.746205253, 5.746205253,
      5.746205253, 5.746205253, 5.746205253, 5.746205253, 5.746205253,
      5.746205253, 5.746205253, 5.746205253, 5.746205253, 5.746205253,
      5.746205253, 5.746205253, 5.746205253, 5.746205253, 5.746205253,
      5.746205253, 5.746205253, 5.746205253, 5.746205253, 5.746205253,
      5.746205253, 5.746205253, 5.746205253, 5.746205253, 5.746205253,
      5.746205253, 5.746205253, 5.746205253, 5.746205253, 5.746205253,
      5.746205253, 5.746205253, 5.624179386, 5.613708863, 5.597222547,
      5.588197475, 5.579309354, 5.559703141, 5.550097212, 5.540840619,
      5.531724462, 5.515008561, 5.636279056, 5.636279056, 5.636279056,
      5.636279056, 5.636279056, 5.636279056, 5.636279056, 5.636279056,
      5.636279056, 5.636279056, 5.592049027, 5.588232653, 5.584482921,
      5.581348772, 5.578262497, 5.573158647, 5.569342251, 5.565525851,
      5.561709447, 5.557893038, 5.598258017, 5.598258017, 5.598258017,
      5.598258017, 5.598258017, 5.598258017, 5.598258017, 5.598258017,
      5.598258017, 5.598258017, 5.598258017, 5.598258017, 5.598258017,
      5.598258017, 5.598258017, 5.598258017, 5.598258017, 5.598258017,
      5.598258017, 5.598258017, 5.471162369, 5.462156848, 5.443980198,
      5.432858832, 5.423169182, 5.413474671, 5.397642318, 5.385743799,
      5.373148022, 5.361883745, 5.438223209, 5.434247431, 5.430271649,
      5.420666198, 5.416945595, 5.413281818, 5.409674, 5.406121291, 5.402622852,
      5.389387184, 5.439504608, 5.439504608, 5.439504608, 5.439504608,
      5.439504608, 5.439504608, 5.439504608, 5.439504608, 5.439504608,
      5.439504608, 5.439504608, 5.439504608, 5.439504608, 5.439504608,
      5.439504608, 5.439504608, 5.439504608, 5.439504608, 5.439504608,
      5.439504608, 5.957124594, 5.99234023, 6.039072278, 6.072739442,
      6.113193841, 6.153704434, 6.194217198, 6.234732428, 6.272672788,
      6.30523162, 5.858331892, 5.859287441, 5.86024299, 5.861198538, 5.862154087,
      5.863109636, 5.864065185, 5.865020734, 5.865976283, 5.866931832,
      5.855764729, 5.855764729, 5.855764729, 5.855764729, 5.855764729,
      5.855764729, 5.855764729, 5.855764729, 5.855764729, 5.855764729,
      5.793026367, 5.788612587, 5.784266124, 5.779985957, 5.77577108,
      5.762925846, 5.757205422, 5.751484985, 5.746405214, 5.741751516,
      5.670500042, 5.661309693, 5.645640317, 5.631778982, 5.62222976,
      5.612825344, 5.599869916, 5.583096708, 5.573339679, 5.563730581,
      5.532119898, 5.510175196, 5.498687438, 5.487373504, 5.476230802,
      5.454205122, 5.442619888, 5.431209947, 5.408934344, 5.397049653,
      5.473188313, 5.456627945, 5.450377139, 5.444221566, 5.438159786,
      5.432190378, 5.426311944, 5.420523107, 5.414822509, 5.398178765,
      5.492527962, 5.493671503, 5.494797509, 5.495906249, 5.496997988,
      5.498072986, 5.499131501, 5.500173785, 5.501200088, 5.504954233,
      5.488857254, 5.488857254, 5.488857254, 5.488857254, 5.488857254,
      5.488857254, 5.488857254, 5.488857254, 5.488857254, 5.488857254,
      5.491332056, 5.491498383, 5.491662161, 5.491823429, 5.491982226,
      5.492138589, 5.492292556, 5.492444164, 5.492593448, 5.492740444,
      5.448575508, 5.445420741, 5.442314182, 5.432075066, 5.429253353,
      5.426517789, 5.423865754, 5.421294707, 5.418802184, 5.416385795,
      5.452173221, 5.452173221, 5.452173221, 5.452173221, 5.452173221,
      5.452173221, 5.452173221, 5.452173221, 5.452173221, 5.452173221,
      5.452173221, 5.452173221, 5.452173221, 5.452173221, 5.452173221,
      5.452173221, 5.452173221, 5.452173221, 5.452173221, 5.452173221,
      5.452173221, 5.452173221, 5.452173221, 5.452173221, 5.452173221,
      5.452173221, 5.452173221, 5.452173221, 5.452173221, 5.452173221,
      5.452173221, 5.452173221, 5.452173221, 5.452173221, 5.452173221,
      5.452173221, 5.452173221, 5.452173221, 5.452173221, 5.452173221,
      5.414043223, 5.409822976, 5.40810154, 5.396225234, 5.393506614,
      5.391463966, 5.389591966, 5.387805647, 5.386101106, 5.384474614,
      5.272818991, 5.255486034, 5.245967666, 5.230816665, 5.215604236,
      5.200334104, 5.191024063, 5.17805298, 5.165084029, 5.15211704, 5.143089755,
      5.127465348, 5.118921132, 5.109764975, 5.101483892, 5.103034919,
      5.110153976, 5.112585638, 5.13447017, 5.148970593, 5.159755615, 5.16465911,
      5.168977901, 5.171840544, 5.173738061, 5.174995865, 5.175829635,
      5.176382327, 5.176748699, 5.176991563, 5.705250416, 5.749430468,
      5.789408964, 5.837223501, 5.873290796, 5.913089017, 5.956274882,
      5.999463313, 6.038633206, 6.084226671, 5.474358721, 5.462938699,
      5.451518554, 5.440098283, 5.428669271, 5.416771087, 5.410867053,
      5.40455523, 5.393644938, 5.382734547, 6.096140036, 6.145947795,
      6.194258712, 6.242572601, 6.290890057, 6.339211674, 6.387538037,
      6.435869728, 6.484207322, 6.532551387, 6.580902491, 6.629261194,
      6.677628054, 6.726003624, 5.602607657, 5.555678792, 5.508744994,
      5.461805925, 5.414861243, 5.367910601, 5.320953645, 5.273990013,
      5.22701934, 5.180041252, 5.133055368, 5.086061301, 5.039058656,
      5.401991766, 5.009402775, 5.006191814, 6.042650972, 6.092945827,
      6.142879789, 6.191190535, 6.239504217, 6.28782143, 6.336142765,
      6.384468809, 6.432800145, 6.481137346, 6.480925921, 6.520347886,
      6.557251066, 6.600725253, 6.644205657, 6.685496737, 6.72043304,
      6.761460245, 6.801333508, 6.835448593, 6.961501828, 7.0099395, 7.058389622,
      7.106171744, 7.153711475, 7.201263995, 7.248828811, 7.296405438,
      7.343993397, 7.391592218, 7.439201438, 7.486820598, 7.534449245,
      7.582086933, 7.629733217, 7.677387659, 7.725049824, 7.772719276,
      7.820395587, 7.868078326, 7.915767067, 7.963461381, 8.011160842,
      8.058865026, 8.106573623, 8.154286447, 8.202003316, 8.249724048,
      8.297448455, 8.34517635, 8.195201316, 8.221965661, 8.25422881, 8.28649285,
      8.318757741, 8.349164994, 8.374650545, 8.401974518, 8.433281203,
      8.464588471, 7.472578843, 7.426774498, 7.380970489, 7.33516614,
      7.289360771, 7.243553702, 7.197744252, 7.151931739, 7.106115484,
      7.060294807, 8.198527714, 8.281815041, 8.329541815, 8.377271948,
      8.425005249, 8.472741523, 8.520480575, 8.568222206, 8.615966216,
      8.663712404, 8.711460566, 8.759210496, 8.806961988, 8.854714834,
      8.902468823, 8.950223746, 8.997209489, 9.044065103, 9.090921113,
      9.137777387, 7.924522998, 7.879584511, 7.834650849, 7.789721968,
      7.744667159, 7.698847112, 7.653031322, 7.607219146, 7.561409933,
      7.515603022, 8.711460566, 8.759210496, 8.806961988, 8.854714834,
      8.902468823, 8.950223746, 8.997209489, 9.044065103, 9.090921113,
      9.137777387, 8.911094318, 8.938045096, 8.964995864, 8.98359083,
      9.005234151, 9.031245095, 9.057255985, 9.070167172, 9.095238959,
      9.120310667, 9.447364232, 9.494218654, 9.541072351, 9.576042865,
      9.612100657, 9.647578323, 9.682485532, 9.714738478, 9.744497502,
      9.773286864, 9.52169465, 9.528766901, 9.54897257, 9.569195264, 9.589417806,
      8.703005626, 8.858503512, 9.282042263, 9.249387662, 9.251619661,
      9.851118975, 9.881498594, 9.910872942, 9.935117122, 9.953622822,
      9.970825971, 9.825073606, 9.984311159, 9.920814209, 9.993260447,
      9.928845157, 9.951526898, 9.961176041, 9.931775521, 9.654295079,
      9.692621986, 9.964028679, 9.975215006, 9.984985213, 9.803056147,
      9.645875166, 9.730149841, 9.739524506, 9.740567578, 9.729762237,
      9.738490255, 9.739595115, 9.73973498, 9.739752686, 9.739754927,
      9.882038677, 9.73309787, 9.739924723, 9.738670859, 9.747316516,
      9.737612246, 9.73670422, 9.893572956, 9.864044923, 9.843553754,
      9.872500571, 9.849790087, 9.828231572, 9.815400745, 9.807479455,
      9.802396178, 9.79795396, 9.795709205, 9.793945135, 9.791655478,
      9.778250159, 9.777295166, 9.776340174, 9.775385181, 9.772938976,
      9.760678131, 9.758768803, 9.756859476, 9.754950149, 9.753040823,
      9.751131497, 9.749222172, 9.747312848, 9.745403524, 9.7434942, 9.741584878,
      9.739675555, 9.737766234, 9.735856913, 9.733947592, 9.732038272,
      9.730128953, 9.728219634, 9.726310316, 9.724400998, 9.722491681,
      9.720582365, 9.718673049, 9.716763733, 9.714854418, 9.700276799,
      9.697413824, 9.694550851, 9.69168788, 9.68882491, 9.685961943, 9.683098977,
      9.670393228, 9.66752214, 9.664694907, 9.65692876, 9.646213858, 9.636122125,
      9.631353889, 9.626585661, 9.621817442, 9.617049231, 9.611112703,
      9.594780081, 9.589060279, 9.58334049, 9.577620716, 9.571900956,
      9.559173278, 9.554194771, 9.541149875, 9.534479267, 9.52780868,
      9.521138114, 9.51446757, 9.457324217, 9.434242601, 9.422828076,
      9.398807437, 9.38539385, 9.361408851, 9.348102097, 9.322207956, 9.30795628,
      9.28112768, 9.278503432, 9.257726641, 9.236947244, 9.221295951,
      9.193973167, 9.177834849, 9.14915926, 9.132078589, 9.106005442,
      9.084718823, 9.066697017, 9.03806038, 9.017410286, 8.99621103, 8.968274924,
      8.949144923, 8.917566294, 8.897534324, 8.869913445, 8.844491432,
      8.874322198, 8.855984826, 8.838665484, 8.820857023, 8.794728635,
      8.773611066, 8.755388976, 8.73716724, 8.712448232, 8.687895308,
      8.705799296, 8.681817388, 8.668366906, 8.643383586, 8.62606794,
      8.608752583, 8.589294963, 8.573963992, 8.549410327, 8.526520431,
      8.471492402, 8.450569358, 8.426243482, 8.397194909, 8.374478615,
      8.35265732, 8.330836577, 8.303507982, 8.27459012, 8.251871752, 8.188843601,
      8.15476704, 8.128462034, 8.090162004, 8.062828383, 8.034798131,
      8.001012114, 7.96845175, 7.939805418, 7.908877664, 7.873761917,
      7.840988337, 7.802587888, 7.769177283, 7.738715058, 7.705590579,
      7.669043373, 7.634496755, 7.59505189, 7.559190547, 7.662811963,
      7.636253371, 7.615462071, 7.591881795, 7.569639276, 7.547396522,
      7.520298058, 7.502115701, 7.472353724, 7.445552306, 7.411676352,
      7.386570287, 7.362491971, 7.338412978, 7.310636975, 7.289962354,
      7.259856586, 7.22956755, 7.208186825, 7.179854187, 7.213479134,
      7.193063961, 7.170364379, 7.152050542, 7.125579086, 7.108715763,
      7.080430697, 7.063326523, 7.046477733, 7.018232864, 6.901628818,
      6.872957343, 6.838475322, 6.803542589, 6.773952819, 6.743935903,
      6.70841959, 6.68408959, 6.648574357, 6.613348784, 6.62256543, 6.5900415,
      6.562267672, 6.532431965, 6.506550617, 6.47582363, 6.441665176,
      6.418560517, 6.384363947, 6.354166626, 6.383570711, 6.364066896,
      6.334842364, 6.31388091, 6.286867632, 6.263541962, 6.238698725,
      6.213052461, 6.193186226, 6.161960925, 6.186940995, 6.158631941,
      6.141136113, 6.123902852, 6.095626175, 6.078139248, 6.059679095,
      6.032584633, 6.015107036, 5.986627584, 5.968902901, 5.951444133,
      5.92300604, 5.905299164, 5.876631808, 5.858683945, 5.841005273, 5.8123885,
      5.794467529, 5.772469999, 5.703222989, 5.675277477, 5.649963381,
      5.620044268, 5.596318575, 5.564521233, 5.542305425, 5.519839211,
      5.488716283, 5.464352409, 5.569673643, 5.555631311, 5.53949189,
      5.529890799, 5.50950626, 5.495905011, 5.479239618, 5.469574221,
      5.449146608, 5.43944803, 5.418997768, 5.409267672, 5.389156697,
      5.378493997, 5.363043503, 5.347296446, 5.33704696, 5.318743797,
      5.300293816, 5.285091145, 5.27414647, 5.255767955, 5.241677039,
      5.229786541, 5.211468524, 5.195320142, 5.189257119, 5.168862517,
      5.155614147, 5.142705875, 5.131998515, 5.115552102, 5.10730036,
      5.097142705, 5.090823423, 5.096071002, 5.100995194, 5.116912856,
      5.137337114, 5.150870399, 5.459835149, 5.482830715, 5.505826978,
      5.528823909, 5.551821475, 5.574819645, 5.597818391, 5.620817681,
      5.643817485, 5.663542353, 5.280477451, 5.268577674, 5.256677769,
      5.244777737, 5.232877577, 5.220977291, 5.209076877, 5.197176336,
      5.185275669, 5.173374875, 5.569547895, 5.592546512, 5.61554568,
      5.638545368, 5.659242728, 5.677842978, 5.696155297, 5.716881407,
      5.738878405, 5.760875707, 5.484337084, 5.481354389, 5.478371692,
      5.475388993, 5.472406291, 5.469423588, 5.466440883, 5.463458176,
      5.460475467, 5.457492756, 5.752876655, 5.774874138, 5.796871886,
      5.818522945, 5.838151756, 5.855111748, 5.871808972, 5.889625785,
      5.909784551, 5.929943597, 5.423422748, 5.408067834, 5.384224748,
      5.375246547, 5.355919497, 5.337759272, 5.327825246, 5.315251089,
      5.305302668, 5.326452613, 5.947105517, 5.982460408, 6.019584001,
      6.05017198, 6.080267657, 6.11591597, 6.149047472, 6.177677952, 6.209823105,
      6.244506986, 6.448867003, 6.49720628, 6.545552183, 6.593905276,
      6.642266117, 6.690635265, 6.739013272, 6.787400687, 6.835798059,
      6.884205933, 6.932624852, 6.981055357, 7.02949799, 7.077830779,
      7.125362654, 7.172907608, 7.220465151, 7.268034793, 7.315616052,
      7.363208453, 7.410811528, 7.458424815, 7.506047859, 7.55368021,
      7.601321421, 7.648971052, 7.696628664, 7.744293822, 7.791966095,
      7.839645053, 7.611433738, 7.637928034, 7.664423311, 7.68209485,
      7.704173003, 7.729715165, 7.755258059, 7.780801656, 7.80634594, 7.81926429,
      7.886976267, 7.909611819, 7.937071727, 7.964532387, 7.99199378, 8.00910927,
      8.033448699, 8.059955048, 8.08646198, 8.112969477, 8.088989676,
      8.111246436, 8.133933574, 8.156621022, 8.17930877, 8.201996808,
      8.211894654, 8.233629472, 8.255364518, 8.277099781, 8.157769694,
      8.169061591, 8.168187096, 8.21642736, 8.229611623, 8.242795926,
      8.255980269, 8.26916465, 8.279904929, 8.282486726, 8.54444324, 8.570031936,
      8.600380855, 8.629723958, 8.648085674, 8.677475557, 8.70686564, 8.72310759,
      8.750903779, 8.778794742, 8.308184144, 8.299949365, 8.291714615,
      8.283479892, 8.275245196, 8.267010529, 8.246671245, 8.237525699,
      8.228380192, 8.219234721, 8.486302415, 8.4973787, 8.508454993, 8.519531294,
      8.530607601, 8.541683914, 8.552760233, 8.563836557, 8.574912887,
      8.585989221, 8.331973659, 8.323738801, 8.31550397, 8.307269167,
      8.299034392, 8.290799644, 8.285362743, 8.283848165, 8.278569731,
      8.27568236, 8.640870398, 8.653597772, 8.673051406, 8.692505068,
      8.711958754, 8.730654107, 8.745880736, 8.756903657, 8.77542361,
      8.793943568, 9.203457799, 9.250314203, 9.297170462, 9.344026462,
      9.390882091, 9.43773724, 9.484591798, 9.531445653, 9.578298693,
      9.625150803, 9.672001864, 9.718851754, 9.765700344, 9.812547502,
      9.832809556, 9.837828768, 9.841525521, 9.842213786, 9.839903843,
      9.847992661, 9.773700215, 9.771966277, 9.76826785, 9.762609407, 9.7549954,
      9.745430258, 9.733918389, 9.720464178, 9.705071991, 9.687746177,
      9.614649862, 9.616561935, 9.618474009, 9.606923632, 9.60787931,
      9.608834988, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.596327143, 9.596327143, 9.596327143, 9.596327143, 9.596327143,
      9.583708863, 9.582753884, 9.571810424, 9.56747095, 9.565561676,
      9.563652403, 9.553262865, 9.546578093, 9.543715213, 9.540852334,
      9.512767582, 9.49539033, 9.485575525, 9.471036571, 9.462845578,
      9.444980714, 9.437360224, 9.417145158, 9.40857529, 9.387417089,
      9.386238113, 9.36901088, 9.35897636, 9.338779147, 9.327001493, 9.309600834,
      9.292981191, 9.279170253, 9.257418674, 9.245059085, 9.270335524,
      9.255142709, 9.238331213, 9.22786564, 9.217400138, 9.197080657,
      9.188131751, 9.172161053, 9.160748753, 9.148580098, 9.101906554,
      9.086221046, 9.067029566, 9.04569377, 9.031089244, 9.01648492, 8.996325119,
      8.974422742, 8.958912502, 8.935032215, 8.976990602, 8.962587492,
      8.953035954, 8.931215386, 8.916146373, 8.903358837, 8.890571426,
      8.87778414, 8.855928489, 8.845271982, 8.825915178, 8.812220667,
      8.798526306, 8.784832093, 8.766632908, 8.744762708, 8.731593034,
      8.715667393, 8.701067099, 8.684614197, 8.659411671, 8.635997166,
      8.623236467, 8.599671395, 8.58326108, 8.566851007, 8.547022964,
      8.521527677, 8.507785509, 8.4871485, 8.51724464, 8.505020566, 8.48315802,
      8.471797898, 8.450722753, 8.436783862, 8.425219599, 8.407252773,
      8.392656026, 8.37805944, 8.363463016, 8.343013648, 8.331056753,
      8.307111953, 8.294793458, 8.276132908, 8.260632012, 8.245131305,
      8.229630787, 8.209024759, 8.222487712, 8.209717383, 8.19886679,
      8.181769704, 8.165172295, 8.153997811, 8.140117729, 8.11954585,
      8.107960444, 8.096549749, 8.121517572, 8.112671478, 8.097727273,
      8.086546789, 8.073975027, 8.064923629, 8.056009174, 8.042018783,
      8.026229238, 8.016975646, 8.019881958, 8.009701718, 7.99140913,
      7.982682284, 7.97408751, 7.965622833, 7.95693124, 7.937066079, 7.928236681,
      7.919540878, 7.851109291, 7.838964712, 7.815042753, 7.802520996,
      7.78138057, 7.76554958, 7.752852717, 7.734207981, 7.715725613, 7.702858574,
      7.749709015, 7.729039672, 7.719658454, 7.710419033, 7.701319297,
      7.683190267, 7.671077048, 7.661647808, 7.652361077, 7.643214729,
      7.717190543, 7.713556585, 7.709978024, 7.706454019, 7.696623151,
      7.693723374, 7.690911849, 7.680024098, 7.676024994, 7.67208682, 7.57269801,
      7.553394964, 7.541544256, 7.53130079, 7.518340311, 7.510662684,
      7.491413715, 7.479221898, 7.464069256, 7.456184958, 7.436761081,
      7.428775172, 7.409263415, 7.401188495, 7.383369606, 7.373521663,
      7.365601966, 7.346178588, 7.338161712, 7.318654931, 7.416074164,
      7.413341216, 7.402119312, 7.400063475, 7.398101229, 7.396228354,
      7.394440817, 7.381022391, 7.378999387, 7.377068499, 7.268176591,
      7.253568305, 7.23892565, 7.235941343, 7.221445839, 7.205629065,
      7.194598471, 7.184825949, 7.175018054, 7.161728606, 7.301895115,
      7.301895115, 7.301895115, 7.301895115, 7.301895115, 7.301895115,
      7.301895115, 7.301895115, 7.301895115, 7.301895115, 7.280216146,
      7.280683345, 7.281619765, 7.282893668, 7.284373902, 7.283655859,
      7.271609139, 7.270486491, 7.269398164, 7.268343111, 7.488081346,
      7.503155129, 7.51822909, 7.533303226, 7.548377531, 7.562418874,
      7.574346332, 7.586088526, 7.597648363, 7.609476938, 7.623604686,
      7.637732553, 7.651860537, 7.6665572, 7.680159279, 7.694287606, 7.717383977,
      7.736196528, 7.738308979, 7.768601141, 8.21085254, 8.258573967,
      8.306299035, 8.354027556, 8.401759339, 8.44949419, 8.497231914,
      8.544972313, 8.59271519, 8.640460343, 8.688207569, 8.735956663,
      8.783707421, 8.831459633, 8.879213092, 8.926967587, 8.974391569,
      9.021246941, 9.068102775, 9.114958937, 9.161815297, 9.208671734,
      9.255528128, 9.302384363, 9.349240327, 9.396095909, 9.442950997,
      9.489805482, 9.536659253, 9.583512195, 9.630364194, 9.677215131,
      9.724064882, 9.77091332, 9.81776031, 9.851311907, 9.844207228, 9.847896588,
      9.835215636, 9.818540452, 9.722740836, 9.714276708, 9.708659352,
      9.687674232, 9.677182672, 9.664746444, 9.636941632, 9.619667051,
      9.587028296, 9.564940721, 9.502309877, 9.50040062, 9.498491363,
      9.496582106, 9.49467285, 9.492763595, 9.49085434, 9.488945085, 9.487035831,
      9.485126577, 9.375121242, 9.350420659, 9.324399603, 9.29865672,
      9.272781287, 9.245966103, 9.218212294, 9.189520997, 9.159893364,
      9.129330555, 8.97311069, 8.91823983, 8.862085014, 8.797862462, 8.758599555,
      8.719047542, 8.679211123, 8.639094922, 8.598703487, 8.558041291,
      8.608379509, 8.566107297, 8.522956051, 8.478927182, 8.434022122,
      8.395846142, 8.363831887, 8.326337971, 8.287179473, 8.247731444,
      8.195758224, 8.155044727, 8.119235767, 8.073602682, 8.039766751,
      8.00254702, 7.960180179, 7.914081757, 7.87748001, 7.833187652, 7.809935888,
      7.775286493, 7.731980077, 7.693951202, 7.659104484, 7.612526603,
      7.574337653, 7.530475775, 7.489795908, 7.44787097, 7.388520913,
      7.340190683, 7.303406893, 7.254954797, 7.213199436, 7.169221477,
      7.120123473, 7.079223053, 7.033745265, 6.98562664, 6.95620536, 6.915457171,
      6.863037794, 6.821976597, 6.780954534, 6.728325523, 6.687009796,
      6.643114632, 6.598553043, 6.551499926, 6.499166137, 6.448879757,
      6.403164873, 6.351572062, 6.30913134, 6.268935385, 6.218381768,
      6.169549519, 6.118088325, 6.080101673, 6.047506619, 6.002654021,
      5.959339942, 5.915824858, 5.866362484, 5.820554425, 5.777267616,
      5.733170512, 5.683213985, 5.636142785, 5.613916019, 5.563667811,
      5.522967016, 5.47750064, 5.432000481, 5.380327781, 5.34277722, 5.296305785,
      5.256595509, 5.20071708, 5.204442136, 5.160662261, 5.120674322,
      5.072704722, 5.032977378, 5.011305032, 5.008622213, 5.008815382,
      5.00971382, 5.01047133, 5.009647075, 5.005767414, 5.002157484, 5.046025295,
      5.090385004, 5.119763104, 5.139225569, 5.152121825, 5.1521 };

    /* InitializeConditions for DiscreteFir: '<S42>/Generated Filter Block' */
    DCDCconverter_DWork.GeneratedFilterBlock_circBuf = 0;

    /* InitializeConditions for DiscreteFir: '<S45>/Generated Filter Block' */
    DCDCconverter_DWork.GeneratedFilterBlock_circBuf_c = 0;

    /* InitializeConditions for DiscreteFir: '<S48>/Generated Filter Block' */
    DCDCconverter_DWork.GeneratedFilterBlock_circBuf_d = 0;

    /* InitializeConditions for DiscreteFir: '<S51>/Generated Filter Block' */
    DCDCconverter_DWork.GeneratedFilterBlock_circBuf_cj = 0;

    /* InitializeConditions for DiscreteFir: '<S54>/Generated Filter Block' */
    DCDCconverter_DWork.GeneratedFilterBlock_circBuf_h = 0;
    for (i = 0; i < 73; i++) {
      /* InitializeConditions for DiscreteFir: '<S42>/Generated Filter Block' */
      DCDCconverter_DWork.GeneratedFilterBlock_states[i] =
        DCDCconverter_P.GeneratedFilterBlock_InitialSta;

      /* InitializeConditions for DiscreteFir: '<S45>/Generated Filter Block' */
      DCDCconverter_DWork.GeneratedFilterBlock_states_i[i] =
        DCDCconverter_P.GeneratedFilterBlock_InitialS_n;

      /* InitializeConditions for DiscreteFir: '<S48>/Generated Filter Block' */
      DCDCconverter_DWork.GeneratedFilterBlock_states_e[i] =
        DCDCconverter_P.GeneratedFilterBlock_InitialS_i;

      /* InitializeConditions for DiscreteFir: '<S51>/Generated Filter Block' */
      DCDCconverter_DWork.GeneratedFilterBlock_states_f[i] =
        DCDCconverter_P.GeneratedFilterBlock_InitialS_k;
      DCDCconverter_DWork.GeneratedFilterBlock_states_o[i] =
        DCDCconverter_P.GeneratedFilterBlock_InitialS_j;
    }

    /* End of InitializeConditions for DiscreteFir: '<S54>/Generated Filter Block' */

    /* InitializeConditions for Delay: '<Root>/Delay1' */
    for (i = 0; i < 10; i++) {
      DCDCconverter_DWork.Delay1_DSTATE[i] =
        DCDCconverter_P.Delay1_InitialCondition;
    }

    /* End of InitializeConditions for Delay: '<Root>/Delay1' */

    /* InitializeConditions for DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn3' */
    for (i = 0; i < 7; i++) {
      DCDCconverter_DWork.DiscreteTransferFcn3_states[i] =
        DCDCconverter_P.DiscreteTransferFcn3_InitialSta;
    }

    /* End of InitializeConditions for DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn3' */

    /* InitializeConditions for Delay: '<Root>/Delay3' */
    for (i = 0; i < 10; i++) {
      DCDCconverter_DWork.Delay3_DSTATE[i] =
        DCDCconverter_P.Delay3_InitialCondition;
    }

    /* End of InitializeConditions for Delay: '<Root>/Delay3' */

    /* InitializeConditions for Delay: '<S58>/Delay' */
    DCDCconverter_DWork.Delay_DSTATE = DCDCconverter_P.Delay_InitialCondition;

    /* InitializeConditions for DiscreteTransferFcn: '<Root>/Discrete Transfer Fcn' */
    DCDCconverter_DWork.DiscreteTransferFcn_states[0] =
      DCDCconverter_P.DiscreteTransferFcn_InitialStat;
    DCDCconverter_DWork.DiscreteTransferFcn_states[1] =
      DCDCconverter_P.DiscreteTransferFcn_InitialStat;
    DCDCconverter_DWork.DiscreteTransferFcn_states[2] =
      DCDCconverter_P.DiscreteTransferFcn_InitialStat;

    /* InitializeConditions for MATLAB Function: '<S34>/Current_Profile_1Hz' */
    memcpy(&DCDCconverter_DWork.profile[0], &tmp[0], 3739U * sizeof(real_T));
    DCDCconverter_DWork.last_time_not_empty = FALSE;
    DCDCconverter_DWork.profile_on_condition = 4.0;
    DCDCconverter_DWork.index = 0.0;
    DCDCconverter_DWork.period = 1.0;
    DCDCconverter_DWork.command = 0.0;

    /* InitializeConditions for MATLAB Function: '<S34>/Current_Profile_10Hz' */
    memcpy(&DCDCconverter_DWork.profile_i[0], &tmp_0[0], 39461U * sizeof(real_T));
    DCDCconverter_DWork.last_time_not_empty_l = FALSE;
    DCDCconverter_DWork.profile_on_condition_b = 5.0;
    DCDCconverter_DWork.index_d = 0.0;
    DCDCconverter_DWork.period_h = 0.1;
    DCDCconverter_DWork.command_d = 0.0;

    /* InitializeConditions for Chart: '<Root>/Supervisory Control State Machine' */
    DCDCconverter_DWork.is_active_c4_DCDCconverter = 0U;
    DCDCconverter_DWork.is_c4_DCDCconverter = DCDCconverte_IN_NO_ACTIVE_CHILD;
    DCDCconverter_DWork.delta_Voltage = 0.0;
    DCDCconverter_B.VoltageCommand = 0.0;
    DCDCconverter_B.EnableVoltageCommand = 0.0;

    /* InitializeConditions for DiscreteIntegrator: '<S27>/Discrete-Time Integrator' */
    DCDCconverter_DWork.DiscreteTimeIntegrator_DSTATE =
      DCDCconverter_P.DiscreteTimeIntegrator_IC;
    DCDCconverter_DWork.DiscreteTimeIntegrator_PrevRese = 2;

    /* InitializeConditions for Delay: '<Root>/Delay2' */
    for (i = 0; i < 10; i++) {
      DCDCconverter_DWork.Delay2_DSTATE[i] =
        DCDCconverter_P.Delay2_InitialCondition;
    }

    /* End of InitializeConditions for Delay: '<Root>/Delay2' */

    /* InitializeConditions for Memory: '<S26>/Memory3' */
    DCDCconverter_DWork.Memory3_PreviousInput = DCDCconverter_P.Memory3_X0;

    /* InitializeConditions for Memory: '<S26>/Memory1' */
    DCDCconverter_DWork.Memory1_PreviousInput = DCDCconverter_P.Memory1_X0;

    /* InitializeConditions for Memory: '<S26>/Memory2' */
    DCDCconverter_DWork.Memory2_PreviousInput = DCDCconverter_P.Memory2_X0;

    /* InitializeConditions for Memory: '<S26>/Memory4' */
    DCDCconverter_DWork.Memory4_PreviousInput = DCDCconverter_P.Memory4_X0;

    /* InitializeConditions for Memory: '<S26>/Memory5' */
    DCDCconverter_DWork.Memory5_PreviousInput = DCDCconverter_P.Memory5_X0;

    /* InitializeConditions for Delay: '<S25>/Delay' */
    DCDCconverter_DWork.Delay_DSTATE_n =
      DCDCconverter_P.Delay_InitialCondition_c;

    /* InitializeConditions for Memory: '<S25>/Memory3' */
    DCDCconverter_DWork.Memory3_PreviousInput_o = DCDCconverter_P.Memory3_X0_e;

    /* InitializeConditions for Delay: '<S25>/Delay2' */
    DCDCconverter_DWork.Delay2_DSTATE_d =
      DCDCconverter_P.Delay2_InitialCondition_k;

    /* InitializeConditions for Memory: '<S25>/Memory1' */
    DCDCconverter_DWork.Memory1_PreviousInput_c = DCDCconverter_P.Memory1_X0_m;

    /* InitializeConditions for Delay: '<S25>/Delay1' */
    DCDCconverter_DWork.Delay1_DSTATE_b =
      DCDCconverter_P.Delay1_InitialCondition_f;

    /* InitializeConditions for Memory: '<S25>/Memory2' */
    DCDCconverter_DWork.Memory2_PreviousInput_l = DCDCconverter_P.Memory2_X0_n;

    /* InitializeConditions for Delay: '<S25>/Delay3' */
    DCDCconverter_DWork.Delay3_DSTATE_b =
      DCDCconverter_P.Delay3_InitialCondition_i;

    /* InitializeConditions for Memory: '<S25>/Memory' */
    DCDCconverter_DWork.Memory_PreviousInput = DCDCconverter_P.Memory_X0;

    /* InitializeConditions for MATLAB Function: '<Root>/ErrorLatchingFunction' */
    DCDCconverter_DWork.LLBatCurrentAlert = 0.0;
    DCDCconverter_DWork.LLUCCurrentAlert = 0.0;
    DCDCconverter_DWork.LLBatVoltageAlert = 0.0;
    DCDCconverter_DWork.LLUCVoltageAlert = 0.0;
    DCDCconverter_DWork.LLTempAlert = 0.0;
    DCDCconverter_DWork.LLErrorHB1 = 0.0;
    DCDCconverter_DWork.LLErrorHB2 = 0.0;
    DCDCconverter_DWork.LLErrorHB3 = 0.0;
    DCDCconverter_DWork.LLOverTemp = 0.0;

    /* InitializeConditions for DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn1' */
    DCDCconverter_DWork.DiscreteTransferFcn1_states =
      DCDCconverter_P.DiscreteTransferFcn1_InitialSta;

    /* InitializeConditions for DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn2' */
    for (i = 0; i < 7; i++) {
      DCDCconverter_DWork.DiscreteTransferFcn2_states[i] =
        DCDCconverter_P.DiscreteTransferFcn2_InitialSta;
    }

    /* End of InitializeConditions for DiscreteTransferFcn: '<S31>/Discrete Transfer Fcn2' */

    /* InitializeConditions for Chart: '<Root>/System Configuration State Machine1' */
    DCDCconverter_DWork.is_active_c5_DCDCconverter = 0U;
    DCDCconverter_DWork.is_c5_DCDCconverter = DCDCconverte_IN_NO_ACTIVE_CHILD;
    DCDCconverter_DWork.dVrail_dT_threshold = 0.0;
    DCDCconverter_B.IGBT_Top_State = 0.0;
    DCDCconverter_B.IGBT_Bot_State = 0.0;
    DCDCconverter_B.AutomaticController = FALSE;
    DCDCconverter_B.UltracapacitorRelay = 0.0;
    DCDCconverter_B.ChargingRelay = 0.0;
    DCDCconverter_B.DischargingRelay = 0.0;
    DCDCconverter_B.BatteryRelay = 0.0;

    /* InitializeConditions for Delay: '<Root>/Delay4' */
    DCDCconverter_DWork.Delay4_DSTATE = DCDCconverter_P.Delay4_InitialCondition;
  }
}

/* Model terminate function */
void DCDCconverter_terminate(void)
{
  /* Terminate for S-Function (rti_commonblock): '<S23>/S-Function1' */

  /* dSPACE I/O Board DS1103 #1 Unit:PWM */
  ds1103_slave_dsp_pwm_output_set(0, SLVDSP1103_PWM_CH1_MSK,
    SLVDSP1103_PWM_TTL_LOW);

  /* flag = UNDEF */
  slaveDSPPwmStopFlagCh1 = 2;

  /* Terminate for S-Function (rti_commonblock): '<S23>/S-Function2' */

  /* dSPACE I/O Board DS1103 #1 Unit:PWM */
  ds1103_slave_dsp_pwm_output_set(0, SLVDSP1103_PWM_CH2_MSK,
    SLVDSP1103_PWM_TTL_LOW);

  /* flag = UNDEF */
  slaveDSPPwmStopFlagCh2 = 2;
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  if (tid == 1)
    tid = 0;
  DCDCconverter_output(tid);
}

void MdlUpdate(int_T tid)
{
  if (tid == 1)
    tid = 0;
  DCDCconverter_update(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  DCDCconverter_initialize();
}

void MdlTerminate(void)
{
  DCDCconverter_terminate();
}

RT_MODEL_DCDCconverter *DCDCconverter(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)DCDCconverter_M, 0,
                sizeof(RT_MODEL_DCDCconverter));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&DCDCconverter_M->solverInfo,
                          &DCDCconverter_M->Timing.simTimeStep);
    rtsiSetTPtr(&DCDCconverter_M->solverInfo, &rtmGetTPtr(DCDCconverter_M));
    rtsiSetStepSizePtr(&DCDCconverter_M->solverInfo,
                       &DCDCconverter_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&DCDCconverter_M->solverInfo, (&rtmGetErrorStatus
      (DCDCconverter_M)));
    rtsiSetRTModelPtr(&DCDCconverter_M->solverInfo, DCDCconverter_M);
  }

  rtsiSetSimTimeStep(&DCDCconverter_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&DCDCconverter_M->solverInfo,"FixedStepDiscrete");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = DCDCconverter_M->Timing.sampleTimeTaskIDArray;
    int_T i;
    for (i = 0; i < 5; i++) {
      mdlTsMap[i] = i;
    }

    DCDCconverter_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    DCDCconverter_M->Timing.sampleTimes =
      (&DCDCconverter_M->Timing.sampleTimesArray[0]);
    DCDCconverter_M->Timing.offsetTimes =
      (&DCDCconverter_M->Timing.offsetTimesArray[0]);

    /* task periods */
    DCDCconverter_M->Timing.sampleTimes[0] = (0.0);
    DCDCconverter_M->Timing.sampleTimes[1] = (2.0E-5);
    DCDCconverter_M->Timing.sampleTimes[2] = (0.0002);
    DCDCconverter_M->Timing.sampleTimes[3] = (0.05);
    DCDCconverter_M->Timing.sampleTimes[4] = (0.5);

    /* task offsets */
    DCDCconverter_M->Timing.offsetTimes[0] = (0.0);
    DCDCconverter_M->Timing.offsetTimes[1] = (0.0);
    DCDCconverter_M->Timing.offsetTimes[2] = (0.0);
    DCDCconverter_M->Timing.offsetTimes[3] = (0.0);
    DCDCconverter_M->Timing.offsetTimes[4] = (0.0);
  }

  rtmSetTPtr(DCDCconverter_M, &DCDCconverter_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = DCDCconverter_M->Timing.sampleHitArray;
    int_T *mdlPerTaskSampleHits = DCDCconverter_M->Timing.perTaskSampleHitsArray;
    DCDCconverter_M->Timing.perTaskSampleHits = (&mdlPerTaskSampleHits[0]);
    mdlSampleHits[0] = 1;
    DCDCconverter_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(DCDCconverter_M, -1);
  DCDCconverter_M->Timing.stepSize0 = 2.0E-5;
  DCDCconverter_M->Timing.stepSize1 = 2.0E-5;
  DCDCconverter_M->Timing.stepSize2 = 0.0002;
  DCDCconverter_M->Timing.stepSize3 = 0.05;
  DCDCconverter_M->Timing.stepSize4 = 0.5;
  DCDCconverter_M->solverInfoPtr = (&DCDCconverter_M->solverInfo);
  DCDCconverter_M->Timing.stepSize = (2.0E-5);
  rtsiSetFixedStepSize(&DCDCconverter_M->solverInfo, 2.0E-5);
  rtsiSetSolverMode(&DCDCconverter_M->solverInfo, SOLVER_MODE_MULTITASKING);

  /* block I/O */
  DCDCconverter_M->ModelData.blockIO = ((void *) &DCDCconverter_B);
  (void) memset(((void *) &DCDCconverter_B), 0,
                sizeof(BlockIO_DCDCconverter));

  /* parameters */
  DCDCconverter_M->ModelData.defaultParam = ((real_T *)&DCDCconverter_P);

  /* states (dwork) */
  DCDCconverter_M->Work.dwork = ((void *) &DCDCconverter_DWork);
  (void) memset((void *)&DCDCconverter_DWork, 0,
                sizeof(D_Work_DCDCconverter));

  {
    /* user code (registration function declaration) */
    /*Call the macro that initializes the global TRC pointers
       inside the model initialization/registration function. */
    RTI_INIT_TRC_POINTERS();
  }

  /* Initialize Sizes */
  DCDCconverter_M->Sizes.numContStates = (0);/* Number of continuous states */
  DCDCconverter_M->Sizes.numY = (0);   /* Number of model outputs */
  DCDCconverter_M->Sizes.numU = (0);   /* Number of model inputs */
  DCDCconverter_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  DCDCconverter_M->Sizes.numSampTimes = (5);/* Number of sample times */
  DCDCconverter_M->Sizes.numBlocks = (282);/* Number of blocks */
  DCDCconverter_M->Sizes.numBlockIO = (216);/* Number of block outputs */
  DCDCconverter_M->Sizes.numBlockPrms = (821);/* Sum of parameter "widths" */
  return DCDCconverter_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
